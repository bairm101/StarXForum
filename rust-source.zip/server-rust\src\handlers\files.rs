use axum::{
    extract::{State, Extension, Multipart},
    Json,
};
use std::sync::Arc;
use tokio::fs;
use tokio::io::AsyncWriteExt;

use crate::{config::AppState, error::{AppError, Result}, utils::Claims};

fn detect_type(name: &str) -> &'static str {
    let ext = name.rsplit('.').next().unwrap_or("").to_lowercase();
    match ext.as_str() {
        "mp4" | "webm" | "mov" | "m4v" => "video",
        "jpg" | "jpeg" | "png" | "gif" | "webp" => "image",
        _ => "file",
    }
}

const DOCUMENT_EXTS: [&str; 18] = [
    "md", "markdown", "txt", "json", "csv", "pdf", "doc", "docx",
    "xls", "xlsx", "ppt", "pptx", "zip", "rar", "7z", "tar", "gz", "apk",
];

/// Upload limits from site settings (admin-configurable), Java-compatible defaults 5/15 MB.
async fn upload_limits(db: &sqlx::MySqlPool) -> (i64, i64) {
    struct LimitRow { image_max_mb: Option<i32>, video_max_mb: Option<i32> }
    impl<'r> sqlx::FromRow<'r, sqlx::mysql::MySqlRow> for LimitRow {
        fn from_row(row: &'r sqlx::mysql::MySqlRow) -> std::result::Result<Self, sqlx::Error> {
            use sqlx::Row;
            Ok(LimitRow { image_max_mb: row.try_get("image_max_mb").ok(), video_max_mb: row.try_get("video_max_mb").ok() })
        }
    }
    let r = sqlx::query_as::<sqlx::MySql, LimitRow>("SELECT image_max_mb, video_max_mb FROM site_settings WHERE id=1")
        .fetch_optional(db).await.ok().flatten();
    match r {
        Some(r) => (
            r.image_max_mb.filter(|v| *v > 0).map(|v| v as i64).unwrap_or(5),
            r.video_max_mb.filter(|v| *v > 0).map(|v| v as i64).unwrap_or(15),
        ),
        None => (5, 15),
    }
}

async fn store_file(state: &AppState, user_id: i64, field: axum::extract::multipart::Field<'_>, requested_type: Option<String>) -> Result<serde_json::Value> {
    let filename = field.file_name().unwrap_or("file").to_string();
    let content_type = field.content_type().map(|m| m.to_string());
    let data = field.bytes().await.map_err(|e| AppError::BadRequest(format!("read failed: {}", e)))?;
    let original = filename.clone();
    if data.is_empty() { return Err(AppError::BadRequest("empty file".into())); }

    let ext = filename.rsplit('.').next().unwrap_or("").to_lowercase();
    let images = ["jpg", "jpeg", "png", "gif", "webp"];
    let videos = ["mp4", "webm", "mov", "m4v"];
    let t = requested_type.clone().unwrap_or_else(|| detect_type(&filename).to_string());
    let ok = match t.as_str() {
        "video" => videos.contains(&ext.as_str()),
        "file" => DOCUMENT_EXTS.contains(&ext.as_str()),
        "avatar" | "image" | _ => images.contains(&ext.as_str()),
    };
    if !ok { return Err(AppError::BadRequest("unsupported file type".into())); }
    let banned = ["php","phtml","jsp","asp","aspx","cgi","pl","py","sh","bat","cmd","exe","dll","com","msi","js","html","htm"];
    if banned.contains(&ext.as_str()) { return Err(AppError::BadRequest("forbidden type".into())); }

    // size limit from site settings (image/video MB); matches Java behavior
    let (img_mb, video_mb) = upload_limits(&state.db).await;
    let max_mb: i64 = match t.as_str() {
        "video" => video_mb,
        "avatar" => img_mb,
        _ => img_mb,
    };
    if data.len() as i64 > max_mb * 1024 * 1024 {
        return Err(AppError::BadRequest(format!("\u{6587}\u{4ef6}\u{8d85}\u{8fc7} {}MB \u{9650}\u{5236}", max_mb)));
    }

    fs::create_dir_all(&state.config.upload_dir).await?;
    let stored_name = format!("{}.{}", uuid::Uuid::new_v4().simple(), ext);
    let target = format!("{}/{}", state.config.upload_dir.trim_end_matches('/'), stored_name);
    let mut f = fs::File::create(&target).await?;
    f.write_all(&data).await?;

    let path = format!("/uploads/{}", stored_name);
    let public_code: String = uuid::Uuid::new_v4().simple().to_string()[..12].to_string();

    sqlx::query(
        "INSERT INTO upload_records(created_at,updated_at,path,size_bytes,type,user_id,content_type,original_name,public_code) VALUES(NOW(),NOW(),?,?,?,?,?,?,?)"
    )
    .bind(&path).bind(data.len() as i64).bind(&t).bind(user_id)
    .bind(content_type)
    .bind(&original).bind(&public_code)
    .execute(&state.db).await?;

    Ok(serde_json::json!({
        "url": public_code, "type": t, "originalBytes": data.len(),
        "storedBytes": data.len(), "compressed": false,
        "usedBytes": data.len(), "quotaBytes": 0
    }))
}

/// POST /api/files/upload -> returns full URL string
pub async fn upload_simple(
    State(state): State<Arc<AppState>>,
    Extension(claims): Extension<Claims>,
    mut multipart: Multipart,
) -> Result<Json<serde_json::Value>> {
    while let Some(field) = multipart.next_field().await.map_err(|e| AppError::BadRequest(format!("{}", e)))? {
        if field.name() == Some("file") {
            let original = field.file_name().unwrap_or("file").to_string();
            let fname = original.clone();
            let data = field.bytes().await.map_err(|e| AppError::BadRequest(format!("{}", e)))?;
            let ext = fname.rsplit('.').next().unwrap_or("").to_lowercase();
            let allowed = ["jpg","jpeg","png","gif","webp"];
            if !allowed.contains(&ext.as_str()) { return Err(AppError::BadRequest("unsupported type".into())); }
            fs::create_dir_all(&state.config.upload_dir).await?;
            let stored_name = format!("{}.{}", uuid::Uuid::new_v4().simple(), ext);
            let target = format!("{}/{}", state.config.upload_dir.trim_end_matches('/'), stored_name);
            let mut f = fs::File::create(&target).await?;
            f.write_all(&data).await?;
            sqlx::query("INSERT INTO upload_records(created_at,updated_at,path,size_bytes,type,user_id,content_type,original_name,public_code) VALUES(NOW(),NOW(),?,?,'image',?,NULL,?,NULL)")
                .bind(format!("/uploads/{}", stored_name)).bind(data.len() as i64)
                .bind(claims.user_id()).bind(&fname)
                .execute(&state.db).await?;
            return Ok(Json(serde_json::json!({"success":true,"message":"uploaded","data":format!("/uploads/{}", stored_name)})));
        } else { let _ = field; }
    }
    Err(AppError::BadRequest("file missing".into()))
}

/// POST /api/files/media?type=image|video|file
pub async fn upload_media(
    State(state): State<Arc<AppState>>,
    Extension(claims): Extension<Claims>,
    mut multipart: Multipart,
) -> Result<Json<serde_json::Value>> {
    let mut req_type: Option<String> = None;
    let mut result: Option<serde_json::Value> = None;

    while let Some(mut field) = multipart.next_field().await.map_err(|e| AppError::BadRequest(format!("{}", e)))? {
        match field.name() {
            Some("type") => { req_type = Some(field.text().await.unwrap_or_default()); }
            Some("file") => {
                let rt = req_type.clone();
                result = Some(store_file(&state, claims.user_id(), field, rt).await?);
            }
            _ => { let _ = field; }
        }
    }
    match result {
        Some(v) => Ok(Json(serde_json::json!({"success":true,"message":"uploaded","data":v}))),
        None => Err(AppError::BadRequest("file missing".into())),
    }
}

/// POST /api/files/media/chunk?uploadId=&index=&total=
pub async fn upload_chunk(
    State(state): State<Arc<AppState>>,
    Extension(claims): Extension<Claims>,
    axum::extract::Query(q): axum::extract::Query<std::collections::HashMap<String, String>>,
    mut multipart: Multipart,
) -> Result<Json<serde_json::Value>> {
    let upload_id = q.get("uploadId").cloned().unwrap_or_default();
    let index: usize = q.get("index").and_then(|v| v.parse().ok()).ok_or_else(|| AppError::BadRequest("bad index".into()))?;
    let total: usize = q.get("total").and_then(|v| v.parse().ok()).ok_or_else(|| AppError::BadRequest("bad total".into()))?;
    if upload_id.len() < 8 || total < 1 || index >= total || total > 5000 {
        return Err(AppError::BadRequest("invalid chunk params".into()));
    }
    let dir = format!("{}/chunks/{}/{}", state.config.upload_dir.trim_end_matches('/'), claims.user_id(), upload_id);
    fs::create_dir_all(&dir).await?;
    while let Some(field) = multipart.next_field().await.map_err(|e| AppError::BadRequest(format!("{}", e)))? {
        if field.name() == Some("file") {
            let data = field.bytes().await.map_err(|e| AppError::BadRequest(format!("{}", e)))?;
            let part = format!("{}/{:06}.part", dir, index);
            let mut f = fs::File::create(&part).await?;
            f.write_all(&data).await?;
            return Ok(Json(serde_json::json!({"success":true,"message":"chunk received","data":{"index":index,"received":data.len()}})));
        } else { let _ = field; }
    }
    Err(AppError::BadRequest("file missing".into()))
}

/// POST /api/files/media/chunk/complete?uploadId=&total=&filename=&type=
pub async fn chunk_complete(
    State(state): State<Arc<AppState>>,
    Extension(claims): Extension<Claims>,
    axum::extract::Query(q): axum::extract::Query<std::collections::HashMap<String, String>>,
) -> Result<Json<serde_json::Value>> {
    let upload_id = q.get("uploadId").cloned().unwrap_or_default();
    let total: usize = q.get("total").and_then(|v| v.parse().ok()).ok_or_else(|| AppError::BadRequest("bad total".into()))?;
    let filename = q.get("filename").cloned().unwrap_or_else(|| "file".into());
    let rtype = q.get("type").cloned().unwrap_or_else(|| "image".into());

    if upload_id.len() < 8 || total < 1 || total > 5000 { return Err(AppError::BadRequest("invalid params".into())); }

    // extension must match the declared type (same whitelist as direct upload)
    let ext = filename.rsplit('.').next().unwrap_or("").to_lowercase();
    let images = ["jpg", "jpeg", "png", "gif", "webp"];
    let videos = ["mp4", "webm", "mov", "m4v"];
    let ok = match rtype.as_str() {
        "video" => videos.contains(&ext.as_str()),
        "file" => DOCUMENT_EXTS.contains(&ext.as_str()),
        _ => images.contains(&ext.as_str()),
    };
    if !ok { return Err(AppError::BadRequest("\u{4e0d}\u{652f}\u{6301}\u{7684}\u{6587}\u{4ef6}\u{7c7b}\u{578b}".into())); }
    let banned = ["php","phtml","jsp","asp","aspx","cgi","pl","py","sh","bat","cmd","exe","dll","com","msi","js","html","htm"];
    if banned.contains(&ext.as_str()) { return Err(AppError::BadRequest("forbidden type".into())); }

    let dir = format!("{}/chunks/{}/{}", state.config.upload_dir.trim_end_matches('/'), claims.user_id(), upload_id);

    // verify all parts exist and merge into uploads dir
    let stored_name = format!("{}.{}", uuid::Uuid::new_v4().simple(), ext);
    let final_path = format!("{}/{}", state.config.upload_dir.trim_end_matches('/'), stored_name);
    let mut merged = tokio::io::BufWriter::new(fs::File::create(&final_path).await?);
    for i in 0..total {
        let part = format!("{}/{}.part", dir, format_args!("{:06}", i));
        let data = fs::read(&part).await.map_err(|_| AppError::BadRequest(format!("missing chunk {}", i)))?;
        use tokio::io::AsyncWriteExt;
        merged.write_all(&data).await?;
    }
    merged.flush().await?;
    let size = fs::metadata(&final_path).await?.len();

    // size limit check (site settings) — same as direct upload
    let dtype = match rtype.as_str() { "video" => "video", "file" => "file", _ => "image" };
    let (img_mb, video_mb) = upload_limits(&state.db).await;
    let max_mb: i64 = if dtype == "video" { video_mb } else { img_mb };
    if size > (max_mb * 1024 * 1024) as u64 {
        let _ = fs::remove_file(&final_path).await;
        let _ = fs::remove_dir_all(&dir).await;
        return Err(AppError::BadRequest(format!("\u{6587}\u{4ef6}\u{8d85}\u{8fc7} {}MB \u{9650}\u{5236}", max_mb)));
    }

    let public_code: String = uuid::Uuid::new_v4().simple().to_string()[..12].to_string();
    let path = format!("/uploads/{}", stored_name);
    sqlx::query(
        "INSERT INTO upload_records(created_at,updated_at,path,size_bytes,type,user_id,content_type,original_name,public_code) VALUES(NOW(),NOW(),?,?,?,?,?,?,?)"
    ).bind(&path).bind(size as i64).bind(dtype).bind(claims.user_id())
     .bind::<Option<String>>(None).bind(&filename).bind(&public_code)
     .execute(&state.db).await?;

    // cleanup chunks dir best-effort
    let _ = fs::remove_dir_all(&dir).await;

    Ok(Json(serde_json::json!({"success":true,"message":"uploaded","data":{
        "url": public_code, "type": dtype, "originalBytes": size, "storedBytes": size,
        "compressed": false, "usedBytes": size, "quotaBytes": 0
    }})))
}
