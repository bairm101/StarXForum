use uuid::Uuid;

/// 鐢熸垚甯栧瓙鍞竴ID (PUID)
/// 鏍煎紡: P + 10浣嶅瓧绗?(澶у啓瀛楁瘝鍜屾暟瀛?
pub fn generate_puid() -> String {
    let uuid = Uuid::new_v4();
    let hex = uuid.simple().to_string();
    
    // 取前 10 个字符并转为大写。
    let puid = format!("P{}", &hex[..10].to_uppercase());
    puid
}

/// 楠岃瘉PUID鏍煎紡
pub fn is_valid_puid(puid: &str) -> bool {
    if puid.len() != 11 {
        return false;
    }
    
    if !puid.starts_with('P') {
        return false;
    }
    
    puid[1..].chars().all(|c| c.is_ascii_alphanumeric())
}
