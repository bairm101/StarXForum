use axum::{
    extract::{State, Path, Query},
    Json,
};
use serde::{Deserialize, Serialize};
use std::sync::Arc;

use crate::{
    config::AppState,
    error::{AppError, Result},
    models::{Board, Post},
};

#[derive(Debug, Deserialize)]
pub struct BoardPostsQuery {
    pub sort: Option<String>,
    pub page: Option<i64>,
    pub page_size: Option<i64>,
}

/// 获取板块列表
pub async fn list_boards(
    State(state): State<Arc<AppState>>,
) -> Result<Json<serde_json::Value>> {
    let boards = sqlx::query_as::<sqlx::MySql, Board>(
        "SELECT * FROM boards WHERE visible = TRUE ORDER BY sort_order ASC, id ASC"
    )
    .fetch_all(&state.db)
    .await?;
    
    Ok(Json(serde_json::json!({ "success": true, "message": null, "data": boards })))
}

/// 获取板块详情
pub async fn get_board(
    State(state): State<Arc<AppState>>,
    Path(id): Path<i64>,
) -> Result<Json<serde_json::Value>> {
    let board = sqlx::query_as::<sqlx::MySql, Board>(
        "SELECT * FROM boards WHERE id = ? AND visible = TRUE"
    )
    .bind(id)
    .fetch_optional(&state.db)
    .await?
    .ok_or_else(|| AppError::NotFound("板块不存在".to_string()))?;
    
    Ok(Json(serde_json::json!({ "success": true, "message": null, "data": board })))
}

/// 获取板块的帖子列表
pub async fn get_board_posts(
    State(state): State<Arc<AppState>>,
    Path(id): Path<i64>,
    Query(query): Query<BoardPostsQuery>,
) -> Result<Json<serde_json::Value>> {
    let page = query.page.unwrap_or(0).max(0);
    let page_size = query.page_size.unwrap_or(20).min(100);
    let offset = page * page_size;
    
    let sort = query.sort.as_deref().unwrap_or("latest");
    
    let order_by = match sort {
        "hot" => "(p.like_count * 2 + p.comment_count * 3 + p.view_count * 0.1) DESC, p.created_at DESC",
        "latest" => "p.created_at DESC",
        _ => "p.created_at DESC",
    };
    
    let sql = format!(
        "SELECT p.* FROM posts p 
         WHERE p.board_id = ? AND p.deleted = FALSE AND p.status = 'APPROVED' 
         ORDER BY {} 
         LIMIT ? OFFSET ?",
        order_by
    );
    
    let posts = sqlx::query_as::<sqlx::MySql, Post>(&sql)
        .bind(id)
        .bind(page_size)
        .bind(offset)
        .fetch_all(&state.db)
        .await?;
    
    let total: (i64,) = sqlx::query_as(
        "SELECT COUNT(*) FROM posts WHERE board_id = ? AND deleted = FALSE AND status = 'APPROVED'"
    )
    .bind(id)
    .fetch_one(&state.db)
    .await?;
    
    let total_pages = if page_size > 0 { (total.0 + page_size - 1) / page_size } else { 0 };
    Ok(Json(serde_json::json!({
        "success": true, "message": null,
        "data": { "items": posts, "page": page, "size": page_size,
                   "totalItems": total.0, "totalPages": total_pages,
                   "hasNext": page + 1 < total_pages }
    })))
}
