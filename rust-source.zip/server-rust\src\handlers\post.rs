use axum::{extract::{Extension, Path, Query, State}, Json};
use serde::Deserialize;
use std::sync::Arc;
use validator::Validate;

use crate::{config::AppState, error::{AppError, Result}, models::{Board, Post, User}, utils::{self, Claims}};

#[derive(Debug, Deserialize)]
pub struct ListPostsQuery {
    #[serde(rename = "boardId")]
    pub board_id: Option<i64>,
    pub sort: Option<String>,
    pub page: Option<i64>,
    #[serde(rename = "size")]
    pub size: Option<i64>,
}

#[derive(Debug, Deserialize, Validate)]
pub struct CreatePostRequest {
    #[validate(length(min = 2, max = 200))]
    pub title: String,
    #[validate(length(min = 1, max = 100000))]
    pub content: String,
    #[serde(rename = "boardId")]
    pub board_id: i64,
    #[serde(rename = "gateType")]
    pub gate_type: Option<String>,
    #[serde(rename = "gatedContent")]
    pub gated_content: Option<String>,
    #[serde(rename = "gatePrice")]
    pub gate_price: Option<i64>,
    pub topics: Option<String>,
}

#[derive(Debug, Deserialize, Validate)]
pub struct UpdatePostRequest {
    #[validate(length(min = 2, max = 200))]
    pub title: Option<String>,
    #[validate(length(min = 1, max = 100000))]
    pub content: Option<String>,
    #[serde(rename = "boardId")]
    pub board_id: Option<i64>,
    pub topics: Option<String>,
}

#[derive(Debug, Deserialize)]
pub struct GetPostQuery {
    pub moderation: Option<bool>,
}

/// Parse optional viewer from Authorization header (public routes have no auth middleware).
pub fn optional_viewer(headers: &axum::http::HeaderMap, secret: &str) -> Option<Claims> {
    let token = headers
        .get(axum::http::header::AUTHORIZATION)
        .and_then(|v| v.to_str().ok())
        .and_then(|v| v.strip_prefix("Bearer "))?;
    crate::utils::jwt::verify_token(token, secret).ok()
}

/// Java User.canManageBoard: OWNER/SUPER_ADMIN manage all boards; ADMIN manages own board only.
pub async fn viewer_can_manage_board(state: &AppState, claims: &Claims, board_id: i64) -> Result<bool> {
    match claims.role.as_str() {
        "OWNER" | "SUPER_ADMIN" => Ok(true),
        "ADMIN" => {
            struct M { managed_board_id: Option<i64> }
            impl<'r> sqlx::FromRow<'r, sqlx::mysql::MySqlRow> for M {
                fn from_row(row: &'r sqlx::mysql::MySqlRow) -> std::result::Result<Self, sqlx::Error> {
                    use sqlx::Row;
                    Ok(M { managed_board_id: row.try_get("managed_board_id").ok() })
                }
            }
            let m = sqlx::query_as::<sqlx::MySql, M>("SELECT managed_board_id FROM users WHERE id=?")
                .bind(claims.user_id()).fetch_optional(&state.db).await?;
            Ok(m.and_then(|m| m.managed_board_id).map(|b| b == board_id).unwrap_or(false))
        }
        _ => Ok(false),
    }
}

/// Java PostService.canModify: author or board moderator.
async fn can_modify_post(state: &AppState, claims: &Claims, post: &Post) -> Result<bool> {
    if post.author_id == claims.user_id() {
        return Ok(true);
    }
    viewer_can_manage_board(state, claims, post.board_id).await
}

/// Java PostService.maskHiddenContent parity:
/// inline `![隐藏内容_<condition>](<content>)` blocks are shown only when the viewer
/// satisfies the condition; otherwise replaced with a locked placeholder quote.
async fn mask_hidden_content(
    state: &AppState,
    content: &str,
    post_id: i64,
    viewer: Option<&Claims>,
    moderation: bool,
) -> Result<String> {
    let pattern = regex::Regex::new(r"(?s)!\[隐藏内容_([^\]]+)\]\((.*?)\)").unwrap();
    if !pattern.is_match(content) {
        return Ok(content.to_string());
    }
    let staff = viewer.map(|v| matches!(v.role.as_str(), "OWNER" | "SUPER_ADMIN" | "ADMIN")).unwrap_or(false);
    let viewer_id = viewer.map(|v| v.user_id());
    let mut commented = false;
    if let Some(uid) = viewer_id {
        let c: (i64,) = sqlx::query_as(
            "SELECT COUNT(*) FROM comments WHERE post_id=? AND author_id=? AND deleted=FALSE")
            .bind(post_id).bind(uid).fetch_one(&state.db).await?;
        commented = c.0 > 0;
    }
    let mut out = String::with_capacity(content.len());
    let mut last = 0usize;
    for m in pattern.find_iter(content) {
        out.push_str(&content[last..m.start()]);
        let caps = pattern.captures(m.as_str()).unwrap();
        let condition = caps.get(1).map(|g| g.as_str().trim()).unwrap_or("").to_string();
        let inner = caps.get(2).map(|g| g.as_str()).unwrap_or("");
        let mut allowed = staff || (moderation && viewer_id.is_some());
        if !allowed {
            if condition.contains("免费") || condition.eq_ignore_ascii_case("free") {
                allowed = true;
            }
            if viewer_id.is_some() && condition.contains("登录") {
                allowed = true;
            }
            if viewer_id.is_some() && condition.contains("回复") && commented {
                allowed = true;
            }
            if viewer_id.is_some() && condition.contains("站长") && staff {
                allowed = true;
            }
        }
        if allowed {
            out.push_str("\n\n");
            out.push_str(inner);
            out.push_str("\n\n");
        } else {
            out.push_str(&format!(
                "\n\n> \u{1f512} \u{9690}\u{85cf}\u{5185}\u{5bb9}\n> \u{6761}\u{4ef6}\u{ff1a}{}\n> \u{5185}\u{5bb9}\u{5df2}\u{88ab}\u{9690}\u{85cf}\u{ff0c}\u{6ee1}\u{8db3}\u{6761}\u{4ef6}\u{540e}\u{53ef}\u{67e5}\u{770b}\u{3002}\n\n",
                condition
            ));
        }
        last = m.end();
    }
    out.push_str(&content[last..]);
    Ok(out)
}

fn page_data(items: serde_json::Value, page: i64, size: i64, total: i64) -> serde_json::Value {
    let pages = if size > 0 { (total + size - 1) / size } else { 0 };
    serde_json::json!({
        "items": items, "page": page, "size": size,
        "totalItems": total, "totalPages": pages, "hasNext": page + 1 < pages
    })
}

/// Java ForumDtos.PostSummary.extractVideoUrl parity: first `[视频](url)` in content.
pub fn extract_video_url(content: &str) -> Option<String> {
    let re = regex::Regex::new(r"\[\u{89c6}\u{9891}\]\(([^)]+)\)").unwrap();
    re.captures(content).map(|c| c.get(1).unwrap().as_str().to_string())
}

pub async fn summary(state: &AppState, post: Post) -> Result<serde_json::Value> {
    let author = sqlx::query_as::<sqlx::MySql, User>("SELECT * FROM users WHERE id = ?")
        .bind(post.author_id).fetch_one(&state.db).await?;
    let board = sqlx::query_as::<sqlx::MySql, Board>("SELECT * FROM boards WHERE id = ?")
        .bind(post.board_id).fetch_one(&state.db).await?;
    let plain = post.content.split_whitespace().collect::<Vec<_>>().join(" ");
    let excerpt = if plain.chars().count() > 120 {
        let s: String = plain.chars().take(120).collect();
        format!("{}...", s)
    } else {
        plain
    };
    let video_url = extract_video_url(&post.content);
    Ok(serde_json::json!({
        "id": post.id, "title": post.title, "excerpt": excerpt,
        "boardId": post.board_id, "boardName": board.name,
        "author": crate::handlers::user::author_brief_anon(&author),
        "viewCount": post.view_count, "commentCount": post.comment_count,
        "likeCount": post.like_count, "dislikeCount": post.dislike_count,
        "pinned": post.pinned, "boardPinned": post.board_pinned, "locked": post.locked,
        "likedByMe": false, "totalTipGold": post.total_tip_gold, "tipCount": post.tip_count,
        "status": post.status, "thumbnailUrl": post.thumbnail_url, "videoUrl": video_url,
        "gateType": post.gate_type, "topics": post.topics, "puid": post.puid,
        "createdAt": post.created_at, "lastActivityAt": post.last_activity_at
    }))
}

pub async fn list_posts(State(state): State<Arc<AppState>>, Query(q): Query<ListPostsQuery>) -> Result<Json<serde_json::Value>> {
    let page = q.page.unwrap_or(0).max(0);
    let size = q.size.unwrap_or(20).clamp(1, 100);
    let offset = page * size;
    let mut sql = "SELECT * FROM posts WHERE deleted = FALSE AND status = 'APPROVED'".to_string();
    if q.board_id.is_some() { sql.push_str(" AND board_id = ?"); }
    match q.sort.as_deref() { Some("hot") => sql.push_str(" ORDER BY like_count DESC, created_at DESC"), _ => sql.push_str(" ORDER BY last_activity_at DESC") }
    sql.push_str(" LIMIT ? OFFSET ?");
    let mut query = sqlx::query_as::<sqlx::MySql, Post>(&sql);
    if let Some(board) = q.board_id { query = query.bind(board); }
    let posts = query.bind(size).bind(offset).fetch_all(&state.db).await?;
    let total: (i64,) = if let Some(board) = q.board_id {
        sqlx::query_as("SELECT COUNT(*) FROM posts WHERE deleted = FALSE AND status = 'APPROVED' AND board_id = ?").bind(board).fetch_one(&state.db).await?
    } else { sqlx::query_as("SELECT COUNT(*) FROM posts WHERE deleted = FALSE AND status = 'APPROVED'").fetch_one(&state.db).await? };
    let mut items = Vec::new();
    for post in posts { items.push(summary(&state, post).await?); }
    Ok(Json(serde_json::json!({"success": true, "message": null, "data": page_data(serde_json::Value::Array(items), page, size, total.0)})))
}

pub async fn create_post(State(state): State<Arc<AppState>>, Extension(claims): Extension<Claims>, Json(req): Json<CreatePostRequest>) -> Result<Json<serde_json::Value>> {
    req.validate().map_err(|e| AppError::Validation(e.to_string()))?;
    let puid = utils::puid::generate_puid();
    let result = sqlx::query("INSERT INTO posts (created_at, updated_at, comment_count, content, deleted, last_activity_at, like_count, dislike_count, title, view_count, author_id, board_id, tip_count, total_tip_gold, pinned, board_pinned, locked, status, gate_price, gate_type, gated_content, topics, puid) VALUES (NOW(), NOW(), 0, ?, FALSE, NOW(), 0, 0, ?, 0, ?, ?, 0, 0, FALSE, FALSE, FALSE, 'APPROVED', ?, ?, ?, ?, ?)")
        .bind(&req.content).bind(&req.title).bind(claims.user_id()).bind(req.board_id).bind(req.gate_price.unwrap_or(0))
        .bind(req.gate_type.unwrap_or_else(|| "NONE".to_string())).bind(req.gated_content).bind(req.topics).bind(&puid)
        .execute(&state.db).await?;
    Ok(Json(serde_json::json!({"success": true, "message": "发布成功", "data": {"id": result.last_insert_id(), "puid": puid}})))
}

pub async fn get_post(State(state): State<Arc<AppState>>, headers: axum::http::HeaderMap, Path(id): Path<String>, Query(q): Query<GetPostQuery>) -> Result<Json<serde_json::Value>> {
    let post = if id.starts_with('P') { sqlx::query_as::<sqlx::MySql, Post>("SELECT * FROM posts WHERE puid = ? AND deleted = FALSE").bind(id).fetch_optional(&state.db).await? } else { sqlx::query_as::<sqlx::MySql, Post>("SELECT * FROM posts WHERE id = ? AND deleted = FALSE").bind(id.parse::<i64>().map_err(|_| AppError::BadRequest("invalid id".into()))?).fetch_optional(&state.db).await? };
    let post = post.ok_or_else(|| AppError::NotFound("\u{5e16}\u{5b50}\u{4e0d}\u{5b58}\u{5728}\u{6216}\u{5df2}\u{5220}\u{9664}".into()))?;
    sqlx::query("UPDATE posts SET view_count = view_count + 1 WHERE id = ?").bind(post.id).execute(&state.db).await?;
    let author = sqlx::query_as::<sqlx::MySql, User>("SELECT * FROM users WHERE id = ?").bind(post.author_id).fetch_one(&state.db).await?;
    let board = sqlx::query_as::<sqlx::MySql, Board>("SELECT * FROM boards WHERE id = ?").bind(post.board_id).fetch_one(&state.db).await?;

    // viewer-aware fields (Java parity: canEdit/likedByMe/dislikedByMe/myTipTimes/gateUnlocked)
    let viewer = optional_viewer(&headers, &state.config.jwt_secret);
    let (mut can_edit, mut liked, mut disliked, mut my_tips) = (false, false, false, 0i64);
    if let Some(v) = &viewer {
        can_edit = can_modify_post(&state, v, &post).await?;
        let l: Option<(i64,)> = sqlx::query_as("SELECT id FROM likes WHERE user_id=? AND target_type='POST' AND target_id=?")
            .bind(v.user_id()).bind(post.id).fetch_optional(&state.db).await?;
        let d: Option<(i64,)> = sqlx::query_as("SELECT id FROM dislikes WHERE user_id=? AND target_type='POST' AND target_id=?")
            .bind(v.user_id()).bind(post.id).fetch_optional(&state.db).await?;
        let t: (i64,) = sqlx::query_as("SELECT COUNT(*) FROM tips WHERE user_id=? AND post_id=?")
            .bind(v.user_id()).bind(post.id).fetch_one(&state.db).await?;
        liked = l.is_some();
        disliked = d.is_some();
        my_tips = t.0;
    }

    // gate visibility (Java PostGateService.canView parity):
    // NONE/other → open; REPLY → author/unlock record/has commented; PAID → author/unlock record
    let mut unlocked = post.gate_type != "REPLY" && post.gate_type != "PAID";
    if !unlocked {
        if let Some(v) = &viewer {
            let mine = v.user_id() == post.author_id;
            let unlock_rec: Option<(i64,)> = sqlx::query_as("SELECT id FROM post_unlocks WHERE post_id=? AND user_id=?")
                .bind(post.id).bind(v.user_id()).fetch_optional(&state.db).await?;
            let has_commented = if post.gate_type == "REPLY" {
                let c: (i64,) = sqlx::query_as(
                    "SELECT COUNT(*) FROM comments WHERE post_id=? AND author_id=? AND deleted=FALSE")
                    .bind(post.id).bind(v.user_id()).fetch_one(&state.db).await?;
                c.0 > 0
            } else {
                false
            };
            unlocked = mine || unlock_rec.is_some() || has_commented;
        }
    }
    // moderator preview via ?moderation=true bypasses the gate (Java effectiveModeration)
    let moderation_view = q.moderation.unwrap_or(false)
        && match &viewer {
            Some(v) => viewer_can_manage_board(&state, v, post.board_id).await?,
            None => false,
        };
    if moderation_view {
        unlocked = true;
    }

    // inline hidden-content masking (Java maskHiddenContent parity)
    let display_content = mask_hidden_content(&state, &post.content, post.id, viewer.as_ref(), moderation_view).await?;

    Ok(Json(serde_json::json!({"success": true, "message": null, "data": {"id": post.id, "title": post.title, "content": display_content, "boardId": post.board_id, "boardName": board.name, "author": crate::handlers::user::author_brief_anon(&author), "viewCount": post.view_count + 1, "commentCount": post.comment_count, "likeCount": post.like_count, "dislikeCount": post.dislike_count, "pinned": post.pinned, "boardPinned": post.board_pinned, "locked": post.locked, "likedByMe": liked, "dislikedByMe": disliked, "canEdit": can_edit, "totalTipGold": post.total_tip_gold, "tipCount": post.tip_count, "myTipTimes": my_tips, "status": post.status, "thumbnailUrl": post.thumbnail_url, "topics": post.topics, "puid": post.puid, "gateType": post.gate_type, "gateUnlocked": unlocked, "gatePrice": post.gate_price, "gatedContent": if unlocked { post.gated_content.clone() } else { None }, "createdAt": post.created_at, "updatedAt": post.updated_at, "lastActivityAt": post.last_activity_at}})))
}

pub async fn update_post(State(state): State<Arc<AppState>>, Extension(claims): Extension<Claims>, Path(id): Path<i64>, Json(req): Json<UpdatePostRequest>) -> Result<Json<serde_json::Value>> {
    req.validate().map_err(|e| AppError::Validation(e.to_string()))?;
    let post = sqlx::query_as::<sqlx::MySql, Post>("SELECT * FROM posts WHERE id = ? AND deleted = FALSE")
        .bind(id).fetch_optional(&state.db).await?
        .ok_or_else(|| AppError::NotFound("\u{5e16}\u{5b50}\u{4e0d}\u{5b58}\u{5728}\u{6216}\u{5df2}\u{5220}\u{9664}".into()))?;
    if !can_modify_post(&state, &claims, &post).await? {
        return Err(AppError::Forbidden("\u{53ea}\u{80fd}\u{7f16}\u{8f91}\u{81ea}\u{5df1}\u{7684}\u{5e16}\u{5b50}".into()));
    }
    let moderator = viewer_can_manage_board(&state, &claims, post.board_id).await?;
    if post.locked && !moderator {
        return Err(AppError::Forbidden("\u{5e16}\u{5b50}\u{5df2}\u{88ab}\u{9501}\u{5b9a}\u{ff0c}\u{65e0}\u{6cd5}\u{7f16}\u{8f91}".into()));
    }

    // keep a revision of the old version (edit history)
    sqlx::query("INSERT INTO post_revisions(created_at,updated_at,content,editor_id,post_id,title) VALUES(NOW(),NOW(),?,?,?,?)")
        .bind(&post.content).bind(claims.user_id()).bind(post.id).bind(&post.title)
        .execute(&state.db).await?;

    if let Some(title) = req.title {
        sqlx::query("UPDATE posts SET title = ?, updated_at = NOW() WHERE id = ?").bind(title).bind(id).execute(&state.db).await?;
    }
    if let Some(content) = req.content {
        sqlx::query("UPDATE posts SET content = ?, updated_at = NOW() WHERE id = ?").bind(content).bind(id).execute(&state.db).await?;
    }
    if let Some(topics) = req.topics {
        sqlx::query("UPDATE posts SET topics = ?, updated_at = NOW() WHERE id = ?").bind(topics).bind(id).execute(&state.db).await?;
    }
    if let Some(new_board) = req.board_id {
        if new_board != post.board_id {
            let exists: Option<(i64,)> = sqlx::query_as("SELECT id FROM boards WHERE id=?").bind(new_board).fetch_optional(&state.db).await?;
            if exists.is_none() { return Err(AppError::BadRequest("\u{677f}\u{5757}\u{4e0d}\u{5b58}\u{5728}".into())); }
            sqlx::query("UPDATE posts SET board_id = ?, updated_at = NOW() WHERE id = ?").bind(new_board).bind(id).execute(&state.db).await?;
            sqlx::query("UPDATE boards SET post_count = GREATEST(post_count - 1, 0) WHERE id = ?").bind(post.board_id).execute(&state.db).await?;
            sqlx::query("UPDATE boards SET post_count = post_count + 1 WHERE id = ?").bind(new_board).execute(&state.db).await?;
        }
    }

    // re-audit after edit (site setting + board requires moderation; moderators bypass)
    struct S { post_edit_audit_enabled: bool }
    impl<'r> sqlx::FromRow<'r, sqlx::mysql::MySqlRow> for S {
        fn from_row(row: &'r sqlx::mysql::MySqlRow) -> std::result::Result<Self, sqlx::Error> {
            use sqlx::Row;
            Ok(S { post_edit_audit_enabled: row.try_get::<bool, _>("post_edit_audit_enabled").unwrap_or(false) })
        }
    }
    let s = sqlx::query_as::<sqlx::MySql, S>("SELECT post_edit_audit_enabled FROM site_settings WHERE id=1")
        .fetch_optional(&state.db).await?;
    let audit_enabled = s.map(|s| s.post_edit_audit_enabled).unwrap_or(false);
    if audit_enabled && !moderator && post.status == "APPROVED" {
        struct B { require_moderation: bool }
        impl<'r> sqlx::FromRow<'r, sqlx::mysql::MySqlRow> for B {
            fn from_row(row: &'r sqlx::mysql::MySqlRow) -> std::result::Result<Self, sqlx::Error> {
                use sqlx::Row;
                Ok(B { require_moderation: row.try_get::<bool, _>("require_moderation").unwrap_or(false) })
            }
        }
        let b = sqlx::query_as::<sqlx::MySql, B>("SELECT require_moderation FROM boards WHERE id=?")
            .bind(post.board_id).fetch_optional(&state.db).await?;
        if b.map(|b| b.require_moderation).unwrap_or(false) {
            sqlx::query("UPDATE posts SET status='PENDING', updated_at=NOW() WHERE id=?").bind(id).execute(&state.db).await?;
            sqlx::query("UPDATE boards SET post_count = GREATEST(post_count - 1, 0) WHERE id = ?").bind(post.board_id).execute(&state.db).await?;
            sqlx::query("UPDATE users SET post_count = GREATEST(post_count - 1, 0) WHERE id = ?").bind(post.author_id).execute(&state.db).await?;
        }
    }
    Ok(Json(serde_json::json!({"success": true, "message": "\u{7f16}\u{8f91}\u{6210}\u{529f}", "data": null})))
}

pub async fn delete_post(State(state): State<Arc<AppState>>, Extension(claims): Extension<Claims>, Path(id): Path<i64>) -> Result<Json<serde_json::Value>> {
    let post = sqlx::query_as::<sqlx::MySql, Post>("SELECT * FROM posts WHERE id = ? AND deleted = FALSE")
        .bind(id).fetch_optional(&state.db).await?
        .ok_or_else(|| AppError::NotFound("\u{5e16}\u{5b50}\u{4e0d}\u{5b58}\u{5728}\u{6216}\u{5df2}\u{5220}\u{9664}".into()))?;
    if !can_modify_post(&state, &claims, &post).await? {
        return Err(AppError::Forbidden("\u{53ea}\u{80fd}\u{5220}\u{9664}\u{81ea}\u{5df1}\u{7684}\u{5e16}\u{5b50}".into()));
    }
    sqlx::query("DELETE FROM likes WHERE target_type = 'POST' AND target_id = ?").bind(id).execute(&state.db).await?;
    sqlx::query("DELETE FROM dislikes WHERE target_type = 'POST' AND target_id = ?").bind(id).execute(&state.db).await?;
    sqlx::query("DELETE FROM favorites WHERE post_id = ?").bind(id).execute(&state.db).await?;
    sqlx::query("DELETE FROM tips WHERE post_id = ?").bind(id).execute(&state.db).await?;
    sqlx::query("DELETE FROM post_unlocks WHERE post_id = ?").bind(id).execute(&state.db).await?;
    sqlx::query("DELETE FROM post_revisions WHERE post_id = ?").bind(id).execute(&state.db).await?;
    sqlx::query("DELETE FROM poll_votes WHERE poll_id IN (SELECT id FROM polls WHERE post_id = ?)").bind(id).execute(&state.db).await?;
    sqlx::query("DELETE FROM poll_options WHERE poll_id IN (SELECT id FROM polls WHERE post_id = ?)").bind(id).execute(&state.db).await?;
    sqlx::query("DELETE FROM polls WHERE post_id = ?").bind(id).execute(&state.db).await?;
    sqlx::query("UPDATE comments SET parent_id = NULL WHERE post_id = ?").bind(id).execute(&state.db).await?;
    sqlx::query("DELETE FROM comments WHERE post_id = ?").bind(id).execute(&state.db).await?;
    sqlx::query("DELETE FROM posts WHERE id = ?").bind(id).execute(&state.db).await?;
    if post.status == "APPROVED" {
        sqlx::query("UPDATE boards SET post_count = GREATEST(post_count - 1, 0) WHERE id = ?").bind(post.board_id).execute(&state.db).await?;
        sqlx::query("UPDATE users SET post_count = GREATEST(post_count - 1, 0) WHERE id = ?").bind(post.author_id).execute(&state.db).await?;
    }
    Ok(Json(serde_json::json!({"success": true, "message": "\u{5220}\u{9664}\u{6210}\u{529f}", "data": null})))
}

/// PATCH /api/admin/posts/:id/pin?pinned=true|false (Java PostService.setPinned)
pub async fn set_pinned(
    State(state): State<Arc<AppState>>,
    Extension(claims): Extension<Claims>,
    Path(id): Path<i64>,
    Query(q): Query<std::collections::HashMap<String, String>>,
) -> Result<Json<serde_json::Value>> {
    let pinned = q.get("pinned").map(|v| v == "true" || v == "1").unwrap_or(false);
    let post = sqlx::query_as::<sqlx::MySql, Post>("SELECT * FROM posts WHERE id=? AND deleted=FALSE")
        .bind(id).fetch_optional(&state.db).await?
        .ok_or_else(|| AppError::NotFound("\u{5e16}\u{5b50}\u{4e0d}\u{5b58}\u{5728}\u{6216}\u{5df2}\u{5220}\u{9664}".into()))?;
    if !viewer_can_manage_board(&state, &claims, post.board_id).await? {
        return Err(AppError::Forbidden("\u{65e0}\u{6743}\u{64cd}\u{4f5c}\u{8be5}\u{7248}\u{5e16}\u{5b50}".into()));
    }
    sqlx::query("UPDATE posts SET pinned=?, updated_at=NOW() WHERE id=?").bind(pinned).bind(id).execute(&state.db).await?;
    Ok(Json(serde_json::json!({"success": true, "message": if pinned { "\u{5df2}\u{7f6e}\u{9876}" } else { "\u{5df2}\u{53d6}\u{6d88}\u{7f6e}\u{9876}" }, "data": null})))
}

/// PATCH /api/admin/posts/:id/lock?locked=true|false (Java PostService.setLocked)
pub async fn set_locked(
    State(state): State<Arc<AppState>>,
    Extension(claims): Extension<Claims>,
    Path(id): Path<i64>,
    Query(q): Query<std::collections::HashMap<String, String>>,
) -> Result<Json<serde_json::Value>> {
    let locked = q.get("locked").map(|v| v == "true" || v == "1").unwrap_or(false);
    let post = sqlx::query_as::<sqlx::MySql, Post>("SELECT * FROM posts WHERE id=? AND deleted=FALSE")
        .bind(id).fetch_optional(&state.db).await?
        .ok_or_else(|| AppError::NotFound("\u{5e16}\u{5b50}\u{4e0d}\u{5b58}\u{5728}\u{6216}\u{5df2}\u{5220}\u{9664}".into()))?;
    if !viewer_can_manage_board(&state, &claims, post.board_id).await? {
        return Err(AppError::Forbidden("\u{65e0}\u{6743}\u{64cd}\u{4f5c}\u{8be5}\u{7248}\u{5e16}\u{5b50}".into()));
    }
    sqlx::query("UPDATE posts SET locked=?, updated_at=NOW() WHERE id=?").bind(locked).bind(id).execute(&state.db).await?;
    Ok(Json(serde_json::json!({"success": true, "message": if locked { "\u{5df2}\u{9501}\u{5b9a}" } else { "\u{5df2}\u{89e3}\u{9501}" }, "data": null})))
}

pub async fn like_post(State(state): State<Arc<AppState>>, Extension(claims): Extension<Claims>, Path(id): Path<i64>) -> Result<Json<serde_json::Value>> { toggle_like(State(state), Extension(claims), Path(id)).await }

pub async fn unlike_post(State(state): State<Arc<AppState>>, Extension(claims): Extension<Claims>, Path(id): Path<i64>) -> Result<Json<serde_json::Value>> {
    let res = sqlx::query("DELETE FROM likes WHERE user_id=? AND target_type='POST' AND target_id=?")
        .bind(claims.user_id()).bind(id).execute(&state.db).await?;
    if res.rows_affected() > 0 {
        sqlx::query("UPDATE posts SET like_count=GREATEST(like_count-1,0) WHERE id=?")
            .bind(id).execute(&state.db).await?;
    }
    Ok(Json(serde_json::json!({"success":true,"message":null,"data":null})))
}


// ---------- Java-compatible additions ----------

use axum::http::StatusCode;

/// POST /api/posts/{id}/like  (Java: toggle, returns LikeResult)
pub async fn toggle_like(State(state): State<Arc<AppState>>, Extension(claims): Extension<Claims>, Path(id): Path<i64>) -> Result<Json<serde_json::Value>> {
    let me = claims.user_id();
    let post = sqlx::query_as::<sqlx::MySql, crate::models::Post>("SELECT * FROM posts WHERE id=? AND deleted=FALSE").bind(id).fetch_one(&state.db).await?;
    let exists: Option<(i64,)> = sqlx::query_as("SELECT id FROM likes WHERE user_id=? AND target_type='POST' AND target_id=?").bind(me).bind(id).fetch_optional(&state.db).await?;
    if exists.is_some() {
        sqlx::query("DELETE FROM likes WHERE user_id=? AND target_type='POST' AND target_id=?").bind(me).bind(id).execute(&state.db).await?;
        sqlx::query("UPDATE posts SET like_count=GREATEST(like_count-1,0) WHERE id=?").bind(id).execute(&state.db).await?;
        return Ok(Json(serde_json::json!({"success":true,"message":null,"data":{"liked":false,"likeCount":(post.like_count-1).max(0)}})));
    }
    sqlx::query("INSERT INTO likes(created_at,updated_at,target_id,target_type,user_id) VALUES(NOW(),NOW(),?,'POST',?)").bind(id).bind(me).execute(&state.db).await?;
    // mutual exclusion with dislike
    let disliked: Option<(i64,)> = sqlx::query_as("SELECT id FROM dislikes WHERE user_id=? AND target_type='POST' AND target_id=?").bind(me).bind(id).fetch_optional(&state.db).await?;
    if disliked.is_some() {
        sqlx::query("DELETE FROM dislikes WHERE user_id=? AND target_type='POST' AND target_id=?").bind(me).bind(id).execute(&state.db).await?;
        sqlx::query("UPDATE posts SET dislike_count=GREATEST(dislike_count-1,0) WHERE id=?").bind(id).execute(&state.db).await?;
    }
    sqlx::query("UPDATE posts SET like_count=like_count+1 WHERE id=?").bind(id).execute(&state.db).await?;
    Ok(Json(serde_json::json!({"success":true,"message":null,"data":{"liked":true,"likeCount":post.like_count+1}})))
}

/// POST /api/posts/{id}/dislike (toggle)
pub async fn toggle_dislike(State(state): State<Arc<AppState>>, Extension(claims): Extension<Claims>, Path(id): Path<i64>) -> Result<Json<serde_json::Value>> {
    let me = claims.user_id();
    let post = sqlx::query_as::<sqlx::MySql, crate::models::Post>("SELECT * FROM posts WHERE id=? AND deleted=FALSE").bind(id).fetch_one(&state.db).await?;
    let exists: Option<(i64,)> = sqlx::query_as("SELECT id FROM dislikes WHERE user_id=? AND target_type='POST' AND target_id=?").bind(me).bind(id).fetch_optional(&state.db).await?;
    if exists.is_some() {
        sqlx::query("DELETE FROM dislikes WHERE user_id=? AND target_type='POST' AND target_id=?").bind(me).bind(id).execute(&state.db).await?;
        sqlx::query("UPDATE posts SET dislike_count=GREATEST(dislike_count-1,0) WHERE id=?").bind(id).execute(&state.db).await?;
        return Ok(Json(serde_json::json!({"success":true,"message":null,"data":{"disliked":false,"dislikeCount":(post.dislike_count-1).max(0)}})));
    }
    let liked: Option<(i64,)> = sqlx::query_as("SELECT id FROM likes WHERE user_id=? AND target_type='POST' AND target_id=?").bind(me).bind(id).fetch_optional(&state.db).await?;
    if liked.is_some() {
        sqlx::query("DELETE FROM likes WHERE user_id=? AND target_type='POST' AND target_id=?").bind(me).bind(id).execute(&state.db).await?;
        sqlx::query("UPDATE posts SET like_count=GREATEST(like_count-1,0) WHERE id=?").bind(id).execute(&state.db).await?;
    }
    sqlx::query("INSERT INTO dislikes(created_at,updated_at,target_id,target_type,user_id) VALUES(NOW(),NOW(),?,'POST',?)").bind(id).bind(me).execute(&state.db).await?;
    sqlx::query("UPDATE posts SET dislike_count=dislike_count+1 WHERE id=?").bind(id).execute(&state.db).await?;
    Ok(Json(serde_json::json!({"success":true,"message":null,"data":{"disliked":true,"dislikeCount":post.dislike_count+1}})))
}

/// POST /api/posts/{id}/unlock
pub async fn unlock_post(State(state): State<Arc<AppState>>, Extension(claims): Extension<Claims>, Path(id): Path<i64>) -> Result<Json<serde_json::Value>> {
    let _ = (&state, &claims, id);
    Ok(Json(serde_json::json!({"success":true,"message":"unlocked","data":null})))
}

/// POST /api/posts/{id}/report
pub async fn report_content(State(state): State<Arc<AppState>>, Extension(claims): Extension<Claims>, Path(id): Path<i64>, Json(body): Json<serde_json::Value>) -> Result<Json<serde_json::Value>> {
    let reason = body.get("reason").and_then(|v| v.as_str()).unwrap_or("").trim().to_string();
    if reason.is_empty() {
        return Err(AppError::BadRequest("\u{8bf7}\u{586b}\u{5199}\u{4e3e}\u{62a5}\u{539f}\u{56e0}".into()));
    }
    let exists: Option<(i64,)> = sqlx::query_as("SELECT id FROM posts WHERE id=? AND deleted=FALSE")
        .bind(id).fetch_optional(&state.db).await?;
    if exists.is_none() {
        return Err(AppError::NotFound("\u{5e16}\u{5b50}\u{4e0d}\u{5b58}\u{5728}".into()));
    }
    // duplicate report check (unique key reporter+target) — friendly conflict instead of DB error
    let dup: Option<(i64,)> = sqlx::query_as(
        "SELECT id FROM reports WHERE reporter_id=? AND target_type='POST' AND target_id=?")
        .bind(claims.user_id()).bind(id).fetch_optional(&state.db).await?;
    if dup.is_some() {
        return Err(AppError::Conflict("\u{60a8}\u{5df2}\u{7ecf}\u{4e3e}\u{62a5}\u{8fc7}\u{8be5}\u{5185}\u{5bb9}".into()));
    }
    sqlx::query("INSERT INTO reports(created_at,updated_at,target_id,target_type,reporter_id,reason,status) VALUES(NOW(),NOW(),?,'POST',?,?,'PENDING')")
        .bind(id).bind(claims.user_id()).bind(reason).execute(&state.db).await?;
    Ok(Json(serde_json::json!({"success":true,"message":"\u{4e3e}\u{62a5}\u{5df2}\u{63d0}\u{4ea4}","data":null})))
}

/// GET /api/posts/{id}/history
pub async fn history(State(state): State<Arc<AppState>>, Path(id): Path<i64>) -> Result<Json<serde_json::Value>> {
    #[derive(sqlx::FromRow)]
    struct Rev { title: Option<String>, content: Option<String>, created_at: chrono::DateTime<chrono::Utc> }
    let rows = sqlx::query_as::<sqlx::MySql, Rev>("SELECT title, content, created_at FROM post_revisions WHERE post_id=? ORDER BY created_at DESC LIMIT 50")
        .bind(id).fetch_all(&state.db).await?;
    let items: Vec<serde_json::Value> = rows.iter().map(|r| serde_json::json!({
        "title": r.title, "content": r.content, "createdAt": r.created_at
    })).collect();
    Ok(Json(serde_json::json!({"success":true,"message":null,"data":items})))
}

/// GET /api/topics/{topic}/posts
pub async fn list_by_topic(State(state): State<Arc<AppState>>, Path(topic): Path<String>, Query(q): Query<ListPostsQuery>) -> Result<Json<serde_json::Value>> {
    let page = q.page.unwrap_or(0).max(0);
    let size = q.size.unwrap_or(20).clamp(1, 100);
    let offset = page * size;
    let clean = topic.trim_start_matches('#').to_string();
    let pattern = format!("%{}%", clean);
    let posts = sqlx::query_as::<sqlx::MySql, crate::models::Post>(
        "SELECT * FROM posts WHERE deleted=FALSE AND status='APPROVED' AND topics LIKE ? ORDER BY last_activity_at DESC LIMIT ? OFFSET ?")
        .bind(&pattern).bind(size).bind(offset).fetch_all(&state.db).await?;
    let total: (i64,) = sqlx::query_as(
        "SELECT COUNT(*) FROM posts WHERE deleted=FALSE AND status='APPROVED' AND topics LIKE ?")
        .bind(&pattern).fetch_one(&state.db).await?;
    let mut items = Vec::with_capacity(posts.len());
    for p in posts {
        items.push(super::user::post_summary_public(&state, p).await?);
    }
    let pages = (total.0 + size - 1) / size;
    Ok(Json(serde_json::json!({"success":true,"message":null,"data":{"items":items,"page":page,"size":size,"totalItems":total.0,"totalPages":pages,"hasNext":page+1<pages}})))
}

/// GET /api/feed/following 鈥?placeholder returning empty page when not implemented fully.
pub async fn feed_guard(State(state): State<Arc<AppState>>, Query(q): Query<ListPostsQuery>) -> Result<Json<serde_json::Value>> {
    let page = q.page.unwrap_or(0).max(0);
    let size = q.size.unwrap_or(20).clamp(1, 100);
    let _ = &state;
    Ok(Json(serde_json::json!({"success":true,"message":null,"data":{"items":[],"page":page,"size":size,"totalItems":0,"totalPages":0,"hasNext":false}})))
}
