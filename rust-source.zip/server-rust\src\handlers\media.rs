use axum::{extract::{Path, State}, http::{header, HeaderMap, StatusCode}, response::{IntoResponse, Response}};
use std::sync::Arc;
use tokio::fs;

use crate::config::AppState;

pub async fn get_media(
    State(state): State<Arc<AppState>>,
    Path(code): Path<String>,
    headers: HeaderMap,
) -> Response {
    match get_media_inner(&state, &code, &headers).await {
        Ok(resp) => resp,
        Err(_) => StatusCode::NOT_FOUND.into_response(),
    }
}

async fn get_media_inner(state: &AppState, code: &str, headers: &HeaderMap) -> Result<Response, ()> {
    let record: Option<(String, Option<String>, Option<String>, Option<String>)> = sqlx::query_as(
        "SELECT path, content_type, type, original_name FROM upload_records WHERE public_code = ?"
    )
    .bind(code)
    .fetch_optional(&state.db)
    .await
    .map_err(|_| ())?;

    let (path, content_type, rtype, original_name) = record.ok_or(())?;

    let root = std::path::Path::new("/opt/server/uploads");
    let clean_path = path.trim_start_matches("/uploads/");
    let file_path = root.join(clean_path);

    if !file_path.exists() {
        return Err(());
    }

    let data = fs::read(&file_path).await.map_err(|_| ())?;
    let total = data.len() as u64;

    let mime = match content_type.as_deref() {
        Some(ct) if !ct.is_empty() && ct != "application/octet-stream" => ct.to_string(),
        _ => guess_content_type(&file_path),
    };

    let range = headers.get(header::RANGE).and_then(|v| v.to_str().ok());
    let (status, body, content_range) = if let Some(range) = range {
        let value = range.strip_prefix("bytes=").ok_or(())?;
        let (start_text, end_text) = value.split_once('-').ok_or(())?;
        let start: u64 = start_text.parse().map_err(|_| ())?;
        let end: u64 = if end_text.is_empty() { total.saturating_sub(1) } else { end_text.parse().map_err(|_| ())? };
        if start >= total || end < start { return Err(()); }
        let end = end.min(total - 1);
        (StatusCode::PARTIAL_CONTENT, data[start as usize..=end as usize].to_vec(), Some(format!("bytes {}-{}/{}", start, end, total)))
    } else {
        (StatusCode::OK, data, None)
    };

    let body_len = body.len();
    let mut response = axum::http::Response::new(axum::body::Body::from(body));
    *response.status_mut() = status;
    response.headers_mut().insert(header::CONTENT_TYPE, mime.parse().unwrap());
    response.headers_mut().insert(header::CACHE_CONTROL, "public, max-age=604800".parse().unwrap());
    response.headers_mut().insert(header::ACCEPT_RANGES, "bytes".parse().unwrap());
    response.headers_mut().insert(header::CONTENT_LENGTH, body_len.to_string().parse().unwrap());
    // Document attachments: force browser download instead of inline preview
    if rtype.as_deref() == Some("file") {
        let name = original_name.filter(|s| !s.is_empty())
            .unwrap_or_else(|| file_path.file_name().unwrap_or_default().to_string_lossy().to_string());
        let encoded = percent_encode_utf8(&name);
        if let Ok(v) = format!("attachment; filename*=UTF-8''{}", encoded).parse() {
            response.headers_mut().insert(header::CONTENT_DISPOSITION, v);
        }
    }
    if let Some(value) = content_range {
        response.headers_mut().insert(header::CONTENT_RANGE, value.parse().unwrap());
    }
    Ok(response)
}

/// Percent-encode UTF-8 bytes for RFC 5987 filename* values.
fn percent_encode_utf8(input: &str) -> String {
    let mut out = String::with_capacity(input.len() * 3);
    for b in input.bytes() {
        match b {
            b'A'..=b'Z' | b'a'..=b'z' | b'0'..=b'9' | b'-' | b'.' | b'_' | b'~' => out.push(b as char),
            _ => out.push_str(&format!("%{:02X}", b)),
        }
    }
    out
}

fn guess_content_type(path: &std::path::Path) -> String {
    let name = path.file_name().unwrap_or_default().to_string_lossy().to_lowercase();
    if name.ends_with(".jpg") || name.ends_with(".jpeg") { return "image/jpeg".into(); }
    if name.ends_with(".png") { return "image/png".into(); }
    if name.ends_with(".gif") { return "image/gif".into(); }
    if name.ends_with(".webp") { return "image/webp".into(); }
    if name.ends_with(".mp4") { return "video/mp4".into(); }
    if name.ends_with(".webm") { return "video/webm".into(); }
    if name.ends_with(".mov") { return "video/quicktime".into(); }
    if name.ends_with(".md") || name.ends_with(".txt") { return "text/plain; charset=utf-8".into(); }
    if name.ends_with(".json") { return "application/json".into(); }
    if name.ends_with(".pdf") { return "application/pdf".into(); }
    "application/octet-stream".into()
}
