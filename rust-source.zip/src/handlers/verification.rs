use axum::{extract::{State, Query}, Json};
use serde::Deserialize;
use std::sync::Arc;

use crate::{config::AppState, error::{AppError, Result}};

/// GET /api/verification/challenge?purpose=POST|COMMENT
/// Stateless challenge: id encodes answer via HMAC-like hash (dev-grade).
pub async fn challenge(
    State(_state): State<Arc<AppState>>,
    Query(q): Query<ChallengeQuery>,
) -> Result<Json<serde_json::Value>> {
    let purpose = q.purpose.unwrap_or_else(|| "POST".into());
    use rand::Rng;
    let mut rng = rand::thread_rng();

    // 10以内加减乘除
    let ops = ["+", "-", "\u{00d7}", "\u{00f7}"];
    let op_idx: usize = rng.gen_range(0..ops.len());
    let (a, b, answer) = match op_idx {
        0 => {
            let a: i32 = rng.gen_range(1..=9);
            let b: i32 = rng.gen_range(1..=(10 - a));
            (a, b, a + b)
        }
        1 => {
            let a: i32 = rng.gen_range(2..=10);
            let b: i32 = rng.gen_range(1..a);
            (a, b, a - b)
        }
        2 => {
            let a: i32 = rng.gen_range(1..=5);
            let b: i32 = rng.gen_range(1..=(10 / a));
            (a, b, a * b)
        }
        _ => {
            // 除法：保证整除且商 ≤ 10
            let b: i32 = rng.gen_range(1..=5);
            let quotient: i32 = rng.gen_range(1..=10);
            let a: i32 = b * quotient;
            (a, b, quotient)
        }
    };
    let expression = format!("{} {} {} = ?", a, ops[op_idx], b);
    let id = format!("{}{}", simple_hash(&answer.to_string()), uuid::Uuid::new_v4().simple());

    Ok(Json(serde_json::json!({"success":true,"message":null,"data":{
        "id": id, "expression": expression, "purpose": purpose, "expiresInSeconds": 300
    }})))
}

#[derive(Debug, Deserialize)]
pub struct ChallengeQuery {
    pub purpose: Option<String>,
}

fn simple_hash(input: &str) -> String {
    // FNV-1a style hash, dev-grade only
    let mut h: u64 = 0xcbf29ce484222325;
    for b in input.as_bytes() {
        h ^= *b as u64;
        h = h.wrapping_mul(0x100000001b3);
    }
    format!("{:016x}", &h)
}

/// Verify a challenge answer against the embedded hash in the challenge id.
pub fn verify_challenge_id(challenge_id: &str, answer: i32) -> bool {
    if challenge_id.len() < 16 { return false; }
    let (hash_part, _) = challenge_id.split_at(16);
    hash_part == simple_hash(&answer.to_string())
}

#[derive(Debug, Deserialize)]
pub struct EmailCodeRequest {
    pub email: Option<String>,
    #[serde(rename = "challengeId")]
    pub challenge_id: Option<String>,
    pub answer: Option<i32>,
}

/// POST /api/verification/email/code
pub async fn email_code(
    State(state): State<Arc<AppState>>,
    Json(req): Json<EmailCodeRequest>,
) -> Result<Json<serde_json::Value>> {
    if let (Some(cid), Some(ans)) = (&req.challenge_id, req.answer) {
        if !verify_challenge_id(cid, ans) {
            return Err(AppError::BadRequest("challenge incorrect".into()));
        }
    }

    let email = req.email.clone().unwrap_or_default();
    if email.is_empty() { return Err(AppError::BadRequest("email required".into())); }

    use rand::Rng;
    let mut rng = rand::thread_rng();
    let code: u32 = rng.gen_range(100000..=999999);
    let key = format!("emailcode:{}", email.to_lowercase());
    let _ = &state;
    // SMTP not configured; code only logged
    tracing::warn!("EMAIL CODE for {} is {} (SMTP not configured)", email, code);

    Ok(Json(serde_json::json!({"success":true,"message":"code sent","data":null})))
}
