use axum::{
    extract::{State, Path, Extension},
    Json,
};
use serde::Deserialize;
use std::sync::Arc;

use crate::{
    config::AppState,
    error::{AppError, Result},
    models::{Poll, PollOption},
    utils::Claims,
};

#[derive(Debug, Deserialize)]
pub struct VoteRequest {
    #[serde(rename = "optionIds")]
    pub option_ids: Vec<i64>,
}

/// GET /api/polls/:id (pollId)
pub async fn get_poll(
    State(state): State<Arc<AppState>>,
    Path(id): Path<i64>,
) -> Result<Json<serde_json::Value>> {
    poll_result(&state, id).await
}

/// GET /api/posts/:id/poll (postId)
pub async fn get_poll_by_post(
    State(state): State<Arc<AppState>>,
    Path(post_id): Path<i64>,
) -> Result<Json<serde_json::Value>> {
    let poll = sqlx::query_as::<sqlx::MySql, Poll>("SELECT * FROM polls WHERE post_id=?")
        .bind(post_id).fetch_optional(&state.db).await?;
    match poll {
        None => Ok(Json(serde_json::json!({"success":true,"message":null,"data":null}))),
        Some(p) => poll_result(&state, p.id).await,
    }
}

async fn poll_result(state: &AppState, poll_id: i64) -> Result<Json<serde_json::Value>> {
    let poll = sqlx::query_as::<sqlx::MySql, Poll>("SELECT * FROM polls WHERE id=?")
        .bind(poll_id).fetch_optional(&state.db).await?
        .ok_or_else(|| AppError::NotFound("poll not found".into()))?;

    let options = sqlx::query_as::<sqlx::MySql, PollOption>(
        "SELECT * FROM poll_options WHERE poll_id=? ORDER BY id ASC")
        .bind(poll_id).fetch_all(&state.db).await?;

    let total_votes: i32 = options.iter().map(|o| o.vote_count).sum();
    let opts: Vec<serde_json::Value> = options.iter().map(|o| {
        let pct = if total_votes > 0 { (o.vote_count as f32 / total_votes as f32) * 100.0 } else { 0.0 };
        serde_json::json!({"id": o.id, "text": o.option_text, "votes": o.vote_count, "percentage": pct})
    }).collect();

    Ok(Json(serde_json::json!({"success":true,"message":null,"data":{
        "id": poll.id, "question": poll.question, "multiple": poll.multiple,
        "options": opts, "totalVotes": total_votes
    }})))
}

/// POST /api/polls/:id/vote
pub async fn vote(
    State(state): State<Arc<AppState>>,
    Extension(claims): Extension<Claims>,
    Path(id): Path<i64>,
    Json(req): Json<VoteRequest>,
) -> Result<Json<serde_json::Value>> {
    if req.option_ids.is_empty() { return Err(AppError::BadRequest("no options selected".into())); }
    let me = claims.user_id();

    let poll = sqlx::query_as::<sqlx::MySql, Poll>("SELECT * FROM polls WHERE id=?")
        .bind(id).fetch_optional(&state.db).await?
        .ok_or_else(|| AppError::NotFound("poll not found".into()))?;

    if let Some(deadline) = poll.deadline {
        if deadline < chrono::Utc::now() { return Err(AppError::BadRequest("poll expired".into())); }
    }

    let existing: Vec<(i64,)> = sqlx::query_as("SELECT id FROM poll_votes WHERE poll_id=? AND user_id=?")
        .bind(id).bind(me).fetch_all(&state.db).await?;
    if !existing.is_empty() { return Err(AppError::BadRequest("already voted".into())); }
    if !poll.multiple && req.option_ids.len() > 1 {
        return Err(AppError::BadRequest("single choice only".into()));
    }

    for oid in &req.option_ids {
        let ok: Option<(i64,)> = sqlx::query_as("SELECT id FROM poll_options WHERE id=? AND poll_id=?")
            .bind(oid).bind(id).fetch_optional(&state.db).await?;
        if ok.is_none() { return Err(AppError::BadRequest("invalid option".into())); }
    }

    let mut tx = state.db.begin().await?;
    for oid in &req.option_ids {
        sqlx::query("INSERT INTO poll_votes(created_at,updated_at,option_id,poll_id,user_id) VALUES(NOW(),NOW(),?,?,?)")
            .bind(oid).bind(id).bind(me).execute(&mut *tx).await?;
        sqlx::query("UPDATE poll_options SET vote_count=vote_count+1, updated_at=NOW() WHERE id=?")
            .bind(oid).execute(&mut *tx).await?;
    }
    tx.commit().await?;

    poll_result(&state, id).await
}
