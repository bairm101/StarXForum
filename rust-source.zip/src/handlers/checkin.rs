use axum::{
    extract::{State, Path, Extension},
    Json,
};
use serde::Deserialize;
use std::sync::Arc;

use crate::{
    config::AppState,
    error::{AppError, Result},
    models::User,
    utils::Claims,
};

const BASE_EXP: i64 = 100;
const MAX_DAYS_STAYED: i64 = 30;
const MAX_LEVEL: i32 = 10;
const MAX_TIP_PER_POST: i64 = 3;

/// GET /api/checkin/status
pub async fn status(State(state): State<Arc<AppState>>, Extension(claims): Extension<Claims>) -> Result<Json<serde_json::Value>> {
    let uid = claims.user_id();

    struct UserCheckinRow {
        level: i32,
        exp: i32,
        gold: i64,
        checkin_streak: i32,
        last_checkin_date: Option<chrono::NaiveDate>,
        level_up_at: Option<chrono::NaiveDateTime>,
        created_at: chrono::NaiveDateTime,
    }
    impl<'r> sqlx::FromRow<'r, sqlx::mysql::MySqlRow> for UserCheckinRow {
        fn from_row(row: &'r sqlx::mysql::MySqlRow) -> std::result::Result<Self, sqlx::Error> {
            use sqlx::Row;
            Ok(UserCheckinRow {
                level: row.try_get("level")?,
                exp: row.try_get("exp")?,
                gold: row.try_get("gold")?,
                checkin_streak: row.try_get("checkin_streak")?,
                last_checkin_date: row.try_get("last_checkin_date")?,
                level_up_at: row.try_get("level_up_at")?,
                created_at: row.try_get("created_at")?,
            })
        }
    }

    let r = sqlx::query_as::<sqlx::MySql, UserCheckinRow>(
        "SELECT level, exp, gold, checkin_streak, last_checkin_date, level_up_at, created_at FROM users WHERE id=?")
        .bind(uid).fetch_optional(&state.db).await?
        .ok_or_else(|| AppError::NotFound("user not found".into()))?;

    let today = chrono::Utc::now().date_naive();
    let checked_today = r.last_checkin_date == Some(today);
    let since = r.level_up_at.unwrap_or(r.created_at);
    let days = ((chrono::Utc::now().naive_utc() - since).num_days()).max(0);
    let capped = days.min(MAX_DAYS_STAYED);
    let next_exp = if r.level >= MAX_LEVEL { 0 } else { (r.level as i64) * (BASE_EXP + capped) };

    Ok(Json(serde_json::json!({"success":true,"message":null,"data":{
        "level": r.level, "exp": r.exp, "gold": r.gold, "streak": r.checkin_streak,
        "checkedToday": checked_today, "lastCheckinDate": r.last_checkin_date,
        "nextLevelExp": next_exp, "daysStayedAtLevel": days
    }})))
}

/// POST /api/checkin
#[axum::debug_handler]
pub async fn checkin(State(state): State<Arc<AppState>>, Extension(claims): Extension<Claims>) -> Result<Json<serde_json::Value>> {
    let uid = claims.user_id();
    let today = chrono::Utc::now().date_naive();

    struct UserCheckinRow {
        id: i64,
        level: i32,
        exp: i32,
        gold: i64,
        checkin_streak: i32,
        last_checkin_date: Option<chrono::NaiveDate>,
        created_at: chrono::NaiveDateTime,
    }
    impl<'r> sqlx::FromRow<'r, sqlx::mysql::MySqlRow> for UserCheckinRow {
        fn from_row(row: &'r sqlx::mysql::MySqlRow) -> std::result::Result<Self, sqlx::Error> {
            use sqlx::Row;
            Ok(UserCheckinRow {
                id: row.try_get("id")?,
                level: row.try_get("level")?,
                exp: row.try_get("exp")?,
                gold: row.try_get("gold")?,
                checkin_streak: row.try_get("checkin_streak")?,
                last_checkin_date: row.try_get("last_checkin_date")?,
                created_at: row.try_get("created_at")?,
            })
        }
    }

    let r = sqlx::query_as::<sqlx::MySql, UserCheckinRow>(
        "SELECT id, level, exp, gold, checkin_streak, last_checkin_date, created_at FROM users WHERE id=?")
        .bind(uid).fetch_optional(&state.db).await?
        .ok_or_else(|| AppError::NotFound("user not found".into()))?;

    if r.last_checkin_date == Some(today) {
        return Err(AppError::BadRequest("already checked in today".into()));
    }

    let (exp_gain, gold_gain) = {
        use rand::Rng;
        let mut rng = rand::thread_rng();
        (rng.gen_range(25..=50), rng.gen_range(1..=10i64))
    };
    let yesterday = today.pred_opt().unwrap_or(today);
    let new_streak = if r.last_checkin_date == Some(yesterday) { r.checkin_streak + 1 } else { 1 };

    let new_gold = r.gold + gold_gain;
    let mut new_exp = r.exp + exp_gain;
    let mut new_level = r.level;

    // normalize level using current stay (approximation of Java behavior)
    loop {
        if new_level >= MAX_LEVEL { break; }
        let since = r.created_at;
        let days = ((chrono::Utc::now().naive_utc() - since).num_days()).max(0);
        let capped = days.min(MAX_DAYS_STAYED);
        let need = (new_level as i64) * (BASE_EXP + capped);
        if (new_exp as i64) >= need {
            new_exp -= need as i32;
            new_level += 1;
        } else { break; }
    }
    if new_level > MAX_LEVEL { new_level = MAX_LEVEL; }
    let leveled_up = new_level > r.level;

    if leveled_up {
        sqlx::query("UPDATE users SET gold=?,exp=?,level=?,checkin_streak=?,last_checkin_date=?,level_up_at=NOW(),updated_at=NOW() WHERE id=?")
            .bind(new_gold).bind(new_exp).bind(new_level).bind(new_streak).bind(today).bind(r.id)
            .execute(&state.db).await?;
    } else {
        sqlx::query("UPDATE users SET gold=?,exp=?,level=?,checkin_streak=?,last_checkin_date=?,level_up_at=COALESCE(level_up_at,created_at),updated_at=NOW() WHERE id=?")
            .bind(new_gold).bind(new_exp).bind(new_level).bind(new_streak).bind(today).bind(r.id)
            .execute(&state.db).await?;
    }

    let capped = ((chrono::Utc::now().naive_utc() - r.created_at).num_days()).max(0).min(MAX_DAYS_STAYED);
    let next_exp = if new_level >= MAX_LEVEL { 0 } else { (new_level as i64) * (BASE_EXP + capped) };

    Ok(Json(serde_json::json!({"success":true,"message":"checkin ok","data":{
        "goldGain": gold_gain, "expGain": exp_gain, "leveledUp": leveled_up,
        "level": new_level, "exp": new_exp, "gold": new_gold, "streak": new_streak,
        "nextLevelExp": next_exp
    }})))
}

// helper trait to avoid duplicating struct

#[derive(Debug, Deserialize)]
pub struct TipRequest { pub amount: Option<i64> }

/// POST /api/posts/{id}/tip
pub async fn tip(
    State(state): State<Arc<AppState>>,
    Extension(claims): Extension<Claims>,
    Path(post_id): Path<i64>,
    Json(req): Json<TipRequest>,
) -> Result<Json<serde_json::Value>> {
    let amount = req.amount.unwrap_or(0);
    if amount <= 0 { return Err(AppError::BadRequest("tip amount must be positive".into())); }
    if amount > 10000 { return Err(AppError::BadRequest("tip too large".into())); }

    let me = claims.user_id();
    struct PostMeta { author_id: i64, total_tip_gold: i64, tip_count: i32 }
    impl<'r> sqlx::FromRow<'r, sqlx::mysql::MySqlRow> for PostMeta {
        fn from_row(row: &'r sqlx::mysql::MySqlRow) -> std::result::Result<Self, sqlx::Error> {
            use sqlx::Row;
            Ok(PostMeta {
                author_id: row.try_get("author_id")?,
                total_tip_gold: row.try_get("total_tip_gold")?,
                tip_count: row.try_get("tip_count")?,
            })
        }
    }
    let post = sqlx::query_as::<sqlx::MySql, PostMeta>(
        "SELECT author_id, total_tip_gold, tip_count FROM posts WHERE id=? AND deleted=FALSE")
        .bind(post_id).fetch_optional(&state.db).await?
        .ok_or_else(|| AppError::NotFound("post not found".into()))?;

    if post.author_id == me { return Err(AppError::BadRequest("cannot tip own post".into())); }

    let already: (i64,) = sqlx::query_as("SELECT COUNT(*) FROM tips WHERE user_id=? AND post_id=?")
        .bind(me).bind(post_id).fetch_one(&state.db).await?;
    if already.0 >= MAX_TIP_PER_POST { return Err(AppError::BadRequest("max tips per post reached".into())); }

    let my_gold_row: (i64,) = sqlx::query_as("SELECT gold FROM users WHERE id=?").bind(me).fetch_one(&state.db).await?;
    if my_gold_row.0 < amount { return Err(AppError::BadRequest("insufficient gold".into())); }

    sqlx::query("UPDATE users SET gold=gold-?,updated_at=NOW() WHERE id=?").bind(amount).bind(me).execute(&state.db).await?;
    sqlx::query("UPDATE users SET gold=gold+?,updated_at=NOW() WHERE id=?").bind(amount).bind(post.author_id).execute(&state.db).await?;
    sqlx::query("UPDATE posts SET total_tip_gold=total_tip_gold+?,tip_count=tip_count+1,updated_at=NOW() WHERE id=?").bind(amount).bind(post_id).execute(&state.db).await?;
    sqlx::query("INSERT INTO tips(created_at,updated_at,amount,post_id,user_id) VALUES(NOW(),NOW(),?,?,?)").bind(amount).bind(post_id).bind(me).execute(&state.db).await?;

    Ok(Json(serde_json::json!({"success":true,"message":"tip ok","data":{
        "amount": amount, "totalTipGold": post.total_tip_gold + amount,
        "tipCount": post.tip_count + 1, "myGold": my_gold_row.0 - amount,
        "myTipTimes": already.0 as i32 + 1, "maxTipTimes": MAX_TIP_PER_POST as i32
    }})))
}
