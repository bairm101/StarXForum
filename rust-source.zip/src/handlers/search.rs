use axum::{
    extract::{State, Query},
    Json,
};
use serde::Deserialize;
use std::sync::Arc;

use crate::{
    config::AppState,
    error::{AppError, Result},
    models::{Post, User},
};

#[derive(Debug, Deserialize)]
pub struct SearchQuery {
    pub q: String,
    #[serde(rename = "type")]
    pub search_type: Option<String>,
    pub page: Option<i64>,
    #[serde(rename = "size")]
    pub size: Option<i64>,
}

/// GET /api/search?q=&page=0&size=20
/// Java PostController.search returns PageResponse<PostSummary>.
pub async fn search(
    State(state): State<Arc<AppState>>,
    Query(query): Query<SearchQuery>,
) -> Result<Json<serde_json::Value>> {
    if query.q.trim().is_empty() {
        return Err(AppError::BadRequest("keyword required".into()));
    }
    let page = query.page.unwrap_or(0).max(0);
    let size = query.size.unwrap_or(20).clamp(1, 100);
    let offset = page * size;
    let pattern = format!("%{}%", query.q.trim());

    let posts = sqlx::query_as::<sqlx::MySql, Post>(
        "SELECT * FROM posts
         WHERE deleted = FALSE AND status = 'APPROVED'
           AND (title LIKE ? OR content LIKE ?)
         ORDER BY last_activity_at DESC
         LIMIT ? OFFSET ?")
        .bind(&pattern).bind(&pattern)
        .bind(size).bind(offset)
        .fetch_all(&state.db).await?;

    let total: (i64,) = sqlx::query_as(
        "SELECT COUNT(*) FROM posts
         WHERE deleted = FALSE AND status = 'APPROVED'
           AND (title LIKE ? OR content LIKE ?)")
        .bind(&pattern).bind(&pattern)
        .fetch_one(&state.db).await?;

    let mut items = Vec::with_capacity(posts.len());
    for p in posts { items.push(crate::handlers::post::summary(&state, p).await?); }

    let pages = (total.0 + size - 1) / size;
    Ok(Json(serde_json::json!({"success":true,"message":null,"data":{
        "items": items, "page": page, "size": size,
        "totalItems": total.0, "totalPages": pages, "hasNext": page + 1 < pages
    }})))
}

/// GET /api/users/by-name/{name} helper reuse: author brief for a username search
pub async fn author_by_name(state: &AppState, name: &str) -> Result<Option<User>> {
    let u = sqlx::query_as::<sqlx::MySql, User>(
        "SELECT * FROM users WHERE (username=? OR nickname=?) AND status <> 'BANNED'")
        .bind(name).bind(name).fetch_optional(&state.db).await?;
    Ok(u)
}

/// GET /api/search/trending — Java has no such endpoint; return empty list.
pub async fn trending_searches() -> Result<Json<serde_json::Value>> {
    Ok(Json(serde_json::json!({"success":true,"message":null,"data":{"trending":[]}})))
}
