use axum::{
    extract::{State, Path, Query, Extension},
    Json,
};
use serde::Deserialize;
use std::sync::Arc;

use crate::{
    config::AppState,
    error::{AppError, Result},
    models::{User, Post},
    utils::Claims,
};

#[derive(Debug, Deserialize)]
pub struct UserPostsQuery {
    pub page: Option<i64>,
    #[serde(rename = "size", alias = "page_size")]
    pub size: Option<i64>,
}

pub fn profile_view(u: &User) -> Json<serde_json::Value> {
    let display_name = u.nickname.clone().unwrap_or_else(|| u.username.clone());
    Json(serde_json::json!({"success":true,"message":null,"data":{
        "id": u.id, "uid": u.uid, "username": u.username, "nickname": u.nickname,
        "displayName": display_name, "avatarUrl": u.avatar_url, "signature": u.signature,
        "role": u.role, "status": u.status, "postCount": u.post_count, "commentCount": u.comment_count,
        "level": u.level, "exp": u.exp, "gold": u.gold, "checkinStreak": u.checkin_streak,
        "title": u.title, "managedBoardId": u.managed_board_id, "rankingWeight": u.ranking_weight,
        "pendingSignature": u.pending_signature, "emailVerified": u.email_verified,
        "maxUploadMb": u.max_upload_mb, "createdAt": u.created_at
    }}))
}

pub async fn user_profile_data(state: &AppState, id: i64) -> Result<Json<serde_json::Value>> {
    let u = sqlx::query_as::<sqlx::MySql, User>("SELECT * FROM users WHERE id=?")
        .bind(id).fetch_optional(&state.db).await?
        .ok_or_else(|| AppError::NotFound("user not found".into()))?;
    Ok(profile_view(&u))
}

/// GET /api/users/{id}  (public profile)
pub async fn get_user(
    State(state): State<Arc<AppState>>,
    Path(id): Path<i64>,
) -> Result<Json<serde_json::Value>> {
    let u = sqlx::query_as::<sqlx::MySql, User>("SELECT * FROM users WHERE id=?")
        .bind(id).fetch_optional(&state.db).await?
        .ok_or_else(|| AppError::NotFound("user not found".into()))?;
    Ok(profile_view(&u))
}

async fn post_summary(state: &AppState, post: Post) -> Result<serde_json::Value> {
    let author = sqlx::query_as::<sqlx::MySql, User>("SELECT * FROM users WHERE id=?")
        .bind(post.author_id).fetch_one(&state.db).await?;
    let board = sqlx::query_as::<sqlx::MySql, crate::models::Board>("SELECT * FROM boards WHERE id=?")
        .bind(post.board_id).fetch_one(&state.db).await?;
    let plain = post.content.split_whitespace().collect::<Vec<_>>().join(" ");
    let excerpt = if plain.len() > 120 { format!("{}...", &plain[..120]) } else { plain };
    Ok(serde_json::json!({
        "id": post.id, "title": post.title, "excerpt": excerpt,
        "boardId": post.board_id, "boardName": board.name,
        "author": {"id": author.id, "uid": author.uid, "username": author.username,
            "displayName": author.nickname.clone().unwrap_or_else(|| author.username.clone()),
            "avatarUrl": author.avatar_url, "title": author.title, "role": author.role},
        "viewCount": post.view_count, "commentCount": post.comment_count,
        "likeCount": post.like_count, "dislikeCount": post.dislike_count,
        "pinned": post.pinned, "boardPinned": post.board_pinned, "locked": post.locked,
        "likedByMe": false, "totalTipGold": post.total_tip_gold, "tipCount": post.tip_count,
        "status": post.status, "thumbnailUrl": post.thumbnail_url, "videoUrl": null,
        "gateType": post.gate_type, "topics": post.topics, "puid": post.puid,
        "createdAt": post.created_at, "lastActivityAt": post.last_activity_at
    }))
}

/// GET /api/users/{id}/posts
pub async fn get_user_posts(
    State(state): State<Arc<AppState>>,
    Path(id): Path<i64>,
    Query(q): Query<UserPostsQuery>,
) -> Result<Json<serde_json::Value>> {
    let page = q.page.unwrap_or(0).max(0);
    let size = q.size.unwrap_or(20).clamp(1, 100);
    let offset = page * size;

    let posts = sqlx::query_as::<sqlx::MySql, Post>(
        "SELECT * FROM posts WHERE author_id=? AND deleted=FALSE AND status='APPROVED' ORDER BY created_at DESC LIMIT ? OFFSET ?"
    ).bind(id).bind(size).bind(offset).fetch_all(&state.db).await?;

    let total: (i64,) = sqlx::query_as(
        "SELECT COUNT(*) FROM posts WHERE author_id=? AND deleted=FALSE AND status='APPROVED'")
        .bind(id).fetch_one(&state.db).await?;

    let mut items = Vec::with_capacity(posts.len());
    for p in posts { items.push(post_summary(&state, p).await?); }
    let pages = (total.0 + size - 1) / size;
    Ok(Json(serde_json::json!({"success":true,"message":null,"data":{"items":items,"page":page,"size":size,"totalItems":total.0,"totalPages":pages,"hasNext":page+1<pages}})))
}

/// GET /api/users/{id}/following
pub async fn get_following(
    State(state): State<Arc<AppState>>,
    Path(id): Path<i64>,
    Query(q): Query<UserPostsQuery>,
) -> Result<Json<serde_json::Value>> {
    let page = q.page.unwrap_or(0).max(0);
    let size = q.size.unwrap_or(20).clamp(1, 100);
    let offset = page * size;
    let rows: Vec<(i64,)> = sqlx::query_as(
        "SELECT following_id FROM follows WHERE user_id=? ORDER BY created_at DESC LIMIT ? OFFSET ?")
        .bind(id).bind(size).bind(offset).fetch_all(&state.db).await?;
    let total: (i64,) = sqlx::query_as("SELECT COUNT(*) FROM follows WHERE user_id=?")
        .bind(id).fetch_one(&state.db).await?;
    let mut items = Vec::with_capacity(rows.len());
    for (fid,) in rows {
        items.push(super::social::author_summary(&state, fid).await?);
    }
    let pages = (total.0 + size - 1) / size;
    Ok(Json(serde_json::json!({"success":true,"message":null,"data":{"items":items,"page":page,"size":size,"totalItems":total.0,"totalPages":pages,"hasNext":page+1<pages}})))
}

/// GET /api/users/{id}/followers
pub async fn get_followers(
    State(state): State<Arc<AppState>>,
    Path(id): Path<i64>,
    Query(q): Query<UserPostsQuery>,
) -> Result<Json<serde_json::Value>> {
    let page = q.page.unwrap_or(0).max(0);
    let size = q.size.unwrap_or(20).clamp(1, 100);
    let offset = page * size;
    let rows: Vec<(i64,)> = sqlx::query_as(
        "SELECT user_id FROM follows WHERE following_id=? ORDER BY created_at DESC LIMIT ? OFFSET ?")
        .bind(id).bind(size).bind(offset).fetch_all(&state.db).await?;
    let total: (i64,) = sqlx::query_as("SELECT COUNT(*) FROM follows WHERE following_id=?")
        .bind(id).fetch_one(&state.db).await?;
    let mut items = Vec::with_capacity(rows.len());
    for (fid,) in rows {
        items.push(super::social::author_summary(&state, fid).await?);
    }
    let pages = (total.0 + size - 1) / size;
    Ok(Json(serde_json::json!({"success":true,"message":null,"data":{"items":items,"page":page,"size":size,"totalItems":total.0,"totalPages":pages,"hasNext":page+1<pages}})))
}


// ---------- shared helpers & Java-compatible additions ----------

pub async fn post_summary_public(state: &crate::config::AppState, post: crate::models::Post) -> crate::error::Result<serde_json::Value> {
    let author = sqlx::query_as::<sqlx::MySql, User>("SELECT * FROM users WHERE id=?")
        .bind(post.author_id).fetch_one(&state.db).await?;
    let board = sqlx::query_as::<sqlx::MySql, crate::models::Board>("SELECT * FROM boards WHERE id=?")
        .bind(post.board_id).fetch_one(&state.db).await?;
    let plain = post.content.split_whitespace().collect::<Vec<_>>().join(" ");
    let excerpt = if plain.len() > 120 { format!("{}...", &plain[..120]) } else { plain };
    Ok(serde_json::json!({
        "id": post.id, "title": post.title, "excerpt": excerpt,
        "boardId": post.board_id, "boardName": board.name,
        "author": {"id": author.id, "uid": author.uid, "username": author.username,
            "displayName": author.nickname.clone().unwrap_or_else(|| author.username.clone()),
            "avatarUrl": author.avatar_url, "title": author.title, "role": author.role},
        "viewCount": post.view_count, "commentCount": post.comment_count,
        "likeCount": post.like_count, "dislikeCount": post.dislike_count,
        "pinned": post.pinned, "boardPinned": post.board_pinned, "locked": post.locked,
        "likedByMe": false, "totalTipGold": post.total_tip_gold, "tipCount": post.tip_count,
        "status": post.status, "thumbnailUrl": post.thumbnail_url, "videoUrl": null,
        "gateType": post.gate_type, "topics": post.topics, "puid": post.puid,
        "createdAt": post.created_at, "lastActivityAt": post.last_activity_at
    }))
}

/// POST /api/users/{id}/unfollow 閳?Java treats as explicit unfollow
pub async fn unfollow_alias(
    State(state): State<Arc<AppState>>,
    Extension(claims): Extension<Claims>,
    Path(id): Path<i64>,
) -> Result<Json<serde_json::Value>> {
    let me = claims.user_id();
    sqlx::query("DELETE FROM follows WHERE user_id=? AND following_id=?").bind(me).bind(id).execute(&state.db).await?;
    Ok(Json(serde_json::json!({"success":true,"message":"unfollowed","data":false})))
}

/// POST /api/users/{id}/report
pub async fn report_user(
    State(state): State<Arc<AppState>>,
    Extension(claims): Extension<Claims>,
    Path(id): Path<i64>,
    Json(body): Json<serde_json::Value>,
) -> Result<Json<serde_json::Value>> {
    let reason = body.get("reason").and_then(|v| v.as_str()).unwrap_or("").to_string();
    sqlx::query("INSERT INTO reports(created_at,updated_at,target_id,target_type,reporter_id,reason,status) VALUES(NOW(),NOW(),?,'USER',?,?,'PENDING')")
        .bind(id).bind(claims.user_id()).bind(reason).execute(&state.db).await?;
    Ok(Json(serde_json::json!({"success":true,"message":"reported","data":null})))
}
