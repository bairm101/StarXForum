use axum::{extract::{Extension, Path, State}, Json};
use serde::Deserialize;
use std::sync::Arc;
use validator::Validate;

use redis::AsyncCommands;
use crate::{config::AppState, error::{AppError, Result}, models::User, utils::{jwt, password, Claims}};

#[derive(Debug, Deserialize, Validate)]
pub struct RegisterRequest {
    #[validate(length(min = 3, max = 32))]
    pub username: String,
    #[validate(length(min = 8, max = 72))]
    pub password: String,
    #[validate(email)]
    pub email: Option<String>,
    pub nickname: Option<String>,
}

#[derive(Debug, Deserialize, Validate)]
pub struct LoginRequest {
    #[validate(length(min = 1))]
    pub username: String,
    #[validate(length(min = 1))]
    pub password: String,
    #[serde(rename = "deviceId")]
    pub device_id: Option<String>,
    #[serde(rename = "deviceName")]
    pub device_name: Option<String>,
}

fn build_user_profile(u: &User) -> serde_json::Value {
    let display_name = u.nickname.clone().unwrap_or_else(|| u.username.clone());
    serde_json::json!({
        "id": u.id, "uid": u.uid, "username": u.username, "nickname": u.nickname,
        "displayName": display_name, "avatarUrl": u.avatar_url, "signature": u.signature,
        "role": u.role, "status": u.status, "postCount": u.post_count, "commentCount": u.comment_count,
        "level": u.level, "exp": u.exp, "gold": u.gold, "checkinStreak": u.checkin_streak,
        "title": u.title, "managedBoardId": u.managed_board_id, "rankingWeight": u.ranking_weight,
        "pendingSignature": u.pending_signature, "emailVerified": u.email_verified,
        "maxUploadMb": u.max_upload_mb, "createdAt": u.created_at
    })
}

pub async fn register(State(state): State<Arc<AppState>>, Json(req): Json<RegisterRequest>) -> Result<Json<serde_json::Value>> {
    req.validate().map_err(|e| AppError::Validation(e.to_string()))?;
    let existing = sqlx::query_as::<sqlx::MySql, User>("SELECT * FROM users WHERE username=?").bind(&req.username).fetch_optional(&state.db).await?;
    if existing.is_some() { return Err(AppError::BadRequest("username already exists".into())); }
    let password_hash = password::hash_password(&req.password)?;
    let result = sqlx::query("INSERT INTO users(username,uid,password_hash,email,nickname,role,status,post_count,comment_count,level,exp,gold,checkin_streak,email_verified,signature_approved_once,failed_login_count,ranking_weight,created_at,updated_at) VALUES(?,?,?,?,?,'USER','ACTIVE',0,0,1,0,0,0,false,false,0,1.0,NOW(),NOW())")
        .bind(&req.username).bind(generate_uid()).bind(&password_hash).bind(&req.email).bind(&req.nickname)
        .execute(&state.db).await?;
    let user_id = result.last_insert_id() as i64;
    let user = sqlx::query_as::<sqlx::MySql, User>("SELECT * FROM users WHERE id=?").bind(user_id).fetch_one(&state.db).await?;
    let claims = Claims::new(user_id, user.username.clone(), user.role.clone(), state.config.jwt_expiration_seconds);
    let token = jwt::create_token(&claims, &state.config.jwt_secret)?;
    Ok(Json(serde_json::json!({"success":true,"message":"register ok","data":{"token":token,"expiresInSeconds":state.config.jwt_expiration_seconds,"user":build_user_profile(&user),"pendingDeviceId":null,"emailSent":false}})))
}

pub async fn login(State(state): State<Arc<AppState>>, Json(req): Json<LoginRequest>) -> Result<Json<serde_json::Value>> {
    req.validate().map_err(|e| AppError::Validation(e.to_string()))?;
    let user = sqlx::query_as::<sqlx::MySql, User>("SELECT * FROM users WHERE username=?").bind(req.username.trim()).fetch_optional(&state.db).await?;
    let user = user.ok_or_else(|| AppError::Auth("username or password incorrect".into()))?;
    if user.status == "BANNED" { return Err(AppError::Forbidden("account banned".into())); }
    if let Some(locked) = user.locked_until { if locked > chrono::Utc::now() { return Err(AppError::Forbidden("account locked".into())); } }
    let valid = password::verify_password(&req.password, &user.password_hash)?;
    if !valid {
        sqlx::query("UPDATE users SET failed_login_count=failed_login_count+1 WHERE id=?").bind(user.id).execute(&state.db).await?;
        return Err(AppError::Auth("username or password incorrect".into()));
    }
    sqlx::query("UPDATE users SET failed_login_count=0,locked_until=NULL WHERE id=?").bind(user.id).execute(&state.db).await?;
    let claims = Claims::new(user.id, user.username.clone(), user.role.clone(), state.config.jwt_expiration_seconds);
    let token = jwt::create_token(&claims, &state.config.jwt_secret)?;
    Ok(Json(serde_json::json!({"success":true,"message":"login ok","data":{"token":token,"expiresInSeconds":state.config.jwt_expiration_seconds,"user":build_user_profile(&user),"pendingDeviceId":null,"emailSent":false}})))
}

pub async fn logout() -> Result<Json<serde_json::Value>> {
    Ok(Json(serde_json::json!({"success":true,"message":null,"data":null})))
}

pub async fn refresh_token(State(state): State<Arc<AppState>>, Extension(claims): Extension<Claims>) -> Result<Json<serde_json::Value>> {
    let new_claims = Claims::new(claims.user_id(), claims.username.clone(), claims.role.clone(), state.config.jwt_expiration_seconds);
    let token = jwt::create_token(&new_claims, &state.config.jwt_secret)?;
    Ok(Json(serde_json::json!({"success":true,"message":null,"data":{"token":token}})))
}

pub async fn get_profile(State(state): State<Arc<AppState>>, Extension(claims): Extension<Claims>) -> Result<Json<serde_json::Value>> {
    let user = sqlx::query_as::<sqlx::MySql, User>("SELECT * FROM users WHERE id=?").bind(claims.user_id()).fetch_optional(&state.db).await?;
    let user = user.ok_or_else(|| AppError::NotFound("user not found".into()))?;
    Ok(Json(serde_json::json!({"success":true,"message":null,"data":build_user_profile(&user)})))
}

fn generate_uid() -> String {
    use rand::Rng;
    let alphabet: Vec<char> = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789".chars().collect();
    let mut rng = rand::thread_rng();
    let mut uid = String::from("U");
    for _ in 0..9 { uid.push(alphabet[rng.gen_range(0..alphabet.len())]); }
    uid
}


// ---------- Java-compatible auth additions ----------

/// POST /api/auth/verify-device 闂?stub (device verification not configured)
pub async fn verify_device_stub(Json(_body): Json<serde_json::Value>) -> Result<Json<serde_json::Value>> {
    Err(AppError::BadRequest("device verification not enabled".into()))
}

/// POST /api/auth/me/logout-all
pub async fn logout_all_devices(State(state): State<Arc<AppState>>, Extension(claims): Extension<Claims>) -> Result<Json<serde_json::Value>> {
    let n = sqlx::query("UPDATE user_sessions SET revoked=TRUE, updated_at=NOW() WHERE user_id=? AND revoked=FALSE")
        .bind(claims.user_id()).execute(&state.db).await?.rows_affected();
    Ok(Json(serde_json::json!({"success":true,"message":format!("logged out {} devices", n),"data":null})))
}

/// GET /api/auth/me/devices
pub async fn my_devices(State(state): State<Arc<AppState>>, Extension(claims): Extension<Claims>) -> Result<Json<serde_json::Value>> {
    struct Sess { sid: String, device_name: Option<String>, user_agent: Option<String>, login_at: Option<chrono::DateTime<chrono::Utc>>, last_seen_at: Option<chrono::DateTime<chrono::Utc>>, revoked: bool }
    impl<'r> sqlx::FromRow<'r, sqlx::mysql::MySqlRow> for Sess {
        fn from_row(row: &'r sqlx::mysql::MySqlRow) -> std::result::Result<Self, sqlx::Error> {
            use sqlx::Row;
            Ok(Sess{ sid: row.try_get("sid")?, device_name: row.try_get("device_name")?, user_agent: row.try_get("user_agent")?,
                login_at: row.try_get("login_at").ok(), last_seen_at: row.try_get("last_seen_at").ok(), revoked: row.try_get::<bool,_>("revoked")? })
        }
    }
    let rows = sqlx::query_as::<sqlx::MySql, Sess>("SELECT sid, device_name, user_agent, created_at AS login_at, last_seen_at, revoked FROM user_sessions WHERE user_id=? ORDER BY created_at DESC")
        .bind(claims.user_id()).fetch_all(&state.db).await?;
    let items: Vec<serde_json::Value> = rows.iter().map(|s| serde_json::json!({
        "sid": s.sid, "deviceName": s.device_name, "userAgent": s.user_agent,
        "loginAt": s.login_at, "lastSeenAt": s.last_seen_at, "revoked": s.revoked
    })).collect();
    Ok(Json(serde_json::json!({"success":true,"message":null,"data":items})))
}

/// DELETE /api/auth/me/devices/{sid}
pub async fn revoke_device(State(state): State<Arc<AppState>>, Extension(claims): Extension<Claims>, Path(sid): Path<String>) -> Result<Json<serde_json::Value>> {
    sqlx::query("UPDATE user_sessions SET revoked=TRUE, updated_at=NOW() WHERE user_id=? AND sid=?")
        .bind(claims.user_id()).bind(sid).execute(&state.db).await?;
    Ok(Json(serde_json::json!({"success":true,"message":"device removed","data":null})))
}

#[derive(Debug, Deserialize)]
pub struct ChangePasswordRequest {
    #[serde(rename = "oldPassword")]
    pub old_password: String,
    #[serde(rename = "newPassword")]
    pub new_password: String,
}

/// POST /api/auth/change-password
pub async fn change_password(State(state): State<Arc<AppState>>, Extension(claims): Extension<Claims>, Json(req): Json<ChangePasswordRequest>) -> Result<Json<serde_json::Value>> {
    let u = sqlx::query_as::<sqlx::MySql, User>("SELECT * FROM users WHERE id=?").bind(claims.user_id())
        .fetch_one(&state.db).await?;
    let ok = password::verify_password(&req.old_password, &u.password_hash)?;
    if !ok { return Err(AppError::BadRequest("old password incorrect".into())); }
    if req.new_password.len() < 8 { return Err(AppError::BadRequest("new password too short".into())); }
    let hash = password::hash_password(&req.new_password)?;
    sqlx::query("UPDATE users SET password_hash=?, updated_at=NOW() WHERE id=?").bind(hash).bind(u.id).execute(&state.db).await?;
    Ok(Json(serde_json::json!({"success":true,"message":"password changed","data":null})))
}

#[derive(Debug, Deserialize)]
pub struct ChangeEmailSend { #[serde(rename = "newEmail")] pub new_email: Option<String> }

/// POST /api/auth/change-email/send
pub async fn change_email_send(State(state): State<Arc<AppState>>, Extension(claims): Extension<Claims>, Json(req): Json<ChangeEmailSend>) -> Result<Json<serde_json::Value>> {
    let email = req.new_email.unwrap_or_default();
    if email.is_empty() { return Err(AppError::BadRequest("email required".into())); }
    use rand::Rng;
    let code: u32 = rand::thread_rng().gen_range(100000..=999999);
    let key = format!("emailchange:{}:{}", claims.user_id(), email.to_lowercase());
    let mut conn = state.redis.clone();
    // SMTP not configured; email change codes unavailable in Rust build
    return Err(AppError::Internal("email service not configured".into()));
    tracing::warn!("CHANGE EMAIL CODE for {} is {}", email, code);
    Ok(Json(serde_json::json!({"success":true,"message":"code sent","data":null})))
}

#[derive(Debug, Deserialize)]
pub struct ChangeEmail { #[serde(rename = "newEmail")] pub new_email: Option<String>, pub code: Option<String> }

/// POST /api/auth/change-email
pub async fn change_email(State(state): State<Arc<AppState>>, Extension(claims): Extension<Claims>, Json(req): Json<ChangeEmail>) -> Result<Json<serde_json::Value>> {
    let email = req.new_email.unwrap_or_default();
    let code = req.code.unwrap_or_default();
    if email.is_empty() || code.is_empty() { return Err(AppError::BadRequest("email and code required".into())); }
    let key = format!("emailchange:{}:{}", claims.user_id(), email.to_lowercase());
    let mut conn = state.redis.clone();
    let stored: Option<String> = None;
    match stored {
        Some(s) if s == code => {}
        _ => return Err(AppError::BadRequest("invalid code".into())),
    }
    sqlx::query("UPDATE users SET email=?, email_verified=TRUE, updated_at=NOW() WHERE id=?")
        .bind(email).bind(claims.user_id()).execute(&state.db).await?;
    Ok(Json(serde_json::json!({"success":true,"message":"email changed","data":null})))
}

#[derive(Debug, Deserialize)]
pub struct UpdateMeRequest {
    pub username: Option<String>,
    pub nickname: Option<String>,
    pub signature: Option<String>,
    #[serde(rename = "avatarUrl")]
    pub avatar_url: Option<String>,
}

/// PUT /api/auth/me
pub async fn update_me(State(state): State<Arc<AppState>>, Extension(claims): Extension<Claims>, Json(req): Json<UpdateMeRequest>) -> Result<Json<serde_json::Value>> {
    let me = claims.user_id();
    if let Some(v) = &req.username { if !v.is_empty() { sqlx::query("UPDATE users SET username=?,updated_at=NOW() WHERE id=?").bind(v).bind(me).execute(&state.db).await?; } }
    if let Some(v) = &req.nickname { sqlx::query("UPDATE users SET nickname=?,updated_at=NOW() WHERE id=?").bind(v).bind(me).execute(&state.db).await?; }
    if let Some(v) = &req.signature { sqlx::query("UPDATE users SET signature=?,updated_at=NOW() WHERE id=?").bind(v).bind(me).execute(&state.db).await?; }
    if let Some(v) = &req.avatar_url { sqlx::query("UPDATE users SET avatar_url=?,updated_at=NOW() WHERE id=?").bind(v).bind(me).execute(&state.db).await?; }
    get_profile(State(state), Extension(claims)).await
}
