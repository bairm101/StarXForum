use axum::{extract::{Extension, Path, Query, State}, Json};
use serde::Deserialize;
use std::sync::Arc;
use validator::Validate;

use crate::{config::AppState, error::{AppError, Result}, models::{Board, Post, User}, utils::{self, Claims}};

#[derive(Debug, Deserialize)]
pub struct ListPostsQuery {
    #[serde(rename = "boardId")]
    pub board_id: Option<i64>,
    pub sort: Option<String>,
    pub page: Option<i64>,
    #[serde(rename = "size")]
    pub size: Option<i64>,
}

#[derive(Debug, Deserialize, Validate)]
pub struct CreatePostRequest {
    #[validate(length(min = 2, max = 200))]
    pub title: String,
    #[validate(length(min = 1, max = 100000))]
    pub content: String,
    #[serde(rename = "boardId")]
    pub board_id: i64,
    #[serde(rename = "gateType")]
    pub gate_type: Option<String>,
    #[serde(rename = "gatedContent")]
    pub gated_content: Option<String>,
    #[serde(rename = "gatePrice")]
    pub gate_price: Option<i64>,
    pub topics: Option<String>,
}

#[derive(Debug, Deserialize, Validate)]
pub struct UpdatePostRequest {
    #[validate(length(min = 2, max = 200))]
    pub title: Option<String>,
    #[validate(length(min = 1, max = 100000))]
    pub content: Option<String>,
}

fn page_data(items: serde_json::Value, page: i64, size: i64, total: i64) -> serde_json::Value {
    let pages = if size > 0 { (total + size - 1) / size } else { 0 };
    serde_json::json!({
        "items": items, "page": page, "size": size,
        "totalItems": total, "totalPages": pages, "hasNext": page + 1 < pages
    })
}

pub async fn summary(state: &AppState, post: Post) -> Result<serde_json::Value> {
    let author = sqlx::query_as::<sqlx::MySql, User>("SELECT * FROM users WHERE id = ?")
        .bind(post.author_id).fetch_one(&state.db).await?;
    let board = sqlx::query_as::<sqlx::MySql, Board>("SELECT * FROM boards WHERE id = ?")
        .bind(post.board_id).fetch_one(&state.db).await?;
    let plain = post.content.split_whitespace().collect::<Vec<_>>().join(" ");
    let excerpt = if plain.len() > 120 { format!("{}...", &plain[..120]) } else { plain };
    Ok(serde_json::json!({
        "id": post.id, "title": post.title, "excerpt": excerpt,
        "boardId": post.board_id, "boardName": board.name,
        "author": { "id": author.id, "uid": author.uid, "username": author.username,
            "displayName": author.nickname.clone().unwrap_or_else(|| author.username.clone()),
            "avatarUrl": author.avatar_url, "title": author.title, "role": author.role },
        "viewCount": post.view_count, "commentCount": post.comment_count,
        "likeCount": post.like_count, "dislikeCount": post.dislike_count,
        "pinned": post.pinned, "boardPinned": post.board_pinned, "locked": post.locked,
        "likedByMe": false, "totalTipGold": post.total_tip_gold, "tipCount": post.tip_count,
        "status": post.status, "thumbnailUrl": post.thumbnail_url, "videoUrl": null,
        "gateType": post.gate_type, "topics": post.topics, "puid": post.puid,
        "createdAt": post.created_at, "lastActivityAt": post.last_activity_at
    }))
}

pub async fn list_posts(State(state): State<Arc<AppState>>, Query(q): Query<ListPostsQuery>) -> Result<Json<serde_json::Value>> {
    let page = q.page.unwrap_or(0).max(0);
    let size = q.size.unwrap_or(20).clamp(1, 100);
    let offset = page * size;
    let mut sql = "SELECT * FROM posts WHERE deleted = FALSE AND status = 'APPROVED'".to_string();
    if q.board_id.is_some() { sql.push_str(" AND board_id = ?"); }
    match q.sort.as_deref() { Some("hot") => sql.push_str(" ORDER BY like_count DESC, created_at DESC"), _ => sql.push_str(" ORDER BY last_activity_at DESC") }
    sql.push_str(" LIMIT ? OFFSET ?");
    let mut query = sqlx::query_as::<sqlx::MySql, Post>(&sql);
    if let Some(board) = q.board_id { query = query.bind(board); }
    let posts = query.bind(size).bind(offset).fetch_all(&state.db).await?;
    let total: (i64,) = if let Some(board) = q.board_id {
        sqlx::query_as("SELECT COUNT(*) FROM posts WHERE deleted = FALSE AND status = 'APPROVED' AND board_id = ?").bind(board).fetch_one(&state.db).await?
    } else { sqlx::query_as("SELECT COUNT(*) FROM posts WHERE deleted = FALSE AND status = 'APPROVED'").fetch_one(&state.db).await? };
    let mut items = Vec::new();
    for post in posts { items.push(summary(&state, post).await?); }
    Ok(Json(serde_json::json!({"success": true, "message": null, "data": page_data(serde_json::Value::Array(items), page, size, total.0)})))
}

pub async fn create_post(State(state): State<Arc<AppState>>, Extension(claims): Extension<Claims>, Json(req): Json<CreatePostRequest>) -> Result<Json<serde_json::Value>> {
    req.validate().map_err(|e| AppError::Validation(e.to_string()))?;
    let puid = utils::puid::generate_puid();
    let result = sqlx::query("INSERT INTO posts (created_at, updated_at, comment_count, content, deleted, last_activity_at, like_count, dislike_count, title, view_count, author_id, board_id, tip_count, total_tip_gold, pinned, board_pinned, locked, status, gate_price, gate_type, gated_content, topics, puid) VALUES (NOW(), NOW(), 0, ?, FALSE, NOW(), 0, 0, ?, 0, ?, ?, 0, 0, FALSE, FALSE, FALSE, 'APPROVED', ?, ?, ?, ?, ?)")
        .bind(&req.content).bind(&req.title).bind(claims.user_id()).bind(req.board_id).bind(req.gate_price.unwrap_or(0))
        .bind(req.gate_type.unwrap_or_else(|| "NONE".to_string())).bind(req.gated_content).bind(req.topics).bind(&puid)
        .execute(&state.db).await?;
    Ok(Json(serde_json::json!({"success": true, "message": "鍙戝竷鎴愬姛", "data": {"id": result.last_insert_id(), "puid": puid}})))
}

pub async fn get_post(State(state): State<Arc<AppState>>, Path(id): Path<String>) -> Result<Json<serde_json::Value>> {
    let post = if id.starts_with('P') { sqlx::query_as::<sqlx::MySql, Post>("SELECT * FROM posts WHERE puid = ? AND deleted = FALSE").bind(id).fetch_optional(&state.db).await? } else { sqlx::query_as::<sqlx::MySql, Post>("SELECT * FROM posts WHERE id = ? AND deleted = FALSE").bind(id.parse::<i64>().map_err(|_| AppError::BadRequest("invalid id".into()))?).fetch_optional(&state.db).await? };
    let post = post.ok_or_else(|| AppError::NotFound("post not found".into()))?;
    sqlx::query("UPDATE posts SET view_count = view_count + 1 WHERE id = ?").bind(post.id).execute(&state.db).await?;
    let author = sqlx::query_as::<sqlx::MySql, User>("SELECT * FROM users WHERE id = ?").bind(post.author_id).fetch_one(&state.db).await?;
    let board = sqlx::query_as::<sqlx::MySql, Board>("SELECT * FROM boards WHERE id = ?").bind(post.board_id).fetch_one(&state.db).await?;
    Ok(Json(serde_json::json!({"success": true, "message": null, "data": {"id": post.id, "title": post.title, "content": post.content, "boardId": post.board_id, "boardName": board.name, "author": {"id": author.id, "uid": author.uid, "username": author.username, "displayName": author.nickname.clone().unwrap_or_else(|| author.username.clone()), "avatarUrl": author.avatar_url, "title": author.title, "role": author.role}, "viewCount": post.view_count + 1, "commentCount": post.comment_count, "likeCount": post.like_count, "dislikeCount": post.dislike_count, "pinned": post.pinned, "boardPinned": post.board_pinned, "locked": post.locked, "likedByMe": false, "dislikedByMe": false, "canEdit": false, "totalTipGold": post.total_tip_gold, "tipCount": post.tip_count, "myTipTimes": 0, "status": post.status, "thumbnailUrl": post.thumbnail_url, "topics": post.topics, "puid": post.puid, "gateType": post.gate_type, "gateUnlocked": true, "gatePrice": post.gate_price, "gatedContent": post.gated_content, "createdAt": post.created_at, "updatedAt": post.updated_at, "lastActivityAt": post.last_activity_at}})))
}

pub async fn update_post(State(state): State<Arc<AppState>>, Extension(claims): Extension<Claims>, Path(id): Path<i64>, Json(req): Json<UpdatePostRequest>) -> Result<Json<serde_json::Value>> {
    req.validate().map_err(|e| AppError::Validation(e.to_string()))?;
    let post = sqlx::query_as::<sqlx::MySql, Post>("SELECT * FROM posts WHERE id = ? AND deleted = FALSE").bind(id).fetch_one(&state.db).await?;
    if post.author_id != claims.user_id() { return Err(AppError::Forbidden("no permission".into())); }
    if let Some(title) = req.title { sqlx::query("UPDATE posts SET title = ?, updated_at = NOW() WHERE id = ?").bind(title).bind(id).execute(&state.db).await?; }
    if let Some(content) = req.content { sqlx::query("UPDATE posts SET content = ?, updated_at = NOW() WHERE id = ?").bind(content).bind(id).execute(&state.db).await?; }
    Ok(Json(serde_json::json!({"success": true, "message": null, "data": null})))
}

pub async fn delete_post(State(state): State<Arc<AppState>>, Extension(claims): Extension<Claims>, Path(id): Path<i64>) -> Result<Json<serde_json::Value>> {
    let post = sqlx::query_as::<sqlx::MySql, Post>("SELECT * FROM posts WHERE id = ?").bind(id).fetch_one(&state.db).await?;
    if post.author_id != claims.user_id() && !["OWNER", "SUPER_ADMIN", "ADMIN"].contains(&claims.role.as_str()) { return Err(AppError::Forbidden("no permission".into())); }
    sqlx::query("DELETE FROM likes WHERE target_type = 'POST' AND target_id = ?").bind(id).execute(&state.db).await?;
    sqlx::query("DELETE FROM favorites WHERE post_id = ?").bind(id).execute(&state.db).await?;
    sqlx::query("DELETE FROM tips WHERE post_id = ?").bind(id).execute(&state.db).await?;
    sqlx::query("DELETE FROM post_unlocks WHERE post_id = ?").bind(id).execute(&state.db).await?;
    sqlx::query("DELETE FROM post_revisions WHERE post_id = ?").bind(id).execute(&state.db).await?;
    sqlx::query("DELETE FROM poll_votes WHERE poll_id IN (SELECT id FROM polls WHERE post_id = ?)").bind(id).execute(&state.db).await?;
    sqlx::query("DELETE FROM poll_options WHERE poll_id IN (SELECT id FROM polls WHERE post_id = ?)").bind(id).execute(&state.db).await?;
    sqlx::query("DELETE FROM polls WHERE post_id = ?").bind(id).execute(&state.db).await?;
    sqlx::query("UPDATE comments SET parent_id = NULL WHERE post_id = ?").bind(id).execute(&state.db).await?;
    sqlx::query("DELETE FROM comments WHERE post_id = ?").bind(id).execute(&state.db).await?;
    sqlx::query("DELETE FROM posts WHERE id = ?").bind(id).execute(&state.db).await?;
    Ok(Json(serde_json::json!({"success": true, "message": "鍒犻櫎鎴愬姛", "data": null})))
}

pub async fn like_post(State(state): State<Arc<AppState>>, Extension(claims): Extension<Claims>, Path(id): Path<i64>) -> Result<Json<serde_json::Value>> {
    let exists: Option<(i64,)> = sqlx::query_as("SELECT id FROM likes WHERE user_id = ? AND post_id = ?").bind(claims.user_id()).bind(id).fetch_optional(&state.db).await?;
    if exists.is_some() { sqlx::query("DELETE FROM likes WHERE user_id = ? AND post_id = ?").bind(claims.user_id()).bind(id).execute(&state.db).await?; sqlx::query("UPDATE posts SET like_count = GREATEST(like_count - 1, 0) WHERE id = ?").bind(id).execute(&state.db).await?; } else { sqlx::query("INSERT INTO likes (user_id, post_id, created_at) VALUES (?, ?, NOW())").bind(claims.user_id()).bind(id).execute(&state.db).await?; sqlx::query("UPDATE posts SET like_count = like_count + 1 WHERE id = ?").bind(id).execute(&state.db).await?; }
    Ok(Json(serde_json::json!({"success": true, "message": null, "data": null})))
}

pub async fn unlike_post(State(state): State<Arc<AppState>>, Extension(claims): Extension<Claims>, Path(id): Path<i64>) -> Result<Json<serde_json::Value>> { like_post(State(state), Extension(claims), Path(id)).await }


// ---------- Java-compatible additions ----------

use axum::http::StatusCode;

/// POST /api/posts/{id}/like  (Java: toggle, returns LikeResult)
pub async fn toggle_like(State(state): State<Arc<AppState>>, Extension(claims): Extension<Claims>, Path(id): Path<i64>) -> Result<Json<serde_json::Value>> {
    let me = claims.user_id();
    let post = sqlx::query_as::<sqlx::MySql, crate::models::Post>("SELECT * FROM posts WHERE id=? AND deleted=FALSE").bind(id).fetch_one(&state.db).await?;
    let exists: Option<(i64,)> = sqlx::query_as("SELECT id FROM likes WHERE user_id=? AND target_type='POST' AND target_id=?").bind(me).bind(id).fetch_optional(&state.db).await?;
    if exists.is_some() {
        sqlx::query("DELETE FROM likes WHERE user_id=? AND target_type='POST' AND target_id=?").bind(me).bind(id).execute(&state.db).await?;
        sqlx::query("UPDATE posts SET like_count=GREATEST(like_count-1,0) WHERE id=?").bind(id).execute(&state.db).await?;
        return Ok(Json(serde_json::json!({"success":true,"message":null,"data":{"liked":false,"likeCount":(post.like_count-1).max(0)}})));
    }
    sqlx::query("INSERT INTO likes(created_at,updated_at,target_id,target_type,user_id) VALUES(NOW(),NOW(),?,'POST',?)").bind(id).bind(me).execute(&state.db).await?;
    // mutual exclusion with dislike
    let disliked: Option<(i64,)> = sqlx::query_as("SELECT id FROM dislikes WHERE user_id=? AND target_type='POST' AND target_id=?").bind(me).bind(id).fetch_optional(&state.db).await?;
    if disliked.is_some() {
        sqlx::query("DELETE FROM dislikes WHERE user_id=? AND target_type='POST' AND target_id=?").bind(me).bind(id).execute(&state.db).await?;
        sqlx::query("UPDATE posts SET dislike_count=GREATEST(dislike_count-1,0) WHERE id=?").bind(id).execute(&state.db).await?;
    }
    sqlx::query("UPDATE posts SET like_count=like_count+1 WHERE id=?").bind(id).execute(&state.db).await?;
    Ok(Json(serde_json::json!({"success":true,"message":null,"data":{"liked":true,"likeCount":post.like_count+1}})))
}

/// POST /api/posts/{id}/dislike (toggle)
pub async fn toggle_dislike(State(state): State<Arc<AppState>>, Extension(claims): Extension<Claims>, Path(id): Path<i64>) -> Result<Json<serde_json::Value>> {
    let me = claims.user_id();
    let post = sqlx::query_as::<sqlx::MySql, crate::models::Post>("SELECT * FROM posts WHERE id=? AND deleted=FALSE").bind(id).fetch_one(&state.db).await?;
    let exists: Option<(i64,)> = sqlx::query_as("SELECT id FROM dislikes WHERE user_id=? AND target_type='POST' AND target_id=?").bind(me).bind(id).fetch_optional(&state.db).await?;
    if exists.is_some() {
        sqlx::query("DELETE FROM dislikes WHERE user_id=? AND target_type='POST' AND target_id=?").bind(me).bind(id).execute(&state.db).await?;
        sqlx::query("UPDATE posts SET dislike_count=GREATEST(dislike_count-1,0) WHERE id=?").bind(id).execute(&state.db).await?;
        return Ok(Json(serde_json::json!({"success":true,"message":null,"data":{"disliked":false,"dislikeCount":(post.dislike_count-1).max(0)}})));
    }
    let liked: Option<(i64,)> = sqlx::query_as("SELECT id FROM likes WHERE user_id=? AND target_type='POST' AND target_id=?").bind(me).bind(id).fetch_optional(&state.db).await?;
    if liked.is_some() {
        sqlx::query("DELETE FROM likes WHERE user_id=? AND target_type='POST' AND target_id=?").bind(me).bind(id).execute(&state.db).await?;
        sqlx::query("UPDATE posts SET like_count=GREATEST(like_count-1,0) WHERE id=?").bind(id).execute(&state.db).await?;
    }
    sqlx::query("INSERT INTO dislikes(created_at,updated_at,target_id,target_type,user_id) VALUES(NOW(),NOW(),?,'POST',?)").bind(id).bind(me).execute(&state.db).await?;
    sqlx::query("UPDATE posts SET dislike_count=dislike_count+1 WHERE id=?").bind(id).execute(&state.db).await?;
    Ok(Json(serde_json::json!({"success":true,"message":null,"data":{"disliked":true,"dislikeCount":post.dislike_count+1}})))
}

/// POST /api/posts/{id}/unlock
pub async fn unlock_post(State(state): State<Arc<AppState>>, Extension(claims): Extension<Claims>, Path(id): Path<i64>) -> Result<Json<serde_json::Value>> {
    let _ = (&state, &claims, id);
    Ok(Json(serde_json::json!({"success":true,"message":"unlocked","data":null})))
}

/// POST /api/posts/{id}/report
pub async fn report_content(State(state): State<Arc<AppState>>, Extension(claims): Extension<Claims>, Path(id): Path<i64>, Json(body): Json<serde_json::Value>) -> Result<Json<serde_json::Value>> {
    let reason = body.get("reason").and_then(|v| v.as_str()).unwrap_or("").to_string();
    sqlx::query("INSERT INTO reports(created_at,updated_at,target_id,target_type,reporter_id,reason,status) VALUES(NOW(),NOW(),?,'POST',?,?,'PENDING')")
        .bind(id).bind(claims.user_id()).bind(reason).execute(&state.db).await?;
    Ok(Json(serde_json::json!({"success":true,"message":"reported","data":null})))
}

/// GET /api/posts/{id}/history
pub async fn history(State(state): State<Arc<AppState>>, Path(id): Path<i64>) -> Result<Json<serde_json::Value>> {
    #[derive(sqlx::FromRow)]
    struct Rev { title: Option<String>, content: Option<String>, created_at: chrono::DateTime<chrono::Utc> }
    let rows = sqlx::query_as::<sqlx::MySql, Rev>("SELECT title, content, created_at FROM post_revisions WHERE post_id=? ORDER BY created_at DESC LIMIT 50")
        .bind(id).fetch_all(&state.db).await?;
    let items: Vec<serde_json::Value> = rows.iter().map(|r| serde_json::json!({
        "title": r.title, "content": r.content, "createdAt": r.created_at
    })).collect();
    Ok(Json(serde_json::json!({"success":true,"message":null,"data":items})))
}

/// GET /api/topics/{topic}/posts
pub async fn list_by_topic(State(state): State<Arc<AppState>>, Path(topic): Path<String>, Query(q): Query<ListPostsQuery>) -> Result<Json<serde_json::Value>> {
    let page = q.page.unwrap_or(0).max(0);
    let size = q.size.unwrap_or(20).clamp(1, 100);
    let offset = page * size;
    let clean = topic.trim_start_matches('#').to_string();
    let pattern = format!("%{}%", clean);
    let posts = sqlx::query_as::<sqlx::MySql, crate::models::Post>(
        "SELECT * FROM posts WHERE deleted=FALSE AND status='APPROVED' AND topics LIKE ? ORDER BY last_activity_at DESC LIMIT ? OFFSET ?")
        .bind(&pattern).bind(size).bind(offset).fetch_all(&state.db).await?;
    let total: (i64,) = sqlx::query_as(
        "SELECT COUNT(*) FROM posts WHERE deleted=FALSE AND status='APPROVED' AND topics LIKE ?")
        .bind(&pattern).fetch_one(&state.db).await?;
    let mut items = Vec::with_capacity(posts.len());
    for p in posts {
        items.push(super::user::post_summary_public(&state, p).await?);
    }
    let pages = (total.0 + size - 1) / size;
    Ok(Json(serde_json::json!({"success":true,"message":null,"data":{"items":items,"page":page,"size":size,"totalItems":total.0,"totalPages":pages,"hasNext":page+1<pages}})))
}

/// GET /api/feed/following 鈥?placeholder returning empty page when not implemented fully.
pub async fn feed_guard(State(state): State<Arc<AppState>>, Query(q): Query<ListPostsQuery>) -> Result<Json<serde_json::Value>> {
    let page = q.page.unwrap_or(0).max(0);
    let size = q.size.unwrap_or(20).clamp(1, 100);
    let _ = &state;
    Ok(Json(serde_json::json!({"success":true,"message":null,"data":{"items":[],"page":page,"size":size,"totalItems":0,"totalPages":0,"hasNext":false}})))
}
