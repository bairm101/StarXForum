mod config;
mod error;
mod handlers;
mod middleware;
mod models;
mod services;
mod utils;

use axum::{middleware as axum_middleware, routing::{delete, get, patch, post, put}, Router};
use std::sync::Arc;
use tower_http::{compression::CompressionLayer, cors::CorsLayer, services::ServeDir, trace::TraceLayer};

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    dotenv::dotenv().ok();
    tracing_subscriber::fmt()
        .with_env_filter(tracing_subscriber::EnvFilter::try_from_default_env().unwrap_or_else(|_| "info".into()))
        .init();

    let config = config::Config::from_env()?;
    let db = config::database::create_pool(&config.database_url, config.db_max_connections).await?;
    let redis = redis::Client::open(config.redis_url.as_str())?.get_connection_manager().await?;
    let state = Arc::new(config::AppState { db, redis, config: config.clone() });

    let public = Router::new()
        .route("/", get(handlers::root::root))
        .route("/health", get(handlers::health::health_check))
        .route("/api/health", get(handlers::health::health_check))
        // auth (public)
        .route("/api/auth/register", post(handlers::auth::register))
        .route("/api/auth/login", post(handlers::auth::login))
        .route("/api/auth/verify-device", post(handlers::auth::verify_device_stub))
        // verification
        .route("/api/verification/challenge", get(handlers::verification::challenge))
        .route("/api/verification/email/code", post(handlers::verification::email_code))
        // boards
        .route("/api/boards", get(handlers::board::list_boards))
        .route("/api/boards/:id", get(handlers::board::get_board))
        .route("/api/boards/:id/posts", get(handlers::board::get_board_posts))
        // posts
        .route("/api/posts", get(handlers::post::list_posts))
        .route("/api/posts/:id", get(handlers::post::get_post))
        .route("/api/posts/:id/comments", get(handlers::comment::list_comments))
        .route("/api/posts/:id/poll", get(handlers::poll::get_poll_by_post))
        .route("/api/posts/puid/:puid", get(handlers::post::get_post))
        .route("/api/topics/:topic/posts", get(handlers::post::list_by_topic))
        // users
        .route("/api/users/by-uid/:uid", get(handlers::social::by_uid))
        .route("/api/users/by-name/:name", get(handlers::social::by_name))
        .route("/api/users/:id", get(handlers::user::get_user))
        .route("/api/users/:id/profile", get(handlers::social::profile))
        .route("/api/users/:id/posts", get(handlers::user::get_user_posts))
        .route("/api/users/:id/comments", get(handlers::comment::list_comments))
        .route("/api/users/:id/following", get(handlers::user::get_following))
        .route("/api/users/:id/followers", get(handlers::user::get_followers))
        .route("/api/users/:id/follow-status", get(handlers::social::follow_status))
        // search / settings / polls
        .route("/api/search", get(handlers::search::search))
        .route("/api/search/trending", get(handlers::search::trending_searches))
        .route("/api/settings", get(handlers::site::get_config))
        .route("/api/polls/:id", get(handlers::poll::get_poll))
        // media & uploads static
        .route("/media/:code", get(handlers::media::get_media));

    let protected = Router::new()
        .route("/api/feed/following", get(handlers::post::feed_guard))
        // auth
        .route("/api/auth/logout", post(handlers::auth::logout))
        .route("/api/auth/me/logout-all", post(handlers::auth::logout_all_devices))
        .route("/api/auth/refresh", post(handlers::auth::refresh_token))
        .route("/api/auth/profile", get(handlers::auth::get_profile))
        .route("/api/auth/me", get(handlers::auth::get_profile))
        .route("/api/auth/me", put(handlers::auth::update_me))
        .route("/api/auth/me/devices", get(handlers::auth::my_devices))
        .route("/api/auth/me/devices/:sid", delete(handlers::auth::revoke_device))
        .route("/api/auth/change-password", post(handlers::auth::change_password))
        .route("/api/auth/change-email/send", post(handlers::auth::change_email_send))
        .route("/api/auth/change-email", post(handlers::auth::change_email))
        // posts write
        .route("/api/posts", post(handlers::post::create_post))
        .route("/api/posts/:id", put(handlers::post::update_post))
        .route("/api/posts/:id", delete(handlers::post::delete_post))
        .route("/api/posts/:id/like", post(handlers::post::toggle_like))
        .route("/api/posts/:id/unlike", post(handlers::post::unlike_post))
        .route("/api/posts/:id/dislike", post(handlers::post::toggle_dislike))
        .route("/api/posts/:id/tip", post(handlers::checkin::tip))
        .route("/api/posts/:id/unlock", post(handlers::post::unlock_post))
        .route("/api/posts/:id/report", post(handlers::post::report_content))
        .route("/api/posts/:id/history", get(handlers::post::history))
        // comments
        .route("/api/posts/:id/comments", post(handlers::comment::create_comment))
        .route("/api/comments/:id", put(handlers::comment::update_comment))
        .route("/api/comments/:id", delete(handlers::comment::delete_comment))
        .route("/api/comments/:id/like", post(handlers::comment::like_comment))
        .route("/api/comments/:id/dislike", post(handlers::comment::dislike_comment))
        .route("/api/comments/:id/report", post(handlers::comment::report_comment))
        // favorites (Java style toggle)
        .route("/api/favorites/toggle/:id", post(handlers::favorite::toggle_favorite))
        .route("/api/favorites/check/:id", get(handlers::favorite::check_favorite))
        .route("/api/favorites/mine", get(handlers::favorite::list_favorites))
        .route("/api/favorites", get(handlers::favorite::list_favorites))
        // social
        .route("/api/users/:id/follow", post(handlers::social::toggle_follow))
        .route("/api/users/:id/unfollow", post(handlers::user::unfollow_alias))
        .route("/api/users/:id/block", post(handlers::social::toggle_block))
        .route("/api/users/:id/blocks", get(handlers::social::blocks))
        .route("/api/users/:id/report", post(handlers::user::report_user))
        // messages
        .route("/api/messages", post(handlers::message::send_message))
        .route("/api/messages/conversations", get(handlers::message::list_conversations))
        .route("/api/messages/with/:peer_id", get(handlers::message::list_messages))
        .route("/api/messages/unread", get(handlers::message::unread_count))
        .route("/api/messages/read-all", post(handlers::message::read_all))
        .route("/api/messages/report", post(handlers::message::report_chat))
        .route("/api/messages/with/:peer_id", delete(handlers::message::delete_conversation))
        // notifications
        .route("/api/notifications", get(handlers::notification::list_notifications))
        .route("/api/notifications/unread", get(handlers::notification::unread_count))
        .route("/api/notifications/read-all", patch(handlers::notification::mark_all_read))
        .route("/api/notifications/:id/read", patch(handlers::notification::mark_read))
        .route("/api/notifications/settings", get(handlers::notification::get_settings))
        .route("/api/notifications/settings", patch(handlers::notification::update_settings))
        // checkin
        .route("/api/checkin/status", get(handlers::checkin::status))
        .route("/api/checkin", post(handlers::checkin::checkin))
        // polls
        .route("/api/polls/:id/vote", post(handlers::poll::vote))
        // files upload (Java compatible)
        .route("/api/files/upload", post(handlers::files::upload_simple))
        .route("/api/files/media", post(handlers::files::upload_media))
        .route("/api/files/media/chunk", post(handlers::files::upload_chunk))
        .route("/api/files/media/chunk/complete", post(handlers::files::chunk_complete))
        .route("/api/upload", post(handlers::upload::upload_file))
        .route("/api/upload/list", get(handlers::upload::get_user_uploads))
        .layer(axum_middleware::from_fn_with_state(state.clone(), middleware::auth::auth_middleware));

    let admin = Router::new()
        .route("/api/admin/stats", get(handlers::admin::get_stats))
        .route("/api/admin/overview", get(handlers::admin::get_stats))
        .route("/api/admin/users/:id/ban", patch(handlers::admin::ban_user_patch))
        .route("/api/admin/users/:id/ban", post(handlers::admin::ban_user))
        .route("/api/admin/posts/:id", delete(handlers::admin::delete_post))
        .route("/api/admin/posts/:id/moderate", post(handlers::admin::moderate_post))
        .route("/api/admin/posts/pending", get(handlers::admin::pending_posts))
        .route("/api/admin/sensitive-words", get(handlers::admin::list_sensitive_words))
        .route("/api/admin/sensitive-words", post(handlers::admin::add_sensitive_word))
        .route("/api/admin/logs", get(handlers::admin::get_operation_logs))
        .route("/api/admin/users", get(handlers::admin::list_users))
        .route("/api/admin/users/:id/role", patch(handlers::admin::set_role))
        .route("/api/admin/users/:id/title", patch(handlers::admin::set_title))
        .route("/api/admin/users/:id/parameters", patch(handlers::admin::update_parameters))
        .route("/api/admin/users/:id/signature", post(handlers::admin::handle_signature))
        .route("/api/admin/users/:id/logout-all", post(handlers::admin::logout_all_user_devices))
        .route("/api/admin/posts", get(handlers::admin::admin_list_posts))
        .route("/api/admin/posts/:id/move", patch(handlers::admin::move_post))
        .route("/api/admin/settings", get(handlers::admin::get_settings))
        .route("/api/admin/settings", put(handlers::admin::put_settings))
        .route("/api/admin/boards", get(handlers::admin::admin_boards))
        .route("/api/admin/boards", post(handlers::admin::create_board))
        .route("/api/admin/boards/:id", put(handlers::admin::update_board))
        .route("/api/admin/boards/:id", delete(handlers::admin::delete_board))
        .route("/api/admin/reports", get(handlers::admin::list_reports))
        .route("/api/admin/reports/:id/resolve", post(handlers::admin::resolve_report_route))
        .route("/api/admin/reports/:id/reject", post(handlers::admin::reject_report_route))
        .route("/api/admin/maintenance/stats", get(handlers::admin::maintenance_stats))
        .route("/api/admin/maintenance/clear/:target", post(handlers::admin::maintenance_clear))
        .layer(axum_middleware::from_fn_with_state(state.clone(), middleware::auth::admin_middleware));

    // stats (staff only, same guard as admin)
    let stats = Router::new()
        .route("/api/stats/overview", get(handlers::stats::overview))
        .route("/api/stats/daily/registrations", get(handlers::stats::registrations))
        .route("/api/stats/daily/posts", get(handlers::stats::posts))
        .route("/api/stats/daily/comments", get(handlers::stats::comments))
        .route("/api/stats/active-users", get(handlers::stats::active_users))
        .layer(axum_middleware::from_fn_with_state(state.clone(), middleware::auth::admin_middleware));

    let app = Router::new()
        .merge(public)
        .merge(protected)
        .merge(admin)
        .merge(stats)
        .nest_service("/uploads", ServeDir::new(&config.upload_dir))
        .with_state(state)
        .layer(TraceLayer::new_for_http())
        .layer(CompressionLayer::new())
        .layer(CorsLayer::permissive());

    let address = format!("{}:{}", config.server_host, config.server_port);
    let listener = tokio::net::TcpListener::bind(&address).await?;
    tracing::info!("Forum Rust listening on {}", address);
    axum::serve(listener, app).await?;
    Ok(())
}
