use argon2::{
    password_hash::{rand_core::OsRng, PasswordHash, PasswordHasher, PasswordVerifier, SaltString},
    Argon2,
};
use crate::error::{AppError, Result};

/// 使用 Argon2 哈希密码
pub fn hash_password(password: &str) -> Result<String> {
    let salt = SaltString::generate(&mut OsRng);
    let argon2 = Argon2::default();
    
    let password_hash = argon2
        .hash_password(password.as_bytes(), &salt)
        .map_err(|e| AppError::Internal(format!("Failed to hash password: {}", e)))?
        .to_string();
    
    Ok(password_hash)
}

/// 验证密码
pub fn verify_password(password: &str, password_hash: &str) -> Result<bool> {
    if password_hash.starts_with("$2a$") || password_hash.starts_with("$2b$") || password_hash.starts_with("$2y$") {
        return bcrypt::verify(password, password_hash)
            .map_err(|e| AppError::Internal(format!("Invalid password hash: {}", e)));
    }
    let parsed_hash = PasswordHash::new(password_hash)
        .map_err(|e| AppError::Internal(format!("Invalid password hash: {}", e)))?;
    
    Ok(Argon2::default()
        .verify_password(password.as_bytes(), &parsed_hash)
        .is_ok())
}
