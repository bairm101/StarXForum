use uuid::Uuid;

/// 生成帖子唯一ID (PUID)
/// 格式: P + 10位字符 (大写字母和数字)
pub fn generate_puid() -> String {
    let uuid = Uuid::new_v4();
    let hex = uuid.simple().to_string();
    
    // 取前10个字符，转大写
    let puid = format!("P{}", &hex[..10].to_uppercase());
    puid
}

/// 验证PUID格式
pub fn is_valid_puid(puid: &str) -> bool {
    if puid.len() != 11 {
        return false;
    }
    
    if !puid.starts_with('P') {
        return false;
    }
    
    puid[1..].chars().all(|c| c.is_ascii_alphanumeric())
}
