use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use sqlx::FromRow;

#[derive(Debug, Clone, Serialize, Deserialize, FromRow)]
pub struct User {
    pub id: i64,
    pub username: String,
    #[serde(skip_serializing)]
    pub password_hash: String,
    pub uid: Option<String>,
    pub email: Option<String>,
    pub nickname: Option<String>,
    pub avatar_url: Option<String>,
    pub signature: Option<String>,
    pub role: String,
    pub status: String,
    pub post_count: i32,
    pub comment_count: i32,
    pub level: i32,
    pub exp: i32,
    pub gold: i64,
    pub checkin_streak: i32,
    pub title: Option<String>,
    pub managed_board_id: Option<i64>,
    pub ranking_weight: f64,
    pub pending_signature: Option<String>,
    pub signature_approved_once: bool,
    pub email_verified: bool,
    pub max_upload_mb: Option<i32>,
    pub failed_login_count: i32,
    pub locked_until: Option<DateTime<Utc>>,
    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize, FromRow)]
pub struct Board {
    pub id: i64,
    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
    pub name: String,
    pub description: Option<String>,
    #[serde(rename = "sortOrder")]
    pub sort_order: i32,
    #[serde(rename = "postCount")]
    pub post_count: i32,
    pub visible: bool,
    pub require_moderation: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize, FromRow)]
pub struct Post {
    pub id: i64,
    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
    #[serde(rename = "commentCount")]
    pub comment_count: i32,
    pub content: String,
    pub deleted: bool,
    #[serde(rename = "lastActivityAt")]
    pub last_activity_at: DateTime<Utc>,
    #[serde(rename = "likeCount")]
    pub like_count: i32,
    #[serde(rename = "dislikeCount")]
    pub dislike_count: i32,
    pub title: String,
    #[serde(rename = "viewCount")]
    pub view_count: i32,
    pub author_id: i64,
    pub board_id: i64,
    #[serde(rename = "tipCount")]
    pub tip_count: i32,
    #[serde(rename = "totalTipGold")]
    pub total_tip_gold: i64,
    pub pinned: bool,
    #[serde(rename = "boardPinned")]
    pub board_pinned: bool,
    pub locked: bool,
    pub status: String,
    #[serde(rename = "gatePrice")]
    pub gate_price: i64,
    #[serde(rename = "gateType")]
    pub gate_type: String,
    #[serde(rename = "gatedContent")]
    pub gated_content: Option<String>,
    #[serde(rename = "thumbnailUrl")]
    pub thumbnail_url: Option<String>,
    pub topics: Option<String>,
    pub puid: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, FromRow)]
pub struct Comment {
    pub id: i64,
    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
    pub content: String,
    pub post_id: i64,
    pub author_id: i64,
    pub parent_id: Option<i64>,
    pub like_count: i32,
    pub dislike_count: i32,
    pub deleted: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize, FromRow)]
pub struct Favorite { pub id: i64, pub created_at: DateTime<Utc>, pub updated_at: DateTime<Utc>, pub post_id: i64, pub user_id: i64 }

#[derive(Debug, Clone, Serialize, Deserialize, FromRow)]
pub struct Follow { pub id: i64, pub created_at: DateTime<Utc>, pub updated_at: DateTime<Utc>, pub following_id: i64, pub user_id: i64 }

#[derive(Debug, Clone, Serialize, Deserialize, FromRow)]
pub struct Message {
    pub id: i64,
    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
    pub content: String,
    #[serde(rename = "conversationKey")]
    pub conversation_key: String,
    #[serde(rename = "deletedByRecipient")]
    pub deleted_by_recipient: bool,
    #[serde(rename = "deletedBySender")]
    pub deleted_by_sender: bool,
    #[serde(rename = "read")]
    pub read_flag: bool,
    #[serde(rename = "recipientId")]
    pub recipient_id: i64,
    #[serde(rename = "senderId")]
    pub sender_id: i64,
}

#[derive(Debug, Clone, Serialize, Deserialize, FromRow)]
pub struct Notification {
    pub id: i64,
    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
    pub content: String,
    #[serde(rename = "read")]
    pub read_flag: bool,
    #[serde(rename = "refId")]
    pub ref_id: Option<i64>,
    pub title: Option<String>,
    #[serde(rename = "type")]
    pub ntype: String,
    #[serde(rename = "userId")]
    pub user_id: i64,
}

#[derive(Debug, Clone, Serialize, Deserialize, FromRow)]
pub struct Poll { pub id: i64, pub created_at: DateTime<Utc>, pub updated_at: DateTime<Utc>, pub deadline: Option<DateTime<Utc>>, pub multiple: bool, pub post_id: i64, pub question: String }

#[derive(Debug, Clone, Serialize, Deserialize, FromRow)]
pub struct PollOption { pub id: i64, pub created_at: DateTime<Utc>, pub updated_at: DateTime<Utc>, #[serde(rename = "optionText")] pub option_text: String, pub poll_id: i64, #[serde(rename = "voteCount")] pub vote_count: i32 }

#[derive(Debug, Clone, Serialize, Deserialize, FromRow)]
pub struct PollVote { pub id: i64, pub created_at: DateTime<Utc>, pub updated_at: DateTime<Utc>, pub option_id: i64, pub poll_id: i64, pub user_id: i64 }

#[derive(Debug, Clone, Serialize, Deserialize, FromRow)]
pub struct SiteSettings {
    pub id: i64, pub allow_register: bool, pub announcement: Option<String>,
    pub site_description: Option<String>, pub site_name: String, pub updated_at: Option<DateTime<Utc>>,
    pub default_theme: Option<String>, pub footer_icp: Option<String>, pub footer_links_json: Option<String>,
    pub footer_text: Option<String>, pub page_title: Option<String>, pub official_website: Option<String>,
    pub web_share_base_url: Option<String>, pub contact_email: Option<String>, pub about_icp: Option<String>,
    pub auto_refresh_seconds: i32, pub email_verification_enabled: bool, pub device_verification_enabled: bool,
    pub arithmetic_email_enabled: bool, pub arithmetic_post_enabled: bool, pub arithmetic_comment_enabled: bool,
    pub smtp_enabled: bool, pub smtp_host: Option<String>, pub smtp_password: Option<String>, pub smtp_port: Option<i32>,
    pub smtp_ssl: bool, pub smtp_username: Option<String>, pub image_compress_enabled: bool,
    pub image_max_mb: i32, pub video_compress_enabled: bool, pub video_max_mb: i32,
    pub post_edit_audit_enabled: bool, pub role_upload_quota_json: Option<String>, pub signature_audit_mode: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, FromRow)]
pub struct SensitiveWord { pub id: i64, pub created_at: DateTime<Utc>, pub updated_at: DateTime<Utc>, pub enabled: bool, pub replacement: Option<String>, pub word: String }
