use axum::{
    extract::State,
    Json,
};
use std::sync::Arc;

use crate::{
    config::AppState,
    error::{AppError, Result},
    models::SiteSettings,
};

/// GET /api/settings - public site settings (Java SiteSettingsView shape)
pub async fn get_config(State(state): State<Arc<AppState>>) -> Result<Json<serde_json::Value>> {
    let s = sqlx::query_as::<sqlx::MySql, SiteSettings>(
        "SELECT * FROM site_settings ORDER BY id ASC LIMIT 1")
        .fetch_optional(&state.db).await?;

    let data = match s {
        Some(s) => serde_json::json!({
            "siteName": s.site_name,
            "siteDescription": s.site_description,
            "pageTitle": s.page_title,
            "announcement": s.announcement,
            "allowRegister": s.allow_register,
            "defaultTheme": s.default_theme,
            "footerText": s.footer_text,
            "footerIcp": s.footer_icp,
            "footerLinksJson": s.footer_links_json,
            "officialWebsite": s.official_website,
            "webShareBaseUrl": s.web_share_base_url,
            "contactEmail": s.contact_email,
            "aboutIcp": s.about_icp,
            "autoRefreshSeconds": s.auto_refresh_seconds,
            "emailVerificationEnabled": s.email_verification_enabled,
            "deviceVerificationEnabled": s.device_verification_enabled,
            "is_maintenance": false
        }),
        None => serde_json::json!({
            "siteName": "Forum",
            "siteDescription": "",
            "allowRegister": true,
            "is_maintenance": false
        }),
    };
    Ok(Json(serde_json::json!({"success":true,"message":null,"data":data})))
}

/// Load settings row as a flat tuple used by admin settings view.
#[allow(clippy::type_complexity)]
pub async fn load_settings(state: &AppState) -> Result<(
    String, Option<String>, Option<String>, Option<String>, bool, Option<String>,
    Option<String>, Option<String>, Option<String>, Option<String>,
    bool, bool, bool, bool,
    bool, Option<String>, Option<i32>, Option<String>, bool, bool,
    bool, bool, bool, bool,
    i32, i32, Option<String>, Option<String>, Option<String>, Option<String>, i32,
)> {
    let s = sqlx::query_as::<sqlx::MySql, SiteSettings>(
        "SELECT * FROM site_settings ORDER BY id ASC LIMIT 1")
        .fetch_optional(&state.db).await?;
    match s {
        Some(s) => Ok((
            s.site_name.clone(), s.page_title.clone(), s.site_description.clone(), s.announcement.clone(),
            s.allow_register, s.default_theme.clone(),
            s.footer_text.clone(), s.footer_icp.clone(), s.footer_links_json.clone(), s.signature_audit_mode.clone(),
            s.email_verification_enabled, s.arithmetic_email_enabled, s.arithmetic_post_enabled, s.arithmetic_comment_enabled,
            s.smtp_enabled, s.smtp_host.clone(), s.smtp_port, s.smtp_username.clone(),
            s.smtp_password.as_deref().map(|v| !v.is_empty()).unwrap_or(false), s.smtp_ssl,
            s.image_compress_enabled, s.video_compress_enabled, s.post_edit_audit_enabled, s.device_verification_enabled,
            s.image_max_mb, s.video_max_mb, s.official_website.clone(), s.web_share_base_url.clone(),
            s.contact_email.clone(), s.about_icp.clone(), s.auto_refresh_seconds,
        )),
        None => Err(AppError::NotFound("settings not found".into())),
    }
}
