use axum::{
    extract::{State, Path, Query, Extension},
    Json,
};
use serde::Deserialize;
use std::sync::Arc;
use validator::Validate;

use crate::{
    config::AppState,
    error::{AppError, Result},
    models::User,
    utils::Claims,
};

#[derive(Debug, Deserialize)]
pub struct ListMessagesQuery {
    pub page: Option<i64>,
    #[serde(rename = "size")]
    pub size: Option<i64>,
}

#[derive(Debug, Deserialize, Validate)]
pub struct SendMessageRequest {
    #[serde(rename = "recipientId")]
    pub recipient_id: i64,
    #[validate(length(min = 1, max = 2000))]
    pub content: String,
}

async fn author_brief(state: &AppState, id: i64) -> Result<serde_json::Value> {
    let u = sqlx::query_as::<sqlx::MySql, User>("SELECT * FROM users WHERE id=?")
        .bind(id).fetch_optional(&state.db).await?;
    match u {
        Some(u) => Ok(crate::handlers::user::author_brief_anon(&u)),
        None => Ok(serde_json::json!(null)),
    }
}

fn conv_key(a: i64, b: i64) -> String {
    // Java Message.buildConversationKey 兼容格式: "{lo}_{hi}"
    if a < b { format!("{}_{}", a, b) } else { format!("{}_{}", b, a) }
}

/// GET /api/messages/conversations
pub async fn list_conversations(
    State(state): State<Arc<AppState>>,
    Extension(claims): Extension<Claims>,
    Query(q): Query<std::collections::HashMap<String, String>>,
) -> Result<Json<serde_json::Value>> {
    let me = claims.user_id();
    let key_prefix = format!("%");
    let _ = key_prefix;

    // Find distinct conversation partners
    let rows: Vec<(i64,)> = sqlx::query_as(
        "SELECT DISTINCT CASE WHEN sender_id=? THEN recipient_id ELSE sender_id END AS peer
         FROM messages
         WHERE (sender_id=? AND deleted_by_sender=FALSE) OR (recipient_id=? AND deleted_by_recipient=FALSE)
         ORDER BY peer DESC"
    )
    .bind(me).bind(me).bind(me)
    .fetch_all(&state.db).await?;

    // Java orders by last message time; do it in SQL per peer (small scale OK)
    let mut items = Vec::with_capacity(rows.len());
    for (peer,) in rows {
        let last: Option<(String, bool, chrono::DateTime<chrono::Utc>, i64)> = sqlx::query_as(
            "SELECT content, read_flag, created_at, sender_id FROM messages
             WHERE (sender_id=? AND recipient_id=? AND deleted_by_sender=FALSE)
                OR (sender_id=? AND recipient_id=? AND deleted_by_recipient=FALSE)
             ORDER BY created_at DESC LIMIT 1"
        )
        .bind(me).bind(peer).bind(peer).bind(me)
        .fetch_optional(&state.db).await?;

        let unread: (i64,) = sqlx::query_as(
            "SELECT COUNT(*) FROM messages
             WHERE sender_id=? AND recipient_id=? AND read_flag=FALSE AND deleted_by_recipient=FALSE"
        )
        .bind(peer).bind(me)
        .fetch_one(&state.db).await?;

        if let Some((content, read_flag, last_at, last_sender)) = last {
            items.push(serde_json::json!({
                "conversationKey": conv_key(me, peer),
                "peer": author_brief(&state, peer).await?,
                "lastContent": content,
                "lastFromMe": last_sender == me,
                "lastRead": read_flag,
                "unreadCount": unread.0,
                "lastAt": last_at
            }));
        }
    }

    // sort by lastAt desc
    items.sort_by(|a, b| {
        let ta = a["lastAt"].as_str().unwrap_or("");
        let tb = b["lastAt"].as_str().unwrap_or("");
        tb.cmp(ta)
    });

    let limit: usize = q.get("limit").and_then(|v| v.parse().ok()).unwrap_or(20);
    items.truncate(limit);

    Ok(Json(serde_json::json!({"success":true,"message":null,"data":items})))
}

/// GET /api/messages/with/{peerId}
pub async fn list_messages(
    State(state): State<Arc<AppState>>,
    Extension(claims): Extension<Claims>,
    Path(peer_id): Path<i64>,
    Query(q): Query<ListMessagesQuery>,
) -> Result<Json<serde_json::Value>> {
    let me = claims.user_id();
    let page = q.page.unwrap_or(0).max(0);
    let size = q.size.unwrap_or(20).clamp(1, 100);
    let offset = page * size;

    struct MsgRow {
        id: i64,
        sender_id: i64,
        recipient_id: i64,
        content: String,
        read_flag: bool,
        created_at: chrono::DateTime<chrono::Utc>,
    }
    impl<'r> sqlx::FromRow<'r, sqlx::mysql::MySqlRow> for MsgRow {
        fn from_row(row: &'r sqlx::mysql::MySqlRow) -> std::result::Result<Self, sqlx::Error> {
            use sqlx::Row;
            Ok(MsgRow {
                id: row.try_get("id")?,
                sender_id: row.try_get("sender_id")?,
                recipient_id: row.try_get("recipient_id")?,
                content: row.try_get("content")?,
                read_flag: row.try_get::<bool, _>("read_flag")?,
                created_at: row.try_get("created_at")?,
            })
        }
    }

    let rows = sqlx::query_as::<sqlx::MySql, MsgRow>(
        "SELECT id, sender_id, recipient_id, content, read_flag, created_at FROM messages
         WHERE (sender_id=? AND recipient_id=? AND deleted_by_sender=FALSE)
            OR (sender_id=? AND recipient_id=? AND deleted_by_recipient=FALSE)
         ORDER BY created_at DESC LIMIT ? OFFSET ?"
    )
    .bind(me).bind(peer_id).bind(peer_id).bind(me).bind(size).bind(offset)
    .fetch_all(&state.db).await?;

    let total: (i64,) = sqlx::query_as(
        "SELECT COUNT(*) FROM messages
         WHERE (sender_id=? AND recipient_id=? AND deleted_by_sender=FALSE)
            OR (sender_id=? AND recipient_id=? AND deleted_by_recipient=FALSE)"
    )
    .bind(me).bind(peer_id).bind(peer_id).bind(me)
    .fetch_one(&state.db).await?;

    // mark incoming as read
    sqlx::query("UPDATE messages SET read_flag=TRUE WHERE sender_id=? AND recipient_id=? AND read_flag=FALSE")
        .bind(peer_id).bind(me).execute(&state.db).await?;

    let mut items = Vec::with_capacity(rows.len());
    for r in rows {
        let sender = author_brief(&state, r.sender_id).await?;
        let recipient = author_brief(&state, r.recipient_id).await?;
        items.push(serde_json::json!({
            "id": r.id, "sender": sender, "recipient": recipient, "content": r.content,
            "read": r.read_flag, "mine": r.sender_id == me, "createdAt": r.created_at
        }));
    }
    // Java returns ascending order within the page? Page sorted desc; keep desc.
    let pages = (total.0 + size - 1) / size;
    Ok(Json(serde_json::json!({"success":true,"message":null,"data":{"items":items,"page":page,"size":size,"totalItems":total.0,"totalPages":pages,"hasNext":page+1<pages}})))
}

/// POST /api/messages
pub async fn send_message(
    State(state): State<Arc<AppState>>,
    Extension(claims): Extension<Claims>,
    Json(req): Json<SendMessageRequest>,
) -> Result<Json<serde_json::Value>> {
    req.validate().map_err(|e| AppError::Validation(e.to_string()))?;
    let me = claims.user_id();
    if me == req.recipient_id { return Err(AppError::BadRequest("cannot message yourself".into())); }

    let exists: Option<(i64,)> = sqlx::query_as("SELECT id FROM users WHERE id=?")
        .bind(req.recipient_id).fetch_optional(&state.db).await?;
    if exists.is_none() { return Err(AppError::NotFound("recipient not found".into())); }

    let key = conv_key(me, req.recipient_id);
    let r = sqlx::query(
        "INSERT INTO messages(created_at,updated_at,content,conversation_key,deleted_by_recipient,deleted_by_sender,read_flag,recipient_id,sender_id) VALUES(NOW(),NOW(),?,?,FALSE,FALSE,FALSE,?,?)"
    ).bind(&req.content).bind(&key).bind(req.recipient_id).bind(me).execute(&state.db).await?;
    let mid = r.last_insert_id() as i64;

    let sender = author_brief(&state, me).await?;
    let recipient = author_brief(&state, req.recipient_id).await?;
    Ok(Json(serde_json::json!({"success":true,"message":"sent","data":{"id":mid,"sender":sender,"recipient":recipient,"content":req.content,"read":false,"mine":true,"createdAt":chrono::Utc::now()}})))
}

/// GET /api/messages/unread
pub async fn unread_count(State(state): State<Arc<AppState>>, Extension(claims): Extension<Claims>) -> Result<Json<serde_json::Value>> {
    let c: (i64,) = sqlx::query_as(
        "SELECT COUNT(*) FROM messages WHERE recipient_id=? AND read_flag=FALSE AND deleted_by_recipient=FALSE"
    ).bind(claims.user_id()).fetch_one(&state.db).await?;
    Ok(Json(serde_json::json!({"success":true,"message":null,"data":{"unread":c.0}})))
}

/// POST /api/messages/read-all
pub async fn read_all(State(state): State<Arc<AppState>>, Extension(claims): Extension<Claims>) -> Result<Json<serde_json::Value>> {
    sqlx::query("UPDATE messages SET read_flag=TRUE WHERE recipient_id=? AND read_flag=FALSE")
        .bind(claims.user_id()).execute(&state.db).await?;
    Ok(Json(serde_json::json!({"success":true,"message":"all marked","data":null})))
}

/// DELETE /api/messages/with/{peerId}
pub async fn delete_conversation(
    State(state): State<Arc<AppState>>,
    Extension(claims): Extension<Claims>,
    Path(peer_id): Path<i64>,
) -> Result<Json<serde_json::Value>> {
    let me = claims.user_id();
    sqlx::query("UPDATE messages SET deleted_by_sender=TRUE WHERE sender_id=? AND recipient_id=?")
        .bind(me).bind(peer_id).execute(&state.db).await?;
    sqlx::query("UPDATE messages SET deleted_by_recipient=TRUE WHERE sender_id=? AND recipient_id=?")
        .bind(peer_id).bind(me).execute(&state.db).await?;
    Ok(Json(serde_json::json!({"success":true,"message":"conversation deleted","data":null})))
}


// ---------- Java-compatible: report private chat with evidence ----------
#[derive(Debug, Deserialize)]
pub struct ReportChatRequest {
    #[serde(rename = "peerId")]
    pub peer_id: i64,
    #[serde(default = "default_reason")]
    pub reason: String,
    #[serde(rename = "messageIds", default)]
    pub message_ids: Vec<i64>,
    #[serde(default)]
    pub images: Vec<String>,
}

fn default_reason() -> String { String::new() }

/// POST /api/messages/report
pub async fn report_chat(
    State(state): State<Arc<AppState>>,
    Extension(claims): Extension<Claims>,
    Json(req): Json<ReportChatRequest>,
) -> Result<Json<serde_json::Value>> {
    let me = claims.user_id();
    if req.reason.trim().is_empty() && req.message_ids.is_empty() {
        return Err(AppError::BadRequest("请填写举报理由或选择聊天记录".into()));
    }
    if req.images.len() > 9 {
        return Err(AppError::BadRequest("截图最多 9 张".into()));
    }
    let peer_exists: Option<(i64,)> = sqlx::query_as("SELECT id FROM users WHERE id=?")
        .bind(req.peer_id).fetch_optional(&state.db).await?;
    if peer_exists.is_none() { return Err(AppError::NotFound("user not found".into())); }

    // duplicate report check (unique key reporter+target) — return friendly conflict
    let dup: Option<(i64,)> = sqlx::query_as(
        "SELECT id FROM reports WHERE reporter_id=? AND target_type='USER' AND target_id=?")
        .bind(me).bind(req.peer_id).fetch_optional(&state.db).await?;
    if dup.is_some() {
        return Err(AppError::Conflict("\u{60a8}\u{5df2}\u{7ecf}\u{4e3e}\u{62a5}\u{8fc7}\u{8be5}\u{7528}\u{6237}".into()));
    }

    // verify selected messages belong to my conversation with peer
    for mid in &req.message_ids {
        let ok: Option<(i64,)> = sqlx::query_as(
            "SELECT id FROM messages WHERE id=? AND ((sender_id=? AND recipient_id=?) OR (sender_id=? AND recipient_id=?))")
            .bind(mid).bind(me).bind(req.peer_id).bind(req.peer_id).bind(me)
            .fetch_optional(&state.db).await?;
        if ok.is_none() { return Err(AppError::BadRequest(format!("无效的消息 ID: {}", mid))); }
    }

    let evidence = serde_json::json!({
        "messageIds": req.message_ids,
        "images": req.images,
    });

    sqlx::query(
        "INSERT INTO reports(created_at,updated_at,target_type,target_id,reporter_id,reason,status,evidence_json) VALUES(NOW(),NOW(),'USER',?,?,?, 'PENDING',?)")
        .bind(req.peer_id).bind(me)
        .bind(if req.reason.trim().is_empty() { "(通过聊天记录举报)".to_string() } else { req.reason.trim().to_string() })
        .bind(evidence.to_string())
        .execute(&state.db).await?;

    Ok(Json(serde_json::json!({"success":true,"message":"举报已提交","data":null})))
}
