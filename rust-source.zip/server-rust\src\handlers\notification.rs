use axum::{
    extract::{State, Path, Query, Extension},
    Json,
};
use serde::Deserialize;
use std::sync::Arc;

use crate::{
    config::AppState,
    error::{AppError, Result},
    utils::Claims,
};

#[derive(Debug, Deserialize)]
pub struct ListQuery {
    pub page: Option<i64>,
    #[serde(rename = "size")]
    pub size: Option<i64>,
}

struct NotifRow {
    id: i64,
    content: String,
    read_flag: bool,
    ref_id: Option<i64>,
    title: Option<String>,
    ntype: String,
    created_at: chrono::DateTime<chrono::Utc>,
}

impl<'r> sqlx::FromRow<'r, sqlx::mysql::MySqlRow> for NotifRow {
    fn from_row(row: &'r sqlx::mysql::MySqlRow) -> std::result::Result<Self, sqlx::Error> {
        use sqlx::Row;
        Ok(NotifRow {
            id: row.try_get("id")?,
            content: row.try_get("content")?,
            read_flag: row.try_get::<bool, _>("read_flag")?,
            ref_id: row.try_get("ref_id")?,
            title: row.try_get("title")?,
            ntype: row.try_get::<String, _>("type")?,
            created_at: row.try_get("created_at")?,
        })
    }
}

/// GET /api/notifications
pub async fn list_notifications(
    State(state): State<Arc<AppState>>,
    Extension(claims): Extension<Claims>,
    Query(q): Query<ListQuery>,
) -> Result<Json<serde_json::Value>> {
    let me = claims.user_id();
    let page = q.page.unwrap_or(0).max(0);
    let size = q.size.unwrap_or(20).clamp(1, 100);
    let offset = page * size;

    let rows = sqlx::query_as::<sqlx::MySql, NotifRow>(
        "SELECT id, content, read_flag, ref_id, title, type, created_at FROM notifications
         WHERE user_id=? ORDER BY created_at DESC LIMIT ? OFFSET ?"
    ).bind(me).bind(size).bind(offset).fetch_all(&state.db).await?;

    let total: (i64,) = sqlx::query_as("SELECT COUNT(*) FROM notifications WHERE user_id=?")
        .bind(me).fetch_one(&state.db).await?;

    let items: Vec<serde_json::Value> = rows.iter().map(|r| serde_json::json!({
        "id": r.id, "content": r.content, "read": r.read_flag, "refId": r.ref_id,
        "title": r.title, "type": r.ntype, "createdAt": r.created_at
    })).collect();

    let pages = (total.0 + size - 1) / size;
    Ok(Json(serde_json::json!({"success":true,"message":null,"data":{"items":items,"page":page,"size":size,"totalItems":total.0,"totalPages":pages,"hasNext":page+1<pages}})))
}

/// GET /api/notifications/unread
pub async fn unread_count(State(state): State<Arc<AppState>>, Extension(claims): Extension<Claims>) -> Result<Json<serde_json::Value>> {
    let c: (i64,) = sqlx::query_as("SELECT COUNT(*) FROM notifications WHERE user_id=? AND read_flag=FALSE")
        .bind(claims.user_id()).fetch_one(&state.db).await?;
    Ok(Json(serde_json::json!({"success":true,"message":null,"data":{"unread":c.0}})))
}

/// PATCH /api/notifications/{id}/read
pub async fn mark_read(
    State(state): State<Arc<AppState>>,
    Extension(claims): Extension<Claims>,
    Path(id): Path<i64>,
) -> Result<Json<serde_json::Value>> {
    let owner: Option<(i64,)> = sqlx::query_as("SELECT user_id FROM notifications WHERE id=?")
        .bind(id).fetch_optional(&state.db).await?;
    match owner {
        Some((uid,)) if uid == claims.user_id() => {}
        _ => return Err(AppError::NotFound("notification not found".into())),
    }
    sqlx::query("UPDATE notifications SET read_flag=TRUE WHERE id=?").bind(id).execute(&state.db).await?;
    Ok(Json(serde_json::json!({"success":true,"message":"read","data":null})))
}

/// PATCH /api/notifications/read-all
pub async fn mark_all_read(
    State(state): State<Arc<AppState>>,
    Extension(claims): Extension<Claims>,
) -> Result<Json<serde_json::Value>> {
    sqlx::query("UPDATE notifications SET read_flag=TRUE WHERE user_id=? AND read_flag=FALSE")
        .bind(claims.user_id()).execute(&state.db).await?;
    Ok(Json(serde_json::json!({"success":true,"message":"all read","data":null})))
}

/// GET /api/notifications/settings
pub async fn get_settings(
    State(state): State<Arc<AppState>>,
    Extension(claims): Extension<Claims>,
) -> Result<Json<serde_json::Value>> {
    let me = claims.user_id();
    let row: Option<(bool, bool, bool, bool, bool, bool)> = sqlx::query_as(
        "SELECT enable_comment, enable_like, enable_announcement, enable_moderation, enable_device_login, TRUE FROM notification_settings WHERE user_id=?"
    ).bind(me).fetch_optional(&state.db).await?;

    let data = match row {
        Some((comment, like, announcement, moderation, device_login, _)) => serde_json::json!({
            "enableComment": comment, "enableLike": like, "enableAnnouncement": announcement,
            "enableModeration": moderation, "enableDeviceLogin": device_login
        }),
        None => serde_json::json!({
            "enableComment": true, "enableLike": true, "enableAnnouncement": true,
            "enableModeration": true, "enableDeviceLogin": true
        }),
    };
    Ok(Json(serde_json::json!({"success":true,"message":null,"data":data})))
}

/// PATCH /api/notifications/settings
pub async fn update_settings(
    State(state): State<Arc<AppState>>,
    Extension(claims): Extension<Claims>,
    Json(body): Json<serde_json::Value>,
) -> Result<Json<serde_json::Value>> {
    let me = claims.user_id();
    let get = |k: &str| body.get(k).and_then(|v| v.as_bool());

    let exists: Option<(i64,)> = sqlx::query_as("SELECT user_id FROM notification_settings WHERE user_id=?")
        .bind(me).fetch_optional(&state.db).await?;

    if exists.is_none() {
        sqlx::query("INSERT INTO notification_settings(created_at,updated_at,enable_announcement,enable_comment,enable_device_login,enable_like,enable_moderation,user_id) VALUES(NOW(),NOW(),TRUE,TRUE,TRUE,TRUE,TRUE,?)")
            .bind(me).execute(&state.db).await?;
    }
    if let Some(v) = get("enableComment") { sqlx::query("UPDATE notification_settings SET enable_comment=?,updated_at=NOW() WHERE user_id=?").bind(v).bind(me).execute(&state.db).await?; }
    if let Some(v) = get("enableLike") { sqlx::query("UPDATE notification_settings SET enable_like=?,updated_at=NOW() WHERE user_id=?").bind(v).bind(me).execute(&state.db).await?; }
    if let Some(v) = get("enableAnnouncement") { sqlx::query("UPDATE notification_settings SET enable_announcement=?,updated_at=NOW() WHERE user_id=?").bind(v).bind(me).execute(&state.db).await?; }
    if let Some(v) = get("enableModeration") { sqlx::query("UPDATE notification_settings SET enable_moderation=?,updated_at=NOW() WHERE user_id=?").bind(v).bind(me).execute(&state.db).await?; }
    if let Some(v) = get("enableDeviceLogin") { sqlx::query("UPDATE notification_settings SET enable_device_login=?,updated_at=NOW() WHERE user_id=?").bind(v).bind(me).execute(&state.db).await?; }

    get_settings(State(state), Extension(claims)).await
}
