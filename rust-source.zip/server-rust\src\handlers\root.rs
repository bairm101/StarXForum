use axum::Json;
use serde_json::json;

pub async fn root() -> Json<serde_json::Value> {
    Json(json!({
        "success": true,
        "message": null,
        "data": { "status": "UP", "engine": "Rust/Axum" }
    }))
}
