use axum::{
    extract::{State, Path, Query, Extension},
    Json,
};
use serde::Deserialize;
use std::sync::Arc;

use crate::{
    config::AppState,
    error::{AppError, Result},
    models::{User, Follow},
    utils::Claims,
};

pub async fn author_summary(state: &AppState, id: i64) -> Result<serde_json::Value> {
    let u = sqlx::query_as::<sqlx::MySql, User>("SELECT * FROM users WHERE id=?")
        .bind(id).fetch_optional(&state.db).await?;
    Ok(match u {
        Some(u) => serde_json::json!({
            "id": u.id, "uid": u.uid, "username": u.username,
            "displayName": u.nickname.clone().unwrap_or_else(|| u.username.clone()),
            "avatarUrl": u.avatar_url, "title": u.title, "role": u.role
        }),
        None => serde_json::json!(null),
    })
}

/// GET /api/users/{id}/follow-status
pub async fn follow_status(
    State(state): State<Arc<AppState>>,
    headers: axum::http::HeaderMap,
    Path(id): Path<i64>,
) -> Result<Json<serde_json::Value>> {
    // Optional auth: public route, but personalizes for logged-in users
    let me: Option<i64> = headers
        .get(axum::http::header::AUTHORIZATION)
        .and_then(|v| v.to_str().ok())
        .and_then(|v| v.strip_prefix("Bearer "))
        .and_then(|token| crate::utils::jwt::verify_token(token, &state.config.jwt_secret).ok())
        .map(|c| c.user_id());

    let is_following = match me {
        Some(m) => sqlx::query_scalar::<_, i64>("SELECT COUNT(*) FROM follows WHERE user_id=? AND following_id=?")
            .bind(m).bind(id).fetch_one(&state.db).await? > 0,
        None => false,
    };
    let following_count: (i64,) = sqlx::query_as("SELECT COUNT(*) FROM follows WHERE user_id=?")
        .bind(id).fetch_one(&state.db).await?;
    let follower_count: (i64,) = sqlx::query_as("SELECT COUNT(*) FROM follows WHERE following_id=?")
        .bind(id).fetch_one(&state.db).await?;
    let (i_blocked, blocked_me) = match me {
        Some(m) => (
            sqlx::query_scalar::<_, i64>("SELECT COUNT(*) FROM blacklists WHERE user_id=? AND blocked_id=?").bind(m).bind(id).fetch_one(&state.db).await? > 0,
            sqlx::query_scalar::<_, i64>("SELECT COUNT(*) FROM blacklists WHERE user_id=? AND blocked_id=?").bind(id).bind(m).fetch_one(&state.db).await? > 0,
        ),
        None => (false, false),
    };

    Ok(Json(serde_json::json!({"success":true,"message":null,"data":{
        "isFollowing": is_following,
        "isMutual": false,
        "followingCount": following_count.0,
        "followerCount": follower_count.0,
        "iBlocked": i_blocked,
        "blockedMe": blocked_me
    }})))
}

/// POST /api/users/{id}/follow  (toggle)
pub async fn toggle_follow(
    State(state): State<Arc<AppState>>,
    Extension(claims): Extension<Claims>,
    Path(id): Path<i64>,
) -> Result<Json<serde_json::Value>> {
    let me = claims.user_id();
    if me == id { return Err(AppError::BadRequest("cannot follow yourself".into())); }
    let exists: Option<(i64,)> = sqlx::query_as("SELECT id FROM follows WHERE user_id=? AND following_id=?")
        .bind(me).bind(id).fetch_optional(&state.db).await?;
    if exists.is_some() {
        sqlx::query("DELETE FROM follows WHERE user_id=? AND following_id=?").bind(me).bind(id).execute(&state.db).await?;
        Ok(Json(serde_json::json!({"success":true,"message":"unfollowed","data":false})))
    } else {
        sqlx::query("INSERT INTO follows(created_at,updated_at,following_id,user_id) VALUES(NOW(),NOW(),?,?)")
            .bind(id).bind(me).execute(&state.db).await?;
        Ok(Json(serde_json::json!({"success":true,"message":"followed","data":true})))
    }
}

/// POST /api/users/{id}/block  (toggle)
pub async fn toggle_block(
    State(state): State<Arc<AppState>>,
    Extension(claims): Extension<Claims>,
    Path(id): Path<i64>,
) -> Result<Json<serde_json::Value>> {
    let me = claims.user_id();
    if me == id { return Err(AppError::BadRequest("cannot block yourself".into())); }
    let exists: Option<(i64,)> = sqlx::query_as("SELECT id FROM blacklists WHERE user_id=? AND blocked_id=?")
        .bind(me).bind(id).fetch_optional(&state.db).await?;
    if exists.is_some() {
        sqlx::query("DELETE FROM blacklists WHERE user_id=? AND blocked_id=?").bind(me).bind(id).execute(&state.db).await?;
        Ok(Json(serde_json::json!({"success":true,"message":"unblocked","data":false})))
    } else {
        sqlx::query("INSERT INTO blacklists(created_at,updated_at,blocked_id,user_id) VALUES(NOW(),NOW(),?,?)")
            .bind(id).bind(me).execute(&state.db).await?;
        Ok(Json(serde_json::json!({"success":true,"message":"blocked","data":true})))
    }
}

/// GET /api/users/{id}/blocks
pub async fn blocks(
    State(state): State<Arc<AppState>>,
    Extension(claims): Extension<Claims>,
    Path(id): Path<i64>,
    Query(_q): Query<std::collections::HashMap<String, String>>,
) -> Result<Json<serde_json::Value>> {
    if claims.user_id() != id { return Err(AppError::Forbidden("forbidden".into())); }
    let rows: Vec<(i64,)> = sqlx::query_as("SELECT blocked_id FROM blacklists WHERE user_id=?")
        .bind(id).fetch_all(&state.db).await?;
    let mut items = Vec::with_capacity(rows.len());
    for (bid,) in rows {
        items.push(author_summary(&state, bid).await?);
    }
    Ok(Json(serde_json::json!({"success":true,"message":null,"data":{"items":items,"page":0,"size":100,"totalItems":items.len() as i64,"totalPages":1,"hasNext":false}})))
}

/// GET /api/users/{id}/profile
pub async fn profile(
    State(state): State<Arc<AppState>>,
    Path(id): Path<i64>,
) -> Result<Json<serde_json::Value>> {
    super::user::user_profile_data(&state, id).await
}

/// GET /api/users/by-uid/{uid}
pub async fn by_uid(State(state): State<Arc<AppState>>, Path(uid): Path<String>) -> Result<Json<serde_json::Value>> {
    let u = sqlx::query_as::<sqlx::MySql, User>("SELECT * FROM users WHERE uid=?")
        .bind(uid).fetch_optional(&state.db).await?
        .ok_or_else(|| AppError::NotFound("user not found".into()))?;
    Ok(super::user::profile_view(&u))
}

/// GET /api/users/by-name/{name}
pub async fn by_name(State(state): State<Arc<AppState>>, Path(name): Path<String>) -> Result<Json<serde_json::Value>> {
    let u = sqlx::query_as::<sqlx::MySql, User>("SELECT * FROM users WHERE username=? OR nickname=?")
        .bind(&name).bind(&name).fetch_optional(&state.db).await?
        .ok_or_else(|| AppError::NotFound("user not found".into()))?;
    Ok(super::user::profile_view(&u))
}
