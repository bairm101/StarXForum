use sqlx::MySqlPool;

use crate::error::{AppError, Result};

/// Load SMTP settings from site_settings and send a verification-code email.
/// Mirrors Java VerificationService.sendRawCode behavior/errors.
pub async fn send_code_email(db: &MySqlPool, to: &str, subject: &str, text: &str) -> Result<()> {
    struct SmtpRow {
        smtp_enabled: bool,
        smtp_host: Option<String>,
        smtp_port: Option<i32>,
        smtp_username: Option<String>,
        smtp_password: Option<String>,
        smtp_ssl: bool,
        site_name: String,
    }
    impl<'r> sqlx::FromRow<'r, sqlx::mysql::MySqlRow> for SmtpRow {
        fn from_row(row: &'r sqlx::mysql::MySqlRow) -> std::result::Result<Self, sqlx::Error> {
            use sqlx::Row;
            Ok(SmtpRow {
                smtp_enabled: row.try_get("smtp_enabled")?,
                smtp_host: row.try_get("smtp_host")?,
                smtp_port: row.try_get("smtp_port")?,
                smtp_username: row.try_get("smtp_username")?,
                smtp_password: row.try_get("smtp_password")?,
                smtp_ssl: row.try_get::<bool, _>("smtp_ssl").unwrap_or(true),
                site_name: row.try_get("site_name")?,
            })
        }
    }
    let s = sqlx::query_as::<sqlx::MySql, SmtpRow>(
        "SELECT smtp_enabled, smtp_host, smtp_port, smtp_username, smtp_password, smtp_ssl, site_name FROM site_settings WHERE id=1",
    )
    .fetch_one(db)
    .await
    .map_err(|e| AppError::Internal(format!("site settings unavailable: {e}")))?;

    if !s.smtp_enabled {
        return Err(AppError::BadRequest("\u{90ae}\u{4ef6}\u{670d}\u{52a1}\u{672a}\u{5f00}\u{542f}".into()));
    }
    let host = s.smtp_host.clone().unwrap_or_default();
    let username = s.smtp_username.clone().unwrap_or_default();
    let password = s.smtp_password.clone().unwrap_or_default();
    if host.is_empty() || username.is_empty() || password.is_empty() {
        return Err(AppError::BadRequest("SMTP \u{914d}\u{7f6e}\u{4e0d}\u{5b8c}\u{6574}".into()));
    }

    let full_subject = format!("{} {}", s.site_name, subject);
    let email = lettre::message::Message::builder()
        .from(
            username
                .parse::<lettre::message::Mailbox>()
                .map_err(|_| AppError::Internal("invalid smtp from address".into()))?,
        )
        .to(
            to.parse::<lettre::message::Mailbox>()
                .map_err(|_| AppError::BadRequest("\u{90ae}\u{7bb1}\u{5730}\u{5740}\u{65e0}\u{6548}".into()))?,
        )
        .subject(&full_subject)
        .body(text.to_string())
        .map_err(|e| AppError::Internal(format!("build email failed: {e}")))?;

    use lettre::transport::smtp::authentication::Credentials;
    let creds = Credentials::new(username.clone(), password);
    let port = s.smtp_port.unwrap_or(465) as u16;

    let mailer = if s.smtp_ssl {
        lettre::SmtpTransport::relay(&host)
            .map_err(|e| AppError::Internal(format!("smtp relay error: {e}")))?
            .port(port)
            .credentials(creds)
            .build()
    } else {
        lettre::SmtpTransport::builder_dangerous(&host)
            .port(port)
            .credentials(creds)
            .build()
    };

    use lettre::Transport;
    mailer
        .send(&email)
        .map_err(|e| AppError::Internal(format!("\u{90ae}\u{4ef6}\u{53d1}\u{9001}\u{5931}\u{8d25}: {e}")))?;
    Ok(())
}

pub fn gen_code() -> String {
    use rand::Rng;
    rand::thread_rng().gen_range(100000..=999999).to_string()
}

/// Enforce a 60s cooldown for verification-code sending. `scope` should be the same
/// key used to store the code (e.g. verify:email:<addr>, emailchange:<uid>).
pub async fn enforce_cooldown(
    conn: &mut redis::aio::ConnectionManager,
    scope: &str,
) -> crate::error::Result<()> {
    let key = format!("sendcd:{}", scope);
    let exists: bool = redis::AsyncCommands::exists(&mut *conn, &key).await.unwrap_or(false);
    if exists {
        return Err(crate::error::AppError::BadRequest(
            "\u{53d1}\u{9001}\u{592a}\u{9891}\u{7e41}\u{ff0c}\u{8bf7} 60 \u{79d2}\u{540e}\u{518d}\u{8bd5}".into(),
        ));
    }
    let _: () = redis::AsyncCommands::set_ex(&mut *conn, &key, "1", 60u64)
        .await
        .map_err(|e| crate::error::AppError::Internal(format!("redis error: {e}")))?;
    Ok(())
}
