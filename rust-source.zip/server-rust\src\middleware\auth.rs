use axum::{
    extract::{Request, State},
    http::{header, StatusCode},
    middleware::Next,
    response::Response,
};
use std::sync::Arc;
use crate::{config::AppState, utils::jwt};

pub fn extract_token(req: &Request) -> Option<String> {
    req.headers()
        .get(header::AUTHORIZATION)
        .and_then(|auth_header| auth_header.to_str().ok())
        .and_then(|auth_value| {
            if auth_value.starts_with("Bearer ") {
                Some(auth_value[7..].to_string())
            } else {
                None
            }
        })
}

/// Java-style error body: {"success":false,"message":...,"data":null}
fn err_body(status: StatusCode, message: &str) -> Response {
    use axum::response::IntoResponse;
    let body = serde_json::json!({"success": false, "message": message, "data": null});
    (status, axum::Json(body)).into_response()
}

pub async fn auth_middleware(
    State(state): State<Arc<AppState>>,
    mut req: Request,
    next: Next,
) -> Result<Response, Response> {
    let token = match extract_token(&req) {
        Some(t) => t,
        None => return Err(err_body(StatusCode::UNAUTHORIZED, "未登录或登录态已失效")),
    };

    let claims = match jwt::verify_token(&token, &state.config.jwt_secret) {
        Ok(c) => c,
        Err(_) => return Err(err_body(StatusCode::UNAUTHORIZED, "未登录或登录态已失效")),
    };

    if claims.role == "BANNED" {
        return Err(err_body(StatusCode::FORBIDDEN, "账号已被封禁"));
    }

    req.extensions_mut().insert(claims);

    Ok(next.run(req).await)
}

pub async fn admin_middleware(
    State(state): State<Arc<AppState>>,
    mut req: Request,
    next: Next,
) -> Result<Response, Response> {
    let token = match extract_token(&req) {
        Some(t) => t,
        None => return Err(err_body(StatusCode::UNAUTHORIZED, "未登录或登录态已失效")),
    };

    let claims = match jwt::verify_token(&token, &state.config.jwt_secret) {
        Ok(c) => c,
        Err(_) => return Err(err_body(StatusCode::UNAUTHORIZED, "未登录或登录态已失效")),
    };

    if claims.role != "OWNER" && claims.role != "SUPER_ADMIN" && claims.role != "ADMIN" {
        return Err(err_body(StatusCode::FORBIDDEN, "没有操作权限"));
    }

    req.extensions_mut().insert(claims);

    Ok(next.run(req).await)
}
