use axum::{
    extract::{State, Query},
    Json,
};
use std::sync::Arc;

use crate::{config::AppState, error::Result};

/// GET /api/stats/overview
pub async fn overview(State(state): State<Arc<AppState>>) -> Result<Json<serde_json::Value>> {
    let users: (i64,) = sqlx::query_as("SELECT COUNT(*) FROM users").fetch_one(&state.db).await?;
    let posts: (i64,) = sqlx::query_as("SELECT COUNT(*) FROM posts WHERE deleted=0").fetch_one(&state.db).await?;
    let comments: (i64,) = sqlx::query_as("SELECT COUNT(*) FROM comments WHERE deleted=0").fetch_one(&state.db).await?;
    let boards: (i64,) = sqlx::query_as("SELECT COUNT(*) FROM boards").fetch_one(&state.db).await?;
    let likes: (i64,) = sqlx::query_as("SELECT COUNT(*) FROM likes").fetch_one(&state.db).await?;
    let messages: (i64,) = sqlx::query_as("SELECT COUNT(*) FROM messages").fetch_one(&state.db).await?;

    Ok(Json(serde_json::json!({"success":true,"message":null,"data":{
        "users": users.0, "posts": posts.0, "comments": comments.0,
        "boards": boards.0, "likes": likes.0, "messages": messages.0
    }})))
}

async fn daily_agg(state: &AppState, table: &str, col: &str, days: i64) -> Result<Vec<serde_json::Value>> {
    // table/col come from whitelisted callers only
    let sql = format!(
        "SELECT DATE({col}) AS d, COUNT(*) AS c FROM {table} WHERE {col} >= DATE_SUB(CURDATE(), INTERVAL ? DAY) GROUP BY DATE({col}) ORDER BY DATE({col})",
        col = col, table = table
    );
    let rows: Vec<(chrono::NaiveDate, i64)> = sqlx::query_as(&sql).bind(days).fetch_all(&state.db).await?;
    Ok(rows.into_iter()
        .map(|(d, c)| serde_json::json!({"d": d.to_string(), "c": c}))
        .collect())
}

/// GET /api/stats/daily/registrations?days=7
pub async fn registrations(State(state): State<Arc<AppState>>, Query(q): Query<std::collections::HashMap<String, String>>) -> Result<Json<serde_json::Value>> {
    let days: i64 = q.get("days").and_then(|v| v.parse().ok()).unwrap_or(7);
    let data = daily_agg(&state, "users", "created_at", days).await?;
    Ok(Json(serde_json::json!({"success":true,"message":null,"data":data})))
}

/// GET /api/stats/daily/posts?days=7
pub async fn posts(State(state): State<Arc<AppState>>, Query(q): Query<std::collections::HashMap<String, String>>) -> Result<Json<serde_json::Value>> {
    let days: i64 = q.get("days").and_then(|v| v.parse().ok()).unwrap_or(7);
    let data = daily_agg(&state, "posts", "created_at", days).await?;
    Ok(Json(serde_json::json!({"success":true,"message":null,"data":data})))
}

/// GET /api/stats/daily/comments?days=7
pub async fn comments(State(state): State<Arc<AppState>>, Query(q): Query<std::collections::HashMap<String, String>>) -> Result<Json<serde_json::Value>> {
    let days: i64 = q.get("days").and_then(|v| v.parse().ok()).unwrap_or(7);
    let data = daily_agg(&state, "comments", "created_at", days).await?;
    Ok(Json(serde_json::json!({"success":true,"message":null,"data":data})))
}

/// GET /api/stats/active-users?limit=10
pub async fn active_users(State(state): State<Arc<AppState>>, Query(q): Query<std::collections::HashMap<String, String>>) -> Result<Json<serde_json::Value>> {
    let limit: i64 = q.get("limit").and_then(|v| v.parse().ok()).unwrap_or(10).clamp(1, 100);
    let rows = sqlx::query_as::<sqlx::MySql, (String, Option<String>, i64, i64)>(
        "SELECT u.username, u.nickname, COUNT(DISTINCT p.id) AS posts, COUNT(DISTINCT c.id) AS comments
         FROM users u
         LEFT JOIN posts p ON p.author_id = u.id AND p.deleted = 0
         LEFT JOIN comments c ON c.author_id = u.id AND c.deleted = 0
         GROUP BY u.id, u.username, u.nickname
         ORDER BY (COUNT(DISTINCT p.id) + COUNT(DISTINCT c.id)) DESC
         LIMIT ?")
        .bind(limit).fetch_all(&state.db).await?;

    let data: Vec<serde_json::Value> = rows.into_iter()
        .map(|(username, nickname, posts, comments)| serde_json::json!({
            "username": username, "nickname": nickname, "posts": posts, "comments": comments
        }))
        .collect();
    Ok(Json(serde_json::json!({"success":true,"message":null,"data":data})))
}
