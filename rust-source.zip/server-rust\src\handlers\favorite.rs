use axum::{
    extract::{State, Path, Query, Extension},
    Json,
};
use serde::Deserialize;
use std::sync::Arc;

use crate::{
    config::AppState,
    error::{AppError, Result},
    models::{Post, User, Board},
    utils::Claims,
};

#[derive(Debug, Deserialize)]
pub struct ListFavoritesQuery {
    pub page: Option<i64>,
    #[serde(rename = "size", alias = "page_size")]
    pub size: Option<i64>,
}

/// GET /api/favorites/mine
pub async fn list_favorites(
    State(state): State<Arc<AppState>>,
    Extension(claims): Extension<Claims>,
    Query(q): Query<ListFavoritesQuery>,
) -> Result<Json<serde_json::Value>> {
    let page = q.page.unwrap_or(0).max(0);
    let size = q.size.unwrap_or(20).clamp(1, 100);
    let offset = page * size;

    let posts = sqlx::query_as::<sqlx::MySql, Post>(
        "SELECT p.* FROM posts p JOIN favorites f ON p.id=f.post_id
         WHERE f.user_id=? AND p.deleted=FALSE AND p.status='APPROVED'
         ORDER BY f.created_at DESC LIMIT ? OFFSET ?")
        .bind(claims.user_id()).bind(size).bind(offset).fetch_all(&state.db).await?;

    let total: (i64,) = sqlx::query_as(
        "SELECT COUNT(*) FROM favorites f JOIN posts p ON f.post_id=p.id
         WHERE f.user_id=? AND p.deleted=FALSE AND p.status='APPROVED'")
        .bind(claims.user_id()).fetch_one(&state.db).await?;

    let mut items = Vec::with_capacity(posts.len());
    for post in posts {
        let author = sqlx::query_as::<sqlx::MySql, User>("SELECT * FROM users WHERE id=?")
            .bind(post.author_id).fetch_one(&state.db).await?;
        let board = sqlx::query_as::<sqlx::MySql, Board>("SELECT * FROM boards WHERE id=?")
            .bind(post.board_id).fetch_one(&state.db).await?;
        let plain = post.content.split_whitespace().collect::<Vec<_>>().join(" ");
        let excerpt = if plain.len() > 120 { format!("{}...", &plain[..120]) } else { plain };
        items.push(serde_json::json!({
            "id": post.id, "title": post.title, "excerpt": excerpt,
            "boardId": post.board_id, "boardName": board.name,
            "author": {"id":author.id,"uid":author.uid,"username":author.username,
                "displayName":author.nickname.clone().unwrap_or_else(||author.username.clone()),
                "avatarUrl":author.avatar_url,"title":author.title,"role":author.role},
            "viewCount":post.view_count,"commentCount":post.comment_count,
            "likeCount":post.like_count,"dislikeCount":post.dislike_count,
            "pinned":post.pinned,"locked":post.locked,"likedByMe":false,
            "totalTipGold":post.total_tip_gold,"tipCount":post.tip_count,
            "status":post.status,"thumbnailUrl":post.thumbnail_url,"videoUrl":null,
            "gateType":post.gate_type,"topics":post.topics,"puid":post.puid,
            "createdAt":post.created_at,"lastActivityAt":post.last_activity_at
        }));
    }
    let pages = (total.0 + size - 1) / size;
    Ok(Json(serde_json::json!({"success":true,"message":null,"data":{"items":items,"page":page,"size":size,"totalItems":total.0,"totalPages":pages,"hasNext":page+1<pages}})))
}

/// POST /api/posts/:id/unfavorite
pub async fn remove_favorite(
    State(state): State<Arc<AppState>>,
    Extension(claims): Extension<Claims>,
    Path(post_id): Path<i64>,
) -> Result<Json<serde_json::Value>> {
    let r = sqlx::query("DELETE FROM favorites WHERE user_id=? AND post_id=?")
        .bind(claims.user_id()).bind(post_id).execute(&state.db).await?;
    if r.rows_affected() == 0 { return Err(AppError::BadRequest("not favorited".into())); }
    Ok(Json(serde_json::json!({"success":true,"message":"removed","data":null})))
}

/// GET /api/favorites/check/:postId -> data: bool
pub async fn check_favorite(
    State(state): State<Arc<AppState>>,
    Extension(claims): Extension<Claims>,
    Path(post_id): Path<i64>,
) -> Result<Json<serde_json::Value>> {
    let existing: Option<(i64,)> = sqlx::query_as("SELECT id FROM favorites WHERE user_id=? AND post_id=?")
        .bind(claims.user_id()).bind(post_id).fetch_optional(&state.db).await?;
    Ok(Json(serde_json::json!({"success":true,"message":null,"data":existing.is_some()})))
}

/// POST /api/favorites/toggle/:postId
pub async fn toggle_favorite(
    State(state): State<Arc<AppState>>,
    Extension(claims): Extension<Claims>,
    Path(post_id): Path<i64>,
) -> Result<Json<serde_json::Value>> {
    let me = claims.user_id();
    let exists: Option<(i64,)> = sqlx::query_as("SELECT id FROM favorites WHERE user_id=? AND post_id=?")
        .bind(me).bind(post_id).fetch_optional(&state.db).await?;
    if exists.is_some() {
        sqlx::query("DELETE FROM favorites WHERE user_id=? AND post_id=?").bind(me).bind(post_id).execute(&state.db).await?;
        return Ok(Json(serde_json::json!({"success":true,"message":"unfavorited","data":false})));
    }
    let post_exists: Option<(i64,)> = sqlx::query_as("SELECT id FROM posts WHERE id=? AND deleted=FALSE")
        .bind(post_id).fetch_optional(&state.db).await?;
    if post_exists.is_none() { return Err(AppError::NotFound("post not found".into())); }
    sqlx::query("INSERT INTO favorites(created_at,updated_at,post_id,user_id) VALUES(NOW(),NOW(),?,?)")
        .bind(post_id).bind(me).execute(&state.db).await?;
    Ok(Json(serde_json::json!({"success":true,"message":"favorited","data":true})))
}
