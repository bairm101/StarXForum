use axum::{
    extract::{State, Path, Query, Extension},
    Json,
};
use serde::Deserialize;
use std::sync::Arc;
use validator::Validate;

use crate::{
    config::AppState,
    error::{AppError, Result},
    models::{User, SensitiveWord},
    utils::Claims,
};

#[derive(Debug, Deserialize)]
pub struct BanUserRequest {
    pub reason: Option<String>,
}

#[derive(Debug, Deserialize, Validate)]
pub struct AddSensitiveWordRequest {
    #[validate(length(min = 1))]
    pub word: String,
    pub replacement: Option<String>,
}

/// GET /api/admin/stats & /api/admin/overview
pub async fn get_stats(
    State(state): State<Arc<AppState>>,
    Extension(_claims): Extension<Claims>,
) -> Result<Json<serde_json::Value>> {
    let total_users: (i64,) = sqlx::query_as("SELECT COUNT(*) FROM users").fetch_one(&state.db).await?;
    let total_posts: (i64,) = sqlx::query_as("SELECT COUNT(*) FROM posts WHERE deleted=FALSE").fetch_one(&state.db).await?;
    let total_comments: (i64,) = sqlx::query_as("SELECT COUNT(*) FROM comments WHERE deleted=FALSE").fetch_one(&state.db).await?;
    let total_boards: (i64,) = sqlx::query_as("SELECT COUNT(*) FROM boards").fetch_one(&state.db).await?;
    let today_users: (i64,) = sqlx::query_as("SELECT COUNT(*) FROM users WHERE DATE(created_at)=CURDATE()").fetch_one(&state.db).await?;
    let today_posts: (i64,) = sqlx::query_as("SELECT COUNT(*) FROM posts WHERE DATE(created_at)=CURDATE() AND deleted=FALSE").fetch_one(&state.db).await?;
    let today_comments: (i64,) = sqlx::query_as("SELECT COUNT(*) FROM comments WHERE DATE(created_at)=CURDATE() AND deleted=FALSE").fetch_one(&state.db).await?;

    Ok(Json(serde_json::json!({"success":true,"message":null,"data":{
        "userCount": total_users.0, "postCount": total_posts.0,
        "commentCount": total_comments.0, "boardCount": total_boards.0,
        "totalUsers": total_users.0, "totalPosts": total_posts.0, "totalComments": total_comments.0,
        "todayNewUsers": today_users.0, "todayNewPosts": today_posts.0, "todayNewComments": today_comments.0
    }})))
}

async fn set_status(state: &AppState, user_id: i64, status: &str) -> Result<()> {
    sqlx::query("UPDATE users SET status=?, updated_at=NOW() WHERE id=?")
        .bind(status).bind(user_id).execute(&state.db).await?;
    Ok(())
}

/// POST /api/admin/users/:id/ban
pub async fn ban_user(
    State(state): State<Arc<AppState>>,
    Extension(claims): Extension<Claims>,
    Path(user_id): Path<i64>,
    Json(_payload): Json<BanUserRequest>,
) -> Result<Json<serde_json::Value>> {
    if user_id == claims.user_id() { return Err(AppError::BadRequest("cannot ban yourself".into())); }
    set_status(&state, user_id, "BANNED").await?;
    log_action(&state, claims.user_id(), "BAN_USER", "灏佺鐢ㄦ埛", &format!("user:{}", user_id)).await?;
    Ok(Json(serde_json::json!({"success":true,"message":"banned","data":null})))
}

/// PATCH /api/admin/users/:id/ban?banned=true|false
pub async fn ban_user_patch(
    State(state): State<Arc<AppState>>,
    Query(q): Query<std::collections::HashMap<String, String>>,
    Path(user_id): Path<i64>,
) -> Result<Json<serde_json::Value>> {
    let banned = q.get("banned").map(|v| v == "true" || v == "1").unwrap_or(true);
    let status = if banned { "BANNED" } else { "ACTIVE" };
    set_status(&state, user_id, status).await?;
    Ok(Json(serde_json::json!({"success":true,"message":if banned {"banned"} else {"unbanned"},"data":null})))
}

pub async fn unban_user(State(state): State<Arc<AppState>>, Path(user_id): Path<i64>) -> Result<Json<serde_json::Value>> {
    set_status(&state, user_id, "ACTIVE").await?;
    Ok(Json(serde_json::json!({"success":true,"message":"unbanned","data":null})))
}

pub async fn log_action(state: &AppState, operator_id: i64, action: &str, detail: &str, target: &str) -> Result<()> {
    let name: Option<(String,)> = sqlx::query_as("SELECT username FROM users WHERE id=?")
        .bind(operator_id).fetch_optional(&state.db).await?;
    let operator_name = name.map(|(n,)| n);
    sqlx::query("INSERT INTO operation_logs(created_at,updated_at,action,detail,operator_id,operator_name,target) VALUES(NOW(),NOW(),?,?,?,?,?)")
        .bind(action).bind(detail).bind(operator_id).bind(operator_name).bind(target)
        .execute(&state.db).await?;
    Ok(())
}
/// DELETE /api/admin/posts/:id (hard delete)
pub async fn delete_post(
    State(state): State<Arc<AppState>>,
    Extension(claims): Extension<Claims>,
    Path(post_id): Path<i64>,
) -> Result<Json<serde_json::Value>> {
    sqlx::query("DELETE FROM likes WHERE target_type='POST' AND target_id=?").bind(post_id).execute(&state.db).await?;
    sqlx::query("DELETE FROM dislikes WHERE target_type='POST' AND target_id=?").bind(post_id).execute(&state.db).await?;
    sqlx::query("DELETE FROM favorites WHERE post_id=?").bind(post_id).execute(&state.db).await?;
    sqlx::query("DELETE FROM tips WHERE post_id=?").bind(post_id).execute(&state.db).await?;
    sqlx::query("DELETE FROM poll_votes WHERE poll_id IN (SELECT id FROM polls WHERE post_id=?)").bind(post_id).execute(&state.db).await?;
    sqlx::query("DELETE FROM poll_options WHERE poll_id IN (SELECT id FROM polls WHERE post_id=?)").bind(post_id).execute(&state.db).await?;
    sqlx::query("DELETE FROM polls WHERE post_id=?").bind(post_id).execute(&state.db).await?;
    sqlx::query("DELETE FROM post_revisions WHERE post_id=?").bind(post_id).execute(&state.db).await?;
    sqlx::query("DELETE FROM post_unlocks WHERE post_id=?").bind(post_id).execute(&state.db).await?;
    sqlx::query("UPDATE comments SET parent_id=NULL WHERE post_id=?").bind(post_id).execute(&state.db).await?;
    sqlx::query("DELETE FROM comments WHERE post_id=?").bind(post_id).execute(&state.db).await?;
    sqlx::query("DELETE FROM posts WHERE id=?").bind(post_id).execute(&state.db).await?;
    log_action(&state, claims.user_id(), "DELETE_POST", "删除帖子", &format!("post:{}", post_id)).await?;
    Ok(Json(serde_json::json!({"success":true,"message":"deleted","data":null})))
}

/// POST /api/admin/posts/:id/moderate?approve=true|false
pub async fn moderate_post(
    State(state): State<Arc<AppState>>,
    Query(q): Query<std::collections::HashMap<String, String>>,
    Path(post_id): Path<i64>,
) -> Result<Json<serde_json::Value>> {
    let approve = q.get("approve").map(|v| v == "true" || v == "1").unwrap_or(true);
    let status = if approve { "APPROVED" } else { "REJECTED" };
    let exists: Option<(i64,)> = sqlx::query_as("SELECT id FROM posts WHERE id=?").bind(post_id).fetch_optional(&state.db).await?;
    if exists.is_none() { return Err(AppError::NotFound("post not found".into())); }
    sqlx::query("UPDATE posts SET status=?, updated_at=NOW() WHERE id=?").bind(status).bind(post_id).execute(&state.db).await?;
    Ok(Json(serde_json::json!({"success":true,"message":"moderated","data":null})))
}

/// GET /api/admin/posts/pending
pub async fn pending_posts(
    State(state): State<Arc<AppState>>,
    Query(q): Query<std::collections::HashMap<String, String>>,
) -> Result<Json<serde_json::Value>> {
    let page: i64 = q.get("page").and_then(|v| v.parse().ok()).unwrap_or(0);
    let size: i64 = q.get("size").and_then(|v| v.parse().ok()).unwrap_or(20).clamp(1, 100);
    let offset = page * size;
    let posts = sqlx::query_as::<sqlx::MySql, crate::models::Post>(
        "SELECT * FROM posts WHERE deleted=FALSE AND status='PENDING' ORDER BY created_at DESC LIMIT ? OFFSET ?")
        .bind(size).bind(offset).fetch_all(&state.db).await?;
    let total: (i64,) = sqlx::query_as("SELECT COUNT(*) FROM posts WHERE deleted=FALSE AND status='PENDING'")
        .fetch_one(&state.db).await?;
    let mut items = Vec::with_capacity(posts.len());
    for p in posts { items.push(super::user::post_summary_public(&state, p).await?); }
    let pages = (total.0 + size - 1) / size;
    Ok(Json(serde_json::json!({"success":true,"message":null,"data":{"items":items,"page":page,"size":size,"totalItems":total.0,"totalPages":pages,"hasNext":page+1<pages}})))
}

/// GET /api/admin/sensitive-words
pub async fn list_sensitive_words(
    State(state): State<Arc<AppState>>,
    Extension(_claims): Extension<Claims>,
) -> Result<Json<serde_json::Value>> {
    struct W { id: i64, word: String, replacement: Option<String>, enabled: bool }
    impl<'r> sqlx::FromRow<'r, sqlx::mysql::MySqlRow> for W {
        fn from_row(row: &'r sqlx::mysql::MySqlRow) -> std::result::Result<Self, sqlx::Error> {
            use sqlx::Row;
            Ok(W{ id: row.try_get("id")?, word: row.try_get("word")?,
                replacement: row.try_get("replacement")?, enabled: row.try_get::<bool,_>("enabled")? })
        }
    }
    let rows = sqlx::query_as::<sqlx::MySql, W>("SELECT id, word, replacement, enabled FROM sensitive_words ORDER BY created_at DESC")
        .fetch_all(&state.db).await?;
    let items: Vec<serde_json::Value> = rows.iter().map(|w| serde_json::json!({
        "id": w.id, "word": w.word, "replacement": w.replacement, "enabled": w.enabled
    })).collect();
    Ok(Json(serde_json::json!({"success":true,"message":null,"data":items})))
}

/// POST /api/admin/sensitive-words
pub async fn add_sensitive_word(
    State(state): State<Arc<AppState>>,
    Extension(_claims): Extension<Claims>,
    Json(payload): Json<AddSensitiveWordRequest>,
) -> Result<Json<serde_json::Value>> {
    payload.validate().map_err(|e| AppError::Validation(e.to_string()))?;
    let exists: Option<(i64,)> = sqlx::query_as("SELECT id FROM sensitive_words WHERE word=?")
        .bind(&payload.word).fetch_optional(&state.db).await?;
    if exists.is_some() { return Err(AppError::BadRequest("word exists".into())); }
    sqlx::query("INSERT INTO sensitive_words(created_at,updated_at,replacement,word,enabled) VALUES(NOW(),NOW(),?,?,TRUE)")
        .bind(&payload.replacement).bind(&payload.word).execute(&state.db).await?;
    Ok(Json(serde_json::json!({"success":true,"message":"added","data":null})))
}

/// GET /api/admin/logs
pub async fn get_operation_logs(
    State(state): State<Arc<AppState>>,
    Extension(_claims): Extension<Claims>,
    Query(q): Query<std::collections::HashMap<String, String>>,
) -> Result<Json<serde_json::Value>> {
    let page: i64 = q.get("page").and_then(|v| v.parse().ok()).unwrap_or(0);
    let size: i64 = q.get("size").and_then(|v| v.parse().ok()).unwrap_or(20).clamp(1, 100);
    let offset = page * size;
    let keyword = q.get("keyword").cloned();

    struct Log { id: i64, operator_id: i64, operator_name: Option<String>, action: String, target: Option<String>, detail: Option<String>, created_at: chrono::DateTime<chrono::Utc> }
    impl<'r> sqlx::FromRow<'r, sqlx::mysql::MySqlRow> for Log {
        fn from_row(row: &'r sqlx::mysql::MySqlRow) -> std::result::Result<Self, sqlx::Error> {
            use sqlx::Row;
            Ok(Log{ id: row.try_get("id")?, operator_id: row.try_get("operator_id")?,
                operator_name: row.try_get("operator_name").ok(),
                action: row.try_get("action")?, target: row.try_get("target").ok(),
                detail: row.try_get("detail").ok(), created_at: row.try_get("created_at")? })
        }
    }

    let (rows, total): (Vec<Log>, (i64,)) = if let Some(kw) = keyword.filter(|k| !k.trim().is_empty()) {
        let like = format!("%{}%", kw.trim());
        (
            sqlx::query_as::<sqlx::MySql, Log>(
                "SELECT id, operator_id, operator_name, action, target, detail, created_at FROM operation_logs WHERE operator_name LIKE ? ORDER BY created_at DESC LIMIT ? OFFSET ?")
                .bind(&like).bind(size).bind(offset).fetch_all(&state.db).await?,
            sqlx::query_as("SELECT COUNT(*) FROM operation_logs WHERE operator_name LIKE ?")
                .bind(&like).fetch_one(&state.db).await?,
        )
    } else {
        (
            sqlx::query_as::<sqlx::MySql, Log>(
                "SELECT id, operator_id, operator_name, action, target, detail, created_at FROM operation_logs ORDER BY created_at DESC LIMIT ? OFFSET ?")
                .bind(size).bind(offset).fetch_all(&state.db).await?,
            sqlx::query_as("SELECT COUNT(*) FROM operation_logs").fetch_one(&state.db).await?,
        )
    };
    let items: Vec<serde_json::Value> = rows.iter().map(|l| serde_json::json!({
        "id": l.id, "operatorId": l.operator_id, "operatorName": l.operator_name,
        "action": l.action, "target": l.target, "detail": l.detail, "createdAt": l.created_at
    })).collect();
    let pages = (total.0 + size - 1) / size;
    Ok(Json(serde_json::json!({"success":true,"message":null,"data":{"items":items,"page":page,"size":size,"totalItems":total.0,"totalPages":pages,"hasNext":page+1<pages}})))
}


// ---------- Java-compatible admin additions ----------

/// GET /api/admin/users?size=100
pub async fn list_users(
    State(state): State<Arc<AppState>>,
    Extension(_claims): Extension<Claims>,
    Query(q): Query<std::collections::HashMap<String, String>>,
) -> Result<Json<serde_json::Value>> {
    let page: i64 = q.get("page").and_then(|v| v.parse().ok()).unwrap_or(0);
    let size: i64 = q.get("size").and_then(|v| v.parse().ok()).unwrap_or(20).clamp(1, 200);
    let offset = page * size;
    let keyword = q.get("keyword").cloned();

    let (rows, total): (Vec<User>, i64) = if let Some(kw) = &keyword {
        let pat = format!("%{}%", kw);
        let rows = sqlx::query_as::<sqlx::MySql, User>(
            "SELECT * FROM users WHERE username LIKE ? OR nickname LIKE ? OR uid LIKE ? ORDER BY created_at DESC LIMIT ? OFFSET ?")
            .bind(&pat).bind(&pat).bind(&pat).bind(size).bind(offset).fetch_all(&state.db).await?;
        let t: (i64,) = sqlx::query_as(
            "SELECT COUNT(*) FROM users WHERE username LIKE ? OR nickname LIKE ? OR uid LIKE ?")
            .bind(&pat).bind(&pat).bind(&pat).fetch_one(&state.db).await?;
        (rows, t.0)
    } else {
        let rows = sqlx::query_as::<sqlx::MySql, User>(
            "SELECT * FROM users ORDER BY created_at DESC LIMIT ? OFFSET ?")
            .bind(size).bind(offset).fetch_all(&state.db).await?;
        let t: (i64,) = sqlx::query_as("SELECT COUNT(*) FROM users").fetch_one(&state.db).await?;
        (rows, t.0)
    };

    fn user_json(u: &User) -> serde_json::Value {
        serde_json::json!({
            "id": u.id, "uid": u.uid, "username": u.username, "nickname": u.nickname,
            "displayName": u.nickname.clone().unwrap_or_else(|| u.username.clone()),
            "avatarUrl": u.avatar_url, "signature": u.signature, "role": u.role,
            "status": u.status, "postCount": u.post_count, "commentCount": u.comment_count,
            "level": u.level, "exp": u.exp, "gold": u.gold, "checkinStreak": u.checkin_streak,
            "title": u.title, "managedBoardId": u.managed_board_id, "rankingWeight": u.ranking_weight,
            "pendingSignature": u.pending_signature, "emailVerified": u.email_verified,
            "maxUploadMb": u.max_upload_mb, "email": u.email, "createdAt": u.created_at
        })
    }
    let items: Vec<serde_json::Value> = rows.iter().map(user_json).collect();
    let pages = (total + size - 1) / size;
    Ok(Json(serde_json::json!({"success":true,"message":null,"data":{"items":items,"page":page,"size":size,"totalItems":total,"totalPages":pages,"hasNext":page+1<pages}})))
}

// ---------- admin create user ----------
#[derive(Debug, Deserialize)]
pub struct CreateUserRequest {
    pub username: String,
    pub password: String,
    pub nickname: Option<String>,
    pub email: Option<String>,
    pub role: Option<String>,
}

fn role_rank(role: &str) -> i64 {
    match role {
        "OWNER" => 3,
        "SUPER_ADMIN" => 2,
        "ADMIN" => 1,
        _ => 0,
    }
}

fn generate_uid_local() -> String {
    use rand::Rng;
    let alphabet: Vec<char> = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789".chars().collect();
    let mut rng = rand::thread_rng();
    let mut uid = String::from("U");
    for _ in 0..9 {
        uid.push(alphabet[rng.gen_range(0..alphabet.len())]);
    }
    uid
}

/// POST /api/admin/users — create a user from the admin panel (Java-compatible)
pub async fn create_user(
    State(state): State<Arc<AppState>>,
    Extension(claims): Extension<Claims>,
    Json(req): Json<CreateUserRequest>,
) -> Result<Json<serde_json::Value>> {
    let username = req.username.trim().to_string();
    let chars = username.chars().count();
    if chars < 3 || chars > 32 {
        return Err(AppError::BadRequest("\u{7528}\u{6237}\u{540d}\u{957f}\u{5ea6}\u{9700}\u{5728} 3-32 \u{4e4b}\u{95f4}".into()));
    }
    if req.password.len() < 8 {
        return Err(AppError::BadRequest("\u{5bc6}\u{7801}\u{81f3}\u{5c11} 8 \u{4f4d}".into()));
    }
    let exists: Option<(i64,)> = sqlx::query_as("SELECT id FROM users WHERE username=?")
        .bind(&username).fetch_optional(&state.db).await?;
    if exists.is_some() {
        return Err(AppError::Conflict("\u{7528}\u{6237}\u{540d}\u{5df2}\u{88ab}\u{5360}\u{7528}".into()));
    }
    let email = req.email.as_deref().map(str::trim).filter(|e| !e.is_empty()).map(str::to_string);
    if let Some(e) = &email {
        let taken: Option<(i64,)> = sqlx::query_as("SELECT id FROM users WHERE email=?")
            .bind(e).fetch_optional(&state.db).await?;
        if taken.is_some() {
            return Err(AppError::Conflict("\u{90ae}\u{7bb1}\u{5df2}\u{88ab}\u{6ce8}\u{518c}".into()));
        }
    }
    let role_req = req.role.as_deref().map(str::trim).unwrap_or("USER").to_uppercase();
    if role_req == "OWNER" {
        return Err(AppError::Forbidden("\u{4e0d}\u{80fd}\u{521b}\u{5efa}\u{7ad9}\u{957f}\u{8d26}\u{53f7}".into()));
    }
    let role = match role_req.as_str() {
        "ADMIN" => "ADMIN",
        "SUPER_ADMIN" => "SUPER_ADMIN",
        "USER" => "USER",
        _ => return Err(AppError::BadRequest("\u{975e}\u{6cd5}\u{89d2}\u{8272}".into())),
    };
    if role_rank(role) >= role_rank(&claims.role) {
        return Err(AppError::Forbidden("\u{4e0d}\u{80fd}\u{521b}\u{5efa}\u{540c}\u{7ea7}\u{6216}\u{66f4}\u{9ad8}\u{7ea7}\u{522b}\u{7684}\u{8d26}\u{53f7}".into()));
    }

    let mut uid = generate_uid_local();
    for _ in 0..50 {
        let dup: Option<(i64,)> = sqlx::query_as("SELECT id FROM users WHERE uid=?")
            .bind(&uid).fetch_optional(&state.db).await?;
        if dup.is_none() {
            break;
        }
        uid = generate_uid_local();
    }

    let hash = crate::utils::password::hash_password(&req.password)?;
    let nickname = req.nickname.as_deref().map(str::trim).filter(|s| !s.is_empty()).map(str::to_string);
    let email_verified = email.is_some();
    let result = sqlx::query("INSERT INTO users(username,uid,password_hash,email,nickname,email_verified,role,status,post_count,comment_count,level,exp,gold,checkin_streak,signature_approved_once,failed_login_count,ranking_weight,created_at,updated_at) VALUES(?,?,?,?,?,?,?,'ACTIVE',0,0,1,0,0,0,false,0,1.0,NOW(),NOW())")
        .bind(&username).bind(&uid).bind(&hash).bind(&email).bind(&nickname)
        .bind(email_verified).bind(role)
        .execute(&state.db).await?;
    let user_id = result.last_insert_id() as i64;
    log_action(&state, claims.user_id(), "CREATE_USER", "\u{521b}\u{5efa}\u{7528}\u{6237}", &format!("user:{}", user_id)).await?;
    let user = sqlx::query_as::<sqlx::MySql, User>("SELECT * FROM users WHERE id=?")
        .bind(user_id).fetch_one(&state.db).await?;
    Ok(Json(serde_json::json!({"success":true,"message":"\u{7528}\u{6237}\u{521b}\u{5efa}\u{6210}\u{529f}","data":{
        "id": user.id, "uid": user.uid, "username": user.username, "nickname": user.nickname,
        "displayName": user.nickname.clone().unwrap_or_else(|| user.username.clone()),
        "avatarUrl": user.avatar_url, "signature": user.signature, "role": user.role,
        "status": user.status, "postCount": user.post_count, "commentCount": user.comment_count,
        "level": user.level, "exp": user.exp, "gold": user.gold, "checkinStreak": user.checkin_streak,
        "title": user.title, "managedBoardId": user.managed_board_id, "rankingWeight": user.ranking_weight,
        "pendingSignature": user.pending_signature, "emailVerified": user.email_verified,
        "maxUploadMb": user.max_upload_mb, "email": user.email, "createdAt": user.created_at
    }})))
}

/// Account deactivation/deletion cascade (shared by admin delete + self cancel).
/// Posts are physically deleted along with all related data; the user's comments are kept
/// but rendered as "account deactivated"; upload files are removed from disk and DB.
pub async fn cancel_user_cascade(state: &AppState, user_id: i64) -> Result<()> {
    // 1. delete all posts authored by the user (with comments/reactions/polls)
    let post_ids: Vec<(i64,)> = sqlx::query_as("SELECT id FROM posts WHERE author_id=?")
        .bind(user_id).fetch_all(&state.db).await?;
    if !post_ids.is_empty() {
        let in_clause: Vec<String> = post_ids.iter().map(|(id,)| id.to_string()).collect();
        let in_clause = in_clause.join(",");
        let comment_ids: Vec<(i64,)> = sqlx::query_as(&format!(
            "SELECT id FROM comments WHERE post_id IN ({})", in_clause))
            .fetch_all(&state.db).await?;
        if !comment_ids.is_empty() {
            let cin: Vec<String> = comment_ids.iter().map(|(id,)| id.to_string()).collect();
            let cin = cin.join(",");
            sqlx::query(&format!("DELETE FROM likes WHERE target_type='COMMENT' AND target_id IN ({})", cin)).execute(&state.db).await?;
            sqlx::query(&format!("DELETE FROM dislikes WHERE target_type='COMMENT' AND target_id IN ({})", cin)).execute(&state.db).await?;
        }
        sqlx::query(&format!("DELETE FROM likes WHERE target_type='POST' AND target_id IN ({})", in_clause)).execute(&state.db).await?;
        sqlx::query(&format!("DELETE FROM dislikes WHERE target_type='POST' AND target_id IN ({})", in_clause)).execute(&state.db).await?;
        sqlx::query(&format!("DELETE FROM favorites WHERE post_id IN ({})", in_clause)).execute(&state.db).await?;
        sqlx::query(&format!("DELETE FROM tips WHERE post_id IN ({})", in_clause)).execute(&state.db).await?;
        sqlx::query(&format!("DELETE FROM poll_votes WHERE poll_id IN (SELECT id FROM polls WHERE post_id IN ({}))", in_clause)).execute(&state.db).await?;
        sqlx::query(&format!("DELETE FROM poll_options WHERE poll_id IN (SELECT id FROM polls WHERE post_id IN ({}))", in_clause)).execute(&state.db).await?;
        sqlx::query(&format!("DELETE FROM polls WHERE post_id IN ({})", in_clause)).execute(&state.db).await?;
        sqlx::query(&format!("DELETE FROM post_revisions WHERE post_id IN ({})", in_clause)).execute(&state.db).await?;
        sqlx::query(&format!("DELETE FROM post_unlocks WHERE post_id IN ({})", in_clause)).execute(&state.db).await?;
        sqlx::query(&format!("UPDATE comments SET parent_id=NULL WHERE post_id IN ({})", in_clause)).execute(&state.db).await?;
        sqlx::query(&format!("DELETE FROM comments WHERE post_id IN ({})", in_clause)).execute(&state.db).await?;
        sqlx::query(&format!("DELETE FROM posts WHERE id IN ({})", in_clause)).execute(&state.db).await?;
    }

    // 2. the user's own interactions
    sqlx::query("DELETE FROM likes WHERE user_id=?").bind(user_id).execute(&state.db).await?;
    sqlx::query("DELETE FROM dislikes WHERE user_id=?").bind(user_id).execute(&state.db).await?;
    sqlx::query("DELETE FROM favorites WHERE user_id=?").bind(user_id).execute(&state.db).await?;
    sqlx::query("DELETE FROM tips WHERE user_id=?").bind(user_id).execute(&state.db).await?;
    sqlx::query("DELETE FROM poll_votes WHERE user_id=?").bind(user_id).execute(&state.db).await?;
    sqlx::query("DELETE FROM post_unlocks WHERE user_id=?").bind(user_id).execute(&state.db).await?;
    sqlx::query("DELETE FROM follows WHERE user_id=? OR following_id=?").bind(user_id).bind(user_id).execute(&state.db).await?;
    sqlx::query("DELETE FROM blacklists WHERE user_id=? OR blocked_id=?").bind(user_id).bind(user_id).execute(&state.db).await?;
    sqlx::query("DELETE FROM notifications WHERE user_id=?").bind(user_id).execute(&state.db).await?;
    sqlx::query("DELETE FROM notification_settings WHERE user_id=?").bind(user_id).execute(&state.db).await?;
    sqlx::query("DELETE FROM user_sessions WHERE user_id=?").bind(user_id).execute(&state.db).await?;

    // 3. uploaded files: remove physical files, then records
    let paths: Vec<(String,)> = sqlx::query_as("SELECT path FROM upload_records WHERE user_id=?")
        .bind(user_id).fetch_all(&state.db).await?;
    for (p,) in paths {
        let rel = p.trim_start_matches("/uploads/");
        let f = format!("{}/{}", state.config.upload_dir.trim_end_matches('/'), rel);
        let _ = tokio::fs::remove_file(&f).await;
    }
    sqlx::query("DELETE FROM upload_records WHERE user_id=?").bind(user_id).execute(&state.db).await?;

    // 4. anonymize profile and mark cancelled
    sqlx::query("UPDATE users SET status='CANCELLED', email=NULL, email_verified=FALSE, avatar_url=NULL, signature=NULL, pending_signature=NULL, title=NULL, post_count=0, updated_at=NOW() WHERE id=?")
        .bind(user_id).execute(&state.db).await?;
    Ok(())
}

/// DELETE /api/admin/users/:id — admin deletes a user (cascade cleanup)
pub async fn delete_user(
    State(state): State<Arc<AppState>>,
    Extension(claims): Extension<Claims>,
    Path(user_id): Path<i64>,
) -> Result<Json<serde_json::Value>> {
    if user_id == claims.user_id() {
        return Err(AppError::BadRequest("\u{4e0d}\u{80fd}\u{5220}\u{9664}\u{81ea}\u{5df1}\u{7684}\u{8d26}\u{53f7}".into()));
    }
    let target = sqlx::query_as::<sqlx::MySql, User>("SELECT * FROM users WHERE id=?")
        .bind(user_id).fetch_optional(&state.db).await?
        .ok_or_else(|| AppError::NotFound("\u{7528}\u{6237}\u{4e0d}\u{5b58}\u{5728}".into()))?;
    if role_rank(&target.role) >= role_rank(&claims.role) {
        return Err(AppError::Forbidden("\u{4e0d}\u{80fd}\u{5220}\u{9664}\u{540c}\u{7ea7}\u{6216}\u{66f4}\u{9ad8}\u{7ea7}\u{522b}\u{7684}\u{8d26}\u{53f7}".into()));
    }
    cancel_user_cascade(&state, user_id).await?;
    log_action(&state, claims.user_id(), "DELETE_USER", "\u{5220}\u{9664}\u{7528}\u{6237}", &format!("user:{}", user_id)).await?;
    Ok(Json(serde_json::json!({"success":true,"message":"\u{7528}\u{6237}\u{5df2}\u{5220}\u{9664}","data":null})))
}

/// PATCH /api/admin/users/:id/role?role=ADMIN
pub async fn set_role(
    State(state): State<Arc<AppState>>,
    Extension(claims): Extension<Claims>,
    Path(user_id): Path<i64>,
    Query(q): Query<std::collections::HashMap<String, String>>,
) -> Result<Json<serde_json::Value>> {
    let role = q.get("role").cloned().unwrap_or_default();
    let allowed = ["OWNER", "SUPER_ADMIN", "ADMIN", "USER"];
    if !allowed.contains(&role.as_str()) { return Err(AppError::BadRequest("invalid role".into())); }
    sqlx::query("UPDATE users SET role=?, updated_at=NOW() WHERE id=?").bind(role).bind(user_id).execute(&state.db).await?;
    log_action(&state, claims.user_id(), "SET_ROLE", "修改角色", &format!("user:{}", user_id)).await?;
    Ok(Json(serde_json::json!({"success":true,"message":"role updated","data":null})))
}

/// PATCH /api/admin/users/:id/title?title=xxx
pub async fn set_title(
    State(state): State<Arc<AppState>>,
    Extension(claims): Extension<Claims>,
    Path(user_id): Path<i64>,
    Query(q): Query<std::collections::HashMap<String, String>>,
) -> Result<Json<serde_json::Value>> {
    let title = q.get("title").clone();
    sqlx::query("UPDATE users SET title=?, updated_at=NOW() WHERE id=?").bind(title).bind(user_id).execute(&state.db).await?;
    log_action(&state, claims.user_id(), "SET_TITLE", "设置头衔", &format!("user:{}", user_id)).await?;
    Ok(Json(serde_json::json!({"success":true,"message":"title updated","data":null})))
}

/// PATCH /api/admin/users/:id/parameters
pub async fn update_parameters(
    State(state): State<Arc<AppState>>,
    Extension(claims): Extension<Claims>,
    Path(user_id): Path<i64>,
    Json(body): Json<serde_json::Value>,
) -> Result<Json<serde_json::Value>> {
    if let Some(v) = body.get("level").and_then(|v| v.as_i64()) {
        sqlx::query("UPDATE users SET level=?,updated_at=NOW() WHERE id=?").bind(v as i32).bind(user_id).execute(&state.db).await?;
    }
    if let Some(v) = body.get("exp").and_then(|v| v.as_i64()) {
        sqlx::query("UPDATE users SET exp=?,updated_at=NOW() WHERE id=?").bind(v as i32).bind(user_id).execute(&state.db).await?;
    }
    if let Some(v) = body.get("gold").and_then(|v| v.as_i64()) {
        sqlx::query("UPDATE users SET gold=?,updated_at=NOW() WHERE id=?").bind(v).bind(user_id).execute(&state.db).await?;
    }
    if let Some(v) = body.get("rankingWeight").and_then(|v| v.as_f64()) {
        sqlx::query("UPDATE users SET ranking_weight=?,updated_at=NOW() WHERE id=?").bind(v).bind(user_id).execute(&state.db).await?;
    }
    if let Some(v) = body.get("maxUploadMb").and_then(|v| v.as_i64()) {
        sqlx::query("UPDATE users SET max_upload_mb=?,updated_at=NOW() WHERE id=?").bind(v as i32).bind(user_id).execute(&state.db).await?;
    }
    if let Some(v) = body.get("signature").and_then(|v| v.as_str()) {
        sqlx::query("UPDATE users SET signature=?, pending_signature=NULL, updated_at=NOW() WHERE id=?").bind(v).bind(user_id).execute(&state.db).await?;
    }
    log_action(&state, claims.user_id(), "UPDATE_USER", "调整用户参数", &format!("user:{}", user_id)).await?;
    Ok(Json(serde_json::json!({"success":true,"message":"updated","data":null})))
}

/// POST /api/admin/users/:id/signature?approve=true|false
pub async fn handle_signature(
    State(state): State<Arc<AppState>>,
    Extension(claims): Extension<Claims>,
    Path(user_id): Path<i64>,
    Query(q): Query<std::collections::HashMap<String, String>>,
) -> Result<Json<serde_json::Value>> {
    let approve = q.get("approve").map(|v| v == "true" || v == "1").unwrap_or(true);
    if approve {
        sqlx::query("UPDATE users SET signature=pending_signature, pending_signature=NULL, signature_approved_once=TRUE, updated_at=NOW() WHERE id=?")
            .bind(user_id).execute(&state.db).await?;
    } else {
        sqlx::query("UPDATE users SET pending_signature=NULL, updated_at=NOW() WHERE id=?")
            .bind(user_id).execute(&state.db).await?;
    }
    log_action(&state, claims.user_id(), if approve { "SIGNATURE_APPROVE" } else { "SIGNATURE_REJECT" }, if approve { "通过签名审核" } else { "驳回签名审核" }, &format!("user:{}", user_id)).await?;
    Ok(Json(serde_json::json!({"success":true,"message":"done","data":null})))
}

/// POST /api/admin/users/:id/logout-all
pub async fn logout_all_user_devices(
    State(state): State<Arc<AppState>>,
    Extension(claims): Extension<Claims>,
    Path(user_id): Path<i64>,
) -> Result<Json<serde_json::Value>> {
    sqlx::query("UPDATE user_sessions SET revoked=TRUE, updated_at=NOW() WHERE user_id=? AND revoked=FALSE")
        .bind(user_id).execute(&state.db).await?;
    log_action(&state, claims.user_id(), "LOGOUT_ALL", "强制退出全部设备", &format!("user:{}", user_id)).await?;
    Ok(Json(serde_json::json!({"success":true,"message":"all devices logged out","data":null})))
}

/// GET /api/admin/posts (all posts incl. non-approved)
pub async fn admin_list_posts(
    State(state): State<Arc<AppState>>,
    Query(q): Query<std::collections::HashMap<String, String>>,
) -> Result<Json<serde_json::Value>> {
    let page: i64 = q.get("page").and_then(|v| v.parse().ok()).unwrap_or(0);
    let size: i64 = q.get("size").and_then(|v| v.parse().ok()).unwrap_or(20).clamp(1, 100);
    let offset = page * size;
    let status_filter = q.get("status").cloned();

    let posts = match status_filter.as_deref() {
        Some(s) if s == "PENDING" || s == "APPROVED" || s == "REJECTED" => {
            sqlx::query_as::<sqlx::MySql, crate::models::Post>(
                "SELECT * FROM posts WHERE deleted=FALSE AND status=? ORDER BY created_at DESC LIMIT ? OFFSET ?")
                .bind(s).bind(size).bind(offset).fetch_all(&state.db).await?
        }
        _ => {
            sqlx::query_as::<sqlx::MySql, crate::models::Post>(
                "SELECT * FROM posts WHERE deleted=FALSE ORDER BY created_at DESC LIMIT ? OFFSET ?")
                .bind(size).bind(offset).fetch_all(&state.db).await?
        }
    };
    let total: (i64,) = sqlx::query_as("SELECT COUNT(*) FROM posts WHERE deleted=FALSE").fetch_one(&state.db).await?;

    let mut items = Vec::with_capacity(posts.len());
    for p in posts { items.push(super::user::post_summary_public(&state, p).await?); }
    let pages = (total.0 + size - 1) / size;
    Ok(Json(serde_json::json!({"success":true,"message":null,"data":{"items":items,"page":page,"size":size,"totalItems":total.0,"totalPages":pages,"hasNext":page+1<pages}})))
}

/// PATCH /api/admin/posts/:id/move?boardId=N (Java PostService.movePost parity)
pub async fn move_post(
    State(state): State<Arc<AppState>>,
    Extension(claims): Extension<Claims>,
    Path(post_id): Path<i64>,
    Query(q): Query<std::collections::HashMap<String, String>>,
) -> Result<Json<serde_json::Value>> {
    let board_id: i64 = q.get("boardId").and_then(|v| v.parse().ok())
        .ok_or_else(|| AppError::BadRequest("boardId required".into()))?;
    let post = sqlx::query_as::<sqlx::MySql, crate::models::Post>(
        "SELECT * FROM posts WHERE id=? AND deleted=FALSE")
        .bind(post_id).fetch_optional(&state.db).await?
        .ok_or_else(|| AppError::NotFound("\u{5e16}\u{5b50}\u{4e0d}\u{5b58}\u{5728}\u{6216}\u{5df2}\u{5220}\u{9664}".into()))?;
    if !crate::handlers::post::viewer_can_manage_board(&state, &claims, post.board_id).await? {
        return Err(AppError::Forbidden("\u{65e0}\u{6743}\u{64cd}\u{4f5c}\u{539f}\u{7248}\u{5757}".into()));
    }
    let exists: Option<(i64,)> = sqlx::query_as("SELECT id FROM boards WHERE id=?").bind(board_id)
        .fetch_optional(&state.db).await?;
    if exists.is_none() { return Err(AppError::NotFound("\u{677f}\u{5757}\u{4e0d}\u{5b58}\u{5728}".into())); }
    if board_id == post.board_id {
        return Ok(Json(serde_json::json!({"success":true,"message":"\u{5df2}\u{5728}\u{8be5}\u{677f}\u{5757}","data":null})));
    }
    sqlx::query("UPDATE posts SET board_id=?, updated_at=NOW() WHERE id=?").bind(board_id).bind(post_id)
        .execute(&state.db).await?;
    if post.status == "APPROVED" {
        sqlx::query("UPDATE boards SET post_count=GREATEST(post_count-1,0) WHERE id=?").bind(post.board_id).execute(&state.db).await?;
        sqlx::query("UPDATE boards SET post_count=post_count+1 WHERE id=?").bind(board_id).execute(&state.db).await?;
    }
    Ok(Json(serde_json::json!({"success":true,"message":"\u{8f6c}\u{79fb}\u{6210}\u{529f}","data":null})))
}

/// GET /api/admin/settings 闂?SettingsView (Java shape)
pub async fn get_settings(State(state): State<Arc<AppState>>) -> Result<Json<serde_json::Value>> {
    let s = crate::handlers::site::load_settings(&state).await?;
    Ok(Json(serde_json::json!({"success":true,"message":null,"data":{
        "siteName": s.0, "pageTitle": s.1, "siteDescription": s.2, "announcement": s.3,
        "allowRegister": s.4, "defaultTheme": s.5, "footerText": s.6, "footerIcp": s.7,
        "footerLinksJson": s.8, "signatureAuditMode": s.9,
        "emailVerificationEnabled": s.10, "arithmeticEmailEnabled": s.11,
        "arithmeticPostEnabled": s.12, "arithmeticCommentEnabled": s.13,
        "smtpEnabled": s.14, "smtpHost": s.15, "smtpPort": s.16, "smtpUsername": s.17,
        "smtpPasswordConfigured": s.18, "smtpSsl": s.19,
        "imageCompressEnabled": s.20, "videoCompressEnabled": s.21,
        "postEditAuditEnabled": s.22, "deviceVerificationEnabled": s.23,
        "imageMaxMb": s.24, "videoMaxMb": s.25,
        "officialWebsite": s.26, "webShareBaseUrl": s.27, "contactEmail": s.28,
        "aboutIcp": s.29, "autoRefreshSeconds": s.30
    }})))
}

/// PUT /api/admin/settings
pub async fn put_settings(
    State(state): State<Arc<AppState>>,
    Extension(claims): Extension<Claims>,
    Json(body): Json<serde_json::Value>,
) -> Result<Json<serde_json::Value>> {
    let updates: [(&str, &str); 15] = [
        ("siteName", "site_name"), ("pageTitle", "page_title"),
        ("siteDescription", "site_description"), ("announcement", "announcement"),
        ("defaultTheme", "default_theme"), ("footerText", "footer_text"),
        ("footerIcp", "footer_icp"), ("footerLinksJson", "footer_links_json"),
        ("signatureAuditMode", "signature_audit_mode"), ("officialWebsite", "official_website"),
        ("webShareBaseUrl", "web_share_base_url"), ("contactEmail", "contact_email"),
        ("aboutIcp", "about_icp"), ("smtpHost", "smtp_host"), ("smtpUsername", "smtp_username"),
    ];
    for (json_key, col) in updates {
        if let Some(v) = body.get(json_key).and_then(|v| v.as_str()) {
            let sql = format!("UPDATE site_settings SET {}=?, updated_at=NOW() WHERE id=1", col);
            sqlx::query(&sql).bind(v).execute(&state.db).await?;
        }
    }
    let bools: [(&str, &str); 11] = [
        ("allowRegister", "allow_register"),
        ("emailVerificationEnabled", "email_verification_enabled"),
        ("arithmeticEmailEnabled", "arithmetic_email_enabled"),
        ("arithmeticPostEnabled", "arithmetic_post_enabled"),
        ("arithmeticCommentEnabled", "arithmetic_comment_enabled"),
        ("smtpEnabled", "smtp_enabled"), ("smtpSsl", "smtp_ssl"),
        ("imageCompressEnabled", "image_compress_enabled"),
        ("videoCompressEnabled", "video_compress_enabled"),
        ("postEditAuditEnabled", "post_edit_audit_enabled"),
        ("deviceVerificationEnabled", "device_verification_enabled"),
    ];
    for (json_key, col) in bools {
        if let Some(v) = body.get(json_key).and_then(|v| v.as_bool()) {
            let sql = format!("UPDATE site_settings SET {}=?, updated_at=NOW() WHERE id=1", col);
            sqlx::query(&sql).bind(v).execute(&state.db).await?;
        }
    }
    for (json_key, col) in [("imageMaxMb", "image_max_mb"), ("videoMaxMb", "video_max_mb"), ("smtpPort", "smtp_port"), ("autoRefreshSeconds", "auto_refresh_seconds")] {
        if let Some(v) = body.get(json_key).and_then(|v| v.as_i64()) {
            let sql = format!("UPDATE site_settings SET {}=?, updated_at=NOW() WHERE id=1", col);
            sqlx::query(&sql).bind(v as i32).execute(&state.db).await?;
        }
    }
    if let Some(v) = body.get("smtpPassword").and_then(|v| v.as_str()) {
        if !v.is_empty() {
            sqlx::query("UPDATE site_settings SET smtp_password=?, updated_at=NOW() WHERE id=1")
                .bind(v).execute(&state.db).await?;
        }
    }
    log_action(&state, claims.user_id(), "UPDATE_SETTINGS", "更新站点设置", "site_settings:1").await?;
    Ok(Json(serde_json::json!({"success":true,"message":"settings saved","data":null})))
}

// ---------- admin boards CRUD ----------
#[derive(Debug, Deserialize)]
pub struct BoardRequest {
    pub name: String,
    pub description: Option<String>,
    #[serde(rename = "sortOrder")]
    pub sort_order: Option<i32>,
    pub visible: Option<bool>,
    #[serde(rename = "requireModeration")]
    pub require_moderation: Option<bool>,
}

/// GET /api/admin/boards 闂?client expects data: List directly
pub async fn admin_boards(State(state): State<Arc<AppState>>) -> Result<Json<serde_json::Value>> {
    let boards = sqlx::query_as::<sqlx::MySql, crate::models::Board>(
        "SELECT * FROM boards ORDER BY sort_order ASC, id ASC").fetch_all(&state.db).await?;
    Ok(Json(serde_json::json!({"success":true,"message":null,"data":boards})))
}

/// POST /api/admin/boards
pub async fn create_board(
    State(state): State<Arc<AppState>>,
    Extension(claims): Extension<Claims>,
    Json(req): Json<BoardRequest>,
) -> Result<Json<serde_json::Value>> {
    let result = sqlx::query("INSERT INTO boards(created_at,updated_at,name,description,sort_order,post_count,visible,require_moderation) VALUES(NOW(),NOW(),?,?,?,0,?,?)")
        .bind(&req.name).bind(&req.description).bind(req.sort_order.unwrap_or(0))
        .bind(req.visible.unwrap_or(true)).bind(req.require_moderation.unwrap_or(false))
        .execute(&state.db).await?;
    let board_id = result.last_insert_id();
    log_action(&state, claims.user_id(), "CREATE_BOARD", "创建板块", &format!("board:{}", board_id)).await?;
    Ok(Json(serde_json::json!({"success":true,"message":"created","data":null})))
}

/// PUT /api/admin/boards/:id
pub async fn update_board(
    State(state): State<Arc<AppState>>,
    Extension(claims): Extension<Claims>,
    Path(id): Path<i64>,
    Json(req): Json<BoardRequest>,
) -> Result<Json<serde_json::Value>> {
    sqlx::query("UPDATE boards SET name=?,description=?,sort_order=?,visible=?,require_moderation=?,updated_at=NOW() WHERE id=?")
        .bind(&req.name).bind(&req.description).bind(req.sort_order.unwrap_or(0))
        .bind(req.visible.unwrap_or(true)).bind(req.require_moderation.unwrap_or(false)).bind(id)
        .execute(&state.db).await?;
    log_action(&state, claims.user_id(), "UPDATE_BOARD", "更新板块", &format!("board:{}", id)).await?;
    Ok(Json(serde_json::json!({"success":true,"message":"updated","data":null})))
}

/// DELETE /api/admin/boards/:id
pub async fn delete_board(
    State(state): State<Arc<AppState>>,
    Extension(claims): Extension<Claims>,
    Path(id): Path<i64>,
) -> Result<Json<serde_json::Value>> {
    let used: (i64,) = sqlx::query_as("SELECT COUNT(*) FROM posts WHERE board_id=? AND deleted=FALSE")
        .bind(id).fetch_one(&state.db).await?;
    if used.0 > 0 { return Err(AppError::BadRequest("\u{677f}\u{5757}\u{4e0b}\u{4ecd}\u{6709}\u{5e16}\u{5b50}\u{ff0c}\u{8bf7}\u{5148}\u{8f6c}\u{79fb}\u{6216}\u{5220}\u{9664}\u{5e16}\u{5b50}\u{540e}\u{518d}\u{5220}\u{9664}".into())); }
    sqlx::query("DELETE FROM boards WHERE id=?").bind(id).execute(&state.db).await?;
    log_action(&state, claims.user_id(), "DELETE_BOARD", "删除板块", &format!("board:{}", id)).await?;
    Ok(Json(serde_json::json!({"success":true,"message":"deleted","data":null})))
}

// ---------- reports ----------
/// GET /api/admin/reports?status=&size=
pub async fn list_reports(
    State(state): State<Arc<AppState>>,
    Query(q): Query<std::collections::HashMap<String, String>>,
) -> Result<Json<serde_json::Value>> {
    let page: i64 = q.get("page").and_then(|v| v.parse().ok()).unwrap_or(0);
    let size: i64 = q.get("size").and_then(|v| v.parse().ok()).unwrap_or(50).clamp(1, 100);
    let offset = page * size;
    let status = q.get("status").cloned().unwrap_or_else(|| "PENDING".into());

    struct Rep { id: i64, target_type: String, target_id: i64, reporter_id: i64, reason: String, status: String, handle_note: Option<String>, handled_by: Option<i64>, evidence_json: Option<String>, created_at: chrono::DateTime<chrono::Utc> }
    impl<'r> sqlx::FromRow<'r, sqlx::mysql::MySqlRow> for Rep {
        fn from_row(row: &'r sqlx::mysql::MySqlRow) -> std::result::Result<Self, sqlx::Error> {
            use sqlx::Row;
            Ok(Rep{ id: row.try_get("id")?, target_type: row.try_get("target_type")?,
                target_id: row.try_get("target_id")?, reporter_id: row.try_get("reporter_id")?,
                reason: row.try_get("reason")?, status: row.try_get::<String,_>("status")?,
                handle_note: row.try_get("handle_note")?, handled_by: row.try_get("handled_by")?, evidence_json: row.try_get("evidence_json").ok(),
                created_at: row.try_get("created_at")? })
        }
    }

    let rows = sqlx::query_as::<sqlx::MySql, Rep>(
        "SELECT id,target_type,target_id,reporter_id,reason,status,handle_note,handled_by,evidence_json,created_at FROM reports WHERE status=? ORDER BY created_at DESC LIMIT ? OFFSET ?")
        .bind(&status).bind(size).bind(offset).fetch_all(&state.db).await?;

    let mut items = Vec::with_capacity(rows.len());
    for r in rows {
        // target summary: check existence
        let (deleted, target_author, summary) = match r.target_type.as_str() {
            "POST" => {
                let row: Option<(bool, i64, String)> = sqlx::query_as(
                    "SELECT deleted, author_id, LEFT(title,60) FROM posts WHERE id=?").bind(r.target_id)
                    .fetch_optional(&state.db).await?.map(|(d,a,t)| (d, a, t));
                match row { Some((d,a,t)) => (d, Some(a), t), None => (true, None, String::new()) }
            }
            "COMMENT" => {
                let row: Option<(bool, i64, String)> = sqlx::query_as(
                    "SELECT c.deleted, c.author_id, LEFT(c.content,60) FROM comments c WHERE c.id=?")
                    .bind(r.target_id).fetch_optional(&state.db).await?
                    .map(|(d,a,t)| (d, a, t));
                match row { Some((d,a,t)) => (d, Some(a), t), None => (true, None, String::new()) }
            }
            _ => (false, None, String::new()),
        };
        items.push(serde_json::json!({
            "id": r.id, "targetType": r.target_type, "targetId": r.target_id,
            "reporterId": r.reporter_id, "reason": r.reason, "status": r.status,
            "handleNote": r.handle_note, "handledBy": r.handled_by, "evidence": r.evidence_json.and_then(|e| serde_json::from_str::<serde_json::Value>(&e).ok()), "createdAt": r.created_at,
            "deleted": deleted, "targetAuthorId": target_author, "summary": summary
        }));
    }
    let pages = (size - 1 + size) / size; // unknown total; single-page approximation
    Ok(Json(serde_json::json!({"success":true,"message":null,"data":{"items":items,"page":page,"size":size,"totalItems":items.len() as i64,"totalPages":pages,"hasNext":false}})))
}

async fn resolve_report(state: &AppState, id: i64, note: Option<String>, resolved: bool) -> Result<()> {
    let status = if resolved { "RESOLVED" } else { "REJECTED" };
    let me: Option<(i64,)> = None;
    let _ = me;
    sqlx::query("UPDATE reports SET status=?, handle_note=COALESCE(handle_note,?), handled_by=COALESCE(handled_by,0), updated_at=NOW() WHERE id=?")
        .bind(status).bind(note).bind(id).execute(&state.db).await?;
    let _ = state;
    Ok(())
}

/// POST /api/admin/reports/:id/resolve?note=
pub async fn resolve_report_route(
    State(state): State<Arc<AppState>>,
    Path(id): Path<i64>,
    Query(q): Query<std::collections::HashMap<String, String>>,
) -> Result<Json<serde_json::Value>> {
    resolve_report(&state, id, q.get("note").cloned(), true).await?;
    Ok(Json(serde_json::json!({"success":true,"message":"resolved","data":null})))
}

/// POST /api/admin/reports/:id/reject?note=
pub async fn reject_report_route(
    State(state): State<Arc<AppState>>,
    Path(id): Path<i64>,
    Query(q): Query<std::collections::HashMap<String, String>>,
) -> Result<Json<serde_json::Value>> {
    resolve_report(&state, id, q.get("note").cloned(), false).await?;
    Ok(Json(serde_json::json!({"success":true,"message":"rejected","data":null})))
}

// ---------- maintenance ----------
/// GET /api/admin/maintenance/stats
pub async fn maintenance_stats(State(state): State<Arc<AppState>>) -> Result<Json<serde_json::Value>> {
    let revoked: (i64,) = sqlx::query_as("SELECT COUNT(*) FROM user_sessions WHERE revoked=TRUE").fetch_one(&state.db).await?;
    let messages: (i64,) = sqlx::query_as("SELECT COUNT(*) FROM messages").fetch_one(&state.db).await?;
    Ok(Json(serde_json::json!({"success":true,"message":null,"data":{
        "logFiles": 0, "revokedDevices": revoked.0, "messages": messages.0
    }})))
}

/// POST /api/admin/maintenance/clear/:target
pub async fn maintenance_clear(
    State(state): State<Arc<AppState>>,
    Path(target): Path<String>,
) -> Result<Json<serde_json::Value>> {
    match target.as_str() {
        "devices" => { sqlx::query("DELETE FROM user_sessions WHERE revoked=TRUE").execute(&state.db).await?; }
        "messages" => { sqlx::query("DELETE FROM messages").execute(&state.db).await?; }
        "logs" => { /* app logs are files on disk; nothing to clear in DB */ }
        _ => return Err(AppError::BadRequest("unknown target".into())),
    }
    Ok(Json(serde_json::json!({"success":true,"message":"cleared","data":null})))
}
