use chrono::{Duration, Utc};
use jsonwebtoken::{decode, encode, DecodingKey, EncodingKey, Header, Validation};
use serde::{Deserialize, Serialize};
use crate::error::{AppError, Result};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Claims {
    pub sub: String,        // user_id as string (matches Java)
    pub username: String,
    pub role: String,
    pub exp: i64,
    pub iat: i64,
    pub iss: String,
}

impl Claims {
    pub fn new(user_id: i64, username: String, role: String, expiration_seconds: i64) -> Self {
        let now = Utc::now();
        let exp = now + Duration::seconds(expiration_seconds);

        Self {
            sub: user_id.to_string(),
            username,
            role,
            exp: exp.timestamp(),
            iat: now.timestamp(),
            iss: "forum-server".to_string(),
        }
    }

    pub fn user_id(&self) -> i64 {
        self.sub.parse::<i64>().unwrap_or(0)
    }
}

pub fn create_token(claims: &Claims, secret: &str) -> Result<String> {
    let token = encode(
        &Header::default(),
        claims,
        &EncodingKey::from_secret(secret.as_ref()),
    )?;
    Ok(token)
}

pub fn verify_token(token: &str, secret: &str) -> Result<Claims> {
    let token_data = decode::<Claims>(
        token,
        &DecodingKey::from_secret(secret.as_ref()),
        &Validation::default(),
    )?;
    Ok(token_data.claims)
}

pub fn extract_user_id(token: &str, secret: &str) -> Result<i64> {
    let claims = verify_token(token, secret)?;
    Ok(claims.user_id())
}
