use axum::{Json, response::IntoResponse};
use serde_json::json;

pub async fn health_check() -> impl IntoResponse {
    Json(json!({
        "success": true,
        "message": null,
        "data": { "status": "UP" },
    }))
}
