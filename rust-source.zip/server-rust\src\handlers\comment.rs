use axum::{extract::{Extension, Path, Query, State}, Json};
use serde::Deserialize;
use std::sync::Arc;
use validator::Validate;

use crate::{config::AppState, error::{AppError, Result}, models::{Comment, User}, utils::Claims};

#[derive(Debug, Deserialize)]
pub struct ListCommentsQuery {
    pub page: Option<i64>,
    #[serde(rename = "size")]
    pub size: Option<i64>,
    pub sort: Option<String>,
}

#[derive(Debug, Deserialize, Validate)]
pub struct CreateCommentRequest {
    #[validate(length(min = 1, max = 5000))]
    pub content: String,
    #[serde(rename = "parentId")]
    pub parent_id: Option<i64>,
}

#[derive(Debug, Deserialize, Validate)]
pub struct UpdateCommentRequest {
    #[validate(length(min = 1, max = 5000))]
    pub content: String,
}

async fn author_json(state: &AppState, uid: i64) -> Result<serde_json::Value> {
    let u = sqlx::query_as::<sqlx::MySql, User>("SELECT * FROM users WHERE id=?")
        .bind(uid).fetch_one(&state.db).await?;
    Ok(crate::handlers::user::author_brief_anon(&u))
}

/// Per-comment viewer flags: liked/disliked by viewer, deletable (author or board moderator).
struct ViewerFlags { liked: bool, disliked: bool, can_delete: bool, can_edit: bool }

async fn viewer_flags(
    state: &AppState,
    viewer: Option<&Claims>,
    comment: &Comment,
    board_id: i64,
    is_moderator: bool,
) -> Result<ViewerFlags> {
    let _ = board_id;
    let Some(v) = viewer else {
        return Ok(ViewerFlags { liked: false, disliked: false, can_delete: false, can_edit: false });
    };
    let me = v.user_id();
    let mine = comment.author_id == me;
    let liked: Option<(i64,)> = sqlx::query_as(
        "SELECT id FROM likes WHERE user_id=? AND target_type='COMMENT' AND target_id=?")
        .bind(me).bind(comment.id).fetch_optional(&state.db).await?;
    let disliked: Option<(i64,)> = sqlx::query_as(
        "SELECT id FROM dislikes WHERE user_id=? AND target_type='COMMENT' AND target_id=?")
        .bind(me).bind(comment.id).fetch_optional(&state.db).await?;
    Ok(ViewerFlags {
        liked: liked.is_some(),
        disliked: disliked.is_some(),
        can_delete: mine || is_moderator,
        can_edit: mine,
    })
}

fn comment_json(c: &Comment, author: &serde_json::Value, replies: Vec<serde_json::Value>, flags: &ViewerFlags) -> serde_json::Value {
    serde_json::json!({
        "id": c.id, "content": c.content, "postId": c.post_id, "parentId": c.parent_id,
        "author": author,
        "likeCount": c.like_count, "dislikeCount": c.dislike_count,
        "likedByMe": flags.liked, "dislikedByMe": flags.disliked,
        "canEdit": flags.can_edit, "canDelete": flags.can_delete,
        "replies": replies, "createdAt": c.created_at
    })
}

/// GET /api/posts/{postId}/comments — tree structure like Java
pub async fn list_comments(
    State(state): State<Arc<AppState>>,
    headers: axum::http::HeaderMap,
    Path(post_id): Path<i64>,
    Query(q): Query<ListCommentsQuery>,
) -> Result<Json<serde_json::Value>> {
    let page = q.page.unwrap_or(0).max(0);
    let size = q.size.unwrap_or(20).clamp(1, 100);
    let offset = page * size;
    let order = if q.sort.as_deref() == Some("hot") { "like_count DESC, created_at ASC" } else { "created_at ASC" };

    // viewer context for likedByMe/dislikedByMe/canDelete/canEdit
    let viewer = crate::handlers::post::optional_viewer(&headers, &state.config.jwt_secret);
    let board_id: Option<(i64,)> = sqlx::query_as("SELECT board_id FROM posts WHERE id=?")
        .bind(post_id).fetch_optional(&state.db).await?;
    let board_id = board_id.map(|(b,)| b).unwrap_or(0);
    let is_moderator = match &viewer {
        Some(v) => crate::handlers::post::viewer_can_manage_board(&state, v, board_id).await?,
        None => false,
    };


    // 1. query top-level comments only (parent_id IS NULL)
    let top_sql = format!(
        "SELECT * FROM comments WHERE post_id=? AND deleted=FALSE AND parent_id IS NULL ORDER BY {} LIMIT ? OFFSET ?",
        order
    );
    let tops = sqlx::query_as::<sqlx::MySql, Comment>(&top_sql)
        .bind(post_id).bind(size).bind(offset)
        .fetch_all(&state.db).await?;

    let total: (i64,) = sqlx::query_as(
        "SELECT COUNT(*) FROM comments WHERE post_id=? AND deleted=FALSE AND parent_id IS NULL")
        .bind(post_id).fetch_one(&state.db).await?;

    // total includes replies (Java counts all non-deleted comments for the post)
    let all_total: (i64,) = sqlx::query_as(
        "SELECT COUNT(*) FROM comments WHERE post_id=? AND deleted=FALSE")
        .bind(post_id).fetch_one(&state.db).await?;

    // 2. collect top-level ids
    let top_ids: Vec<i64> = tops.iter().map(|c| c.id).collect();
    if top_ids.is_empty() {
        return Ok(Json(serde_json::json!({"success":true,"message":null,"data":{
            "items":[],"page":page,"size":size,"totalItems":0,"totalPages":0,"hasNext":false
        }})));
    }

    // 3. build IN clause and fetch all replies in one query
    let placeholders: Vec<&str> = top_ids.iter().map(|_| "?").collect();
    let reply_sql = format!(
        "SELECT * FROM comments WHERE post_id=? AND deleted=FALSE AND parent_id IN ({}) ORDER BY created_at ASC",
        placeholders.join(",")
    );
    let mut q2 = sqlx::query_as::<sqlx::MySql, Comment>(&reply_sql).bind(post_id);
    for id in &top_ids { q2 = q2.bind(id); }
    let all_replies = q2.fetch_all(&state.db).await?;

    // 4. group replies by parent_id
    use std::collections::HashMap;
    let mut reply_map: HashMap<i64, Vec<Comment>> = HashMap::new();
    for r in all_replies {
        if let Some(pid) = r.parent_id { reply_map.entry(pid).or_default().push(r); }
    }

    // 5. build tree items
    let mut items = Vec::with_capacity(tops.len());
    for top in &tops {
        let author = author_json(&state, top.author_id).await?;

        let mut replies_json = Vec::new();
        if let Some(replies) = reply_map.get(&top.id) {
            for r in replies {
                let r_author = author_json(&state, r.author_id).await?;
                let r_flags = viewer_flags(&state, viewer.as_ref(), r, board_id, is_moderator).await?;
                replies_json.push(comment_json(r, &r_author, vec![], &r_flags));
            }
        }

        let flags = viewer_flags(&state, viewer.as_ref(), top, board_id, is_moderator).await?;
        items.push(comment_json(top, &author, replies_json, &flags));
    }

    let pages = (total.0 + size - 1) / size;
    Ok(Json(serde_json::json!({"success":true,"message":null,"data":{
        "items":items,"page":page,"size":size,
        "totalItems":all_total.0,"totalPages":pages,"hasNext":page+1<pages
    }})))
}

/// POST /api/posts/{postId}/comments
pub async fn create_comment(
    State(state): State<Arc<AppState>>,
    Extension(claims): Extension<Claims>,
    Path(post_id): Path<i64>,
    Json(req): Json<CreateCommentRequest>,
) -> Result<Json<serde_json::Value>> {
    req.validate().map_err(|e| AppError::Validation(e.to_string()))?;

    let exists: Option<(i64,)> = sqlx::query_as(
        "SELECT id FROM posts WHERE id=? AND deleted=FALSE AND status='APPROVED'")
        .bind(post_id).fetch_optional(&state.db).await?;
    if exists.is_none() { return Err(AppError::NotFound("post not found".into())); }

    // resolve parent: if replying to a child comment, merge up to root (same as Java)
    let resolved_parent = if let Some(pid) = req.parent_id {
        let parent = sqlx::query_as::<sqlx::MySql, Comment>(
            "SELECT * FROM comments WHERE id=? AND deleted=FALSE")
            .bind(pid).fetch_optional(&state.db).await?;
        match parent {
            Some(p) => {
                if p.post_id != post_id {
                    return Err(AppError::BadRequest("comment not on this post".into()));
                }
                // walk up to root
                let mut root = p.parent_id.unwrap_or(p.id);
                while let Some(grand) = sqlx::query_scalar::<_, Option<i64>>(
                    "SELECT parent_id FROM comments WHERE id=?")
                    .bind(root).fetch_optional(&state.db).await?
                    .flatten()
                {
                    if grand == 0 || grand == root { break; }
                    root = grand;
                }
                Some(root)
            }
            None => return Err(AppError::NotFound("parent comment not found".into())),
        }
    } else { None };

    let r = sqlx::query(
        "INSERT INTO comments(created_at,updated_at,content,deleted,like_count,dislike_count,author_id,parent_id,post_id) VALUES(NOW(),NOW(),?,FALSE,0,0,?,?,?)")
        .bind(&req.content).bind(claims.user_id()).bind(resolved_parent).bind(post_id)
        .execute(&state.db).await?;
    let cid = r.last_insert_id() as i64;

    sqlx::query("UPDATE posts SET comment_count=comment_count+1,last_activity_at=NOW() WHERE id=?")
        .bind(post_id).execute(&state.db).await?;

    Ok(Json(serde_json::json!({"success":true,"message":"reply ok","data":{"id":cid}})))
}

/// PUT /api/comments/:id
pub async fn update_comment(
    State(state): State<Arc<AppState>>,
    Extension(claims): Extension<Claims>,
    Path(id): Path<i64>,
    Json(req): Json<UpdateCommentRequest>,
) -> Result<Json<serde_json::Value>> {
    req.validate().map_err(|e| AppError::Validation(e.to_string()))?;
    let c = sqlx::query_as::<sqlx::MySql, Comment>("SELECT * FROM comments WHERE id=? AND deleted=FALSE")
        .bind(id).fetch_optional(&state.db).await?
        .ok_or_else(|| AppError::NotFound("comment not found".into()))?;
    if c.author_id != claims.user_id() { return Err(AppError::Forbidden("no permission".into())); }
    sqlx::query("UPDATE comments SET content=?, updated_at=NOW() WHERE id=?")
        .bind(req.content).bind(id).execute(&state.db).await?;
    Ok(Json(serde_json::json!({"success":true,"message":null,"data":null})))
}

/// DELETE /api/comments/:id — hard delete (consistent with post hard delete)
pub async fn delete_comment(
    State(state): State<Arc<AppState>>,
    Extension(claims): Extension<Claims>,
    Path(id): Path<i64>,
) -> Result<Json<serde_json::Value>> {
    let c = sqlx::query_as::<sqlx::MySql, Comment>("SELECT * FROM comments WHERE id=? AND deleted=FALSE")
        .bind(id).fetch_optional(&state.db).await?
        .ok_or_else(|| AppError::NotFound("\u{8bc4}\u{8bba}\u{4e0d}\u{5b58}\u{5728}".into()))?;
    let board_id: Option<(i64,)> = sqlx::query_as("SELECT board_id FROM posts WHERE id=?")
        .bind(c.post_id).fetch_optional(&state.db).await?;
    let is_moderator = match board_id {
        Some((b,)) => crate::handlers::post::viewer_can_manage_board(&state, &claims, b).await?,
        None => false,
    };
    if c.author_id != claims.user_id() && !is_moderator {
        return Err(AppError::Forbidden("\u{53ea}\u{80fd}\u{5220}\u{9664}\u{81ea}\u{5df1}\u{7684}\u{8bc4}\u{8bba}".into()));
    }
    // detach children then hard delete
    sqlx::query("UPDATE comments SET parent_id=NULL WHERE parent_id=?").bind(id).execute(&state.db).await?;
    sqlx::query("DELETE FROM likes WHERE target_type='COMMENT' AND target_id=?").bind(id).execute(&state.db).await?;
    sqlx::query("DELETE FROM dislikes WHERE target_type='COMMENT' AND target_id=?").bind(id).execute(&state.db).await?;
    sqlx::query("DELETE FROM comments WHERE id=?").bind(id).execute(&state.db).await?;
    sqlx::query("UPDATE posts SET comment_count=GREATEST(comment_count-1,0) WHERE id=?").bind(c.post_id).execute(&state.db).await?;
    Ok(Json(serde_json::json!({"success":true,"message":"\u{5220}\u{9664}\u{6210}\u{529f}","data":null})))
}

/// POST /api/comments/:id/like
pub async fn like_comment(
    State(state): State<Arc<AppState>>,
    Extension(claims): Extension<Claims>,
    Path(id): Path<i64>,
) -> Result<Json<serde_json::Value>> {
    let x: Option<(i64,)> = sqlx::query_as(
        "SELECT id FROM likes WHERE target_type='COMMENT' AND target_id=? AND user_id=?")
        .bind(id).bind(claims.user_id()).fetch_optional(&state.db).await?;
    if x.is_some() {
        sqlx::query("DELETE FROM likes WHERE target_type='COMMENT' AND target_id=? AND user_id=?")
            .bind(id).bind(claims.user_id()).execute(&state.db).await?;
        sqlx::query("UPDATE comments SET like_count=GREATEST(like_count-1,0) WHERE id=?")
            .bind(id).execute(&state.db).await?;
    } else {
        sqlx::query("INSERT INTO likes(created_at,updated_at,target_id,target_type,user_id) VALUES(NOW(),NOW(),?,'COMMENT',?)")
            .bind(id).bind(claims.user_id()).execute(&state.db).await?;
        sqlx::query("UPDATE comments SET like_count=like_count+1 WHERE id=?")
            .bind(id).execute(&state.db).await?;
    }
    Ok(Json(serde_json::json!({"success":true,"message":null,"data":null})))
}

/// POST /api/comments/:id/dislike (toggle)
pub async fn dislike_comment(
    State(state): State<Arc<AppState>>,
    Extension(claims): Extension<Claims>,
    Path(id): Path<i64>,
) -> Result<Json<serde_json::Value>> {
    let me = claims.user_id();
    let x: Option<(i64,)> = sqlx::query_as(
        "SELECT id FROM dislikes WHERE target_type='COMMENT' AND target_id=? AND user_id=?")
        .bind(id).bind(me).fetch_optional(&state.db).await?;
    if x.is_some() {
        sqlx::query("DELETE FROM dislikes WHERE target_type='COMMENT' AND target_id=? AND user_id=?")
            .bind(id).bind(me).execute(&state.db).await?;
        sqlx::query("UPDATE comments SET dislike_count=GREATEST(dislike_count-1,0) WHERE id=?")
            .bind(id).execute(&state.db).await?;
    } else {
        sqlx::query("INSERT INTO dislikes(created_at,updated_at,target_id,target_type,user_id) VALUES(NOW(),NOW(),?,'COMMENT',?)")
            .bind(id).bind(me).execute(&state.db).await?;
        sqlx::query("UPDATE comments SET dislike_count=dislike_count+1 WHERE id=?")
            .bind(id).execute(&state.db).await?;
    }
    Ok(Json(serde_json::json!({"success":true,"message":null,"data":null})))
}

/// POST /api/comments/:id/report
pub async fn report_comment(
    State(state): State<Arc<AppState>>,
    Extension(claims): Extension<Claims>,
    Path(id): Path<i64>,
    Json(body): Json<serde_json::Value>,
) -> Result<Json<serde_json::Value>> {
    let reason = body.get("reason").and_then(|v| v.as_str()).unwrap_or("").to_string();
    sqlx::query("INSERT INTO reports(created_at,updated_at,target_type,target_id,reporter_id,reason,status) VALUES(NOW(),NOW(),?,'COMMENT',?,?,'PENDING')")
        .bind(id).bind(claims.user_id()).bind(reason)
        .execute(&state.db).await?;
    Ok(Json(serde_json::json!({"success":true,"message":"reported","data":null})))
}
