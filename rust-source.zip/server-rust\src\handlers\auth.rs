use axum::{extract::{Extension, Path, State}, Json};
use serde::Deserialize;
use std::sync::Arc;
use validator::Validate;

use redis::AsyncCommands;
use crate::{config::AppState, error::{AppError, Result}, models::User, utils::{jwt, password, Claims}};

#[derive(Debug, Deserialize, Validate)]
pub struct RegisterRequest {
    #[validate(length(min = 3, max = 32))]
    pub username: String,
    #[validate(length(min = 8, max = 72))]
    pub password: String,
    #[validate(email)]
    pub email: Option<String>,
    pub nickname: Option<String>,
    #[serde(rename = "emailCode")]
    pub email_code: Option<String>,
}

#[derive(Debug, Deserialize, Validate)]
pub struct LoginRequest {
    #[validate(length(min = 1))]
    pub username: String,
    #[validate(length(min = 1))]
    pub password: String,
    #[serde(rename = "deviceId")]
    pub device_id: Option<String>,
    #[serde(rename = "deviceName")]
    pub device_name: Option<String>,
}

fn build_user_profile(u: &User) -> serde_json::Value {
    let display_name = u.nickname.clone().unwrap_or_else(|| u.username.clone());
    serde_json::json!({
        "id": u.id, "uid": u.uid, "username": u.username, "nickname": u.nickname,
        "displayName": display_name, "avatarUrl": u.avatar_url, "signature": u.signature,
        "role": u.role, "status": u.status, "postCount": u.post_count, "commentCount": u.comment_count,
        "level": u.level, "exp": u.exp, "gold": u.gold, "checkinStreak": u.checkin_streak,
        "title": u.title, "managedBoardId": u.managed_board_id, "rankingWeight": u.ranking_weight,
        "pendingSignature": u.pending_signature, "emailVerified": u.email_verified,
        "maxUploadMb": u.max_upload_mb, "createdAt": u.created_at
    })
}

pub async fn register(State(state): State<Arc<AppState>>, Json(req): Json<RegisterRequest>) -> Result<Json<serde_json::Value>> {
    req.validate().map_err(|e| AppError::Validation(e.to_string()))?;
    // site settings: allow_register / email_verification_enabled
    struct S { allow_register: bool, email_verification_enabled: bool }
    impl<'r> sqlx::FromRow<'r, sqlx::mysql::MySqlRow> for S {
        fn from_row(row: &'r sqlx::mysql::MySqlRow) -> std::result::Result<Self, sqlx::Error> {
            use sqlx::Row;
            Ok(S{ allow_register: row.try_get::<bool,_>("allow_register").unwrap_or(true),
                email_verification_enabled: row.try_get::<bool,_>("email_verification_enabled").unwrap_or(false) })
        }
    }
    let s = sqlx::query_as::<sqlx::MySql, S>("SELECT allow_register, email_verification_enabled FROM site_settings WHERE id=1")
        .fetch_optional(&state.db).await?;
    let email_verification_enabled = s.as_ref().map(|s| s.email_verification_enabled).unwrap_or(false);
    if s.as_ref().map(|s| !s.allow_register).unwrap_or(false) {
        let cnt: (i64,) = sqlx::query_as("SELECT COUNT(*) FROM users").fetch_one(&state.db).await?;
        if cnt.0 > 0 { return Err(AppError::Forbidden("\u{5f53}\u{524d}\u{5df2}\u{5173}\u{95ed}\u{7528}\u{6237}\u{6ce8}\u{518c}".into())); }
    }

    let username = req.username.trim();
    let existing = sqlx::query_as::<sqlx::MySql, User>("SELECT * FROM users WHERE username=?").bind(username).fetch_optional(&state.db).await?;
    if existing.is_some() { return Err(AppError::Conflict("\u{7528}\u{6237}\u{540d}\u{5df2}\u{88ab}\u{5360}\u{7528}".into())); }
    let email = req.email.as_deref().map(str::trim).filter(|e| !e.is_empty()).map(str::to_string);
    if let Some(e) = &email {
        let taken: Option<(i64,)> = sqlx::query_as("SELECT id FROM users WHERE email=?").bind(e).fetch_optional(&state.db).await?;
        if taken.is_some() { return Err(AppError::Conflict("\u{90ae}\u{7bb1}\u{5df2}\u{88ab}\u{6ce8}\u{518c}".into())); }
    }
    // email verification code check (Java-compatible key verify:email:<email>)
    if email_verification_enabled {
        let mut ok = false;
        if let (Some(code), Some(e)) = (&req.email_code, &email) {
            let mut conn = state.redis.clone();
            let key = format!("verify:email:{}", e.to_lowercase());
            let stored: Option<String> = redis::AsyncCommands::get(&mut conn, &key).await.unwrap_or(None);
            if let Some(stored) = stored {
                if stored == *code {
                    let _: std::result::Result<i64, _> = redis::AsyncCommands::del(&mut conn, &key).await;
                    ok = true;
                } else {
                    ok = false;
                }
            }
        }
        if !ok { return Err(AppError::BadRequest("\u{90ae}\u{7bb1}\u{9a8c}\u{8bc1}\u{7801}\u{9519}\u{8bef}\u{6216}\u{5df2}\u{8fc7}\u{671f}".into())); }
    }
    let password_hash = password::hash_password(&req.password)?;
    let result = sqlx::query("INSERT INTO users(username,uid,password_hash,email,nickname,email_verified,role,status,post_count,comment_count,level,exp,gold,checkin_streak,signature_approved_once,failed_login_count,ranking_weight,created_at,updated_at) VALUES(?,?,?,?,?,?,?,'ACTIVE',0,0,1,0,0,0,false,0,1.0,NOW(),NOW())")
        .bind(username).bind(generate_uid()).bind(&password_hash).bind(&email).bind(&req.nickname)
        .bind(email_verification_enabled)
        .execute(&state.db).await?;
    let user_id = result.last_insert_id() as i64;
    let user = sqlx::query_as::<sqlx::MySql, User>("SELECT * FROM users WHERE id=?").bind(user_id).fetch_one(&state.db).await?;
    create_session(&state, user.id, None, req.nickname.as_deref(), None).await?;
    let claims = Claims::new(user_id, user.username.clone(), user.role.clone(), state.config.jwt_expiration_seconds);
    let token = jwt::create_token(&claims, &state.config.jwt_secret)?;
    Ok(Json(serde_json::json!({"success":true,"message":"register ok","data":{"token":token,"expiresInSeconds":state.config.jwt_expiration_seconds,"user":build_user_profile(&user),"pendingDeviceId":null,"emailSent":false}})))
}

/// Create a user session row (mirrors Java DeviceService.createSession).
async fn create_session(state: &AppState, user_id: i64, device_id: Option<&str>, device_name: Option<&str>, user_agent: Option<&str>) -> Result<String> {
    let sid = uuid::Uuid::new_v4().simple().to_string();
    sqlx::query("INSERT INTO user_sessions(sid,user_id,device_id,device_name,user_agent,created_at,updated_at,created_at2,last_seen_at,revoked) VALUES(?,?,?,?,?,NOW(),NOW(),NOW(),NOW(),FALSE)")
        .bind(&sid).bind(user_id)
        .bind(device_id.map(str::trim).filter(|s| !s.is_empty()))
        .bind(device_name).bind(user_agent)
        .execute(&state.db).await?;
    Ok(sid)
}

async fn device_verification_enabled(db: &sqlx::MySqlPool) -> Result<bool> {
    struct S { device_verification_enabled: bool }
    impl<'r> sqlx::FromRow<'r, sqlx::mysql::MySqlRow> for S {
        fn from_row(row: &'r sqlx::mysql::MySqlRow) -> std::result::Result<Self, sqlx::Error> {
            use sqlx::Row;
            Ok(S{ device_verification_enabled: row.try_get::<bool,_>("device_verification_enabled").unwrap_or(false) })
        }
    }
    let s = sqlx::query_as::<sqlx::MySql, S>("SELECT device_verification_enabled FROM site_settings WHERE id=1")
        .fetch_optional(db).await?;
    Ok(s.map(|s| s.device_verification_enabled).unwrap_or(false))
}

pub async fn login(State(state): State<Arc<AppState>>, Json(req): Json<LoginRequest>) -> Result<Json<serde_json::Value>> {
    req.validate().map_err(|e| AppError::Validation(e.to_string()))?;
    let acct = req.username.trim();
    let user = sqlx::query_as::<sqlx::MySql, User>("SELECT * FROM users WHERE username=? OR email=? OR uid=?")
        .bind(acct).bind(acct).bind(acct).fetch_optional(&state.db).await?;
    let user = user.ok_or_else(|| AppError::Auth("\u{7528}\u{6237}\u{540d}\u{6216}\u{5bc6}\u{7801}\u{9519}\u{8bef}".into()))?;
    if user.status == "BANNED" { return Err(AppError::Forbidden("\u{8d26}\u{53f7}\u{5df2}\u{88ab}\u{5c01}\u{7981}\u{ff0c}\u{8bf7}\u{8054}\u{7cfb}\u{7ba1}\u{7406}\u{5458}".into())); }
    if user.status == "CANCELLED" { return Err(AppError::Forbidden("\u{8be5}\u{8d26}\u{53f7}\u{5df2}\u{6ce8}\u{9500}".into())); }
    if let Some(locked) = user.locked_until { if locked > chrono::Utc::now() { return Err(AppError::Forbidden("account locked".into())); } }
    let valid = password::verify_password(&req.password, &user.password_hash)?;
    if !valid {
        sqlx::query("UPDATE users SET failed_login_count=failed_login_count+1 WHERE id=?").bind(user.id).execute(&state.db).await?;
        return Err(AppError::Auth("\u{7528}\u{6237}\u{540d}\u{6216}\u{5bc6}\u{7801}\u{9519}\u{8bef}".into()));
    }
    sqlx::query("UPDATE users SET failed_login_count=0,locked_until=NULL WHERE id=?").bind(user.id).execute(&state.db).await?;

    // device verification: unknown device requires email code (Java-compatible)
    if device_verification_enabled(&state.db).await? {
        let dev = req.device_id.as_deref().map(str::trim).unwrap_or("");
        let known = if dev.is_empty() { false } else {
            let c: Option<(i64,)> = sqlx::query_as(
                "SELECT id FROM user_sessions WHERE user_id=? AND device_id=? AND revoked=FALSE")
                .bind(user.id).bind(dev).fetch_optional(&state.db).await?;
            c.is_some()
        };
        if !known {
            let email = user.email.clone().unwrap_or_default();
            if email.trim().is_empty() { return Err(AppError::Forbidden("\u{8be5}\u{8d26}\u{53f7}\u{672a}\u{7ed1}\u{90ae}\u{7bb1}\u{ff0c}\u{65e0}\u{6cd5}\u{8fdb}\u{884c}\u{6362}\u{8bbe}\u{5907}\u{9a8c}\u{8bc1}".into())); }
            let mut conn = state.redis.clone();
            let scope = format!("device:{}", user.id);
            crate::utils::mail::enforce_cooldown(&mut conn, &scope).await?;
            let code = crate::utils::mail::gen_code();
            crate::utils::mail::send_code_email(
                &state.db,
                email.trim(),
                "\u{65b0}\u{8bbe}\u{5907}\u{767b}\u{5f55}\u{9a8c}\u{8bc1}\u{7801}",
        &format!("\u{60a8}\u{7684}\u{65b0}\u{8bbe}\u{5907}\u{767b}\u{5f55}\u{9a8c}\u{8bc1}\u{7801}\u{662f}\u{ff1a}{}\u{ff0c}5\u{5206}\u{949f}\u{5185}\u{6709}\u{6548}\u{3002}\u{82e5}\u{975e}\u{672c}\u{4eba}\u{64cd}\u{4f5c}\u{8bf7}\u{7acb}\u{5373}\u{4fee}\u{6539}\u{5bc6}\u{7801}\u{3002}", code),
            ).await?;
            let key = format!("device:{}", user.id);
            let _: () = redis::AsyncCommands::set_ex(&mut conn, &key, code, 300u64).await
                .map_err(|e| AppError::Internal(format!("redis error: {e}")))?;
            sqlx::query("INSERT INTO notifications(created_at,updated_at,type,title,content,ref_id,read_flag,user_id) VALUES(NOW(),NOW(),'DEVICE_LOGIN','\u{68c0}\u{6d4b}\u{5230}\u{65b0}\u{8bbe}\u{5907}\u{767b}\u{5f55}','\u{68c0}\u{6d4b}\u{5230}\u{65b0}\u{8bbe}\u{5907}\u{5c1d}\u{8bd5}\u{767b}\u{5f55}\u{60a8}\u{7684}\u{8d26}\u{53f7}\u{ff0c}\u{9700}\u{8981}\u{90ae}\u{7bb1}\u{9a8c}\u{8bc1}\u{7801}\u{9a8c}\u{8bc1}\u{3002}\u{5982}\u{975e}\u{672c}\u{4eba}\u{64cd}\u{4f5c}\u{8bf7}\u{7acb}\u{5373}\u{4fee}\u{6539}\u{5bc6}\u{7801}\u{3002}',NULL,FALSE,?)")
                .bind(user.id).execute(&state.db).await?;
            return Ok(Json(serde_json::json!({"success":true,"message":null,"data":{"token":null,"expiresInSeconds":0,"user":null,"pendingDeviceId":req.device_id,"emailSent":true}})));
        }
    }

    let sid = create_session(&state, user.id, req.device_id.as_deref(), req.device_name.as_deref(), None).await?;
    tracing::info!(sid = %sid, user = %user.username, "session created");
    let claims = Claims::new(user.id, user.username.clone(), user.role.clone(), state.config.jwt_expiration_seconds);
    let token = jwt::create_token(&claims, &state.config.jwt_secret)?;
    Ok(Json(serde_json::json!({"success":true,"message":"login ok","data":{"token":token,"expiresInSeconds":state.config.jwt_expiration_seconds,"user":build_user_profile(&user),"pendingDeviceId":null,"emailSent":false}})))
}

pub async fn logout() -> Result<Json<serde_json::Value>> {
    Ok(Json(serde_json::json!({"success":true,"message":null,"data":null})))
}

pub async fn refresh_token(State(state): State<Arc<AppState>>, Extension(claims): Extension<Claims>) -> Result<Json<serde_json::Value>> {
    let new_claims = Claims::new(claims.user_id(), claims.username.clone(), claims.role.clone(), state.config.jwt_expiration_seconds);
    let token = jwt::create_token(&new_claims, &state.config.jwt_secret)?;
    Ok(Json(serde_json::json!({"success":true,"message":null,"data":{"token":token}})))
}

pub async fn get_profile(State(state): State<Arc<AppState>>, Extension(claims): Extension<Claims>) -> Result<Json<serde_json::Value>> {
    let user = sqlx::query_as::<sqlx::MySql, User>("SELECT * FROM users WHERE id=?").bind(claims.user_id()).fetch_optional(&state.db).await?;
    let user = user.ok_or_else(|| AppError::NotFound("user not found".into()))?;
    Ok(Json(serde_json::json!({"success":true,"message":null,"data":build_user_profile(&user)})))
}

fn generate_uid() -> String {
    use rand::Rng;
    let alphabet: Vec<char> = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789".chars().collect();
    let mut rng = rand::thread_rng();
    let mut uid = String::from("U");
    for _ in 0..9 { uid.push(alphabet[rng.gen_range(0..alphabet.len())]); }
    uid
}


// ---------- Java-compatible auth additions ----------

#[derive(Debug, Deserialize)]
pub struct DeviceVerifyRequest {
    pub username: String,
    #[serde(rename = "deviceId")]
    pub device_id: Option<String>,
    #[serde(rename = "deviceName")]
    pub device_name: Option<String>,
    pub code: Option<String>,
}

/// POST /api/auth/verify-device — exchange email code for token (Java-compatible)
pub async fn verify_device(State(state): State<Arc<AppState>>, Json(req): Json<DeviceVerifyRequest>) -> Result<Json<serde_json::Value>> {
    let acct = req.username.trim();
    let user = sqlx::query_as::<sqlx::MySql, User>("SELECT * FROM users WHERE username=? OR email=? OR uid=?")
        .bind(acct).bind(acct).bind(acct).fetch_optional(&state.db).await?;
    let user = user.ok_or_else(|| AppError::Auth("\u{7528}\u{6237}\u{540d}\u{6216}\u{5bc6}\u{7801}\u{9519}\u{8bef}".into()))?;
    if user.status == "BANNED" { return Err(AppError::Forbidden("\u{8d26}\u{53f7}\u{5df2}\u{88ab}\u{5c01}\u{7981}\u{ff0c}\u{8bf7}\u{8054}\u{7cfb}\u{7ba1}\u{7406}\u{5458}".into())); }
    if user.status == "CANCELLED" { return Err(AppError::Forbidden("\u{8be5}\u{8d26}\u{53f7}\u{5df2}\u{6ce8}\u{9500}".into())); }
    if user.email.is_none() || user.email.as_deref().unwrap_or("").trim().is_empty() {
        return Err(AppError::Forbidden("\u{8be5}\u{8d26}\u{53f7}\u{672a}\u{7ed1}\u{90ae}\u{7bb1}".into()));
    }
    let code = req.code.clone().unwrap_or_default();
    let mut conn = state.redis.clone();
    let key = format!("device:{}", user.id);
    let stored: Option<String> = redis::AsyncCommands::get(&mut conn, &key).await.unwrap_or(None);
    if stored.as_deref() != Some(code.trim()) {
        return Err(AppError::BadRequest("\u{9a8c}\u{8bc1}\u{7801}\u{9519}\u{8bef}\u{6216}\u{5df2}\u{8fc7}\u{671f}".into()));
    }
    let _: std::result::Result<i64, _> = redis::AsyncCommands::del(&mut conn, &key).await;
    create_session(&state, user.id, req.device_id.as_deref(), req.device_name.as_deref(), None).await?;
    let claims = Claims::new(user.id, user.username.clone(), user.role.clone(), state.config.jwt_expiration_seconds);
    let token = jwt::create_token(&claims, &state.config.jwt_secret)?;
    Ok(Json(serde_json::json!({"success":true,"message":"\u{9a8c}\u{8bc1}\u{6210}\u{529f}","data":{"token":token,"expiresInSeconds":state.config.jwt_expiration_seconds,"user":build_user_profile(&user),"pendingDeviceId":null,"emailSent":false}})))
}

/// POST /api/auth/me/logout-all
pub async fn logout_all_devices(State(state): State<Arc<AppState>>, Extension(claims): Extension<Claims>) -> Result<Json<serde_json::Value>> {
    let n = sqlx::query("UPDATE user_sessions SET revoked=TRUE, updated_at=NOW() WHERE user_id=? AND revoked=FALSE")
        .bind(claims.user_id()).execute(&state.db).await?.rows_affected();
    Ok(Json(serde_json::json!({"success":true,"message":format!("logged out {} devices", n),"data":null})))
}

/// GET /api/auth/me/devices
pub async fn my_devices(State(state): State<Arc<AppState>>, Extension(claims): Extension<Claims>) -> Result<Json<serde_json::Value>> {
    struct Sess { sid: String, device_name: Option<String>, user_agent: Option<String>, login_at: Option<chrono::DateTime<chrono::Utc>>, last_seen_at: Option<chrono::DateTime<chrono::Utc>>, revoked: bool }
    impl<'r> sqlx::FromRow<'r, sqlx::mysql::MySqlRow> for Sess {
        fn from_row(row: &'r sqlx::mysql::MySqlRow) -> std::result::Result<Self, sqlx::Error> {
            use sqlx::Row;
            Ok(Sess{ sid: row.try_get("sid")?, device_name: row.try_get("device_name")?, user_agent: row.try_get("user_agent")?,
                login_at: row.try_get("login_at").ok(), last_seen_at: row.try_get("last_seen_at").ok(), revoked: row.try_get::<bool,_>("revoked")? })
        }
    }
    let rows = sqlx::query_as::<sqlx::MySql, Sess>("SELECT sid, device_name, user_agent, created_at AS login_at, last_seen_at, revoked FROM user_sessions WHERE user_id=? ORDER BY created_at DESC")
        .bind(claims.user_id()).fetch_all(&state.db).await?;
    let items: Vec<serde_json::Value> = rows.iter().map(|s| serde_json::json!({
        "sid": s.sid, "deviceName": s.device_name, "userAgent": s.user_agent,
        "loginAt": s.login_at, "lastSeenAt": s.last_seen_at, "revoked": s.revoked
    })).collect();
    Ok(Json(serde_json::json!({"success":true,"message":null,"data":items})))
}

/// DELETE /api/auth/me/devices/{sid}
pub async fn revoke_device(State(state): State<Arc<AppState>>, Extension(claims): Extension<Claims>, Path(sid): Path<String>) -> Result<Json<serde_json::Value>> {
    sqlx::query("UPDATE user_sessions SET revoked=TRUE, updated_at=NOW() WHERE user_id=? AND sid=?")
        .bind(claims.user_id()).bind(sid).execute(&state.db).await?;
    Ok(Json(serde_json::json!({"success":true,"message":"device removed","data":null})))
}

#[derive(Debug, Deserialize)]
pub struct ChangePasswordRequest {
    #[serde(rename = "oldPassword")]
    pub old_password: String,
    #[serde(rename = "newPassword")]
    pub new_password: String,
}

/// POST /api/auth/change-password
pub async fn change_password(State(state): State<Arc<AppState>>, Extension(claims): Extension<Claims>, Json(req): Json<ChangePasswordRequest>) -> Result<Json<serde_json::Value>> {
    let u = sqlx::query_as::<sqlx::MySql, User>("SELECT * FROM users WHERE id=?").bind(claims.user_id())
        .fetch_one(&state.db).await?;
    let ok = password::verify_password(&req.old_password, &u.password_hash)?;
    if !ok { return Err(AppError::BadRequest("old password incorrect".into())); }
    if req.new_password.len() < 8 { return Err(AppError::BadRequest("new password too short".into())); }
    let hash = password::hash_password(&req.new_password)?;
    sqlx::query("UPDATE users SET password_hash=?, updated_at=NOW() WHERE id=?").bind(hash).bind(u.id).execute(&state.db).await?;
    Ok(Json(serde_json::json!({"success":true,"message":"password changed","data":null})))
}

#[derive(Debug, Deserialize)]
pub struct ChangeEmailSend { #[serde(rename = "newEmail")] pub new_email: Option<String> }

/// POST /api/auth/change-email/send
pub async fn change_email_send(State(state): State<Arc<AppState>>, Extension(claims): Extension<Claims>, Json(req): Json<ChangeEmailSend>) -> Result<Json<serde_json::Value>> {
    let email = req.new_email.unwrap_or_default().trim().to_string();
    if email.is_empty() { return Err(AppError::BadRequest("\u{8bf7}\u{586b}\u{5199}\u{65b0}\u{90ae}\u{7bb1}".into())); }
    // email must not be used by another user
    let taken: Option<(i64,)> = sqlx::query_as("SELECT id FROM users WHERE email=?")
        .bind(&email).fetch_optional(&state.db).await?;
    if let Some((id,)) = taken { if id != claims.user_id() {
        return Err(AppError::Conflict("\u{8be5}\u{90ae}\u{7bb1}\u{5df2}\u{88ab}\u{5176}\u{4ed6}\u{7528}\u{6237}\u{4f7f}\u{7528}".into()));
    }}
    // generate + send code (Java-compatible redis key: emailchange:<userId>)
    let mut conn = state.redis.clone();
    let scope = format!("emailchange:{}", claims.user_id());
    crate::utils::mail::enforce_cooldown(&mut conn, &scope).await?;
    let code = crate::utils::mail::gen_code();
    crate::utils::mail::send_code_email(
        &state.db,
        &email,
        "\u{90ae}\u{7bb1}\u{53d8}\u{66f4}\u{9a8c}\u{8bc1}\u{7801}",
        &format!("\u{60a8}\u{6b63}\u{5728}\u{4fee}\u{6539}\u{7ed1}\u{5b9a}\u{90ae}\u{7bb1}\u{ff0c}\u{9a8c}\u{8bc1}\u{7801}\u{ff1a}{}\u{ff0c}5\u{5206}\u{949f}\u{5185}\u{6709}\u{6548}\u{3002}\u{82e5}\u{975e}\u{672c}\u{4eba}\u{64cd}\u{4f5c}\u{8bf7}\u{5ffd}\u{7565}\u{3002}", code),
    ).await?;
    let key = format!("emailchange:{}", claims.user_id());
    let _: () = redis::AsyncCommands::set_ex(&mut conn, &key, code, 300u64).await
        .map_err(|e| AppError::Internal(format!("redis error: {e}")))?;
    Ok(Json(serde_json::json!({"success":true,"message":"code sent","data":null})))
}

#[derive(Debug, Deserialize)]
pub struct ChangeEmail { #[serde(rename = "newEmail")] pub new_email: Option<String>, pub code: Option<String> }

/// POST /api/auth/change-email
pub async fn change_email(State(state): State<Arc<AppState>>, Extension(claims): Extension<Claims>, Json(req): Json<ChangeEmail>) -> Result<Json<serde_json::Value>> {
    let email = req.new_email.unwrap_or_default().trim().to_string();
    let code = req.code.unwrap_or_default();
    if email.is_empty() || code.is_empty() { return Err(AppError::BadRequest("\u{8bf7}\u{586b}\u{5199}\u{65b0}\u{90ae}\u{7bb1}\u{548c}\u{9a8c}\u{8bc1}\u{7801}".into())); }
    let taken: Option<(i64,)> = sqlx::query_as("SELECT id FROM users WHERE email=?")
        .bind(&email).fetch_optional(&state.db).await?;
    if let Some((id,)) = taken { if id != claims.user_id() {
        return Err(AppError::Conflict("\u{8be5}\u{90ae}\u{7bb1}\u{5df2}\u{88ab}\u{5176}\u{4ed6}\u{7528}\u{6237}\u{4f7f}\u{7528}".into()));
    }}
    let mut conn = state.redis.clone();
    let key = format!("emailchange:{}", claims.user_id());
    let stored: Option<String> = redis::AsyncCommands::get(&mut conn, &key).await.unwrap_or(None);
    match stored {
        Some(s) if s == code => { let _: std::result::Result<i64, _> = redis::AsyncCommands::del(&mut conn, &key).await; }
        _ => return Err(AppError::BadRequest("\u{9a8c}\u{8bc1}\u{7801}\u{9519}\u{8bef}\u{6216}\u{5df2}\u{8fc7}\u{671f}".into())),
    }
    sqlx::query("UPDATE users SET email=?, email_verified=TRUE, updated_at=NOW() WHERE id=?")
        .bind(email).bind(claims.user_id()).execute(&state.db).await?;
    Ok(Json(serde_json::json!({"success":true,"message":"email changed","data":null})))
}

/// POST /api/auth/cancel — self account cancellation (cascade cleanup, Java-compatible)
pub async fn cancel_account(State(state): State<Arc<AppState>>, Extension(claims): Extension<Claims>) -> Result<Json<serde_json::Value>> {
    crate::handlers::admin::cancel_user_cascade(&state, claims.user_id()).await?;
    tracing::info!(user = %claims.user_id(), "user self-cancelled account");
    Ok(Json(serde_json::json!({"success":true,"message":"\u{8d26}\u{53f7}\u{5df2}\u{6ce8}\u{9500}","data":null})))
}

#[derive(Debug, Deserialize)]
pub struct ForgotPasswordRequest {
    pub account: Option<String>,
    pub code: Option<String>,
    #[serde(rename = "newPassword")]
    pub new_password: Option<String>,
}

/// Locate a user by username or email (Java AuthService.findUserByAccount parity).
async fn find_user_by_account(state: &AppState, account: &str) -> Result<User> {
    let a = account.trim();
    if a.is_empty() {
        return Err(AppError::BadRequest("\u{8bf7}\u{8f93}\u{5165}\u{7528}\u{6237}\u{540d}\u{6216}\u{90ae}\u{7bb1}".into()));
    }
    sqlx::query_as::<sqlx::MySql, User>("SELECT * FROM users WHERE username=? OR email=?")
        .bind(a).bind(a)
        .fetch_optional(&state.db).await?
        .ok_or_else(|| AppError::NotFound("\u{7528}\u{6237}\u{4e0d}\u{5b58}\u{5728}".into()))
}

/// POST /api/auth/forgot-password/send — send reset code to the account's bound email
pub async fn forgot_password_send(State(state): State<Arc<AppState>>, Json(req): Json<ForgotPasswordRequest>) -> Result<Json<serde_json::Value>> {
    let user = find_user_by_account(&state, &req.account.clone().unwrap_or_default()).await?;
    if user.status == "CANCELLED" {
        return Err(AppError::Forbidden("\u{8be5}\u{8d26}\u{53f7}\u{5df2}\u{6ce8}\u{9500}".into()));
    }
    let email = user.email.clone().filter(|e| !e.trim().is_empty())
        .ok_or_else(|| AppError::BadRequest("\u{8be5}\u{8d26}\u{53f7}\u{672a}\u{7ed1}\u{5b9a}\u{90ae}\u{7bb1}\u{ff0c}\u{65e0}\u{6cd5}\u{91cd}\u{7f6e}\u{5bc6}\u{7801}".into()))?;
    let mut conn = state.redis.clone();
    let scope = format!("forgotpwd:{}", user.id);
    crate::utils::mail::enforce_cooldown(&mut conn, &scope).await?;
    let code = crate::utils::mail::gen_code();
    crate::utils::mail::send_code_email(
        &state.db,
        &email,
        "\u{5bc6}\u{7801}\u{91cd}\u{7f6e}\u{9a8c}\u{8bc1}\u{7801}",
        &format!("\u{60a8}\u{6b63}\u{5728}\u{91cd}\u{7f6e}\u{5bc6}\u{7801}\u{ff0c}\u{9a8c}\u{8bc1}\u{7801}\u{ff1a}{}\u{ff0c}5\u{5206}\u{949f}\u{5185}\u{6709}\u{6548}\u{3002}\u{82e5}\u{975e}\u{672c}\u{4eba}\u{64cd}\u{4f5c}\u{8bf7}\u{5ffd}\u{7565}\u{3002}", code),
    ).await?;
    let key = format!("forgotpwd:{}", user.id);
    let _: () = redis::AsyncCommands::set_ex(&mut conn, &key, code, 300u64).await
        .map_err(|e| AppError::Internal(format!("redis error: {e}")))?;
    Ok(Json(serde_json::json!({"success":true,"message":"\u{9a8c}\u{8bc1}\u{7801}\u{5df2}\u{53d1}\u{9001}\u{5230}\u{7ed1}\u{5b9a}\u{90ae}\u{7bb1}","data":null})))
}

/// POST /api/auth/forgot-password — verify code and reset password
pub async fn forgot_password(State(state): State<Arc<AppState>>, Json(req): Json<ForgotPasswordRequest>) -> Result<Json<serde_json::Value>> {
    let user = find_user_by_account(&state, &req.account.clone().unwrap_or_default()).await?;
    if user.status == "CANCELLED" {
        return Err(AppError::Forbidden("\u{8be5}\u{8d26}\u{53f7}\u{5df2}\u{6ce8}\u{9500}".into()));
    }
    let new_password = req.new_password.clone().unwrap_or_default();
    if new_password.len() < 8 {
        return Err(AppError::BadRequest("\u{65b0}\u{5bc6}\u{7801}\u{81f3}\u{5c11} 8 \u{4f4d}".into()));
    }
    let code = req.code.clone().unwrap_or_default();
    let mut conn = state.redis.clone();
    let key = format!("forgotpwd:{}", user.id);
    let stored: Option<String> = redis::AsyncCommands::get(&mut conn, &key).await.unwrap_or(None);
    match stored {
        Some(s) if !code.is_empty() && s == code => {
            let _: std::result::Result<i64, _> = redis::AsyncCommands::del(&mut conn, &key).await;
        }
        _ => return Err(AppError::BadRequest("\u{9a8c}\u{8bc1}\u{7801}\u{9519}\u{8bef}\u{6216}\u{5df2}\u{8fc7}\u{671f}".into())),
    }
    let hash = password::hash_password(&new_password)?;
    sqlx::query("UPDATE users SET password_hash=?, failed_login_count=0, locked_until=NULL, updated_at=NOW() WHERE id=?")
        .bind(hash).bind(user.id).execute(&state.db).await?;
    tracing::info!(user = %user.id, "user reset password");
    Ok(Json(serde_json::json!({"success":true,"message":"\u{5bc6}\u{7801}\u{91cd}\u{7f6e}\u{6210}\u{529f}","data":null})))
}

#[derive(Debug, Deserialize)]
pub struct UpdateMeRequest {
    pub username: Option<String>,
    pub nickname: Option<String>,
    pub signature: Option<String>,
    #[serde(rename = "avatarUrl")]
    pub avatar_url: Option<String>,
}

/// PUT /api/auth/me
pub async fn update_me(State(state): State<Arc<AppState>>, Extension(claims): Extension<Claims>, Json(req): Json<UpdateMeRequest>) -> Result<Json<serde_json::Value>> {
    let me = claims.user_id();
    if let Some(v) = &req.username { if !v.is_empty() { sqlx::query("UPDATE users SET username=?,updated_at=NOW() WHERE id=?").bind(v).bind(me).execute(&state.db).await?; } }
    if let Some(v) = &req.nickname { sqlx::query("UPDATE users SET nickname=?,updated_at=NOW() WHERE id=?").bind(v).bind(me).execute(&state.db).await?; }
    // signature audit (Java-compatible): OFF | FIRST | ALWAYS
    if let Some(sig) = &req.signature {
        let mode: Option<(Option<String>,)> = sqlx::query_as("SELECT signature_audit_mode FROM site_settings WHERE id=1")
            .fetch_optional(&state.db).await?;
        let mode = mode.and_then(|(m,)| m).unwrap_or_else(|| "OFF".into());
        let u = sqlx::query_as::<sqlx::MySql, User>("SELECT * FROM users WHERE id=?").bind(me)
            .fetch_one(&state.db).await?;
        let audit = mode == "ALWAYS" || (mode == "FIRST" && !u.signature_approved_once);
        if audit && !sig.trim().is_empty() {
            sqlx::query("UPDATE users SET pending_signature=?, updated_at=NOW() WHERE id=?")
                .bind(sig.trim()).bind(me).execute(&state.db).await?;
        } else {
            sqlx::query("UPDATE users SET signature=?, updated_at=NOW() WHERE id=?")
                .bind(if sig.trim().is_empty() { None } else { Some(sig.trim().to_string()) })
                .bind(me).execute(&state.db).await?;
        }
    }
    if let Some(v) = &req.avatar_url { sqlx::query("UPDATE users SET avatar_url=?,updated_at=NOW() WHERE id=?").bind(v).bind(me).execute(&state.db).await?; }
    get_profile(State(state), Extension(claims)).await
}
