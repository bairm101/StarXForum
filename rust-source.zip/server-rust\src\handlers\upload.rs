use axum::{
    extract::{State, Extension, Multipart},
    Json,
};
use std::sync::Arc;
use tokio::fs;
use tokio::io::AsyncWriteExt;

use crate::{
    config::AppState,
    error::{AppError, Result},
    utils::Claims,
};

/// POST /api/upload 鈥?legacy simple upload, returns file list
pub async fn upload_file(
    State(state): State<Arc<AppState>>,
    Extension(claims): Extension<Claims>,
    mut multipart: Multipart,
) -> Result<Json<serde_json::Value>> {
    let mut uploaded_files = Vec::new();
    fs::create_dir_all(&state.config.upload_dir).await?;

    while let Some(field) = multipart.next_field().await
        .map_err(|e| AppError::BadRequest(format!("parse failed: {}", e)))? {

        let filename = field.file_name()
            .ok_or_else(|| AppError::BadRequest("filename missing".into()))?
            .to_string();

        let ext = std::path::Path::new(&filename)
            .extension().and_then(|e| e.to_str())
            .ok_or_else(|| AppError::BadRequest("bad extension".into()))?
            .to_lowercase();

        let allowed = ["jpg", "jpeg", "png", "gif", "webp", "mp4", "mov"];
        if !allowed.contains(&ext.as_str()) {
            return Err(AppError::BadRequest(format!("unsupported type: {}", ext)));
        }

        let data = field.bytes().await
            .map_err(|e| AppError::BadRequest(format!("read failed: {}", e)))?;

        if data.len() > state.config.max_upload_size {
            return Err(AppError::BadRequest("file too large".into()));
        }

        let stored_name = format!("{}.{}", uuid::Uuid::new_v4().simple(), ext);
        let target = format!("{}/{}", state.config.upload_dir.trim_end_matches('/'), stored_name);
        let mut f = fs::File::create(&target).await?;
        f.write_all(&data).await?;

        sqlx::query(
            "INSERT INTO upload_records(created_at,updated_at,path,size_bytes,type,user_id,content_type,original_name,public_code) VALUES(NOW(),NOW(),?,?,'image',?,NULL,?,NULL)"
        )
        .bind(format!("/uploads/{}", stored_name))
        .bind(data.len() as i64)
        .bind(claims.user_id())
        .bind(&filename)
        .execute(&state.db).await?;

        uploaded_files.push(serde_json::json!({
            "originalName": filename,
            "url": format!("/uploads/{}", stored_name),
            "size": data.len(),
        }));
    }

    Ok(Json(serde_json::json!({"success":true,"message":"uploaded","data":{"files":uploaded_files}})))
}

/// GET /api/upload/list 鈥?user's uploads (best effort)
pub async fn get_user_uploads(
    State(state): State<Arc<AppState>>,
    Extension(claims): Extension<Claims>,
) -> Result<Json<serde_json::Value>> {
    struct Rec { public_code: Option<String>, path: String, original_name: Option<String>, size_bytes: i64, created_at: chrono::DateTime<chrono::Utc> }
    impl<'r> sqlx::FromRow<'r, sqlx::mysql::MySqlRow> for Rec {
        fn from_row(row: &'r sqlx::mysql::MySqlRow) -> std::result::Result<Self, sqlx::Error> {
            use sqlx::Row;
            Ok(Rec{ public_code: row.try_get("public_code")?, path: row.try_get("path")?,
                original_name: row.try_get("original_name")?, size_bytes: row.try_get("size_bytes")?,
                created_at: row.try_get("created_at")? })
        }
    }
    let rows = match sqlx::query_as::<sqlx::MySql, Rec>(
        "SELECT public_code, path, original_name, size_bytes, created_at FROM upload_records WHERE user_id=? ORDER BY created_at DESC LIMIT 100")
        .bind(claims.user_id()).fetch_all(&state.db).await {
        Ok(r) => r,
        Err(_) => Vec::new(),
    };
    let files: Vec<serde_json::Value> = rows.iter().map(|r| serde_json::json!({
        "code": r.public_code, "path": r.path, "name": r.original_name,
        "size": r.size_bytes, "createdAt": r.created_at
    })).collect();
    Ok(Json(serde_json::json!({"success":true,"message":null,"data":{"files":files}})))
}
