import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../site_config.dart';
import 'pwa_install.dart' if (dart.library.js_interop) 'pwa_install_web.dart';

/// 关于页面：展示站点信息、官网、联系方式、备案号。
class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final site = context.watch<SiteConfig>();
    return Scaffold(
      appBar: AppBar(title: const Text('关于')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const SizedBox(height: 24),
          Center(
            child: Column(
              children: [
                Icon(Icons.forum, size: 72, color: Colors.indigo.shade400),
                const SizedBox(height: 12),
                Text(site.siteName, style: Theme.of(context).textTheme.headlineSmall),
                if (site.settings.siteDescription.isNotEmpty) ...[
                  const SizedBox(height: 6),
                  Text(site.settings.siteDescription,
                      style: TextStyle(color: Colors.grey[600]),
                      textAlign: TextAlign.center),
                ],
              ],
            ),
          ),
          const SizedBox(height: 32),
          _infoTile(
            context,
            icon: Icons.language,
            title: '官方网站',
            value: site.officialWebsite,
            onTap: () => _launch(context, 'https://${site.officialWebsite}'),
          ),
          _infoTile(
            context,
            icon: Icons.email_outlined,
            title: '联系邮箱',
            value: site.contactEmail,
            onTap: () => _launch(context, 'mailto:${site.contactEmail}'),
          ),
          if (site.aboutIcp != null && site.aboutIcp!.isNotEmpty)
            _infoTile(
              context,
              icon: Icons.verified_outlined,
              title: '备案号',
              value: site.aboutIcp!,
              onTap: null,
            ),
          const SizedBox(height: 32),
          if (pwaInstallable()) ...[
            _infoTile(
              context,
              icon: Icons.download_for_offline_outlined,
              title: '安装到主屏',
              value: '将本论坛安装为桌面/主屏应用（PWA）',
              onTap: requestPwaInstall,
            ),
          ],
          const SizedBox(height: 32),
          Center(
            child: Text(
              '版本 1.4.9',
              style: TextStyle(color: Colors.grey[500], fontSize: 12),
            ),
          ),
        ],
      ),
    );
  }

  void _installPwa() {}

  Widget _infoTile(BuildContext context,
      {required IconData icon,
      required String title,
      required String value,
      VoidCallback? onTap}) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 6),
      child: ListTile(
        leading: Icon(icon, color: Colors.indigo),
        title: Text(title),
        subtitle: Text(value),
        trailing: onTap != null ? const Icon(Icons.chevron_right) : null,
        onTap: onTap,
      ),
    );
  }

  Future<void> _launch(BuildContext context, String url) async {
    final uri = Uri.tryParse(url);
    if (uri == null) return;
    try {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (_) {
      if (context.mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('无法打开链接')));
      }
    }
  }
}
