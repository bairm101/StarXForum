import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../api/api_client.dart';
import '../models/models.dart';
import '../site_config.dart';
import 'post_detail_screen.dart';
import 'topic_screen.dart';
import 'media_widgets.dart';
import 'common.dart';
import 'user_home_screen.dart';
import 'package:image_picker/image_picker.dart';
import 'package:file_picker/file_picker.dart';

class PostListScreen extends StatefulWidget {
  final int? boardId;
  final String sort;
  const PostListScreen({super.key, this.boardId, this.sort = 'latest'});

  @override
  State<PostListScreen> createState() => _PostListScreenState();
}

class _PostListScreenState extends State<PostListScreen> {
  final _scrollCtrl = ScrollController();
  final List<PostSummary> _posts = [];
  int _page = 0;
  bool _loading = false;
  bool _hasMore = true;
  Timer? _autoRefreshTimer;

  @override
  void initState() {
    super.initState();
    _scrollCtrl.addListener(() {
      if (_scrollCtrl.position.pixels >
          _scrollCtrl.position.maxScrollExtent - 200) {
        _loadMore();
      }
    });
    _loadMore();
    _startAutoRefresh();
  }

  @override
  void dispose() {
    _autoRefreshTimer?.cancel();
    _scrollCtrl.dispose();
    super.dispose();
  }

  /// 按后台配置的间隔自动刷新（0 表示关闭）。
  void _startAutoRefresh() {
    final seconds = context.read<SiteConfig>().autoRefreshSeconds;
    if (seconds <= 0) return;
    _autoRefreshTimer = Timer.periodic(Duration(seconds: seconds), (_) {
      if (mounted) _refresh();
    });
  }

  Future<void> _loadMore() async {
    if (_loading || !_hasMore) return;
    setState(() => _loading = true);
    try {
      final query = <String, String>{
        'page': '$_page',
        'size': '20',
        'sort': widget.sort,
      };
      Map<String, dynamic> data;
      if (widget.sort == 'following') {
        // 关注的人的帖子流
        final d = await ApiClient.get('/api/feed/following', query: {'page': '$_page', 'size': '20'});
        data = d['data'] as Map<String, dynamic>;
      } else {
        if (widget.boardId != null) {
          query['boardId'] = '${widget.boardId}';
        }
        final d = await ApiClient.get('/api/posts', query: query);
        data = d['data'] as Map<String, dynamic>;
      }
      final items = (data['items'] as List)
          .map((e) => PostSummary.fromJson(e as Map<String, dynamic>))
          .toList();
      if (!mounted) return;
      setState(() {
        _posts.addAll(items);
        _page++;
        _hasMore = (data['hasNext'] as bool?) ?? false;
        _loading = false;
      });
    } catch (e) {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _refresh() async {
    if (!mounted) return;
    _posts.clear();
    _page = 0;
    _hasMore = true;
    await _loadMore();
  }

  @override
  Widget build(BuildContext context) {
    if (_posts.isEmpty && _loading) {
      return const Center(child: CircularProgressIndicator());
    }
    if (_posts.isEmpty) {
      return const Center(child: Text('还没有帖子，点击右上角发帖'));
    }
    return RefreshIndicator(
      onRefresh: _refresh,
      child: ListView.separated(
        controller: _scrollCtrl,
        physics: const AlwaysScrollableScrollPhysics(),
        itemCount: _posts.length + (_hasMore ? 1 : 0),
        separatorBuilder: (_, __) => const Divider(height: 1),
        itemBuilder: (context, i) {
          if (i >= _posts.length) {
            return const Padding(
              padding: EdgeInsets.all(16),
              child: Center(child: CircularProgressIndicator()),
            );
          }
          final p = _posts[i];
          return _PostTile(post: p, onChanged: _refresh);
        },
      ),
    );
  }
}

class _PostTile extends StatelessWidget {
  final PostSummary post;
  final VoidCallback? onChanged;
  const _PostTile({required this.post, this.onChanged});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () async {
        await Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => PostDetailScreen(postId: post.id)),
        );
        onChanged?.call();
      },
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                if (post.pinned)
                  const Padding(
                    padding: EdgeInsets.only(right: 6),
                    child: Icon(Icons.push_pin, size: 16, color: Colors.red),
                  ),
                Expanded(
                  child: Text(
                    post.title,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 6),
            Text(
              post.excerpt,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(color: Colors.grey[600], fontSize: 13),
            ),
            if (post.topics.isNotEmpty) ...[
              const SizedBox(height: 6),
              Wrap(
                spacing: 6,
                runSpacing: 4,
                children: post.topics.map((t) => GestureDetector(
                  onTap: () => Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => TopicScreen(topic: t))),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                    decoration: BoxDecoration(
                      color: Colors.indigo.shade50,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text('#$t', style: TextStyle(fontSize: 11, color: Colors.indigo.shade600)),
                  ),
                )).toList(),
              ),
            ],
            if (post.gateType == 'NONE' && post.thumbnailUrl != null && post.thumbnailUrl!.isNotEmpty) ...[
              const SizedBox(height: 8),
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: AspectRatio(
                  aspectRatio: 16 / 7,
                  child: GestureDetector(onTap:()=>_showImage(context,ApiClient.resourceUrl(post.thumbnailUrl)),child: Image.network(ApiClient.resourceUrl(post.thumbnailUrl), fit: BoxFit.cover,
                    loadingBuilder: (_, child, progress) => progress == null ? child : Container(color: Colors.grey.shade100, alignment: Alignment.center, child: const Column(mainAxisSize: MainAxisSize.min, children:[CircularProgressIndicator(),SizedBox(height:6),Text('图片加载中')])),
                    errorBuilder: (_, __, ___) => Container(color: Colors.grey.shade200, alignment: Alignment.center, child: const Icon(Icons.broken_image)),
                  )),
                ),
              ),
            ] else if (post.gateType == 'NONE' && post.videoUrl != null && post.videoUrl!.isNotEmpty) ...[
              const SizedBox(height: 8),
              InlineVideo(url: ApiClient.resourceUrl(post.videoUrl)),
            ],
            const SizedBox(height: 8),
            Row(
              children: [
                GestureDetector(
                  onTap: () => Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => UserHomeScreen(userId: post.author.id))),
                  child: CircleAvatar(radius: 10, child: post.author.avatarUrl == null ? Text(post.author.displayName.characters.first) : ClipOval(child: Image.network(ApiClient.resourceUrl(post.author.avatarUrl),width:20,height:20,fit:BoxFit.cover,loadingBuilder:(_,child,p)=>p==null?child:const SizedBox(width:10,height:10,child:CircularProgressIndicator(strokeWidth:1)),errorBuilder:(_,__,___)=>Text(post.author.displayName.characters.first)))),
                ),
                const SizedBox(width: 6),
                GestureDetector(
                  onTap: () => Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => UserHomeScreen(userId: post.author.id))),
                  child: Text(post.author.displayName, style: const TextStyle(fontSize: 12)),
                ),
                if (post.author.title != null && post.author.title!.isNotEmpty) ...[
                  const SizedBox(width: 4),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
                    decoration: BoxDecoration(
                      color: Colors.indigo.shade50,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(post.author.title!,
                        style: TextStyle(fontSize: 10, color: Colors.indigo.shade400)),
                  ),
                ],
                const SizedBox(width: 12),
                Icon(Icons.remove_red_eye_outlined, size: 14, color: Colors.grey[600]),
                const SizedBox(width: 2),
                Text('${post.viewCount}', style: TextStyle(fontSize: 12, color: Colors.grey[600])),
                const SizedBox(width: 12),
                Icon(Icons.chat_bubble_outline, size: 14, color: Colors.grey[600]),
                const SizedBox(width: 2),
                Text('${post.commentCount}', style: TextStyle(fontSize: 12, color: Colors.grey[600])),
                const SizedBox(width: 12),
                Icon(Icons.thumb_up_outlined, size: 14, color: Colors.grey[600]),
                const SizedBox(width: 2),
                Text('${post.likeCount}', style: TextStyle(fontSize: 12, color: Colors.grey[600])),
                if (post.tipCount > 0) ...[
                  const SizedBox(width: 12),
                  Icon(Icons.monetization_on_outlined, size: 14, color: Colors.amber[700]),
                  const SizedBox(width: 2),
                  Text('${post.totalTipGold}',
                      style: TextStyle(fontSize: 12, color: Colors.amber[700])),
                ],
                const Spacer(),
                Text(
                  DateFormat('MM-dd HH:mm').format(post.createdAt),
                  style: TextStyle(fontSize: 12, color: Colors.grey[500]),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _showImage(BuildContext context, String url) {
    showDialog(context: context, builder: (_) => Dialog(child: InteractiveViewer(child: Image.network(url, fit: BoxFit.contain, loadingBuilder: (_, child, p)=>p==null?child:const SizedBox(height:180,child:Center(child:CircularProgressIndicator())), errorBuilder:(_,__,___)=>const SizedBox(height:180,child:Center(child:Icon(Icons.broken_image)))))));
  }
}

class PostEditorScreen extends StatefulWidget {
  const PostEditorScreen({super.key});

  @override
  State<PostEditorScreen> createState() => _PostEditorScreenState();
}

class _PostEditorScreenState extends State<PostEditorScreen> {
  final _titleCtrl = TextEditingController();
  final _contentCtrl = TextEditingController();
  List<Board> _boards = [];
  int? _boardId;
  bool _loading = false;
  String _gateType='NONE';
  final _gatedCtrl=TextEditingController();
  final _priceCtrl=TextEditingController(text:'1');
  final _topicsCtrl=TextEditingController();
  double? _uploadProgress;

  Future<void> _uploadMedia(String type) async {
    final picker=ImagePicker();
    final XFile? file = type=='video' ? await picker.pickVideo(source:ImageSource.gallery) : await picker.pickImage(source:ImageSource.gallery);
    if(file==null)return;
    try{
      setState(()=>_uploadProgress=0);
      final bytes = await file.readAsBytes();
      final cb=(double p){if(mounted)setState(()=>_uploadProgress=p);};
      final d=bytes.length>8*1024*1024
        ? await ApiClient.uploadLarge('/api/files/media',bytes,file.name,type:type,onProgress:cb)
        : await ApiClient.upload('/api/files/media',bytes,file.name,type:type,onProgress:cb);
      final url=(d['data'] as Map<String,dynamic>)['url'].toString();
      final tag=type=='video'?'\n[视频]($url)\n':'\n![图片]($url)\n';
      _contentCtrl.text+=tag;
    }on ApiException catch(e){_toast(e.message);}
    finally{if(mounted)setState(()=>_uploadProgress=null);}
  }

  Future<void> _uploadFile() async {
    final f=await FilePicker.pickFile();
    if(f==null)return;
    try{
      setState(()=>_uploadProgress=0);
      final bytes=await f.readAsBytes();
      final cb=(double p){if(mounted)setState(()=>_uploadProgress=p);};
      final d=bytes.length>8*1024*1024
        ? await ApiClient.uploadLarge('/api/files/media',bytes,f.name,type:'file',onProgress:cb)
        : await ApiClient.upload('/api/files/media',bytes,f.name,type:'file',onProgress:cb);
      final url=(d['data'] as Map<String,dynamic>)['url'].toString();_contentCtrl.text+='\n[下载文件 ${f.name}]($url)\n';
    }on ApiException catch(e){_toast(e.message);}
    finally{if(mounted)setState(()=>_uploadProgress=null);}
  }

  Future<void> _insertHidden() async {
    final condition=TextEditingController(text:'回复后可见'); final hidden=TextEditingController();
    final ok=await showDialog<bool>(context:context,builder:(dialog)=>AlertDialog(title:const Text('插入隐藏内容'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:condition,decoration:const InputDecoration(labelText:'显示条件',helperText:'例如：回复后可见 / 登录可见 / 站长可见')),TextField(controller:hidden,maxLines:5,decoration:const InputDecoration(labelText:'隐藏内容'))]),actions:[TextButton(onPressed:()=>Navigator.pop(dialog,false),child:const Text('取消')),FilledButton(onPressed:()=>Navigator.pop(dialog,true),child:const Text('插入'))]));
    if(ok==true&&hidden.text.trim().isNotEmpty){_contentCtrl.text+='\n![隐藏内容_${condition.text.trim()}](${hidden.text.trim()})\n';setState((){});}
  }

  @override
  void initState() {
    super.initState();
    _loadBoards();
    _loadDraft();
  }

  @override
  void dispose() {
    _saveDraft();
    _titleCtrl.dispose();
    _contentCtrl.dispose();
    _gatedCtrl.dispose();
    _priceCtrl.dispose();
    _topicsCtrl.dispose();
    super.dispose();
  }

  // ---------- 发帖草稿 ----------
  static const _draftKey = 'post_draft';

  Future<void> _saveDraft() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_draftKey, jsonEncode({
        'title': _titleCtrl.text,
        'content': _contentCtrl.text,
        'topics': _topicsCtrl.text,
      }));
    } catch (_) {}
  }

  Future<void> _loadDraft() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_draftKey);
      if (raw == null || raw.isEmpty) return;
      final d = jsonDecode(raw) as Map<String, dynamic>;
      if (!mounted) return;
      setState(() {
        _titleCtrl.text = d['title']?.toString() ?? '';
        _contentCtrl.text = d['content']?.toString() ?? '';
        _topicsCtrl.text = d['topics']?.toString() ?? '';
      });
      if (_titleCtrl.text.isNotEmpty || _contentCtrl.text.isNotEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已恢复上次的草稿')));
      }
    } catch (_) {}
  }

  Future<void> _clearDraft() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove(_draftKey);
    } catch (_) {}
  }

  Future<void> _loadBoards() async {
    try {
      final d = await ApiClient.get('/api/boards');
      final list = (d['data'] as List)
          .map((e) => Board.fromJson(e as Map<String, dynamic>))
          .toList();
      setState(() {
        _boards = list;
        if (list.isNotEmpty) _boardId = list.first.id;
      });
    } catch (_) {}
  }

  Future<void> _submit() async {
    final title = _titleCtrl.text.trim();
    final content = _contentCtrl.text.trim();
    if (title.isEmpty || content.isEmpty || _boardId == null) {
      _toast('请填写标题、内容和板块');
      return;
    }
    setState(() => _loading = true);
    try {
      final challenge = await solveChallenge(context, 'POST');
      if (challenge == null) return;
      await ApiClient.post('/api/posts',
          body: {'title': title, 'content': content, 'boardId': _boardId,'gateType':_gateType,'gatedContent':_gateType=='NONE'?null:_gatedCtrl.text,'gatePrice':_gateType=='PAID'?int.tryParse(_priceCtrl.text):0,'topics':_topicsCtrl.text.trim()}, extraHeaders: challenge);
      await _clearDraft();
      if (!mounted) return;
      Navigator.of(context).pop(true);
    } on ApiException catch (e) {
      _toast(e.message);
    } catch (e) {
      _toast('发布失败');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _toast(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('发布帖子'), actions: [
        PopupMenuButton<String>(
          onSelected: (v) {
            if (v == 'clear') {
              _titleCtrl.clear();
              _contentCtrl.clear();
              _topicsCtrl.clear();
              _clearDraft();
              _toast('草稿已清空');
            }
          },
          itemBuilder: (_) => [
            const PopupMenuItem(value: 'clear', child: Text('清空草稿')),
          ],
        ),
        TextButton(
          onPressed: _loading ? null : _submit,
          child: const Text('发布'),
        ),
      ]),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
            DropdownButtonFormField<int>(
              value: _boardId,
              decoration: const InputDecoration(
                labelText: '板块',
                border: OutlineInputBorder(),
              ),
              items: _boards
                  .map((b) => DropdownMenuItem(value: b.id, child: Text(b.name)))
                  .toList(),
              onChanged: (v) => setState(() => _boardId = v),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _titleCtrl,
              decoration: const InputDecoration(
                labelText: '标题',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _contentCtrl,
              maxLines: null,
              minLines: 10,
              textAlignVertical: TextAlignVertical.top,
              decoration: const InputDecoration(
                labelText: '内容',
                alignLabelWithHint: true,
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 8),
            Wrap(spacing:8,runSpacing:8,children:[OutlinedButton.icon(onPressed:()=>_uploadMedia('image'),icon:const Icon(Icons.image),label:const Text('图片')),OutlinedButton.icon(onPressed:()=>_uploadMedia('video'),icon:const Icon(Icons.video_file),label:const Text('视频')),OutlinedButton.icon(onPressed:_uploadFile,icon:const Icon(Icons.attach_file),label:const Text('文件')),OutlinedButton.icon(onPressed:_insertHidden,icon:const Icon(Icons.visibility_off),label:const Text('隐藏内容'))]),
            if (_uploadProgress != null) ...[
              const SizedBox(height: 8),
              Row(children:[
                Expanded(child: ClipRRect(borderRadius: BorderRadius.circular(4), child: LinearProgressIndicator(value: _uploadProgress, minHeight: 6))),
                const SizedBox(width: 8),
                Text('${(_uploadProgress! * 100).round()}%', style: const TextStyle(fontSize: 12)),
              ]),
            ],
            const SizedBox(height:8),
            DropdownButtonFormField<String>(value:_gateType,decoration:const InputDecoration(labelText:'内容权限'),items:const [DropdownMenuItem(value:'NONE',child:Text('公开')),DropdownMenuItem(value:'REPLY',child:Text('回复后查看')),DropdownMenuItem(value:'PAID',child:Text('金币付费查看'))],onChanged:(v)=>setState(()=>_gateType=v??'NONE')),
            if(_gateType!='NONE') TextField(controller:_gatedCtrl,maxLines:4,decoration:const InputDecoration(labelText:'受限内容（一个帖子仅此一段）')),
            if(_gateType=='PAID') TextField(controller:_priceCtrl,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'金币价格')),
            TextField(controller:_topicsCtrl,decoration:const InputDecoration(labelText:'话题',helperText:'用逗号分隔，如：科技, 数码（正文中的 #话题 也会自动提取）')),
          ],
      ),
    );
  }
}
