class Board {
  final int id;
  final String name;
  final String? description;
  final int postCount;
  final bool visible;
  final bool requireModeration;

  Board({
    required this.id,
    required this.name,
    this.description,
    required this.postCount,
    this.visible = true,
    this.requireModeration = false,
  });

  factory Board.fromJson(Map<String, dynamic> j) => Board(
        id: j['id'] as int,
        name: j['name'] as String,
        description: j['description'] as String?,
        postCount: (j['postCount'] as int?) ?? 0,
        visible: (j['visible'] as bool?) ?? true,
        requireModeration: (j['requireModeration'] as bool?) ?? false,
      );
}

class Author {
  final int id;
  final String? uid;
  final String username;
  final String displayName;
  final String? avatarUrl;
  final String? title;
  final String role;

  Author({
    required this.id,
    this.uid,
    required this.username,
    required this.displayName,
    this.avatarUrl,
    this.title,
    this.role = 'USER',
  });

  factory Author.fromJson(Map<String, dynamic> j) => Author(
        id: j['id'] as int,
        uid: j['uid'] as String?,
        username: j['username'] as String,
        displayName: j['displayName'] as String? ?? j['username'] as String,
        avatarUrl: j['avatarUrl'] as String?,
        title: j['title'] as String?,
        role: (j['role'] as String?) ?? 'USER',
      );
}

/// 站点设置
class SiteSettings {
  final String siteName;
  final String siteDescription;
  final String? announcement;
  final bool allowRegister;
  final String pageTitle;
  final String defaultTheme;
  final String? footerText;
  final String? footerIcp;
  final String footerLinksJson;
  final String officialWebsite;
  final String webShareBaseUrl;
  final String contactEmail;
  final String? aboutIcp;
  final int autoRefreshSeconds;

  SiteSettings({
    required this.siteName,
    required this.siteDescription,
    this.announcement,
    required this.allowRegister,
    this.pageTitle = '论坛',
    this.defaultTheme = 'SYSTEM',
    this.footerText,
    this.footerIcp,
    this.footerLinksJson = '[]',
    this.officialWebsite = 'www.starxx.cn',
    this.webShareBaseUrl = 'https://forum.starxx.cn',
    this.contactEmail = '908696225@qq.com',
    this.aboutIcp,
    this.autoRefreshSeconds = 180,
  });

  factory SiteSettings.fromJson(Map<String, dynamic> j) => SiteSettings(
        siteName: (j['siteName'] as String?) ?? '论坛',
        siteDescription: (j['siteDescription'] as String?) ?? '',
        announcement: j['announcement'] as String?,
        allowRegister: (j['allowRegister'] as bool?) ?? true,
        pageTitle: (j['pageTitle'] as String?) ?? '论坛',
        defaultTheme: (j['defaultTheme'] as String?) ?? 'SYSTEM',
        footerText: j['footerText'] as String?,
        footerIcp: j['footerIcp'] as String?,
        footerLinksJson: (j['footerLinksJson'] as String?) ?? '[]',
        officialWebsite: (j['officialWebsite'] as String?) ?? 'www.starxx.cn',
        webShareBaseUrl: (j['webShareBaseUrl'] as String?) ?? 'https://forum.starxx.cn',
        contactEmail: (j['contactEmail'] as String?) ?? '908696225@qq.com',
        aboutIcp: j['aboutIcp'] as String?,
        autoRefreshSeconds: (j['autoRefreshSeconds'] as int?) ?? 180,
      );
}

class PostSummary {
  final int id;
  final String title;
  final String excerpt;
  final int boardId;
  final String boardName;
  final Author author;
  final int viewCount;
  final int commentCount;
  final int likeCount;
  final int dislikeCount;
  final bool pinned;
  final bool locked;
  final bool likedByMe;
  final int totalTipGold;
  final int tipCount;
  final String status;
  final String? thumbnailUrl;
  final String? videoUrl;
  final String gateType;
  final List<String> topics;
  final String? puid;
  final DateTime createdAt;

  PostSummary({
    required this.id,
    required this.title,
    required this.excerpt,
    required this.boardId,
    required this.boardName,
    required this.author,
    required this.viewCount,
    required this.commentCount,
    required this.likeCount,
    required this.dislikeCount,
    required this.pinned,
    required this.locked,
    required this.likedByMe,
    required this.totalTipGold,
    required this.tipCount,
    required this.status,
    this.thumbnailUrl,
    this.videoUrl,
    this.gateType = 'NONE',
    this.topics = const [],
    this.puid,
    required this.createdAt,
  });

  factory PostSummary.fromJson(Map<String, dynamic> j) => PostSummary(
        id: j['id'] as int,
        title: j['title'] as String,
        excerpt: (j['excerpt'] as String?) ?? '',
        boardId: (j['boardId'] as int?) ?? 0,
        boardName: (j['boardName'] as String?) ?? '',
        author: Author.fromJson(j['author'] as Map<String, dynamic>),
        viewCount: (j['viewCount'] as int?) ?? 0,
        commentCount: (j['commentCount'] as int?) ?? 0,
        likeCount: (j['likeCount'] as int?) ?? 0,
        dislikeCount: (j['dislikeCount'] as int?) ?? 0,
        pinned: (j['pinned'] as bool?) ?? false,
        locked: (j['locked'] as bool?) ?? false,
        likedByMe: (j['likedByMe'] as bool?) ?? false,
        totalTipGold: (j['totalTipGold'] as int?) ?? 0,
        tipCount: (j['tipCount'] as int?) ?? 0,
        status: (j['status'] as String?) ?? 'APPROVED',
        thumbnailUrl: (j['thumbnailUrl'] as String?) ?? _firstImage(j['excerpt'] as String?),
        videoUrl: j['videoUrl'] as String?,
        gateType: (j['gateType'] as String?) ?? 'NONE',
        topics: _splitTopics(j['topics']),
        puid: j['puid'] as String?,
        createdAt: DateTime.parse(j['createdAt'] as String).toLocal(),
      );

  static List<String> _splitTopics(dynamic v) {
    if (v == null) return const [];
    return v.toString().split(',').where((s) => s.trim().isNotEmpty).toList();
  }

  static String? _firstImage(String? content) {
    if (content == null) return null;
    final m = RegExp(r'!\[[^]]*\]\((https?://[^)]+|/uploads/[^)]+)\)').firstMatch(content);
    return m?.group(1);
  }
}

class PostDetail {
  final int id;
  final String title;
  final String content;
  final int boardId;
  final String boardName;
  final Author author;
  final int viewCount;
  final int commentCount;
  final int likeCount;
  final int dislikeCount;
  final bool pinned;
  final bool locked;
  final bool likedByMe;
  final bool dislikedByMe;
  final bool canEdit;
  final int totalTipGold;
  final int tipCount;
  final int myTipTimes;
  final String status;
  final String? thumbnailUrl;
  final List<String> topics;
  final String? puid;
  final String gateType;
  final bool gateUnlocked;
  final int gatePrice;
  final String? gatedContent;
  final DateTime createdAt;

  PostDetail({
    required this.id,
    required this.title,
    required this.content,
    required this.boardId,
    required this.boardName,
    required this.author,
    required this.viewCount,
    required this.commentCount,
    required this.likeCount,
    required this.dislikeCount,
    required this.pinned,
    required this.locked,
    required this.likedByMe,
    required this.dislikedByMe,
    required this.canEdit,
    required this.totalTipGold,
    required this.tipCount,
    required this.myTipTimes,
    required this.status,
    this.thumbnailUrl,
    this.topics = const [],
    this.puid,
    this.gateType = 'NONE',
    this.gateUnlocked = true,
    this.gatePrice = 0,
    this.gatedContent,
    required this.createdAt,
  });

  factory PostDetail.fromJson(Map<String, dynamic> j) => PostDetail(
        id: j['id'] as int,
        title: j['title'] as String,
        content: (j['content'] as String?) ?? '',
        boardId: (j['boardId'] as int?) ?? 0,
        boardName: (j['boardName'] as String?) ?? '',
        author: Author.fromJson(j['author'] as Map<String, dynamic>),
        viewCount: (j['viewCount'] as int?) ?? 0,
        commentCount: (j['commentCount'] as int?) ?? 0,
        likeCount: (j['likeCount'] as int?) ?? 0,
        dislikeCount: (j['dislikeCount'] as int?) ?? 0,
        pinned: (j['pinned'] as bool?) ?? false,
        locked: (j['locked'] as bool?) ?? false,
        likedByMe: (j['likedByMe'] as bool?) ?? false,
        dislikedByMe: (j['dislikedByMe'] as bool?) ?? false,
        canEdit: (j['canEdit'] as bool?) ?? false,
        totalTipGold: (j['totalTipGold'] as int?) ?? 0,
        tipCount: (j['tipCount'] as int?) ?? 0,
        myTipTimes: (j['myTipTimes'] as int?) ?? 0,
        status: (j['status'] as String?) ?? 'APPROVED',
        thumbnailUrl: j['thumbnailUrl'] as String?,
        topics: PostSummary._splitTopics(j['topics']),
        puid: j['puid'] as String?,
        gateType: (j['gateType'] as String?) ?? 'NONE',
        gateUnlocked: (j['gateUnlocked'] as bool?) ?? true,
        gatePrice: (j['gatePrice'] as int?) ?? 0,
        gatedContent: j['gatedContent'] as String?,
        createdAt: DateTime.parse(j['createdAt'] as String).toLocal(),
      );
}

/// 签到状态
class CheckinStatus {
  final int level;
  final int exp;
  final int gold;
  final int streak;
  final bool checkedToday;
  final int nextLevelExp;
  final int daysStayedAtLevel;

  CheckinStatus({
    required this.level,
    required this.exp,
    required this.gold,
    required this.streak,
    required this.checkedToday,
    required this.nextLevelExp,
    required this.daysStayedAtLevel,
  });

  factory CheckinStatus.fromJson(Map<String, dynamic> j) => CheckinStatus(
        level: (j['level'] as int?) ?? 1,
        exp: (j['exp'] as int?) ?? 0,
        gold: (j['gold'] as int?) ?? 0,
        streak: (j['streak'] as int?) ?? 0,
        checkedToday: (j['checkedToday'] as bool?) ?? false,
        nextLevelExp: (j['nextLevelExp'] as int?) ?? 0,
        daysStayedAtLevel: (j['daysStayedAtLevel'] as int?) ?? 0,
      );
}

/// 签到结果
class CheckinResult {
  final int goldGain;
  final int expGain;
  final bool leveledUp;
  final int level;
  final int exp;
  final int gold;
  final int streak;
  final int nextLevelExp;

  CheckinResult({
    required this.goldGain,
    required this.expGain,
    required this.leveledUp,
    required this.level,
    required this.exp,
    required this.gold,
    required this.streak,
    required this.nextLevelExp,
  });

  factory CheckinResult.fromJson(Map<String, dynamic> j) => CheckinResult(
        goldGain: (j['goldGain'] as int?) ?? 0,
        expGain: (j['expGain'] as int?) ?? 0,
        leveledUp: (j['leveledUp'] as bool?) ?? false,
        level: (j['level'] as int?) ?? 1,
        exp: (j['exp'] as int?) ?? 0,
        gold: (j['gold'] as int?) ?? 0,
        streak: (j['streak'] as int?) ?? 0,
        nextLevelExp: (j['nextLevelExp'] as int?) ?? 0,
      );
}

class Comment {
  final int id;
  final String content;
  final int postId;
  final int? parentId;
  final Author author;
  final int likeCount;
  final int dislikeCount;
  final bool likedByMe;
  final bool dislikedByMe;
  final bool canEdit;
  final bool canDelete;
  final DateTime createdAt;
  final List<Comment> replies;

  Comment({
    required this.id,
    required this.content,
    required this.postId,
    this.parentId,
    required this.author,
    required this.likeCount,
    required this.dislikeCount,
    required this.likedByMe,
    required this.dislikedByMe,
    required this.canEdit,
    required this.canDelete,
    required this.createdAt,
    required this.replies,
  });

  Comment copyWithReaction({bool? likedByMe, bool? dislikedByMe, int? likeCount, int? dislikeCount}) {
    return Comment(
      id: id,
      content: content,
      postId: postId,
      parentId: parentId,
      author: author,
      likeCount: likeCount ?? this.likeCount,
      dislikeCount: dislikeCount ?? this.dislikeCount,
      likedByMe: likedByMe ?? this.likedByMe,
      dislikedByMe: dislikedByMe ?? this.dislikedByMe,
      canEdit: canEdit,
      canDelete: canDelete,
      createdAt: createdAt,
      replies: replies,
    );
  }

  factory Comment.fromJson(Map<String, dynamic> j) => Comment(
        id: j['id'] as int,
        content: j['content'] as String,
        postId: (j['postId'] as int?) ?? 0,
        parentId: j['parentId'] as int?,
        author: Author.fromJson(j['author'] as Map<String, dynamic>),
        likeCount: (j['likeCount'] as int?) ?? 0,
        dislikeCount: (j['dislikeCount'] as int?) ?? 0,
        likedByMe: (j['likedByMe'] as bool?) ?? false,
        dislikedByMe: (j['dislikedByMe'] as bool?) ?? false,
        canEdit: (j['canEdit'] as bool?) ?? false,
        canDelete: (j['canDelete'] as bool?) ?? false,
        createdAt: DateTime.parse(j['createdAt'] as String).toLocal(),
        replies: (j['replies'] as List?)
                ?.map((e) => Comment.fromJson(e as Map<String, dynamic>))
                .toList() ??
            [],
      );
}

class Message {
  final int id;
  final Author sender;
  final String content;
  final bool read;
  final bool mine;
  final DateTime createdAt;

  Message({
    required this.id,
    required this.sender,
    required this.content,
    required this.read,
    required this.mine,
    required this.createdAt,
  });

  factory Message.fromJson(Map<String, dynamic> j) => Message(
        id: j['id'] as int,
        sender: Author.fromJson(j['sender'] as Map<String, dynamic>),
        content: j['content'] as String,
        read: (j['read'] as bool?) ?? false,
        mine: (j['mine'] as bool?) ?? false,
        createdAt: DateTime.parse(j['createdAt'] as String).toLocal(),
      );
}

class Conversation {
  final String conversationKey;
  final Author peer;
  final String lastContent;
  final bool lastFromMe;
  final int unreadCount;
  final DateTime lastAt;

  Conversation({
    required this.conversationKey,
    required this.peer,
    required this.lastContent,
    required this.lastFromMe,
    required this.unreadCount,
    required this.lastAt,
  });

  factory Conversation.fromJson(Map<String, dynamic> j) => Conversation(
        conversationKey: j['conversationKey'] as String,
        peer: Author.fromJson(j['peer'] as Map<String, dynamic>),
        lastContent: (j['lastContent'] as String?) ?? '',
        lastFromMe: (j['lastFromMe'] as bool?) ?? false,
        unreadCount: (j['unreadCount'] as int?) ?? 0,
        lastAt: DateTime.parse(j['lastAt'] as String).toLocal(),
      );
}
