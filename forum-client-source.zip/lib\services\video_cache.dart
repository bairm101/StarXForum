import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';

/// 视频缓存：已看过的视频缓存到应用私有目录（Android 上位于 /data 应用数据区），
/// 下次播放同一视频直接读本地文件，无需再次下载。
///
/// 策略：
/// - 首次播放走网络流式播放，同时后台下载完整文件到缓存；
/// - 再次播放检测到本地缓存文件后直接本地播放；
/// - 单文件超过 [_maxFileBytes] 不缓存，缓存总量超过 [_maxCacheBytes] 时按最旧优先清理。
class VideoCache {
  VideoCache._();

  /// 单文件缓存上限（超过则不缓存，仍走在线播放）
  static const int _maxFileBytes = 512 * 1024 * 1024;

  /// 缓存目录总容量上限
  static const int _maxCacheBytes = 512 * 1024 * 1024;

  static Directory? _dir;
  static final Map<String, Future<File?>> _inflight = {};

  static Future<Directory> _cacheDir() async {
    final d = _dir;
    if (d != null) return d;
    final base = await getApplicationSupportDirectory();
    final dir = Directory('${base.path}${Platform.pathSeparator}video_cache');
    if (!await dir.exists()) {
      await dir.create(recursive: true);
    }
    _dir = dir;
    return dir;
  }

  /// 根据 URL 生成稳定的本地文件名（URL 哈希 + 原始文件名尾段）。
  static String _fileNameFor(String url) {
    final uri = Uri.tryParse(url);
    final seg = (uri != null && uri.pathSegments.isNotEmpty) ? uri.pathSegments.last : 'video';
    final safe = seg.replaceAll(RegExp(r'[^A-Za-z0-9._-]'), '_');
    final hash = url.hashCode.toUnsigned(32).toRadixString(16);
    return '$hash-$safe';
  }

  /// 若已有缓存返回本地文件，否则返回 null。
  static Future<File?> cachedFile(String url) async {
    if (kIsWeb) return null;
    try {
      final dir = await _cacheDir();
      final f = File('${dir.path}${Platform.pathSeparator}${_fileNameFor(url)}');
      if (await f.exists()) return f;
      return null;
    } catch (_) {
      return null;
    }
  }

  /// 后台确保视频被缓存；正在下载中的同一 URL 不会重复下载。
  /// 失败时静默返回（不影响在线播放）。
  static Future<File?> ensureCached(String url) {
    if (kIsWeb) return Future.value(null);
    return _inflight.putIfAbsent(url, () async {
      try {
        final existing = await cachedFile(url);
        if (existing != null) return existing;

        final dir = await _cacheDir();
        final name = _fileNameFor(url);
        final tmp = File('${dir.path}${Platform.pathSeparator}$name.part');

        final client = http.Client();
        try {
          final streamed = await client.send(http.Request('GET', Uri.parse(url)));
          if (streamed.statusCode != 200) return null;
          final total = streamed.contentLength ?? -1;
          if (total > _maxFileBytes) return null;

          final sink = tmp.openWrite();
          var received = 0;
          try {
            await for (final chunk in streamed.stream) {
              received += chunk.length;
              if (received > _maxFileBytes) {
                throw _TooLargeException();
              }
              sink.add(chunk);
            }
          } finally {
            await sink.flush();
            await sink.close();
          }

          final target = File('${dir.path}${Platform.pathSeparator}$name');
          if (await target.exists()) await target.delete();
          await tmp.rename(target.path);
          await _evictIfNeeded(dir);
          return target;
        } finally {
          client.close();
          if (await tmp.exists()) {
            try {
              await tmp.delete();
            } catch (_) {}
          }
        }
      } catch (_) {
        return null;
      } finally {
        _inflight.remove(url);
      }
    });
  }

  /// 缓存总量超限时按修改时间从旧到新删除。
  static Future<void> _evictIfNeeded(Directory dir) async {
    try {
      final files = <File>[];
      await for (final e in dir.list()) {
        if (e is File && !e.path.endsWith('.part')) files.add(e);
      }
      var total = 0;
      final lenOf = <File, int>{};
      final times = <File, DateTime>{};
      for (final f in files) {
        lenOf[f] = await f.length();
        total += lenOf[f]!;
        times[f] = await f.lastModified();
      }
      if (total <= _maxCacheBytes) return;
      files.sort((a, b) => times[a]!.compareTo(times[b]!));
      for (final f in files) {
        if (total <= _maxCacheBytes) break;
        total -= lenOf[f] ?? 0;
        try {
          await f.delete();
        } catch (_) {}
      }
    } catch (_) {}
  }
}

class _TooLargeException implements Exception {}
