import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../api/api_client.dart';
import '../auth/auth_state.dart';
import 'media_widgets.dart';
import 'post_detail_screen.dart';
import 'user_home_screen.dart';

/// 管理后台：概览 / 待审核 / 用户管理 / 站点设置
class AdminScreen extends StatefulWidget {
  const AdminScreen({super.key});

  @override
  State<AdminScreen> createState() => _AdminScreenState();
}

class _AdminScreenState extends State<AdminScreen> {
  @override
  Widget build(BuildContext context) {
    final auth = context.read<AuthState>();
    return DefaultTabController(
      length: 9,
      child: Scaffold(
        appBar: AppBar(
          title: Text(_roleTitle(auth.role)),
          actions: [IconButton(onPressed: () => setState(() {}), icon: const Icon(Icons.refresh), tooltip: '刷新')],
          bottom: TabBar(
            isScrollable: true,
            tabs: const [
              Tab(icon: Icon(Icons.inbox), text: '待审核'),
              Tab(icon: Icon(Icons.people), text: '用户'),
              Tab(icon: Icon(Icons.dashboard), text: '板块'),
              Tab(icon: Icon(Icons.settings), text: '站点'),
              Tab(icon: Icon(Icons.bar_chart), text: '统计'),
              Tab(icon: Icon(Icons.gpp_good), text: '敏感词'),
              Tab(icon: Icon(Icons.flag), text: '举报'),
              Tab(icon: Icon(Icons.cleaning_services), text: '清理'),
              Tab(icon: Icon(Icons.history), text: '日志'),
            ],
            labelColor: Colors.indigo,
            indicatorColor: Colors.indigo,
          ),
        ),
        body: TabBarView(
          children: [
            const _ModerationTab(),
            const _UsersTab(),
            const _BoardsAdminTab(),
            if (auth.isOwner) const _SiteSettingsTab() else const _NotOwnerTab(),
            const _StatsTab(),
            const _SensitiveWordsTab(),
            const _ReportsTab(),
            if (auth.isOwner) const _MaintenanceTab() else const _NotOwnerTab(),
            const _LogsTab(),
          ],
        ),
      ),
    );
  }

  String _roleTitle(String role) => switch (role) {
        'OWNER' => '管理后台 · 站长',
        'SUPER_ADMIN' => '管理后台 · 超级管理员',
        _ => '管理后台 · 管理员',
      };
}

// ---------- 待审核 ----------

class _ModerationTab extends StatefulWidget {
  const _ModerationTab();

  @override
  State<_ModerationTab> createState() => _ModerationTabState();
}

class _ModerationTabState extends State<_ModerationTab> {
  List<dynamic> _posts = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final d = await ApiClient.get('/api/admin/posts/pending', query: {'size': '50'});
      setState(() {
        _posts = ((d['data'] as Map<String, dynamic>)['items'] as List);
        _loading = false;
      });
    } catch (e) {
      setState(() => _loading = false);
    }
  }

  Future<void> _moderate(int postId, bool approve) async {
    try {
      await ApiClient.post('/api/admin/posts/$postId/moderate?approve=$approve');
      _toast(approve ? '已通过' : '已驳回');
      await _load();
    } on ApiException catch (e) {
      _toast(e.message);
    } catch (e) {
      _toast('操作失败');
    }
  }

  Future<void> _delete(int postId) async {
    try {
      await ApiClient.delete('/api/admin/posts/$postId');
      _toast('已删除');
      await _load();
    } on ApiException catch (e) {
      _toast(e.message);
    } catch (e) {
      _toast('删除失败');
    }
  }

  void _toast(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_posts.isEmpty) return const Center(child: Text('没有待审核的帖子'));
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView.builder(
        itemCount: _posts.length,
        itemBuilder: (_, i) {
          final p = _posts[i] as Map<String, dynamic>;
          return Card(
            margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            child: InkWell(
              onTap: () => _showDetail(p),
              child: SizedBox(
                height: 190,
                child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(p['title'] as String? ?? '',
                      style: const TextStyle(fontWeight: FontWeight.w600)),
                  const SizedBox(height: 4),
                   Text((p['excerpt'] as String?) ?? '',
                       maxLines: 2,
                       style: TextStyle(color: Colors.grey[600], fontSize: 13)),
                   if ((p['topics'] as String?)?.isNotEmpty == true)
                     Padding(
                       padding: const EdgeInsets.only(top: 5),
                       child: Text('#${(p['topics'] as String).replaceAll(',', '  #')}',
                           style: TextStyle(fontSize: 12, color: Colors.indigo.shade500)),
                     ),
                  const SizedBox(height: 4),
                  Text(
                      '${p['boardName']} · ${((p['author'] as Map<String, dynamic>?)?['displayName']) ?? ''}',
                      style: TextStyle(fontSize: 12, color: Colors.grey[500])),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      FilledButton(
                          onPressed: () => _moderate(p['id'] as int, true),
                          child: const Text('通过')),
                      const SizedBox(width: 8),
                      OutlinedButton(
                          onPressed: () => _moderate(p['id'] as int, false),
                          child: const Text('驳回')),
                      const SizedBox(width: 8),
                      TextButton(
                          onPressed: () => _delete(p['id'] as int),
                          style: TextButton.styleFrom(foregroundColor: Colors.red),
                          child: const Text('删除')),
                    ],
                  ),
                ],
              ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Future<void> _showDetail(Map<String, dynamic> p) async {
    try {
      final d=await ApiClient.get('/api/posts/${p['id']}', query: {'moderation': 'true'});
      final post=d['data'] as Map<String,dynamic>;
      if(!mounted)return;
      showModalBottomSheet(context:context,isScrollControlled:true,builder:(_)=>Padding(padding:const EdgeInsets.all(16),child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text(post['title']?.toString()??'',style:const TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
        const SizedBox(height:10),Flexible(child:SingleChildScrollView(child:PostContentRenderer(content: post['content']?.toString()??'', hostContext: context))),
        const SizedBox(height:12),Row(children:[Expanded(child:FilledButton(onPressed:(){Navigator.pop(context);_moderate(p['id'] as int,true);},child:const Text('通过'))),const SizedBox(width:8),Expanded(child:OutlinedButton(onPressed:(){Navigator.pop(context);_moderate(p['id'] as int,false);},child:const Text('驳回')))])
      ])));
    } catch(e){_toast('详情加载失败');}
  }
}

// ---------- 用户管理 ----------

class _UsersTab extends StatefulWidget {
  const _UsersTab();

  @override
  State<_UsersTab> createState() => _UsersTabState();
}

class _UsersTabState extends State<_UsersTab> {
  List<dynamic> _users = [];
  List<dynamic> _boards = [];
  bool _loading = true;
  final _searchCtrl = TextEditingController();
  String _keyword = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final q = <String, String>{'size': '100'};
      if (_keyword.trim().isNotEmpty) q['keyword'] = _keyword.trim();
      final u = await ApiClient.get('/api/admin/users', query: q);
      final b = await ApiClient.get('/api/boards');
      setState(() {
        _users = ((u['data'] as Map<String, dynamic>)['items'] as List);
        _boards = (b['data'] as List);
        _loading = false;
      });
    } catch (e) {
      setState(() => _loading = false);
    }
  }

  Future<void> _createUser() async {
    final auth = context.read<AuthState>();
    final username = TextEditingController();
    final password = TextEditingController();
    final nickname = TextEditingController();
    final email = TextEditingController();
    String role = 'USER';
    final ok = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (dialogContext, setLocal) => AlertDialog(
          title: const Text('添加用户'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: username,
                  decoration: const InputDecoration(
                      labelText: '用户名 *', hintText: '3-32 个字符', border: OutlineInputBorder()),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: password,
                  obscureText: true,
                  decoration: const InputDecoration(
                      labelText: '密码 *', hintText: '至少 8 位', border: OutlineInputBorder()),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: nickname,
                  decoration: const InputDecoration(labelText: '昵称（可选）', border: OutlineInputBorder()),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: email,
                  keyboardType: TextInputType.emailAddress,
                  decoration: const InputDecoration(labelText: '邮箱（可选）', border: OutlineInputBorder()),
                ),
                const SizedBox(height: 10),
                DropdownButtonFormField<String>(
                  value: role,
                  decoration: const InputDecoration(labelText: '角色', border: OutlineInputBorder()),
                  items: [
                    const DropdownMenuItem(value: 'USER', child: Text('普通用户')),
                    if (auth.isOwner)
                      const DropdownMenuItem(value: 'SUPER_ADMIN', child: Text('超级管理员')),
                  ],
                  onChanged: (v) => setLocal(() => role = v ?? 'USER'),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(dialogContext, false), child: const Text('取消')),
            FilledButton(
                onPressed: () => Navigator.pop(dialogContext, true), child: const Text('创建')),
          ],
        ),
      ),
    );
    if (ok != true) return;
    if (username.text.trim().isEmpty || password.text.length < 8) {
      _toast('请填写用户名和至少 8 位密码');
      return;
    }
    try {
      await ApiClient.post('/api/admin/users', body: {
        'username': username.text.trim(),
        'password': password.text,
        'nickname': nickname.text.trim().isEmpty ? null : nickname.text.trim(),
        'email': email.text.trim().isEmpty ? null : email.text.trim(),
        'role': role,
      });
      _toast('用户已创建');
      await _load();
    } on ApiException catch (e) {
      _toast(e.message);
    } catch (e) {
      _toast('创建失败');
    }
  }

  Future<void> _setRole(int userId, String role, {int? boardId}) async {
    try {
      final q = <String, String>{'role': role};
      if (boardId != null) q['boardId'] = '$boardId';
      final query = q.entries.map((e) => '${e.key}=${e.value}').join('&');
      await ApiClient.patch('/api/admin/users/$userId/role?$query');
      _toast('角色已更新');
      await _load();
    } on ApiException catch (e) {
      _toast(e.message);
    } catch (e) {
      _toast('操作失败');
    }
  }

  Future<void> _setTitle(int userId) async {
    final ctrl = TextEditingController();
    final title = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('设置头衔'),
        content: TextField(
            controller: ctrl,
            decoration: const InputDecoration(hintText: '如：论坛达人、官方认证')),
        actions: [
          TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('取消')),
          FilledButton(
              onPressed: () => Navigator.of(context).pop(ctrl.text), child: const Text('确定')),
        ],
      ),
    );
    if (title == null) return;
    try {
      await ApiClient.patch('/api/admin/users/$userId/title?title=${Uri.encodeComponent(title)}');
      _toast('头衔已更新');
      await _load();
    } on ApiException catch (e) {
      _toast(e.message);
    }
  }

  Future<void> _ban(int userId, bool banned) async {
    String? reason;
    if (banned) {
      // 封禁时选择原因（违规处理模板）
      const templates = ['广告骚扰', '辱骂攻击', '政治敏感', '色情低俗', '恶意刷屏', '其他违规'];
      final customCtrl = TextEditingController();
      reason = await showDialog<String>(
        context: context,
        builder: (dialogContext) => AlertDialog(
          title: const Text('封禁原因'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ...templates.map((t) => ListTile(
                    dense: true,
                    title: Text(t),
                    onTap: () => Navigator.pop(dialogContext, t),
                  )),
              TextField(
                controller: customCtrl,
                decoration: const InputDecoration(labelText: '自定义原因', border: OutlineInputBorder()),
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('取消')),
            FilledButton(
              onPressed: () => Navigator.pop(dialogContext, customCtrl.text.trim()),
              child: const Text('使用自定义'),
            ),
          ],
        ),
      );
      if (reason == null) return;
    }
    try {
      final q = reason != null && reason.isNotEmpty
          ? '&reason=${Uri.encodeComponent(reason)}'
          : '';
      await ApiClient.patch('/api/admin/users/$userId/ban?banned=$banned$q');
      _toast(banned ? '已封禁' : '已解封');
      await _load();
    } on ApiException catch (e) {
      _toast(e.message);
    }
  }

  void _toast(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.read<AuthState>();
    if (_loading) return const Center(child: CircularProgressIndicator());
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 4),
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _searchCtrl,
                  decoration: InputDecoration(
                    hintText: '搜索 UID / 用户名 / 昵称',
                    isDense: true,
                    prefixIcon: const Icon(Icons.search, size: 20),
                    suffixIcon: _keyword.isNotEmpty
                        ? IconButton(
                            icon: const Icon(Icons.clear, size: 18),
                            onPressed: () {
                              _searchCtrl.clear();
                              setState(() => _keyword = '');
                              _load();
                            },
                          )
                        : null,
                    border: const OutlineInputBorder(),
                  ),
                  onSubmitted: (_) {
                    setState(() => _keyword = _searchCtrl.text);
                    _load();
                  },
                ),
              ),
              const SizedBox(width: 8),
              IconButton.filledTonal(
                tooltip: '添加用户',
                onPressed: _createUser,
                icon: const Icon(Icons.person_add_alt_1),
              ),
            ],
          ),
        ),
        Expanded(
          child: ListView.builder(
      itemCount: _users.length,
      itemBuilder: (_, i) {
        final user = _users[i] as Map<String, dynamic>;
        final role = (user['role'] as String?) ?? 'USER';
        final banned = user['status'] == 'BANNED';
        final cancelled = user['status'] == 'CANCELLED';
        final isSelf = user['username'] == auth.username;
        return ListTile(
          leading: CircleAvatar(
              child: Text((user['displayName'] as String? ?? '?').characters.first)),
          title: Row(
            children: [
              Text(user['displayName'] as String? ?? ''),
              const SizedBox(width: 6),
              _roleChip(role),
              if (cancelled) ...[
                const SizedBox(width: 6),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
                  decoration: BoxDecoration(
                      color: Colors.grey.shade300, borderRadius: BorderRadius.circular(8)),
                  child: const Text('已注销',
                      style: TextStyle(fontSize: 10, color: Colors.black54)),
                ),
              ],
            ],
          ),
          subtitle: Text('@${user['username']}'
              '${(user['title'] as String?) != null ? ' · ${user['title']}' : ''}'),
          trailing: PopupMenuButton<String>(
            onSelected: (action) async {
              switch (action) {
                case 'title':
                  await _setTitle(user['id'] as int);
                  break;
                case 'ban':
                  await _ban(user['id'] as int, !banned);
                  break;
                case 'admin':
                  await _pickBoardThenAdmin(user['id'] as int);
                  break;
                case 'superadmin':
                  await _setRole(user['id'] as int, 'SUPER_ADMIN');
                  break;
                case 'user':
                  await _setRole(user['id'] as int, 'USER');
                  break;
                case 'params':
                  await _editParameters(user);
                  break;
                case 'sig_ok':
                  await _moderateSignature(user['id'] as int, true);
                  break;
                case 'sig_no':
                  await _moderateSignature(user['id'] as int, false);
                  break;
                case 'logout_all':
                  await _forceLogout(user['id'] as int);
                  break;
                case 'delete_user':
                  await _deleteUser(user['id'] as int, user['displayName'] as String? ?? '');
                  break;
              }
            },
            itemBuilder: (_) => [
              const PopupMenuItem(value: 'title', child: Text('设置头衔')),
              if (auth.isOwner) const PopupMenuItem(value: 'params', child: Text('调整参数')),
              if ((user['pendingSignature'] as String?) != null)
                const PopupMenuItem(value: 'sig_ok', child: Text('通过待审签名')),
              if ((user['pendingSignature'] as String?) != null)
                const PopupMenuItem(value: 'sig_no', child: Text('驳回待审签名')),
              if (auth.isOwner && !isSelf)
                const PopupMenuItem(value: 'superadmin', child: Text('任命超级管理员')),
              if (!isSelf) const PopupMenuItem(value: 'admin', child: Text('任命板块管理员')),
              if (!isSelf && role != 'USER')
                const PopupMenuItem(value: 'user', child: Text('降为普通用户')),
              if (!isSelf)
                PopupMenuItem(value: 'ban', child: Text(banned ? '解封' : '封禁')),
              if (auth.isStaff && !isSelf)
                const PopupMenuItem(value: 'logout_all', child: Text('强制退登（清空设备）')),
              if (auth.isStaff && !isSelf)
                const PopupMenuItem(
                    value: 'delete_user',
                    child: Text('删除用户', style: TextStyle(color: Colors.red))),
            ],
          ),
        );
      },
          ),
        ),
      ],
    );
  }

  Future<void> _moderateSignature(int userId, bool approve) async {
    try { await ApiClient.post('/api/admin/users/$userId/signature?approve=$approve'); _toast(approve?'签名已通过':'签名已驳回'); await _load(); }
    on ApiException catch(e){_toast(e.message);}
  }

  Future<void> _deleteUser(int userId, String name) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('删除用户'),
        content: Text(
          '确定删除用户「$name」吗？\n\n'
          '· 该用户的所有帖子将被永久删除；\n'
          '· 该用户上传的所有文件将被永久删除；\n'
          '· 其历史评论保留，署名显示为「账号已注销」；\n'
          '· 账号无法再登录。\n\n此操作不可恢复。',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('取消')),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            style: FilledButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('确认删除'),
          ),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await ApiClient.delete('/api/admin/users/$userId');
      _toast('用户已删除');
      await _load();
    } on ApiException catch (e) {
      _toast(e.message);
    } catch (_) {
      _toast('删除失败');
    }
  }

  Future<void> _forceLogout(int userId) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('强制退登'),
        content: const Text('将清空该用户所有已保存设备并强制退出登录。确定继续？'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('取消')),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            style: FilledButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('强制退登'),
          ),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await ApiClient.post('/api/admin/users/$userId/logout-all');
      _toast('已强制退登');
    } on ApiException catch (e) {
      _toast(e.message);
    }
  }

  Future<void> _editParameters(Map<String, dynamic> user) async {
    final level = TextEditingController(text: '${user['level'] ?? 1}');
    final exp = TextEditingController(text: '${user['exp'] ?? 0}');
    final gold = TextEditingController(text: '${user['gold'] ?? 0}');
    final weight = TextEditingController(text: '${user['rankingWeight'] ?? 1.0}');
    final password = TextEditingController();
    final username = TextEditingController(text: user['username']?.toString());
    final email = TextEditingController(text: user['email']?.toString() ?? '');
    final maxUpload = TextEditingController(text: user['maxUploadMb']?.toString() ?? '');
    final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
      title: Text('调整 ${user['username']}'), content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: username, decoration: const InputDecoration(labelText:'用户名')),
        TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText:'邮箱（留空清除）')),
        TextField(controller: level, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText:'等级 1-10')),
        TextField(controller: exp, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText:'经验')),
        TextField(controller: gold, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText:'金币')),
        TextField(controller: weight, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText:'推荐权重 0.1-10')),
        TextField(controller: maxUpload, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText:'最大上传 MB（留空用默认）')),
        TextField(controller: password, obscureText: true, decoration: const InputDecoration(labelText:'重置密码（留空不改）')),
      ])), actions:[TextButton(onPressed:()=>Navigator.pop(context,false),child:const Text('取消')),FilledButton(onPressed:()=>Navigator.pop(context,true),child:const Text('保存'))]));
    if (ok != true) return;
    try { await ApiClient.patch('/api/admin/users/${user['id']}/parameters', body:{
      'username':username.text,'email':email.text,'level':int.tryParse(level.text),'exp':int.tryParse(exp.text),
      'gold':int.tryParse(gold.text),'rankingWeight':double.tryParse(weight.text),
      'maxUploadMb':maxUpload.text.isEmpty?null:int.tryParse(maxUpload.text),
      'password':password.text.isEmpty?null:password.text}); _toast('参数已更新'); await _load(); }
    on ApiException catch(e){_toast(e.message);}
  }

  Future<void> _pickBoardThenAdmin(int userId) async {
    if (_boards.isEmpty) {
      _toast('暂无板块');
      return;
    }
    final boardId = await showDialog<int>(
      context: context,
      builder: (_) => SimpleDialog(
        title: const Text('选择所辖板块'),
        children: _boards.map((b) {
          final board = b as Map<String, dynamic>;
          return SimpleDialogOption(
            onPressed: () => Navigator.of(context).pop(board['id'] as int),
            child: Text(board['name'] as String? ?? ''),
          );
        }).toList(),
      ),
    );
    if (boardId == null) return;
    await _setRole(userId, 'ADMIN', boardId: boardId);
  }

  Widget _roleChip(String role) {
    final (label, color) = switch (role) {
      'OWNER' => ('站长', Colors.deepOrange),
      'SUPER_ADMIN' => ('超管', Colors.purple),
      'ADMIN' => ('管理', Colors.blue),
      _ => ('', Colors.grey),
    };
    if (label.isEmpty) return const SizedBox.shrink();
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
      decoration: BoxDecoration(color: color.withOpacity(0.12), borderRadius: BorderRadius.circular(8)),
      child: Text(label, style: TextStyle(fontSize: 10, color: color)),
    );
  }
}

// ---------- 站点设置（仅站长） ----------

class _SiteSettingsTab extends StatefulWidget {
  const _SiteSettingsTab();

  @override
  State<_SiteSettingsTab> createState() => _SiteSettingsTabState();
}

class _SiteSettingsTabState extends State<_SiteSettingsTab> {
  final _nameCtrl = TextEditingController();
  final _descCtrl = TextEditingController();
  final _announceCtrl = TextEditingController();
  final _titleCtrl = TextEditingController();
  final _footerCtrl = TextEditingController();
  final _icpCtrl = TextEditingController();
  final _linksCtrl = TextEditingController();
  final _websiteCtrl = TextEditingController();
  final _shareBaseCtrl = TextEditingController();
  final _contactEmailCtrl = TextEditingController();
  final _aboutIcpCtrl = TextEditingController();
  final _smtpHostCtrl = TextEditingController();
  final _smtpPortCtrl = TextEditingController();
  final _smtpUserCtrl = TextEditingController();
  final _smtpPassCtrl = TextEditingController();
  String _theme='SYSTEM', _signatureAudit='OFF';
  bool _smtpEnabled=false, _smtpSsl=true;
  bool _allowRegister = true;
  bool _emailVerify = false, _mathEmail = true, _mathPost = true, _mathComment = true;
  bool _imageCompress = false, _videoCompress = false;
  bool _postEditAudit = false;
  bool _deviceVerification = false;
  int _imageMb = 5, _videoMb = 15;
  final _autoRefreshCtrl = TextEditingController();
  bool _loading = true;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _descCtrl.dispose();
    _announceCtrl.dispose();
    _titleCtrl.dispose(); _footerCtrl.dispose(); _icpCtrl.dispose(); _linksCtrl.dispose();
    _websiteCtrl.dispose(); _shareBaseCtrl.dispose(); _contactEmailCtrl.dispose(); _aboutIcpCtrl.dispose();
    _autoRefreshCtrl.dispose();
    _smtpHostCtrl.dispose(); _smtpPortCtrl.dispose(); _smtpUserCtrl.dispose(); _smtpPassCtrl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final d = await ApiClient.get('/api/admin/settings');
      final s = d['data'] as Map<String, dynamic>;
      setState(() {
        _nameCtrl.text = (s['siteName'] as String?) ?? '';
        _descCtrl.text = (s['siteDescription'] as String?) ?? '';
        _announceCtrl.text = (s['announcement'] as String?) ?? '';
        _titleCtrl.text = (s['pageTitle'] as String?) ?? '论坛';
        _footerCtrl.text = (s['footerText'] as String?) ?? '';
        _icpCtrl.text = (s['footerIcp'] as String?) ?? '';
        _linksCtrl.text = (s['footerLinksJson'] as String?) ?? '[]';
        _websiteCtrl.text = (s['officialWebsite'] as String?) ?? 'www.starxx.cn';
        _shareBaseCtrl.text = (s['webShareBaseUrl'] as String?) ?? 'https://forum.starxx.cn';
        _contactEmailCtrl.text = (s['contactEmail'] as String?) ?? '908696225@qq.com';
        _aboutIcpCtrl.text = (s['aboutIcp'] as String?) ?? '';
        _autoRefreshCtrl.text = '${s['autoRefreshSeconds'] ?? 180}';
        _smtpHostCtrl.text=(s['smtpHost'] as String?)??'smtp.qq.com';
        _smtpPortCtrl.text='${s['smtpPort']??465}';
        _smtpUserCtrl.text=(s['smtpUsername'] as String?)??'';
        _theme=(s['defaultTheme'] as String?)??'SYSTEM';
        _signatureAudit=(s['signatureAuditMode'] as String?)??'OFF';
        _smtpEnabled=(s['smtpEnabled'] as bool?)??false;
        _smtpSsl=(s['smtpSsl'] as bool?)??true;
        _allowRegister = (s['allowRegister'] as bool?) ?? true;
        _emailVerify=(s['emailVerificationEnabled'] as bool?)??false;
        _mathEmail=(s['arithmeticEmailEnabled'] as bool?)??true; _mathPost=(s['arithmeticPostEnabled'] as bool?)??true; _mathComment=(s['arithmeticCommentEnabled'] as bool?)??true;
        _imageCompress=(s['imageCompressEnabled'] as bool?)??false; _videoCompress=(s['videoCompressEnabled'] as bool?)??false;
        _postEditAudit=(s['postEditAuditEnabled'] as bool?)??false;
        _deviceVerification=(s['deviceVerificationEnabled'] as bool?)??false;
        _imageMb=(s['imageMaxMb'] as int?)??5; _videoMb=(s['videoMaxMb'] as int?)??15;
        _loading = false;
      });
    } catch (e) {
      setState(() => _loading = false);
    }
  }

  Future<void> _save() async {
    setState(() => _saving = true);
    try {
      await ApiClient.put('/api/admin/settings', body: {
        'siteName': _nameCtrl.text,
        'siteDescription': _descCtrl.text,
        'announcement': _announceCtrl.text,
        'allowRegister': _allowRegister,
        'pageTitle':_titleCtrl.text,'footerText':_footerCtrl.text,'footerIcp':_icpCtrl.text,'footerLinksJson':_linksCtrl.text,
        'officialWebsite':_websiteCtrl.text,'webShareBaseUrl':_shareBaseCtrl.text,'contactEmail':_contactEmailCtrl.text,'aboutIcp':_aboutIcpCtrl.text,
        'autoRefreshSeconds':int.tryParse(_autoRefreshCtrl.text)??180,
        'emailVerificationEnabled':_emailVerify,'arithmeticEmailEnabled':_mathEmail,'arithmeticPostEnabled':_mathPost,'arithmeticCommentEnabled':_mathComment,
        'imageCompressEnabled':_imageCompress,'videoCompressEnabled':_videoCompress,'imageMaxMb':_imageMb,'videoMaxMb':_videoMb,
        'postEditAuditEnabled':_postEditAudit,
        'deviceVerificationEnabled':_deviceVerification,
        'defaultTheme':_theme,'signatureAuditMode':_signatureAudit,
        'smtpEnabled':_smtpEnabled,'smtpHost':_smtpHostCtrl.text,'smtpPort':int.tryParse(_smtpPortCtrl.text),
        'smtpUsername':_smtpUserCtrl.text,'smtpPassword':_smtpPassCtrl.text,'smtpSsl':_smtpSsl,
      });
      _toast('已保存');
    } on ApiException catch (e) {
      _toast(e.message);
    } catch (e) {
      _toast('保存失败');
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  void _toast(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        TextField(controller: _nameCtrl,
            decoration: const InputDecoration(labelText: '站点名称', border: OutlineInputBorder())),
        const SizedBox(height: 12),
        TextField(controller: _descCtrl,
            decoration: const InputDecoration(labelText: '站点描述', border: OutlineInputBorder())),
        const SizedBox(height: 12),
        TextField(controller: _announceCtrl, maxLines: 3,
            decoration: const InputDecoration(labelText: '全站公告', border: OutlineInputBorder())),
        const SizedBox(height: 12),
        TextField(controller:_titleCtrl,decoration:const InputDecoration(labelText:'网页标题',border:OutlineInputBorder())),
        const SizedBox(height:12),
        TextField(controller:_footerCtrl,decoration:const InputDecoration(labelText:'页脚详细',border:OutlineInputBorder())),
        const SizedBox(height:12),
        TextField(controller:_icpCtrl,decoration:const InputDecoration(labelText:'备案信息',border:OutlineInputBorder())),
        const SizedBox(height:12),
        TextField(controller:_linksCtrl,maxLines:3,decoration:const InputDecoration(labelText:'友情链接 JSON',helperText:'[{"name":"站点","url":"https://..."}]',border:OutlineInputBorder())),
        const SizedBox(height:12),
        const Text('关于页信息',style:TextStyle(fontWeight:FontWeight.bold)),
        const SizedBox(height:8),
        TextField(controller:_websiteCtrl,decoration:const InputDecoration(labelText:'官方网站',hintText:'www.starxx.cn',border:OutlineInputBorder())),
        const SizedBox(height:12),
        TextField(controller:_shareBaseCtrl,decoration:const InputDecoration(labelText:'Web 分享链接域名',hintText:'https://forum.starxx.cn',helperText:'分享帖子时拼接 ?puid=xxx 生成链接',border:OutlineInputBorder())),
        const SizedBox(height:12),
        TextField(controller:_contactEmailCtrl,keyboardType:TextInputType.emailAddress,decoration:const InputDecoration(labelText:'联系邮箱',hintText:'908696225@qq.com',border:OutlineInputBorder())),
        const SizedBox(height:12),
        TextField(controller:_aboutIcpCtrl,decoration:const InputDecoration(labelText:'关于页备案号',border:OutlineInputBorder())),
        const SizedBox(height:12),
        TextFormField(controller:_autoRefreshCtrl,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'自动刷新间隔（秒）',helperText:'0 表示关闭自动刷新，默认 180 秒',border:OutlineInputBorder())),
        const SizedBox(height:12),
        DropdownButtonFormField<String>(value:_theme,decoration:const InputDecoration(labelText:'默认主题'),items:const [DropdownMenuItem(value:'SYSTEM',child:Text('跟随系统')),DropdownMenuItem(value:'LIGHT',child:Text('日间')),DropdownMenuItem(value:'DARK',child:Text('夜间'))],onChanged:(v)=>setState(()=>_theme=v??'SYSTEM')),
        DropdownButtonFormField<String>(value:_signatureAudit,decoration:const InputDecoration(labelText:'签名审核'),items:const [DropdownMenuItem(value:'OFF',child:Text('关闭')),DropdownMenuItem(value:'FIRST',child:Text('仅第一次')),DropdownMenuItem(value:'ALWAYS',child:Text('每次修改'))],onChanged:(v)=>setState(()=>_signatureAudit=v??'OFF')),
        SwitchListTile(title:const Text('注册邮箱验证'),value:_emailVerify,onChanged:(v)=>setState(()=>_emailVerify=v)),
        SwitchListTile(title:const Text('邮箱前算术验证'),value:_mathEmail,onChanged:(v)=>setState(()=>_mathEmail=v)),
        SwitchListTile(title:const Text('发帖算术验证'),value:_mathPost,onChanged:(v)=>setState(()=>_mathPost=v)),
        SwitchListTile(title:const Text('评论算术验证'),value:_mathComment,onChanged:(v)=>setState(()=>_mathComment=v)),
        SwitchListTile(title:const Text('图片压缩'),value:_imageCompress,onChanged:(v)=>setState(()=>_imageCompress=v)),
        SwitchListTile(title:const Text('视频压缩（需 ffmpeg）'),value:_videoCompress,onChanged:(v)=>setState(()=>_videoCompress=v)),
        SwitchListTile(title:const Text('用户二次编辑帖子需重新审核'),value:_postEditAudit,onChanged:(v)=>setState(()=>_postEditAudit=v)),
        SwitchListTile(title:const Text('换设备登录二次验证（邮箱验证码）'),value:_deviceVerification,onChanged:(v)=>setState(()=>_deviceVerification=v)),
        const Divider(),
        const Text('SMTP 邮件服务',style:TextStyle(fontWeight:FontWeight.bold)),
        SwitchListTile(title:const Text('启用 SMTP'),value:_smtpEnabled,onChanged:(v)=>setState(()=>_smtpEnabled=v)),
        Row(children:[Expanded(child:TextField(controller:_smtpHostCtrl,decoration:const InputDecoration(labelText:'SMTP 主机'))),const SizedBox(width:8),SizedBox(width:100,child:TextField(controller:_smtpPortCtrl,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'端口')))]),
        TextField(controller:_smtpUserCtrl,decoration:const InputDecoration(labelText:'SMTP 账号')),
        TextField(controller:_smtpPassCtrl,obscureText:true,decoration:const InputDecoration(labelText:'授权码（留空不改）')),
        SwitchListTile(title:const Text('SSL'),value:_smtpSsl,onChanged:(v)=>setState(()=>_smtpSsl=v)),
        Row(children:[Expanded(child:TextFormField(initialValue:'$_imageMb',keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'图片上限 MB'),onChanged:(v)=>_imageMb=int.tryParse(v)??5)),const SizedBox(width:12),Expanded(child:TextFormField(initialValue:'$_videoMb',keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'视频上限 MB'),onChanged:(v)=>_videoMb=int.tryParse(v)??15))]),
        SwitchListTile(
          title: const Text('允许新用户注册'),
          value: _allowRegister,
          onChanged: (v) => setState(() => _allowRegister = v),
        ),
        const SizedBox(height: 16),
        FilledButton(
          onPressed: _saving ? null : _save,
          style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 14)),
          child: _saving
              ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
              : const Text('保存设置'),
        ),
      ],
    );
  }
}

class _NotOwnerTab extends StatelessWidget {
  const _NotOwnerTab();

  @override
  Widget build(BuildContext context) {
    return const Center(child: Text('站点设置仅站长可修改'));
  }
}

// ---------- 板块管理 ----------
class _BoardsAdminTab extends StatefulWidget { const _BoardsAdminTab(); @override State<_BoardsAdminTab> createState()=>_BoardsAdminTabState(); }
class _BoardsAdminTabState extends State<_BoardsAdminTab> {
  List<dynamic> boards=[]; bool loading=true;
  @override void initState(){super.initState();load();}
  Future<void> load() async { try { final d=await ApiClient.get('/api/admin/boards'); setState((){boards=d['data'] as List;loading=false;}); } catch(_){setState(()=>loading=false);} }
  Future<void> edit([Map<String,dynamic>? b]) async {
    final name=TextEditingController(text:b?['name']?.toString()); final desc=TextEditingController(text:b?['description']?.toString());
    bool visible=(b?['visible'] as bool?)??true, audit=(b?['requireModeration'] as bool?)??false;
    final data=await showDialog<Map<String,dynamic>>(context:context,builder:(_)=>StatefulBuilder(builder:(context,setLocal)=>AlertDialog(title:Text(b==null?'新建板块':'编辑板块'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:name,decoration:const InputDecoration(labelText:'名称')),TextField(controller:desc,decoration:const InputDecoration(labelText:'描述')),SwitchListTile(title:const Text('显示'),value:visible,onChanged:(v)=>setLocal(()=>visible=v)),SwitchListTile(title:const Text('发帖需审核'),value:audit,onChanged:(v)=>setLocal(()=>audit=v))]),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('取消')),FilledButton(onPressed:()=>Navigator.pop(context,{'name':name.text,'description':desc.text,'visible':visible,'requireModeration':audit}),child:const Text('保存'))])));
    if(data==null)return; try { if(b==null) await ApiClient.post('/api/admin/boards',body:data); else await ApiClient.put('/api/admin/boards/${b['id']}',body:data); await load(); } on ApiException catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(e.message)));}
  }
  Future<void> remove(Map<String,dynamic> b) async {
    final ok=await showDialog<bool>(context:context,builder:(_)=>AlertDialog(title:const Text('删除板块'),content:Text('确定删除板块「${b['name']??''}」吗？\n板块下有帖子时将无法删除。'),actions:[TextButton(onPressed:()=>Navigator.pop(context,false),child:const Text('取消')),FilledButton(style:FilledButton.styleFrom(backgroundColor:Colors.red),onPressed:()=>Navigator.pop(context,true),child:const Text('删除'))]));
    if(ok!=true)return;
    try { await ApiClient.delete('/api/admin/boards/${b['id']}'); await load(); }
    on ApiException catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(e.message)));}
  }
  @override Widget build(BuildContext context)=>Scaffold(floatingActionButton:FloatingActionButton(onPressed:()=>edit(),child:const Icon(Icons.add)),body:loading?const Center(child:CircularProgressIndicator()):ListView(children:boards.map((x){final b=x as Map<String,dynamic>;return ListTile(title:Text(b['name']??''),subtitle:Text('${b['description']??''} · 审核:${b['requireModeration']==true?'开':'关'}'),trailing:Row(mainAxisSize:MainAxisSize.min,children:[IconButton(icon:const Icon(Icons.delete_outline,color:Colors.red),tooltip:'删除',onPressed:()=>remove(b)),IconButton(icon:const Icon(Icons.edit),onPressed:()=>edit(b))]));}).toList()));
}

// ---------- 数据统计 ----------
class _StatsTab extends StatefulWidget { const _StatsTab(); @override State<_StatsTab> createState()=>_StatsTabState(); }
class _StatsTabState extends State<_StatsTab> {
  Map<String,dynamic>? _overview;
  List<Map<String,dynamic>> _regs=[], _posts=[], _comments=[];
  List<Map<String,dynamic>> _active=[];
  bool _loading=true;

  @override void initState(){super.initState();load();}
  Future<void> load() async {
    setState(()=>_loading=true);
    try {
      final o=await ApiClient.get('/api/stats/overview');
      final r=await ApiClient.get('/api/stats/daily/registrations?days=7');
      final p=await ApiClient.get('/api/stats/daily/posts?days=7');
      final c=await ApiClient.get('/api/stats/daily/comments?days=7');
      final a=await ApiClient.get('/api/stats/active-users?limit=10');
      setState((){
        _overview=o['data'] as Map<String,dynamic>;
        _regs=(r['data'] as List).map((e)=>e as Map<String,dynamic>).toList();
        _posts=(p['data'] as List).map((e)=>e as Map<String,dynamic>).toList();
        _comments=(c['data'] as List).map((e)=>e as Map<String,dynamic>).toList();
        _active=(a['data'] as List).map((e)=>e as Map<String,dynamic>).toList();
        _loading=false;
      });
    } catch(_){setState(()=>_loading=false);}
  }

  Widget _card(String label, String value, IconData icon, Color color) {
    return Expanded(child: Container(padding:const EdgeInsets.all(12),margin:const EdgeInsets.symmetric(horizontal:4),decoration:BoxDecoration(color:color.withOpacity(0.1),borderRadius:BorderRadius.circular(12)),child:Column(children:[Icon(icon,color:color),const SizedBox(height:4),Text(value,style:const TextStyle(fontSize:18,fontWeight:FontWeight.bold)),Text(label,style:TextStyle(fontSize:11,color:Colors.grey[600]))])));
  }

  Widget _chart(String title, List<Map<String,dynamic>> data) {
    final maxV=data.map((e)=>(e['c'] as num?)?.toInt()??0).fold(0,(a,b)=>a>b?a:b);
    return Padding(padding:const EdgeInsets.only(bottom:16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Text(title,style:const TextStyle(fontWeight:FontWeight.w600)),
      const SizedBox(height:8),
      SizedBox(height:100,child:Row(crossAxisAlignment:CrossAxisAlignment.end,children:data.map((e){final v=(e['c'] as num?)?.toInt()??0;final label=(e['d']?.toString()??'').substring(5);return Expanded(child:Column(mainAxisAlignment:MainAxisAlignment.end,children:[Text('$v',style:const TextStyle(fontSize:10)),const SizedBox(height:2),Container(height:maxV==0?2:(v/maxV*70).clamp(2,70),margin:const EdgeInsets.symmetric(horizontal:3),decoration:BoxDecoration(color:Colors.indigo, borderRadius:const BorderRadius.vertical(top:Radius.circular(3)))),Text(label,style:const TextStyle(fontSize:9))]));}).toList())),
    ]));
  }

  @override Widget build(BuildContext context) {
    if(_loading)return const Center(child:CircularProgressIndicator());
    return RefreshIndicator(onRefresh:load,child:ListView(padding:const EdgeInsets.all(12),children:[
      Row(children:[
        _card('用户', '${_overview?['users']??0}', Icons.people, Colors.indigo),
        _card('帖子', '${_overview?['posts']??0}', Icons.article, Colors.green),
        _card('评论', '${_overview?['comments']??0}', Icons.chat, Colors.orange),
        _card('点赞', '${_overview?['likes']??0}', Icons.thumb_up, Colors.pink),
      ]),
      const SizedBox(height:16),
      _chart('近7天注册', _regs),
      _chart('近7天发帖', _posts),
      _chart('近7天评论', _comments),
      const SizedBox(height:8),
      Text('活跃用户 Top',style:const TextStyle(fontWeight:FontWeight.w600)),
      const SizedBox(height:4),
      ..._active.asMap().entries.map((e){final u=e.value;final nick=(u['nickname']?.toString()??'').trim();final uname=u['username']?.toString()??'';return ListTile(dense:true,leading:CircleAvatar(radius:14,child:Text('${e.key+1}')),title:Text(nick.isNotEmpty?nick:uname),trailing:Text('帖 ${u['posts']} · 评 ${u['comments']}',style:TextStyle(fontSize:12,color:Colors.grey[600])));}),
    ]));
  }
}

// ---------- 敏感词管理 ----------
class _SensitiveWordsTab extends StatefulWidget { const _SensitiveWordsTab(); @override State<_SensitiveWordsTab> createState()=>_SensitiveWordsTabState(); }
class _SensitiveWordsTabState extends State<_SensitiveWordsTab> {
  List<dynamic> _words=[]; bool _loading=true;
  @override void initState(){super.initState();load();}
  Future<void> load() async { try { final d=await ApiClient.get('/api/admin/sensitive-words'); setState((){_words=d['data'] as List; _loading=false;}); } catch(_){setState(()=>_loading=false);} }
  void _toast(String m){if(!mounted)return;ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(m)));}
  Future<void> _add() async {
    final word=TextEditingController(); final rep=TextEditingController();
    final ok=await showDialog<bool>(context:context,builder:(_)=>AlertDialog(title:const Text('添加敏感词'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:word,decoration:const InputDecoration(labelText:'敏感词')),TextField(controller:rep,decoration:const InputDecoration(labelText:'替换为（默认 ***）'))]),actions:[TextButton(onPressed:()=>Navigator.pop(context,false),child:const Text('取消')),FilledButton(onPressed:()=>Navigator.pop(context,true),child:const Text('添加'))]));
    if(ok!=true)return;
    try{await ApiClient.post('/api/admin/sensitive-words',body:{'word':word.text.trim(),'replacement':rep.text.trim()});_toast('已添加');await load();}on ApiException catch(e){_toast(e.message);}catch(_){_toast('添加失败');}
  }
  Future<void> _toggle(dynamic w) async {
    try{await ApiClient.put('/api/admin/sensitive-words/${w['id']}',body:{'replacement':w['replacement'],'enabled':!(w['enabled'] as bool? ?? true)});await load();}on ApiException catch(e){_toast(e.message);}
  }
  Future<void> _delete(dynamic w) async {
    try{await ApiClient.delete('/api/admin/sensitive-words/${w['id']}');_toast('已删除');await load();}on ApiException catch(e){_toast(e.message);}
  }
  @override Widget build(BuildContext context)=>Scaffold(floatingActionButton:FloatingActionButton(onPressed:_add,child:const Icon(Icons.add)),body:_loading?const Center(child:CircularProgressIndicator()):_words.isEmpty?const Center(child:Text('暂无敏感词')):ListView(children:_words.map((w)=>ListTile(title:Text('${w['word']}  →  ${w['replacement']??'***'}'),subtitle:Text(w['enabled']==true?'已启用':'已停用'),trailing:Row(mainAxisSize:MainAxisSize.min,children:[Switch(value:(w['enabled'] as bool?)??true,onChanged:(_)=>_toggle(w)),IconButton(icon:const Icon(Icons.delete_outline,color:Colors.red),onPressed:()=>_delete(w))]))).toList()));
}

// ---------- 举报处理 ----------
class _ReportsTab extends StatefulWidget { const _ReportsTab(); @override State<_ReportsTab> createState()=>_ReportsTabState(); }
class _ReportsTabState extends State<_ReportsTab> {
  List<dynamic> _reports=[]; bool _loading=true; String _status='PENDING';
  void _toast(String m){if(!mounted)return;ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(m)));}
  @override void initState(){super.initState();load();}
  Future<void> load() async {
    try { final d=await ApiClient.get('/api/admin/reports',query:{'status':_status,'size':'50'}); setState((){_reports=((d['data'] as Map<String,dynamic>)['items'] as List);_loading=false;}); } catch(_){setState(()=>_loading=false);}
  }
  Future<void> _handle(dynamic r, bool resolve) async {
    final note=TextEditingController();
    final ok=await showDialog<bool>(context:context,builder:(_)=>AlertDialog(title:Text(resolve?'处理举报':'驳回举报'),content:TextField(controller:note,decoration:const InputDecoration(labelText:'处理备注（可选）')),actions:[TextButton(onPressed:()=>Navigator.pop(context,false),child:const Text('取消')),FilledButton(onPressed:()=>Navigator.pop(context,true),child:Text(resolve?'确认处理':'驳回'))]));
    if(ok!=true)return;
    try{
      final q=note.text.trim().isEmpty?'':'?note=${Uri.encodeComponent(note.text.trim())}';
      if(resolve) await ApiClient.post('/api/admin/reports/${r['id']}/resolve$q');
      else await ApiClient.post('/api/admin/reports/${r['id']}/reject$q');
      _toast(resolve?'已处理':'已驳回'); await load();
    }on ApiException catch(e){_toast(e.message);}
  }

  String _typeLabel(String t)=>switch(t){'POST'=>'帖子','COMMENT'=>'评论','USER'=>'用户',_=>t};

  void _open(dynamic r) {
    if (r['targetDeleted'] == true) { _toast('目标已被删除'); return; }
    if (!mounted) return;
    final type=r['targetType'];
    if (type=='USER' && r['userId']!=null) {
      Navigator.of(context).push(MaterialPageRoute(builder:(_)=>UserHomeScreen(userId:r['userId'] as int)));
    } else if (r['postId']!=null) {
      Navigator.of(context).push(MaterialPageRoute(builder:(_)=>PostDetailScreen(postId:r['postId'] as int,
        highlightCommentId: type=='COMMENT' ? (r['commentId'] as int?) : null)));
    }
  }

  @override Widget build(BuildContext context) {
    return Column(children:[
      Padding(padding:const EdgeInsets.all(8),child:SegmentedButton<String>(segments:const [ButtonSegment(value:'PENDING',label:Text('待处理')),ButtonSegment(value:'RESOLVED',label:Text('已处理')),ButtonSegment(value:'REJECTED',label:Text('已驳回'))],selected:{_status},onSelectionChanged:(s){setState(()=>_status=s.first);load();})),
      Expanded(child:_loading?const Center(child:CircularProgressIndicator()):_reports.isEmpty?const Center(child:Text('暂无举报')):RefreshIndicator(onRefresh:load,child:ListView(children:[
        for(final r in _reports)
          Card(margin:const EdgeInsets.symmetric(horizontal:12,vertical:4),child:ListTile(
            title:Text('举报${_typeLabel('${r['targetType']}')}${r['targetDeleted']==true?'（已删除）':''}'),
            subtitle:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
              Text('${r['targetSummary']??''}',style:const TextStyle(fontSize:13),maxLines:4,overflow:TextOverflow.ellipsis),
              const SizedBox(height:2),
              Text('举报者：${r['reporterName']??''} · 原因：${r['reason']??''}',style:TextStyle(fontSize:12,color:Colors.grey[600])),
              Text('时间：${r['createdAt']?.toString().substring(0,16)??''}',style:TextStyle(fontSize:11,color:Colors.grey[500])),
            ]),
            isThreeLine:true,
            onTap:()=>_open(r),
            trailing:Row(mainAxisSize:MainAxisSize.min,children:[
              if(r['status']=='PENDING')IconButton(icon:const Icon(Icons.check_circle,color:Colors.green),tooltip:'处理',onPressed:()=>_handle(r,true)),
              if(r['status']=='PENDING')IconButton(icon:const Icon(Icons.cancel,color:Colors.orange),tooltip:'驳回',onPressed:()=>_handle(r,false)),
            ])))
      ])))
    ]);
  }
}

// ---------- 操作日志 ----------
class _MaintenanceTab extends StatefulWidget { const _MaintenanceTab(); @override State<_MaintenanceTab> createState()=>_MaintenanceTabState(); }
class _MaintenanceTabState extends State<_MaintenanceTab> {
  Map<String,dynamic> _stats={}; bool _loading=true;
  @override void initState(){super.initState();load();}
  Future<void> load() async { try { final d=await ApiClient.get('/api/admin/maintenance/stats'); setState((){_stats=d['data'] as Map<String,dynamic>;_loading=false;}); } catch(_){setState(()=>_loading=false);} }
  Future<void> clear(String target,String label) async {
    final ok=await showDialog<bool>(context:context,builder:(_)=>AlertDialog(title:Text('清理$label'),content:Text('该操作不可恢复，确定继续吗？'),actions:[TextButton(onPressed:()=>Navigator.pop(context,false),child:const Text('取消')),FilledButton(onPressed:()=>Navigator.pop(context,true),child:const Text('确认清理'))]));
    if(ok!=true)return;
    try{final d=await ApiClient.post('/api/admin/maintenance/clear/$target');if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(d['message']?.toString()??'清理完成')));await load();}on ApiException catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(e.message)));}
  }
  @override Widget build(BuildContext context){
    if(_loading)return const Center(child:CircularProgressIndicator());
    return RefreshIndicator(onRefresh:load,child:ListView(padding:const EdgeInsets.all(12),children:[
      const Text('站长维护工具',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),
      const SizedBox(height:6),
      const Text('清理前请确认影响范围。聊天记录清理后无法恢复，撤销设备只删除已退出的历史设备。',style:TextStyle(color:Colors.grey,fontSize:12)),
      const SizedBox(height:12),
      Card(child:ListTile(leading:const Icon(Icons.memory),title:const Text('Redis 缓存'),subtitle:Text('按应用前缀清理，当前不可精确统计'),trailing:FilledButton(onPressed:()=>clear('cache','缓存'),child:const Text('清理')))),
      Card(child:ListTile(leading:const Icon(Icons.description),title:const Text('应用日志'),subtitle:Text('日志文件 ${_stats['logFiles']??0} 个'),trailing:FilledButton(onPressed:()=>clear('logs','日志'),child:const Text('清理')))),
      Card(child:ListTile(leading:const Icon(Icons.devices_other),title:const Text('已撤销设备'),subtitle:Text('${_stats['revokedDevices']??0} 条历史设备'),trailing:FilledButton(onPressed:()=>clear('devices','历史设备'),child:const Text('清理')))),
      Card(child:ListTile(leading:const Icon(Icons.chat_bubble_outline),title:const Text('聊天记录'),subtitle:Text('${_stats['messages']??0} 条消息'),trailing:FilledButton(style:FilledButton.styleFrom(backgroundColor:Colors.red),onPressed:()=>clear('messages','聊天记录'),child:const Text('全部清理')))),
    ]));
  }
}

// ---------- 操作日志 ----------
class _LogsTab extends StatefulWidget { const _LogsTab(); @override State<_LogsTab> createState()=>_LogsTabState(); }
class _LogsTabState extends State<_LogsTab> {
  List<dynamic> _logs=[]; bool _loading=true; String _filter='';
  @override void initState(){super.initState();load();}
  Future<void> load() async {
    try { final d=await ApiClient.get('/api/admin/logs',query:{'size':'100',if(_filter.isNotEmpty)'keyword':_filter}); setState((){_logs=((d['data'] as Map<String,dynamic>)['items'] as List);_loading=false;}); } catch(_){setState(()=>_loading=false);}
  }
  String _actionLabel(String a)=>switch(a){
    'BAN_USER'=>'封禁/解封', 'SET_ROLE'=>'角色变更', 'SET_TITLE'=>'头衔变更',
    'POST_APPROVE'=>'通过审核', 'POST_REJECT'=>'驳回', 'DELETE_POST'=>'删除帖子',
    'MOVE_POST'=>'转移板块', _=>a
  };
  @override Widget build(BuildContext context) {
    return Column(children:[
      Padding(padding:const EdgeInsets.all(8),child:TextField(decoration:const InputDecoration(labelText:'按操作者搜索',border:OutlineInputBorder(),prefixIcon:Icon(Icons.search),isDense:true),onSubmitted:(_)=>load())),
      Expanded(child:_loading?const Center(child:CircularProgressIndicator()):_logs.isEmpty?const Center(child:Text('暂无操作日志')):RefreshIndicator(onRefresh:load,child:ListView(children:_logs.map((l)=>ListTile(dense:true,leading:CircleAvatar(radius:14,child:Text('${l['operatorName']??'?'}'.characters.first)),title:Text('${_actionLabel(l['action']?.toString()??'')} · ${l['target']??''}'),subtitle:Text('${l['operatorName']??''} · ${l['createdAt']?.toString().substring(0,16)??''}\n${l['detail']??''}'),isThreeLine:true)).toList())))
    ]);
  }
}
