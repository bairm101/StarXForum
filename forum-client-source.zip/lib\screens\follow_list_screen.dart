import 'package:flutter/material.dart';
import '../api/api_client.dart';
import '../models/models.dart';
import 'user_home_screen.dart';

/// 关注 / 粉丝列表
class FollowListScreen extends StatefulWidget {
  final int userId;
  final bool follow; // true=关注列表, false=粉丝列表
  const FollowListScreen({super.key, required this.userId, required this.follow});

  @override
  State<FollowListScreen> createState() => _FollowListScreenState();
}

class _FollowListScreenState extends State<FollowListScreen> {
  List<Author> _users = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final path = widget.follow ? 'following' : 'followers';
      final d = await ApiClient.get('/api/users/${widget.userId}/$path', query: {'size': '100'});
      final items = ((d['data'] as Map<String, dynamic>)['items'] as List)
          .map((e) => Author.fromJson(e as Map<String, dynamic>))
          .toList();
      setState(() {
        _users = items;
        _loading = false;
      });
    } catch (_) {
      setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.follow ? '关注' : '粉丝')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _users.isEmpty
              ? const Center(child: Text('暂无'))
              : ListView.builder(
                  itemCount: _users.length,
                  itemBuilder: (_, i) {
                    final u = _users[i];
                    return ListTile(
                      leading: CircleAvatar(
                        backgroundImage: u.avatarUrl != null && u.avatarUrl!.isNotEmpty
                            ? NetworkImage(ApiClient.resourceUrl(u.avatarUrl))
                            : null,
                        child: u.avatarUrl == null || u.avatarUrl!.isEmpty
                            ? Text(u.displayName.characters.first)
                            : null,
                      ),
                      title: Text(u.displayName),
                      subtitle: Text('@${u.username}'),
                      onTap: () => Navigator.of(context).push(
                          MaterialPageRoute(builder: (_) => UserHomeScreen(userId: u.id))),
                    );
                  },
                ),
    );
  }
}
