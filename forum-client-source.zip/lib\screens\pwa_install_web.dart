import 'dart:js_interop';

/// Web 平台：触发 PWA 安装提示。
@JS('window')
extension type _JsWindow(JSObject _) implements JSObject {
  external JSObject? get forumInstallPrompt;
  external void alert(String message);
}

@JS()
extension type _JsInstallPrompt(JSObject _) implements JSObject {
  external JSPromise<JSAny?> prompt();
}

@JS('window')
external JSObject get _windowJs;

bool pwaInstallable() => true;

void requestPwaInstall() {
  try {
    final win = _JsWindow(_windowJs);
    final prompt = win.forumInstallPrompt;
    if (prompt == null) {
      win.alert('请使用浏览器菜单 → 安装应用/添加到主屏幕');
      return;
    }
    _JsInstallPrompt(prompt).prompt();
  } catch (_) {
    // 浏览器不支持时静默
  }
}
