import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import '../api/api_client.dart';
import 'user_home_screen.dart';
import 'post_detail_screen.dart';

/// 渲染文本并让 @用户名 / @UID:xxxx / @PUID:xxxx 变蓝可点击：
/// 用户名/UID → 跳转用户主页；PUID → 跳转对应帖子。
class MentionText extends StatefulWidget {
  final String content;
  final TextStyle? style;
  final TextAlign? textAlign;
  final String? prefix;
  final TextStyle? prefixStyle;

  const MentionText({
    super.key,
    required this.content,
    this.style,
    this.textAlign,
    this.prefix,
    this.prefixStyle,
  });

  @override
  State<MentionText> createState() => _MentionTextState();
}

class _MentionTextState extends State<MentionText> {
  static final _mention = RegExp(
      r'@PUID:(P[A-Za-z0-9]{10})|@UID:([A-Za-z0-9]{4,32})|@([\w\u4e00-\u9fa5\-]{3,32})');

  final List<TapGestureRecognizer> _recognizers = [];

  @override
  void dispose() {
    for (final r in _recognizers) {
      r.dispose();
    }
    super.dispose();
  }

  Future<void> _open({String? username, String? uid, String? puid}) async {
    if (puid != null) {
      if (!mounted) return;
      Navigator.of(context)
          .push(MaterialPageRoute(builder: (_) => PuidPostScreen(puid: puid)));
      return;
    }
    try {
      final path = uid != null
          ? '/api/users/by-uid/$uid'
          : '/api/users/by-name/${Uri.encodeComponent(username ?? '')}';
      final d = await ApiClient.get(path);
      final id = (d['data'] as Map<String, dynamic>)['id'] as int;
      if (!mounted) return;
      Navigator.of(context)
          .push(MaterialPageRoute(builder: (_) => UserHomeScreen(userId: id)));
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('用户不存在')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final content = widget.content;
    final spans = <InlineSpan>[];
    if (widget.prefix != null) {
      spans.add(TextSpan(text: widget.prefix, style: widget.prefixStyle));
    }
    int last = 0;
    for (final m in _mention.allMatches(content)) {
      if (m.start > last) {
        spans.add(TextSpan(text: content.substring(last, m.start)));
      }
      final puid = m.group(1)?.toUpperCase();
      final uid = m.group(2);
      final username = m.group(3);
      final recognizer = TapGestureRecognizer()
          ..onTap = () => _open(username: username, uid: uid, puid: puid);
      _recognizers.add(recognizer);
      spans.add(TextSpan(
        text: m.group(0),
        style: TextStyle(color: Colors.blue.shade600, fontWeight: FontWeight.w500),
        recognizer: recognizer,
      ));
      last = m.end;
    }
    if (last < content.length) {
      spans.add(TextSpan(text: content.substring(last)));
    }
    // SelectionArea 支持长按选择/复制，同时保留 @提及 点击跳转
    return SelectionArea(
      child: Text.rich(
        TextSpan(children: spans, style: widget.style),
        textAlign: widget.textAlign,
      ),
    );
  }
}
