import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'auth/auth_state.dart';
import 'site_config.dart';
import 'theme_state.dart';
import 'screens/home_screen.dart';
import 'screens/post_detail_screen.dart';
import 'api/api_client.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const ForumApp());
}

final navigatorKey = GlobalKey<NavigatorState>();

class ForumApp extends StatelessWidget {
  const ForumApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthState()),
        ChangeNotifierProvider(create: (_) => SiteConfig()),
        ChangeNotifierProvider(create: (_) => ThemeState()),
      ],
      child: Consumer2<SiteConfig, ThemeState>(
        builder: (context, site, theme, _) {
          return MaterialApp(
            navigatorKey: navigatorKey,
            title: site.pageTitle,
            debugShowCheckedModeBanner: false,
            theme: ThemeData(
              colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo),
              useMaterial3: true,
            ),
            darkTheme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo, brightness: Brightness.dark), useMaterial3: true),
            themeMode: theme.mode,
            home: const SplashScreen(),
          );
        },
      ),
    );
  }
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<String?> _clipboardPuid() async {
    try {
      final data = await Clipboard.getData(Clipboard.kTextPlain);
      final text = data?.text?.trim();
      if (text == null || text.isEmpty) return null;
      // 仅接受三种明确形式，避免任意文本误触发：
      // 1) 整段 = PUID:P1234567890
      var m = RegExp(r'^PUID\s*[:：]\s*(P[A-Za-z0-9]{10})$', caseSensitive: false).firstMatch(text);
      if (m != null) return m.group(1)!.toUpperCase();
      // 2) 整段 = 裸 P1234567890
      m = RegExp(r'^(P[A-Za-z0-9]{10})$', caseSensitive: false).firstMatch(text);
      if (m != null) return m.group(1)!.toUpperCase();
      // 3) 分享链接 ?puid=P1234567890 或 &puid=
      m = RegExp(r'[?&]puid=(P[A-Za-z0-9]{10})', caseSensitive: false).firstMatch(text);
      if (m != null) return m.group(1)!.toUpperCase();
      return null;
    } catch (_) {
      return null;
    }
  }

  Future<void> _init() async {
    // 并行加载站点配置与登录态
    await Future.wait([
      context.read<SiteConfig>().load(),
      context.read<AuthState>().init(),
      context.read<ThemeState>().init(),
    ]);
    if (!mounted) return;
    // 不强制登录：未登录也可直接浏览论坛首页
    final nav = navigatorKey.currentState;
    // 深链仅在 Web 从 URL 读取；移动/桌面从剪贴板读取
    String? puid;
    if (kIsWeb) {
      puid = Uri.base.queryParameters['puid'];
    }
    if (puid == null) {
      puid = await _clipboardPuid();
    }
    nav?.pushReplacement(MaterialPageRoute(builder: (_) => const HomeScreen()));
    final code = puid;
    if (code != null && code.isNotEmpty) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        final n = navigatorKey.currentState;
        if (n != null) {
          n.push(MaterialPageRoute(builder: (_) => PuidPostScreen(puid: code)));
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(child: CircularProgressIndicator()),
    );
  }
}
