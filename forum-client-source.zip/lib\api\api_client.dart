import 'dart:convert';
import 'dart:math';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ApiClient {
  /// 编译期用 --dart-define=API_BASE_URL=https://你的api域名 指定；
  /// 运行期可在"关于 → API 服务器"中修改（保存到本地，切换后需重新登录）。
  static String baseUrl = const String.fromEnvironment(
      'API_BASE_URL', defaultValue: 'https://forumapi.starxx.cn');
  static String? _token;

  static Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();
    _token = prefs.getString('token');
    final saved = prefs.getString('api_base_url');
    if (saved != null && saved.isNotEmpty) {
      baseUrl = saved;
    }
  }

  /// 运行时切换 API 服务器地址。
  static Future<void> setBaseUrl(String url) async {
    String u = url.trim();
    if (!u.startsWith('http://') && !u.startsWith('https://')) {
      u = 'https://$u';
    }
    u = u.replaceAll(RegExp(r'/+$'), '');
    baseUrl = u;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('api_base_url', u);
  }

  static String? get token => _token;
  static String resourceUrl(String? path) {
    if (path == null || path.isEmpty) return '';
    if (path.startsWith('http://') || path.startsWith('https://')) return path;
    if (RegExp(r'^[a-zA-Z0-9]{12}$').hasMatch(path)) return '$baseUrl/media/$path';
    return '$baseUrl${path.startsWith('/') ? path : '/$path'}';
  }

  static Future<void> setToken(String? token) async {
    _token = token;
    final prefs = await SharedPreferences.getInstance();
    if (token == null) {
      await prefs.remove('token');
    } else {
      await prefs.setString('token', token);
    }
  }

  static Map<String, String> _headers({bool json = true}) {
    final h = <String, String>{};
    if (json) h['Content-Type'] = 'application/json';
    if (_token != null) h['Authorization'] = 'Bearer $_token';
    return h;
  }

  static Uri _uri(String path, [Map<String, String>? query]) {
    final base = Uri.parse(baseUrl);
    final parsed = Uri.parse(path);
    final uri = parsed.hasScheme ? parsed : base.resolve(path);
    if (query == null || query.isEmpty) return uri;
    return uri.replace(queryParameters: {
      ...uri.queryParameters,
      ...query,
    });
  }

  static Future<Map<String, dynamic>> get(String path,
      {Map<String, String>? query}) async {
    final resp = await http.get(_uri(path, query), headers: _headers(json: false));
    return _decode(resp);
  }

  static Future<Map<String, dynamic>> post(String path,
      {Object? body, Map<String, String>? extraHeaders, Map<String, String>? query}) async {
    final headers = _headers()..addAll(extraHeaders ?? const {});
    final resp = await http.post(_uri(path, query),
        headers: headers,
        body: body == null ? null : jsonEncode(body));
    return _decode(resp);
  }

  static Future<Map<String, dynamic>> upload(String path, List<int> bytes, String filename,
      {String type = 'image', void Function(double)? onProgress}) async {
    final req = _ProgressMultipartRequest('POST', _uri(path, {'type': type}), onProgress: onProgress);
    if (_token != null) req.headers['Authorization'] = 'Bearer $_token';
    req.files.add(http.MultipartFile.fromBytes('file', bytes, filename: filename));
    final streamed = await req.send();
    final resp = await http.Response.fromStream(streamed);
    return _decode(resp);
  }

  /// 大文件分片上传：每个分片得到服务端确认后才推进进度。
  static Future<Map<String, dynamic>> uploadLarge(String path, List<int> bytes, String filename,
      {String type = 'image', void Function(double)? onProgress, int chunkSize = 2 * 1024 * 1024}) async {
    final uploadId = '${DateTime.now().microsecondsSinceEpoch}_${Random().nextInt(1 << 30)}';
    final total = (bytes.length / chunkSize).ceil().clamp(1, 5000);
    for (int index = 0; index < total; index++) {
      final start = index * chunkSize;
      final end = min(start + chunkSize, bytes.length);
      final req = http.MultipartRequest('POST', _uri('/api/files/media/chunk', {
        'uploadId': uploadId,
        'index': '$index',
        'total': '$total',
      }));
      if (_token != null) req.headers['Authorization'] = 'Bearer $_token';
      req.files.add(http.MultipartFile.fromBytes('file', bytes.sublist(start, end), filename: filename));
      final response = await http.Response.fromStream(await req.send());
      _decode(response);
      onProgress?.call((index + 1) / (total + 1));
    }
    final d = await post('/api/files/media/chunk/complete', query: {
      'uploadId': uploadId,
      'total': '$total',
      'filename': filename,
      'type': type,
    });
    onProgress?.call(1.0);
    return d;
  }

  static Future<Map<String, dynamic>> put(String path,
      {Object? body}) async {
    final resp = await http.put(_uri(path),
        headers: _headers(), body: body == null ? null : jsonEncode(body));
    return _decode(resp);
  }

  static Future<Map<String, dynamic>> patch(String path,
      {Object? body}) async {
    final resp = await http.patch(_uri(path),
        headers: _headers(), body: body == null ? null : jsonEncode(body));
    return _decode(resp);
  }

  static Future<Map<String, dynamic>> delete(String path) async {
    final resp = await http.delete(_uri(path), headers: _headers(json: false));
    return _decode(resp);
  }

  static Map<String, dynamic> _decode(http.Response resp) {
    final String body = utf8.decode(resp.bodyBytes);
    Map<String, dynamic> json;
    try {
      json = jsonDecode(body) as Map<String, dynamic>;
    } catch (_) {
      throw ApiException('响应解析失败 (HTTP ${resp.statusCode})');
    }
    if (json['success'] == false) {
      throw ApiException(json['message']?.toString() ?? '请求失败');
    }
    return json;
  }
}

class ApiException implements Exception {
  final String message;
  ApiException(this.message);
  @override
  String toString() => message;
}

/// 上传进度包装：覆写 finalize()，在客户端实际写出请求体时按字节汇报进度。
class _ProgressMultipartRequest extends http.MultipartRequest {
  final void Function(double)? onProgress;

  _ProgressMultipartRequest(super.method, super.url, {this.onProgress});

  @override
  http.ByteStream finalize() {
    final inner = super.finalize();
    final total = contentLength ?? 0;
    var sent = 0;
    // 进度封顶 95%，最后 5% 留给服务端处理与响应，避免"刚到 100% 其实还在上传"
    final counted = inner.map((chunk) {
      sent += chunk.length;
      final p = total == 0 ? 0.95 : (sent / total).clamp(0.0, 0.95);
      onProgress?.call(p);
      return chunk;
    });
    return http.ByteStream(counted);
  }
}
