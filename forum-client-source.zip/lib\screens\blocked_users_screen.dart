import 'package:flutter/material.dart';
import '../api/api_client.dart';
import '../models/models.dart';
import 'user_home_screen.dart';

/// 我的黑名单管理
class BlockedUsersScreen extends StatefulWidget {
  final int userId;
  const BlockedUsersScreen({super.key, required this.userId});

  @override
  State<BlockedUsersScreen> createState() => _BlockedUsersScreenState();
}

class _BlockedUsersScreenState extends State<BlockedUsersScreen> {
  List<Author> _users = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final d = await ApiClient.get('/api/users/${widget.userId}/blocks', query: {'size': '100'});
      final items = ((d['data'] as Map<String, dynamic>)['items'] as List)
          .map((e) => Author.fromJson(e as Map<String, dynamic>))
          .toList();
      setState(() {
        _users = items;
        _loading = false;
      });
    } catch (_) {
      setState(() => _loading = false);
    }
  }

  Future<void> _unblock(int id) async {
    try {
      await ApiClient.post('/api/users/$id/block');
      await _load();
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('操作失败')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('黑名单')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _users.isEmpty
              ? const Center(child: Text('暂无拉黑用户'))
              : ListView.builder(
                  itemCount: _users.length,
                  itemBuilder: (_, i) {
                    final u = _users[i];
                    return ListTile(
                      leading: CircleAvatar(
                        backgroundImage: u.avatarUrl != null && u.avatarUrl!.isNotEmpty
                            ? NetworkImage(ApiClient.resourceUrl(u.avatarUrl))
                            : null,
                        child: u.avatarUrl == null || u.avatarUrl!.isEmpty
                            ? Text(u.displayName.characters.first)
                            : null,
                      ),
                      title: Text(u.displayName),
                      subtitle: Text('@${u.username}'),
                      trailing: TextButton(
                        onPressed: () => _unblock(u.id),
                        child: const Text('解除拉黑'),
                      ),
                      onTap: () => Navigator.of(context).push(
                          MaterialPageRoute(builder: (_) => UserHomeScreen(userId: u.id))),
                    );
                  },
                ),
    );
  }
}
