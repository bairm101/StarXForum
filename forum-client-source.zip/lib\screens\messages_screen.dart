import 'dart:io';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

import '../api/api_client.dart';
import '../models/models.dart';
import '../auth/auth_state.dart';
import 'common.dart';
import 'notifications_screen.dart';
import 'user_home_screen.dart';

import 'package:image_picker/image_picker.dart';

class MessagesScreen extends StatefulWidget {
  const MessagesScreen({super.key});

  @override
  State<MessagesScreen> createState() => _MessagesScreenState();
}

class _MessagesScreenState extends State<MessagesScreen> {
  List<Conversation> _conversations = [];
  bool _loading = true;
  int _notifUnread = 0;
  bool _unreadOnly = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  List<Conversation> get _visible => _unreadOnly
      ? _conversations.where((c) => c.unreadCount > 0).toList()
      : _conversations;

  Future<void> _load() async {
    final auth = context.read<AuthState>();
    if (!auth.isLoggedIn) {
      setState(() => _loading = false);
      return;
    }
    try {
      final d = await ApiClient.get('/api/messages/conversations');
      final list = (d['data'] as List)
          .map((e) => Conversation.fromJson(e as Map<String, dynamic>))
          .toList();
      var nu = 0;
      try {
        final u = await ApiClient.get('/api/notifications/unread');
        nu = ((u['data'] as Map<String, dynamic>)['unread'] as int?) ?? 0;
      } catch (_) {}
      if (!mounted) return;
      setState(() {
        _conversations = list;
        _notifUnread = nu;
        _loading = false;
      });
    } catch (e) {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _markAllRead() async {
    try {
      await ApiClient.post('/api/messages/read-all');
      await _load();
    } catch (_) {}
  }

  Future<void> _deleteConversation(Conversation c) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('删除会话'),
        content: Text('删除与 ${c.peer.displayName} 的会话记录？'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('取消'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            style: FilledButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('删除'),
          ),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await ApiClient.delete('/api/messages/with/${c.peer.id}');
      await _load();
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final loggedIn = context.watch<AuthState>().isLoggedIn;
    return Scaffold(
      appBar: AppBar(
        title: const Text('私信'),
        actions: [
          IconButton(
            icon: Icon(
              _unreadOnly
                  ? Icons.mark_email_read
                  : Icons.mark_email_unread_outlined,
              color: _unreadOnly ? Colors.indigo : null,
            ),
            tooltip: _unreadOnly ? '查看全部' : '只看未读',
            onPressed: () => setState(() => _unreadOnly = !_unreadOnly),
          ),
          IconButton(
            icon: const Icon(Icons.done_all),
            tooltip: '全部已读',
            onPressed: _markAllRead,
          ),
        ],
      ),
      body: !loggedIn
          ? const LoginPrompt(text: '登录后可查看私信')
          : _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView.separated(
                itemCount: _visible.length + 1,
                separatorBuilder: (_, __) => const Divider(height: 1),
                itemBuilder: (_, i) {
                  if (i == 0) {
                    // 系统通知固定在私信最上面
                    return ListTile(
                      leading: const CircleAvatar(
                        backgroundColor: Colors.indigo,
                        child: Icon(
                          Icons.campaign_outlined,
                          color: Colors.white,
                        ),
                      ),
                      title: const Text('系统通知'),
                      subtitle: const Text('公告、被回复、被点赞、举报处理等'),
                      trailing: _notifUnread > 0
                          ? Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 8,
                                vertical: 2,
                              ),
                              decoration: BoxDecoration(
                                color: Colors.red,
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Text(
                                '$_notifUnread',
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 12,
                                ),
                              ),
                            )
                          : const Icon(Icons.chevron_right, color: Colors.grey),
                      onTap: () async {
                        await Navigator.of(context).push(
                          MaterialPageRoute(
                            builder: (_) => const NotificationsScreen(),
                          ),
                        );
                        _load();
                      },
                    );
                  }
                  final c = _visible[i - 1];
                  return ListTile(
                    leading: CircleAvatar(
                      backgroundImage: c.peer.avatarUrl != null && c.peer.avatarUrl!.isNotEmpty
                          ? NetworkImage(ApiClient.resourceUrl(c.peer.avatarUrl))
                          : null,
                      child: c.peer.avatarUrl == null || c.peer.avatarUrl!.isEmpty
                          ? Text(c.peer.displayName.characters.first)
                          : null,
                    ),
                    title: Text(c.peer.displayName),
                    subtitle: Text(
                      c.lastContent,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    trailing: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        if (c.unreadCount > 0)
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8,
                              vertical: 2,
                            ),
                            decoration: BoxDecoration(
                              color: Colors.red,
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Text(
                              '${c.unreadCount}',
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 12,
                              ),
                            ),
                          ),
                        const SizedBox(height: 4),
                        Text(
                          DateFormat('MM-dd').format(c.lastAt),
                          style: TextStyle(
                            fontSize: 11,
                            color: Colors.grey[500],
                          ),
                        ),
                      ],
                    ),
                    onTap: () => Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) => ChatScreen(peer: c.peer),
                      ),
                    ),
                    onLongPress: () => _deleteConversation(c),
                  );
                },
              ),
            ),
    );
  }
}

class ChatScreen extends StatefulWidget {
  final Author peer;
  const ChatScreen({super.key, required this.peer});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _ctrl = TextEditingController();
  List<Message> _messages = [];
  bool _loading = true;
  double? _uploadProgress;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final d = await ApiClient.get(
        '/api/messages/with/${widget.peer.id}',
        query: {'size': '50'},
      );
      final items = ((d['data'] as Map<String, dynamic>)['items'] as List)
          .map((e) => Message.fromJson(e as Map<String, dynamic>))
          .toList()
          .reversed
          .toList();
      setState(() {
        _messages = items;
        _loading = false;
      });
    } catch (e) {
      setState(() => _loading = false);
    }
  }

  Future<void> _send() async {
    final content = _ctrl.text.trim();
    if (content.isEmpty) return;
    try {
      await ApiClient.post(
        '/api/messages',
        body: {'recipientId': widget.peer.id, 'content': content},
      );
      _ctrl.clear();
      await _load();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('发送失败')));
    }
  }

  Future<void> _sendImage() async {
    try {
      final x = await ImagePicker().pickImage(source: ImageSource.gallery);
      if (x == null) return;
      setState(() => _uploadProgress = 0);
      final d = await ApiClient.upload(
        '/api/files/media',
        await x.readAsBytes(),
        x.name,
        type: 'image',
        onProgress: (p) {
          if (mounted) setState(() => _uploadProgress = p);
        },
      );
      final url = ((d['data'] as Map<String, dynamic>)['url']).toString();
      await ApiClient.post(
        '/api/messages',
        body: {'recipientId': widget.peer.id, 'content': '![图片]($url)'},
      );
      await _load();
    } on ApiException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(e.message)));
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('图片发送失败')));
    } finally {
      if (mounted) setState(() => _uploadProgress = null);
    }
  }

  Widget _buildBubble(Message m) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 4),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      constraints: BoxConstraints(
        maxWidth: MediaQuery.of(context).size.width * 0.62,
      ),
      decoration: BoxDecoration(
        color: m.mine ? Colors.indigo : Colors.grey[300],
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _messageContent(m),
          const SizedBox(height: 2),
          Text(
            DateFormat('HH:mm').format(m.createdAt),
            style: TextStyle(
              fontSize: 10,
              color: m.mine ? Colors.white70 : Colors.grey[600],
            ),
          ),
        ],
      ),
    );
  }

  /// 举报私信：填写理由 + 勾选聊天记录作为证据 + 上传截图（≤9 张，每张 ≤5MB）
  Future<void> _reportChat() async {
    final ok = await ensureLoggedIn(context);
    if (!ok) return;
    if (!mounted) return;

    final reasonCtrl = TextEditingController();
    final selected = <int>{};
    final picked = <XFile>[];
    bool submitting = false;

    final submitted = await showDialog<bool>(
      context: context,
      builder: (dialogCtx) => StatefulBuilder(
        builder: (dialogCtx, setDlg) {
          Future<void> addImages() async {
            final xfiles = await ImagePicker().pickMultiImage();
            if (xfiles.isEmpty) return;
            for (final x in xfiles) {
              if (picked.length >= 9) {
                if (dialogCtx.mounted) {
                  ScaffoldMessenger.of(dialogCtx)
                      .showSnackBar(const SnackBar(content: Text('截图最多 9 张')));
                }
                break;
              }
              final len = File(x.path).lengthSync();
              if (len > 5 * 1024 * 1024) {
                if (dialogCtx.mounted) {
                  ScaffoldMessenger.of(dialogCtx).showSnackBar(
                    SnackBar(content: Text('${x.name} 超过 5MB，已跳过')),
                  );
                }
                continue;
              }
              picked.add(x);
            }
            setDlg(() {});
          }

          Future<void> submit() async {
            if (submitting) return;
            if (reasonCtrl.text.trim().isEmpty &&
                selected.isEmpty &&
                picked.isEmpty) {
              ScaffoldMessenger.of(dialogCtx)
                  .showSnackBar(const SnackBar(content: Text('请填写理由或选择证据')));
              return;
            }
            setDlg(() => submitting = true);
            try {
              // 先上传截图
              final codes = <String>[];
              for (final x in picked) {
                final d = await ApiClient.upload(
                  '/api/files/media',
                  await x.readAsBytes(),
                  x.name,
                  type: 'image',
                );
                codes.add(
                  ((d['data'] as Map<String, dynamic>)['url']) as String,
                );
              }
              await ApiClient.post(
                '/api/messages/report',
                body: {
                  'peerId': widget.peer.id,
                  'reason': reasonCtrl.text.trim(),
                  'messageIds': selected.toList(),
                  'images': codes,
                },
              );
              if (dialogCtx.mounted) Navigator.pop(dialogCtx, true);
            } on ApiException catch (e) {
              setDlg(() => submitting = false);
              ScaffoldMessenger.of(dialogCtx)
                  .showSnackBar(SnackBar(content: Text(e.message)));
            } catch (e) {
              setDlg(() => submitting = false);
              ScaffoldMessenger.of(dialogCtx)
                  .showSnackBar(const SnackBar(content: Text('提交失败')));
            }
          }

          return AlertDialog(
            title: const Text('举报该用户'),
            content: SizedBox(
              width: double.maxFinite,
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    TextField(
                      controller: reasonCtrl,
                      maxLines: 2,
                      decoration: const InputDecoration(
                        labelText: '举报理由',
                        hintText: '描述违规行为',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        OutlinedButton.icon(
                          onPressed: () {
                            setDlg(() => selected.clear());
                            showModalBottomSheet(
                              context: dialogCtx,
                              builder: (_) => SafeArea(
                                child: ListView.builder(
                                  itemCount: _messages.length,
                                  itemBuilder: (_, i) {
                                    final m = _messages[i];
                                    final checked = selected.contains(m.id);
                                    return CheckboxListTile(
                                      dense: true,
                                      value: checked,
                                      title: Text(
                                        '${m.mine ? "我" : widget.peer.displayName}: '
                                        '${m.content.replaceAll(RegExp(r"!\[[^\]]*\]\([^)]+\)"), "[图片]").trim()}',
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                      onChanged: (v) {
                                        setDlg(
                                          () => v == true
                                              ? selected.add(m.id)
                                              : selected.remove(m.id),
                                        );
                                      },
                                    );
                                  },
                                ),
                              ),
                            );
                          },
                          icon: const Icon(Icons.fact_check_outlined, size: 18),
                          label: Text('选择聊天记录 (${selected.length})'),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 6,
                      runSpacing: 6,
                      children: [
                        for (final x in picked)
                          Stack(
                            children: [
                              ClipRRect(
                                borderRadius: BorderRadius.circular(6),
                                child: Image.file(
                                  File(x.path),
                                  width: 56,
                                  height: 56,
                                  fit: BoxFit.cover,
                                ),
                              ),
                              Positioned(
                                right: 0,
                                top: 0,
                                child: GestureDetector(
                                  onTap: () => setDlg(() => picked.remove(x)),
                                  child: Container(
                                    decoration: const BoxDecoration(
                                      color: Colors.black54,
                                      shape: BoxShape.circle,
                                    ),
                                    child: const Icon(
                                      Icons.close,
                                      size: 14,
                                      color: Colors.white,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        if (picked.length < 9)
                          GestureDetector(
                            onTap: addImages,
                            child: Container(
                              width: 56,
                              height: 56,
                              decoration: BoxDecoration(
                                border: Border.all(color: Colors.grey),
                                borderRadius: BorderRadius.circular(6),
                              ),
                              child: const Icon(
                                Icons.add_photo_alternate_outlined,
                              ),
                            ),
                          ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '截图最多 9 张，每张不超过 5MB',
                      style: TextStyle(fontSize: 11, color: Colors.grey[600]),
                    ),
                  ],
                ),
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(dialogCtx, false),
                child: const Text('取消'),
              ),
              FilledButton(
                onPressed: submitting ? null : submit,
                child: Text(submitting ? '提交中...' : '提交举报'),
              ),
            ],
          );
        },
      ),
    );

    if (submitted == true && mounted) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('举报已提交')));
    }
  }

  Widget _messageContent(Message m) {
    final img = RegExp(r'!\[[^\]]*\]\(([^)]+)\)').firstMatch(m.content);
    if (img == null) return Text(m.content);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxHeight: 220),
            child: Image.network(
              ApiClient.resourceUrl(img.group(1)),
              fit: BoxFit.cover,
              width: 180,
              errorBuilder: (_, __, ___) => const Text('[图片]'),
            ),
          ),
        ),
        if (m.content != img.group(0))
          Padding(
            padding: const EdgeInsets.only(top: 4),
            child: Text(m.content.replaceFirst(img.group(0)!, '').trim()),
          ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthState>();
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.peer.displayName),
        actions: [
          IconButton(
            icon: const Icon(Icons.report_outlined),
            tooltip: '举报',
            onPressed: _reportChat,
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : ListView.builder(
                    itemCount: _messages.length,
                    itemBuilder: (_, i) {
                      final m = _messages[i];
                      return Padding(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 4,
                        ),
                        child: Row(
                          mainAxisAlignment: m.mine
                              ? MainAxisAlignment.end
                              : MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            if (!m.mine)
                              GestureDetector(
                                onTap: () => Navigator.of(context).push(
                                  MaterialPageRoute(
                                    builder: (_) =>
                                        UserHomeScreen(userId: widget.peer.id),
                                  ),
                                ),
                                child: CircleAvatar(
                                  radius: 16,
                                  backgroundImage:
                                      widget.peer.avatarUrl != null &&
                                          widget.peer.avatarUrl!.isNotEmpty
                                      ? NetworkImage(
                                          ApiClient.resourceUrl(
                                            widget.peer.avatarUrl,
                                          ),
                                        )
                                      : null,
                                  child:
                                      widget.peer.avatarUrl == null ||
                                          widget.peer.avatarUrl!.isEmpty
                                      ? Text(
                                          widget
                                              .peer
                                              .displayName
                                              .characters
                                              .first,
                                        )
                                      : null,
                                ),
                              ),
                            if (!m.mine) const SizedBox(width: 6),
                            Flexible(child: _buildBubble(m)),
                            if (m.mine) const SizedBox(width: 6),
                            if (m.mine)
                              GestureDetector(
                                onTap: auth.userId == null
                                    ? null
                                    : () => Navigator.of(context).push(
                                        MaterialPageRoute(
                                          builder: (_) => UserHomeScreen(
                                            userId: auth.userId!,
                                          ),
                                        ),
                                      ),
                                child: CircleAvatar(
                                  radius: 16,
                                  backgroundImage:
                                      auth.avatarUrl != null &&
                                          auth.avatarUrl!.isNotEmpty
                                      ? NetworkImage(
                                          ApiClient.resourceUrl(auth.avatarUrl),
                                        )
                                      : null,
                                  child:
                                      auth.avatarUrl == null ||
                                          auth.avatarUrl!.isEmpty
                                      ? Text(
                                          (auth.displayName ?? '我')
                                              .characters
                                              .first,
                                        )
                                      : null,
                                ),
                              ),
                          ],
                        ),
                      );
                    },
                  ),
          ),
          if (_uploadProgress != null)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Row(
                children: [
                  Expanded(
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(4),
                      child: LinearProgressIndicator(
                        value: _uploadProgress,
                        minHeight: 4,
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    '${(_uploadProgress! * 100).round()}%',
                    style: const TextStyle(fontSize: 11),
                  ),
                ],
              ),
            ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(8),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _ctrl,
                      decoration: InputDecoration(
                        hintText: '发消息...',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(24),
                        ),
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 8,
                        ),
                      ),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.image_outlined),
                    tooltip: '发送图片',
                    onPressed: _sendImage,
                  ),
                  IconButton(icon: const Icon(Icons.send), onPressed: _send),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
