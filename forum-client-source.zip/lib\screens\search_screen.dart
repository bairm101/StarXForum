import 'package:flutter/material.dart';
import '../api/api_client.dart';
import '../models/models.dart';
import 'post_detail_screen.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final _ctrl = TextEditingController();
  List<PostSummary> _results = [];
  bool _searched = false;
  bool _loading = false;

  Future<void> _search() async {
    final q = _ctrl.text.trim();
    if (q.isEmpty) return;
    // 输入完整 PUID（可带 PUID: 前缀）时直接跳转对应帖子
    final puidMatch =
        RegExp(r'^(?:PUID:)?\s*(P[A-Za-z0-9]{10})$', caseSensitive: false).firstMatch(q);
    if (puidMatch != null) {
      Navigator.of(context).push(MaterialPageRoute(
          builder: (_) => PuidPostScreen(puid: puidMatch.group(1)!.toUpperCase())));
      return;
    }
    setState(() => _loading = true);
    try {
      final d = await ApiClient.get('/api/search', query: {'q': q, 'size': '50'});
      final items = ((d['data'] as Map<String, dynamic>)['items'] as List)
          .map((e) => PostSummary.fromJson(e as Map<String, dynamic>))
          .toList();
      setState(() {
        _results = items;
        _searched = true;
        _loading = false;
      });
    } catch (e) {
      setState(() => _loading = false);
      _toast('搜索失败');
    }
  }

  void _toast(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: TextField(
          controller: _ctrl,
          decoration: const InputDecoration(
            hintText: '搜索帖子标题和内容...',
            border: InputBorder.none,
          ),
          onSubmitted: (_) => _search(),
        ),
        actions: [
          IconButton(icon: const Icon(Icons.search), onPressed: _search),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : !_searched
              ? const Center(child: Text('输入关键词搜索'))
              : _results.isEmpty
                  ? const Center(child: Text('没有找到相关帖子'))
                  : ListView.separated(
                      itemCount: _results.length,
                      separatorBuilder: (_, __) => const Divider(height: 1),
                      itemBuilder: (_, i) {
                        final p = _results[i];
                        return ListTile(
                          title: Text(p.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                          subtitle: Text(p.excerpt, maxLines: 1, overflow: TextOverflow.ellipsis),
                          trailing: Text('${p.likeCount} 赞'),
                          onTap: () => Navigator.of(context).push(
                            MaterialPageRoute(
                                builder: (_) => PostDetailScreen(postId: p.id)),
                          ),
                        );
                      },
                    ),
    );
  }
}
