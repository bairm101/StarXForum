import 'package:flutter/material.dart';
import '../api/api_client.dart';
import '../models/models.dart';
import 'post_detail_screen.dart';
import 'user_home_screen.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final _ctrl = TextEditingController();
  /// post / user
  String _mode = 'post';
  List<PostSummary> _posts = [];
  List<Map<String, dynamic>> _users = [];
  bool _searched = false;
  bool _loading = false;

  Future<void> _search() async {
    final q = _ctrl.text.trim();
    if (q.isEmpty) return;
    if (_mode == 'post') {
      // 输入完整 PUID（可带 PUID: 前缀）时直接跳转对应帖子
      final puidMatch =
          RegExp(r'^(?:PUID:)?\s*(P[A-Za-z0-9]{10})$', caseSensitive: false).firstMatch(q);
      if (puidMatch != null) {
        Navigator.of(context).push(MaterialPageRoute(
            builder: (_) => PuidPostScreen(puid: puidMatch.group(1)!.toUpperCase())));
        return;
      }
    }
    setState(() => _loading = true);
    try {
      if (_mode == 'post') {
        final d = await ApiClient.get('/api/search', query: {'q': q, 'size': '50'});
        final items = ((d['data'] as Map<String, dynamic>)['items'] as List)
            .map((e) => PostSummary.fromJson(e as Map<String, dynamic>))
            .toList();
        setState(() {
          _posts = items;
          _searched = true;
          _loading = false;
        });
      } else {
        final d = await ApiClient.get('/api/search/users', query: {'q': q, 'size': '50'});
        final items = ((d['data'] as Map<String, dynamic>)['items'] as List)
            .map((e) => e as Map<String, dynamic>)
            .toList();
        setState(() {
          _users = items;
          _searched = true;
          _loading = false;
        });
      }
    } catch (e) {
      setState(() => _loading = false);
      _toast('搜索失败');
    }
  }

  void _toast(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }

  Widget _buildUserItem(Map<String, dynamic> u) {
    final avatarUrl = u['avatarUrl'] as String?;
    final displayName = (u['displayName'] as String?) ?? (u['username'] as String? ?? '?');
    final title = u['title'] as String?;
    final signature = u['signature'] as String?;
    return ListTile(
      leading: CircleAvatar(
        radius: 20,
        backgroundImage:
            (avatarUrl != null && avatarUrl.isNotEmpty) ? NetworkImage(ApiClient.resourceUrl(avatarUrl)) : null,
        child: (avatarUrl == null || avatarUrl.isEmpty) ? Text(displayName.characters.first) : null,
      ),
      title: Row(
        children: [
          Flexible(child: Text(displayName, maxLines: 1, overflow: TextOverflow.ellipsis)),
          if (title != null && title.isNotEmpty) ...[
            const SizedBox(width: 6),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
              decoration: BoxDecoration(
                color: Colors.amber.shade100,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(title, style: const TextStyle(fontSize: 10, color: Colors.brown)),
            ),
          ],
        ],
      ),
      subtitle: Text(
        '@${u['username'] ?? ''} · ${u['uid'] ?? ''}${(signature != null && signature.isNotEmpty) ? ' · $signature' : ''}',
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
      ),
      onTap: () => Navigator.of(context)
          .push(MaterialPageRoute(builder: (_) => UserHomeScreen(userId: u['id'] as int))),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: TextField(
          controller: _ctrl,
          decoration: InputDecoration(
            hintText: _mode == 'post' ? '搜索帖子标题和内容...' : '搜索用户名 / 昵称 / UID...',
            border: InputBorder.none,
          ),
          onSubmitted: (_) => _search(),
        ),
        actions: [
          IconButton(icon: const Icon(Icons.search), onPressed: _search),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 0, 12, 8),
            child: SegmentedButton<String>(
              segments: const [
                ButtonSegment(value: 'post', label: Text('帖子'), icon: Icon(Icons.article_outlined, size: 18)),
                ButtonSegment(value: 'user', label: Text('用户'), icon: Icon(Icons.person_outline, size: 18)),
              ],
              selected: {_mode},
              onSelectionChanged: (s) {
                setState(() {
                  _mode = s.first;
                  _searched = false;
                });
              },
            ),
          ),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : !_searched
                    ? const Center(child: Text('输入关键词搜索'))
                    : _mode == 'post'
                        ? _posts.isEmpty
                            ? const Center(child: Text('没有找到相关帖子'))
                            : ListView.separated(
                                itemCount: _posts.length,
                                separatorBuilder: (_, __) => const Divider(height: 1),
                                itemBuilder: (_, i) {
                                  final p = _posts[i];
                                  return ListTile(
                                    title: Text(p.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                                    subtitle: Text(p.excerpt, maxLines: 1, overflow: TextOverflow.ellipsis),
                                    trailing: Text('${p.likeCount} 赞'),
                                    onTap: () => Navigator.of(context).push(
                                      MaterialPageRoute(
                                          builder: (_) => PostDetailScreen(postId: p.id)),
                                    ),
                                  );
                                },
                              )
                        : _users.isEmpty
                            ? const Center(child: Text('没有找到相关用户'))
                            : ListView.separated(
                                itemCount: _users.length,
                                separatorBuilder: (_, __) => const Divider(height: 1),
                                itemBuilder: (_, i) => _buildUserItem(_users[i]),
                              ),
          ),
        ],
      ),
    );
  }
}
