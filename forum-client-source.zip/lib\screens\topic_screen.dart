import 'package:flutter/material.dart';
import '../api/api_client.dart';
import '../models/models.dart';
import 'post_detail_screen.dart';
import 'user_home_screen.dart';

/// 按话题浏览帖子
class TopicScreen extends StatefulWidget {
  final String topic;
  const TopicScreen({super.key, required this.topic});

  @override
  State<TopicScreen> createState() => _TopicScreenState();
}

class _TopicScreenState extends State<TopicScreen> {
  List<PostSummary> _posts = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final d = await ApiClient.get('/api/topics/${Uri.encodeComponent(widget.topic)}/posts',
          query: {'size': '50'});
      final items = ((d['data'] as Map<String, dynamic>)['items'] as List)
          .map((e) => PostSummary.fromJson(e as Map<String, dynamic>))
          .toList();
      setState(() {
        _posts = items;
        _loading = false;
      });
    } catch (_) {
      setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('#${widget.topic}')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _posts.isEmpty
              ? const Center(child: Text('该话题下暂无帖子'))
              : RefreshIndicator(
                  onRefresh: _load,
                  child: ListView.separated(
                    itemCount: _posts.length,
                    separatorBuilder: (_, __) => const Divider(height: 1),
                    itemBuilder: (_, i) {
                      final p = _posts[i];
                      return ListTile(
                        leading: p.thumbnailUrl != null && p.thumbnailUrl!.isNotEmpty
                            ? ClipRRect(
                                borderRadius: BorderRadius.circular(6),
                                child: Image.network(ApiClient.resourceUrl(p.thumbnailUrl),
                                    width: 48, height: 48, fit: BoxFit.cover),
                              )
                            : Container(
                                width: 48,
                                height: 48,
                                color: Colors.grey.shade200,
                                child: const Icon(Icons.article_outlined, color: Colors.grey),
                              ),
                        title: Text(p.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                        subtitle: Text(
                          '${p.author.displayName} · ${p.commentCount} 回复 · 👍 ${p.likeCount}',
                          style: const TextStyle(fontSize: 12),
                        ),
                        onTap: () async {
                          await Navigator.of(context).push(
                              MaterialPageRoute(builder: (_) => PostDetailScreen(postId: p.id)));
                          await _load();
                        },
                      );
                    },
                  ),
                ),
    );
  }
}
