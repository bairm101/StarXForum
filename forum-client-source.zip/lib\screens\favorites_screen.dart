import 'package:flutter/material.dart';
import '../api/api_client.dart';
import '../models/models.dart';
import 'post_detail_screen.dart';
import 'user_home_screen.dart';

/// 我的收藏
class FavoritesScreen extends StatefulWidget {
  const FavoritesScreen({super.key});

  @override
  State<FavoritesScreen> createState() => _FavoritesScreenState();
}

class _FavoritesScreenState extends State<FavoritesScreen> {
  List<PostSummary> _posts = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final d = await ApiClient.get('/api/favorites/mine', query: {'size': '100'});
      final items = ((d['data'] as Map<String, dynamic>)['items'] as List)
          .where((e) => e != null)
          .map((e) => PostSummary.fromJson(e as Map<String, dynamic>))
          .toList();
      setState(() {
        _posts = items;
        _loading = false;
      });
    } catch (_) {
      setState(() => _loading = false);
    }
  }

  void _toast(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('我的收藏')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: _posts.isEmpty
                  ? ListView(children: const [
                      SizedBox(height: 200),
                      Center(child: Text('还没有收藏任何帖子'))
                    ])
                  : ListView.builder(
                      itemCount: _posts.length,
                      itemBuilder: (_, i) => _buildItem(_posts[i]),
                    ),
            ),
    );
  }

  Widget _buildItem(PostSummary p) {
    return ListTile(
      leading: p.thumbnailUrl != null && p.thumbnailUrl!.isNotEmpty
          ? ClipRRect(
              borderRadius: BorderRadius.circular(6),
              child: Image.network(ApiClient.resourceUrl(p.thumbnailUrl),
                  width: 56, height: 56, fit: BoxFit.cover),
            )
          : Container(
              width: 56,
              height: 56,
              color: Colors.grey.shade200,
              child: const Icon(Icons.article_outlined, color: Colors.grey),
            ),
      title: Text(p.title, maxLines: 1, overflow: TextOverflow.ellipsis),
      subtitle: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => UserHomeScreen(userId: p.author.id))),
            child: Text(p.author.displayName, style: TextStyle(fontSize: 12, color: Colors.indigo.shade400)),
          ),
          const SizedBox(width: 8),
          Text('${p.boardName} · ${p.commentCount} 回复',
              style: TextStyle(fontSize: 12, color: Colors.grey[500])),
        ],
      ),
      trailing: IconButton(
        icon: const Icon(Icons.bookmark_remove_outlined),
        tooltip: '取消收藏',
        onPressed: () async {
          try {
            await ApiClient.post('/api/favorites/toggle/${p.id}');
            _toast('已取消收藏');
            await _load();
          } catch (_) {
            _toast('操作失败');
          }
        },
      ),
      onTap: () async {
        await Navigator.of(context).push(
            MaterialPageRoute(builder: (_) => PostDetailScreen(postId: p.id)));
        await _load();
      },
    );
  }
}
