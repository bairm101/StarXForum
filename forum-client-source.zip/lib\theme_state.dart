import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ThemeState extends ChangeNotifier {
  ThemeMode mode = ThemeMode.system;
  Future<void> init() async {
    final p = await SharedPreferences.getInstance();
    mode = switch (p.getString('theme')) { 'dark' => ThemeMode.dark, 'light' => ThemeMode.light, _ => ThemeMode.system };
    notifyListeners();
  }
  Future<void> set(ThemeMode value) async {
    mode = value; notifyListeners();
    final p = await SharedPreferences.getInstance();
    await p.setString('theme', value == ThemeMode.dark ? 'dark' : value == ThemeMode.light ? 'light' : 'system');
  }
}
