import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';

import '../api/api_client.dart';
import '../models/models.dart';
import 'common.dart';

import 'package:provider/provider.dart';

import '../auth/auth_state.dart';
import '../site_config.dart';
import 'media_widgets.dart';
import 'user_home_screen.dart';
import 'topic_screen.dart';
import 'mention_text.dart';

class PostDetailScreen extends StatefulWidget {
  final int postId;

  /// 打开后滚动并高亮指定评论（用于举报跳转等）
  final int? highlightCommentId;
  const PostDetailScreen({
    super.key,
    required this.postId,
    this.highlightCommentId,
  });

  @override
  State<PostDetailScreen> createState() => _PostDetailScreenState();
}

class _PostDetailScreenState extends State<PostDetailScreen>
    with SingleTickerProviderStateMixin {
  PostDetail? _post;
  List<Comment> _comments = [];
  bool _loading = true;
  final _commentCtrl = TextEditingController();
  final _commentFocus = FocusNode();
  final _scrollCtrl = ScrollController();
  final _highlightKey = GlobalKey();
  late final AnimationController _pressAnim;
  int? _pressedCommentId;
  int? _replyToId;
  String? _replyToName;
  bool _replyIsChild = false;
  String? _replyTargetUsername;
  bool _favorited = false;
  bool _onlyAuthor = false;
  bool _hotComments = false;
  Map<String, dynamic>? _poll;

  @override
  void initState() {
    super.initState();
    _pressAnim =
        AnimationController(
          vsync: this,
          duration: const Duration(milliseconds: 260),
        )..addListener(() {
          if (mounted) setState(() {});
        });
    _load();
  }

  @override
  void dispose() {
    _commentCtrl.dispose();
    _commentFocus.dispose();
    _scrollCtrl.dispose();
    _pressAnim.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final d = await ApiClient.get('/api/posts/${widget.postId}');
      final post = PostDetail.fromJson(d['data'] as Map<String, dynamic>);
      final cd = await ApiClient.get(
        '/api/posts/${widget.postId}/comments',
        query: {
          'page': '0',
          'size': '100',
          'sort': _hotComments ? 'hot' : 'latest',
        },
      );
      final comments = ((cd['data'] as Map<String, dynamic>)['items'] as List)
          .map((e) => Comment.fromJson(e as Map<String, dynamic>))
          .toList();
      Map<String, dynamic>? poll;
      try {
        final pd = await ApiClient.get('/api/posts/${widget.postId}/poll');
        poll = pd['data'] as Map<String, dynamic>?;
      } catch (_) {}
      var favorited = false;
      if (context.read<AuthState>().isLoggedIn) {
        try {
          final fd = await ApiClient.get(
            '/api/favorites/check/${widget.postId}',
          );
          favorited = (fd['data'] as bool?) ?? false;
        } catch (_) {}
      }
      if (!mounted) return;
      setState(() {
        _post = post;
        _comments = comments;
        _poll = poll;
        _favorited = favorited;
        _loading = false;
      });
      if (widget.highlightCommentId != null) {
        WidgetsBinding.instance.addPostFrameCallback(
          (_) => _scrollToHighlight(),
        );
      }
    } catch (e) {
      if (!mounted) return;
      setState(() => _loading = false);
      _toast('加载失败');
    }
  }

  void _scrollToHighlight() {
    if (!mounted) return;
    final ctx = _highlightKey.currentContext;
    if (ctx == null) return;
    Scrollable.ensureVisible(
      ctx,
      duration: const Duration(milliseconds: 400),
      alignment: 0.15,
    );
  }

  PostDetail _copyPost({
    int? likeCount,
    int? dislikeCount,
    bool? likedByMe,
    bool? dislikedByMe,
  }) {
    return PostDetail(
      id: _post!.id,
      title: _post!.title,
      content: _post!.content,
      boardId: _post!.boardId,
      boardName: _post!.boardName,
      author: _post!.author,
      viewCount: _post!.viewCount,
      commentCount: _post!.commentCount,
      likeCount: likeCount ?? _post!.likeCount,
      dislikeCount: dislikeCount ?? _post!.dislikeCount,
      pinned: _post!.pinned,
      locked: _post!.locked,
      likedByMe: likedByMe ?? _post!.likedByMe,
      dislikedByMe: dislikedByMe ?? _post!.dislikedByMe,
      canEdit: _post!.canEdit,
      totalTipGold: _post!.totalTipGold,
      tipCount: _post!.tipCount,
      myTipTimes: _post!.myTipTimes,
      status: _post!.status,
      thumbnailUrl: _post!.thumbnailUrl,
      topics: _post!.topics,
      gateType: _post!.gateType,
      gateUnlocked: _post!.gateUnlocked,
      gatePrice: _post!.gatePrice,
      gatedContent: _post!.gatedContent,
      createdAt: _post!.createdAt,
    );
  }

  Future<void> _toggleFavorite() async {
    final ok = await ensureLoggedIn(context);
    if (!ok) return;
    final nowFav = !_favorited;
    setState(() => _favorited = nowFav); // 乐观更新
    try {
      await ApiClient.post('/api/favorites/toggle/${widget.postId}');
    } catch (e) {
      setState(() => _favorited = !nowFav);
      _toast('操作失败');
    }
  }

  Future<void> _toggleDislike() async {
    final ok = await ensureLoggedIn(context);
    if (!ok) return;
    final nowDisliked = !_post!.dislikedByMe;
    // 乐观更新（点赞/点踩互斥）
    setState(() {
      _post = _copyPost(
        dislikedByMe: nowDisliked,
        dislikeCount: _post!.dislikeCount + (nowDisliked ? 1 : -1),
        likedByMe: nowDisliked ? false : _post!.likedByMe,
        likeCount: (nowDisliked && _post!.likedByMe)
            ? _post!.likeCount - 1
            : _post!.likeCount,
      );
    });
    try {
      await ApiClient.post('/api/posts/${widget.postId}/dislike');
    } catch (e) {
      _toast('操作失败');
      await _load();
    }
  }

  Future<void> _reportContent({required bool isPost, int? commentId}) async {
    final ok = await ensureLoggedIn(context);
    if (!ok) return;
    if (!mounted) return;
    final ctrl = TextEditingController();
    final reason = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('举报'),
        content: TextField(
          controller: ctrl,
          maxLines: 3,
          decoration: const InputDecoration(
            labelText: '举报原因',
            hintText: '请填写违规原因，我们会尽快处理',
            border: OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('取消'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, ctrl.text.trim()),
            child: const Text('提交'),
          ),
        ],
      ),
    );
    if (reason == null || reason.isEmpty) return;
    try {
      final path = isPost
          ? '/api/posts/${widget.postId}/report'
          : '/api/comments/$commentId/report';
      await ApiClient.post(path, body: {'reason': reason});
      _toast('举报已提交');
    } on ApiException catch (e) {
      _toast(e.message);
    } catch (_) {
      _toast('提交失败');
    }
  }

  Future<void> _toggleLike() async {
    final ok = await ensureLoggedIn(context);
    if (!ok) return;
    final nowLiked = !_post!.likedByMe;
    // 乐观更新（点赞/点踩互斥）
    setState(() {
      _post = _copyPost(
        likedByMe: nowLiked,
        likeCount: _post!.likeCount + (nowLiked ? 1 : -1),
        dislikedByMe: nowLiked ? false : _post!.dislikedByMe,
        dislikeCount: (nowLiked && _post!.dislikedByMe)
            ? _post!.dislikeCount - 1
            : _post!.dislikeCount,
      );
    });
    try {
      await ApiClient.post('/api/posts/${widget.postId}/like');
    } catch (e) {
      _toast('操作失败');
      await _load();
    }
  }

  /// 点击评论/回复 → 进入回复状态并聚焦输入框
  void _startReply(Comment c) {
    setState(() {
      // Java 服务端只保留两级楼中楼；回复子评论时仍提交顶级评论 ID。
      _replyToId = c.parentId ?? c.id;
      _replyToName = c.author.displayName;
      _replyIsChild = c.parentId != null;
      _replyTargetUsername = c.author.username;
    });
    _commentFocus.requestFocus();
  }

  void _cancelReply() {
    setState(() {
      _replyToId = null;
      _replyToName = null;
      _replyIsChild = false;
      _replyTargetUsername = null;
    });
  }

  Future<void> _submitComment() async {
    final ok = await ensureLoggedIn(context);
    if (!ok) return;
    var content = _commentCtrl.text.trim();
    if (content.isEmpty) return;
    // 回复子评论时自动在内容前加上 @对方用户名
    if (_replyToId != null && _replyIsChild && _replyTargetUsername != null) {
      final at = '@$_replyTargetUsername ';
      if (!content.startsWith(at)) content = at + content;
    }
    try {
      final challenge = await solveChallenge(context, 'COMMENT');
      if (challenge == null) return;
      await ApiClient.post(
        '/api/posts/${widget.postId}/comments',
        body: {'content': content, 'parentId': _replyToId},
        extraHeaders: challenge,
      );
      _commentCtrl.clear();
      _cancelReply();
      _toast('回复成功');
      await _load();
    } catch (e) {
      _toast('回复失败');
    }
  }

  void _toast(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }

  Future<void> _showTipDialog() async {
    final ok = await ensureLoggedIn(context);
    if (!ok) return;
    if (!mounted) return;

    final p = _post!;
    final me = context.read<AuthState>().userId;
    if (me != null && p.author.id == me) {
      _toast('不能打赏自己的帖子');
      return;
    }
    if (p.myTipTimes >= 3) {
      _toast('每人每帖最多打赏 3 次');
      return;
    }

    final controller = TextEditingController(text: '1');
    final amount = await showDialog<int>(
      context: context,
      builder: (_) => AlertDialog(
        title: Row(
          children: [
            Icon(Icons.monetization_on, color: Colors.amber[700]),
            const SizedBox(width: 8),
            const Text('打赏作者'),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('已打赏 ${p.myTipTimes}/3 次'),
            const SizedBox(height: 12),
            TextField(
              controller: controller,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: '金币数量',
                border: OutlineInputBorder(),
                helperText: '每次最多 2 金币，仅限整数（签到可获得金币）',
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('取消'),
          ),
          FilledButton(
            onPressed: () {
              final v = int.tryParse(controller.text.trim());
              Navigator.of(context).pop(v);
            },
            child: const Text('打赏'),
          ),
        ],
      ),
    );

    if (amount == null || amount <= 0) return;
    if (amount > 2) {
      _toast('单次打赏最多 2 金币');
      return;
    }
    await _submitTip(amount);
  }

  Future<void> _submitTip(int amount) async {
    try {
      await ApiClient.post(
        '/api/posts/${widget.postId}/tip',
        body: {'amount': amount},
      );
      _toast('打赏成功');
      await _load();
    } on ApiException catch (e) {
      _toast(e.message);
    } catch (e) {
      _toast('打赏失败');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_post?.title ?? '帖子详情'),
        actions: [
          if (_post != null)
            IconButton(
              icon: Icon(
                Icons.monetization_on_outlined,
                color: Colors.amber[700],
              ),
              tooltip: '打赏',
              onPressed: _showTipDialog,
            ),
          if (_post != null)
            IconButton(
              icon: Icon(
                _post!.likedByMe ? Icons.thumb_up : Icons.thumb_up_outlined,
              ),
              onPressed: _toggleLike,
            ),
          if (_post != null)
            IconButton(
              icon: Icon(
                _post!.dislikedByMe
                    ? Icons.thumb_down
                    : Icons.thumb_down_outlined,
                color: _post!.dislikedByMe ? Colors.red : null,
              ),
              tooltip: '踩',
              onPressed: _toggleDislike,
            ),
          if (_post != null)
            IconButton(
              icon: Icon(
                _favorited ? Icons.bookmark : Icons.bookmark_outline,
                color: _favorited ? Colors.orange : null,
              ),
              tooltip: '收藏',
              onPressed: _toggleFavorite,
            ),
          if (_post != null)
            PopupMenuButton<String>(
              onSelected: _postAction,
              itemBuilder: (_) => [
                if (_post!.canEdit)
                  const PopupMenuItem(value: 'edit', child: Text('编辑帖子')),
                if (_post!.canEdit && _poll == null)
                  const PopupMenuItem(value: 'poll', child: Text('发起投票')),
                if (_post!.canEdit)
                  const PopupMenuItem(value: 'delete', child: Text('删除帖子')),
                const PopupMenuItem(value: 'share', child: Text('分享帖子')),
                const PopupMenuItem(value: 'history', child: Text('查看编辑历史')),
                const PopupMenuItem(value: 'report', child: Text('举报帖子')),
                if (context.read<AuthState>().isStaff) ...[
                  const PopupMenuItem(value: 'pin', child: Text('全站置顶/取消')),
                  const PopupMenuItem(value: 'lock', child: Text('锁定/解锁')),
                  const PopupMenuItem(value: 'move', child: Text('转移板块')),
                ],
              ],
            ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                Expanded(
                  child: ListView(
                    controller: _scrollCtrl,
                    children: [
                      _buildPost(),
                      const Divider(),
                      Padding(
                        padding: const EdgeInsets.fromLTRB(16, 8, 8, 0),
                        child: Row(
                          children: [
                            Text(
                              '评论 (${_comments.length})',
                              style: Theme.of(context).textTheme.titleMedium,
                            ),
                            const Spacer(),
                            TextButton(
                              onPressed: () {
                                setState(() => _hotComments = !_hotComments);
                                _load();
                              },
                              child: Text(
                                _hotComments ? '热门评论' : '最新评论',
                                style: const TextStyle(fontSize: 13),
                              ),
                            ),
                            if (_post != null)
                              TextButton.icon(
                                onPressed: () =>
                                    setState(() => _onlyAuthor = !_onlyAuthor),
                                icon: Icon(
                                  _onlyAuthor
                                      ? Icons.check_box
                                      : Icons.check_box_outline_blank,
                                  size: 18,
                                ),
                                label: const Text('只看楼主'),
                              ),
                          ],
                        ),
                      ),
                      ..._displayComments().map((c) => _buildComment(c)),
                    ],
                  ),
                ),
                _buildInputBar(),
              ],
            ),
    );
  }

  Widget _buildPost() {
    final p = _post!;
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              GestureDetector(
                onTap: () => Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (_) => UserHomeScreen(userId: p.author.id),
                  ),
                ),
                child: _avatar(p.author),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: GestureDetector(
                  onTap: () => Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (_) => UserHomeScreen(userId: p.author.id),
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text(p.author.displayName),
                          if (p.author.title != null &&
                              p.author.title!.isNotEmpty) ...[
                            const SizedBox(width: 6),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 6,
                                vertical: 1,
                              ),
                              decoration: BoxDecoration(
                                color: Colors.indigo.shade50,
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Text(
                                p.author.title!,
                                style: TextStyle(
                                  fontSize: 10,
                                  color: Colors.indigo.shade400,
                                ),
                              ),
                            ),
                          ],
                        ],
                      ),
                      Text(
                        '${p.boardName} · ${DateFormat('yyyy-MM-dd HH:mm').format(p.createdAt)}',
                        style: TextStyle(fontSize: 12, color: Colors.grey[600]),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Text(
            p.title,
            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          if (p.topics.isNotEmpty) ...[
            const SizedBox(height: 8),
            Wrap(
              spacing: 6,
              runSpacing: 4,
              children: p.topics
                  .map(
                    (t) => GestureDetector(
                      onTap: () => _openTopic(t),
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 10,
                          vertical: 4,
                        ),
                        decoration: BoxDecoration(
                          color: Colors.indigo.shade50,
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: Text(
                          '#$t',
                          style: TextStyle(
                            fontSize: 12,
                            color: Colors.indigo.shade600,
                          ),
                        ),
                      ),
                    ),
                  )
                  .toList(),
            ),
          ],
          const SizedBox(height: 12),
          PostContentRenderer(content: p.content, hostContext: context),
          if (_poll != null) ...[
            const SizedBox(height: 16),
            _PollWidget(
              poll: _poll!,
              canManage: p.canEdit,
              onChanged: (updated) => setState(() => _poll = updated),
            ),
          ],
          const SizedBox(height: 12),
          Row(
            children: [
              Icon(
                Icons.remove_red_eye_outlined,
                size: 16,
                color: Colors.grey[600],
              ),
              const SizedBox(width: 4),
              Text('${p.viewCount}', style: TextStyle(color: Colors.grey[600])),
              const SizedBox(width: 16),
              Icon(Icons.thumb_up_outlined, size: 16, color: Colors.grey[600]),
              const SizedBox(width: 4),
              Text('${p.likeCount}', style: TextStyle(color: Colors.grey[600])),
              const SizedBox(width: 16),
              Icon(
                Icons.thumb_down_outlined,
                size: 16,
                color: Colors.grey[600],
              ),
              const SizedBox(width: 4),
              Text(
                '${p.dislikeCount}',
                style: TextStyle(color: Colors.grey[600]),
              ),
              const SizedBox(width: 16),
              Icon(
                Icons.monetization_on_outlined,
                size: 16,
                color: Colors.amber[700],
              ),
              const SizedBox(width: 4),
              Text(
                '${p.totalTipGold}',
                style: TextStyle(color: Colors.amber[700]),
              ),
              const SizedBox(width: 6),
              Text(
                '(${p.myTipTimes}/3)',
                style: TextStyle(fontSize: 12, color: Colors.grey[500]),
              ),
            ],
          ),
        ],
      ),
    );
  }

  List<Widget> _videoAttachments(String content) {
    final links = RegExp(r'\[视频\]\(([^)]+)\)')
        .allMatches(content)
        .map((m) => m.group(1)!)
        .toSet();
    return links
        .map((raw) => InlineVideo(url: ApiClient.resourceUrl(raw)))
        .toList();
  }

  Widget _avatar(Author a, {double radius = 20}) {
    if (a.avatarUrl == null || a.avatarUrl!.isEmpty) {
      return CircleAvatar(
        radius: radius,
        child: Text(a.displayName.characters.first),
      );
    }
    return CircleAvatar(
      radius: radius,
      backgroundColor: Colors.grey.shade200,
      child: ClipOval(
        child: Image.network(
          ApiClient.resourceUrl(a.avatarUrl),
          fit: BoxFit.cover,
          width: radius * 2,
          height: radius * 2,
          loadingBuilder: (_, child, progress) => progress == null
              ? child
              : const CircularProgressIndicator(strokeWidth: 2),
          errorBuilder: (_, __, ___) => Text(a.displayName.characters.first),
        ),
      ),
    );
  }

  Future<void> _postAction(String action) async {
    try {
      if (action == 'delete') {
        final staff = context.read<AuthState>().isStaff;
        await ApiClient.delete(
          staff
              ? '/api/admin/posts/${widget.postId}'
              : '/api/posts/${widget.postId}',
        );
        if (mounted) Navigator.pop(context);
      } else if (action == 'pin') {
        final pinning = !_post!.pinned;
        try {
          await ApiClient.patch(
            '/api/admin/posts/${widget.postId}/pin?pinned=$pinning',
          );
          _toast(pinning ? '已置顶' : '已取消置顶');
          await _load();
        } on ApiException catch (e) {
          _toast(e.message);
        }
      } else if (action == 'lock') {
        final locking = !_post!.locked;
        try {
          await ApiClient.patch(
            '/api/admin/posts/${widget.postId}/lock?locked=$locking',
          );
          _toast(locking ? '已锁定' : '已解锁');
          await _load();
        } on ApiException catch (e) {
          _toast(e.message);
        }
      } else if (action == 'move') {
        final boards = await ApiClient.get('/api/admin/boards');
        final list = boards['data'] as List;
        if (!mounted) return;
        final id = await showDialog<int>(
          context: context,
          builder: (_) => SimpleDialog(
            title: const Text('选择目标板块'),
            children: list.map((x) {
              final b = x as Map<String, dynamic>;
              return SimpleDialogOption(
                onPressed: () => Navigator.pop(context, b['id'] as int),
                child: Text(b['name'].toString()),
              );
            }).toList(),
          ),
        );
        if (id != null) {
          try {
            await ApiClient.patch(
              '/api/admin/posts/${widget.postId}/move?boardId=$id',
            );
            _toast('已转移板块');
            await _load();
          } on ApiException catch (e) {
            _toast(e.message);
          }
        }
      } else if (action == 'edit') {
        await _editPost();
      } else if (action == 'poll') {
        await _createPoll();
      } else if (action == 'report') {
        await _reportContent(isPost: true);
      } else if (action == 'share') {
        await _sharePost();
      } else if (action == 'history') {
        await _showHistory();
      }
    } on ApiException catch (e) {
      _toast(e.message);
    }
  }

  Future<void> _showHistory() async {
    try {
      final d = await ApiClient.get('/api/posts/${widget.postId}/history');
      final list = (d['data'] as List)
          .map((e) => e as Map<String, dynamic>)
          .toList();
      if (!mounted) return;
      if (list.isEmpty) {
        _toast('暂无编辑历史');
        return;
      }
      await showDialog<void>(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text('编辑历史'),
          content: SizedBox(
            width: double.maxFinite,
            child: ListView.builder(
              shrinkWrap: true,
              itemCount: list.length,
              itemBuilder: (_, i) {
                final r = list[i];
                final t = DateTime.tryParse(r['createdAt']?.toString() ?? '');
                final ts = t == null
                    ? ''
                    : '${t.year}-${t.month.toString().padLeft(2, '0')}-${t.day.toString().padLeft(2, '0')} ${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';
                return Card(
                  margin: const EdgeInsets.symmetric(vertical: 4),
                  child: InkWell(
                    onTap: () => _showRevision(r),
                    child: ListTile(
                      title: Text('版本 ${list.length - i}'),
                      subtitle: Text('$ts · ${r['title']?.toString() ?? ''}'),
                    ),
                  ),
                );
              },
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('关闭'),
            ),
          ],
        ),
      );
    } catch (_) {
      _toast('历史加载失败');
    }
  }

  void _showRevision(Map<String, dynamic> r) {
    showDialog<void>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(r['title']?.toString() ?? '历史版本'),
        content: SingleChildScrollView(
          child: Text(r['content']?.toString() ?? ''),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('关闭'),
          ),
        ],
      ),
    );
  }

  Future<void> _sharePost() async {
    final puid = _post?.puid;
    if (puid == null || puid.isEmpty) {
      _toast('当前帖子暂无 PUID');
      return;
    }
    final choice = await showModalBottomSheet<String>(
      context: context,
      builder: (_) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.link),
              title: const Text('复制链接'),
              onTap: () => Navigator.pop(context, 'link'),
            ),
            ListTile(
              leading: const Icon(Icons.key),
              title: const Text('复制 PUID'),
              onTap: () => Navigator.pop(context, 'puid'),
            ),
          ],
        ),
      ),
    );
    if (choice == null) return;
    final shareBase = context.read<SiteConfig>().webShareBaseUrl;
    final value = choice == 'puid'
        ? 'PUID:$puid'
        : '${shareBase.replaceAll(RegExp(r'/+$'), '')}/?puid=$puid';
    await Clipboard.setData(ClipboardData(text: value));
    _toast(choice == 'puid' ? 'PUID 已复制' : '帖子链接已复制');
  }

  Future<void> _createPoll() async {
    final question = TextEditingController();
    final opt1 = TextEditingController();
    final opt2 = TextEditingController();
    final opt3 = TextEditingController();
    final opt4 = TextEditingController();
    var multiple = false;
    final ok = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (ctx, setLocal) => AlertDialog(
          title: const Text('发起投票'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: question,
                  decoration: const InputDecoration(labelText: '投票问题'),
                ),
                TextField(
                  controller: opt1,
                  decoration: const InputDecoration(labelText: '选项 1'),
                ),
                TextField(
                  controller: opt2,
                  decoration: const InputDecoration(labelText: '选项 2'),
                ),
                TextField(
                  controller: opt3,
                  decoration: const InputDecoration(labelText: '选项 3（可选）'),
                ),
                TextField(
                  controller: opt4,
                  decoration: const InputDecoration(labelText: '选项 4（可选）'),
                ),
                SwitchListTile(
                  title: const Text('多选'),
                  value: multiple,
                  onChanged: (v) => setLocal(() => multiple = v),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: const Text('取消'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(dialogContext, true),
              child: const Text('发布'),
            ),
          ],
        ),
      ),
    );
    if (ok != true) return;
    final options = [
      opt1.text.trim(),
      opt2.text.trim(),
      opt3.text.trim(),
      opt4.text.trim(),
    ].where((s) => s.isNotEmpty).toList();
    if (question.text.trim().isEmpty || options.length < 2) {
      _toast('请填写问题并至少提供两个选项');
      return;
    }
    try {
      final d = await ApiClient.post(
        '/api/polls/${widget.postId}',
        body: {
          'question': question.text.trim(),
          'multiple': multiple,
          'options': options,
        },
      );
      setState(() => _poll = d['data'] as Map<String, dynamic>);
      _toast('投票已创建');
    } on ApiException catch (e) {
      _toast(e.message);
    } catch (_) {
      _toast('创建失败');
    }
  }

  Future<void> _editPost() async {
    final title = TextEditingController(text: _post!.title);
    final content = TextEditingController(text: _post!.content);
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('编辑帖子'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: title,
                decoration: const InputDecoration(labelText: '标题'),
              ),
              TextField(
                controller: content,
                maxLines: 8,
                decoration: const InputDecoration(labelText: '正文'),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('取消'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('保存'),
          ),
        ],
      ),
    );
    if (ok == true) {
      try {
        await ApiClient.put(
          '/api/posts/${widget.postId}',
          body: {
            'title': title.text,
            'content': content.text,
            'boardId': _post!.boardId,
          },
        );
        await _load();
      } on ApiException catch (e) {
        _toast(e.message);
      }
    }
  }

  void _openTopic(String topic) {
    Navigator.of(context)
        .push(MaterialPageRoute(builder: (_) => TopicScreen(topic: topic)));
  }

  Future<void> _deleteComment(Comment c) async {
    final ok = await ensureLoggedIn(context);
    if (!ok) return;
    if (!mounted) return;
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('删除评论'),
        content: const Text('确定删除这条评论吗？'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('取消'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            style: FilledButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('删除'),
          ),
        ],
      ),
    );
    if (confirm != true) return;
    try {
      await ApiClient.delete('/api/comments/${c.id}');
      _toast('评论已删除');
      await _load();
    } on ApiException catch (e) {
      _toast(e.message);
    } catch (_) {
      _toast('删除失败');
    }
  }

  List<Comment> _displayComments() {
    if (!_onlyAuthor || _post == null) return _comments;
    final authorId = _post!.author.id;
    return _comments.where((c) => c.author.id == authorId).toList();
  }

  /// 在评论树中定位并替换指定 id 的评论
  List<Comment> _mapCommentTree(
    List<Comment> list,
    int id,
    Comment Function(Comment) transform,
  ) {
    return list.map((c) {
      if (c.id == id) return transform(c);
      if (c.replies.any((r) => r.id == id)) {
        return Comment(
          id: c.id,
          content: c.content,
          postId: c.postId,
          parentId: c.parentId,
          author: c.author,
          likeCount: c.likeCount,
          dislikeCount: c.dislikeCount,
          likedByMe: c.likedByMe,
          dislikedByMe: c.dislikedByMe,
          canEdit: c.canEdit,
          canDelete: c.canDelete,
          createdAt: c.createdAt,
          replies: _mapCommentTree(c.replies, id, transform),
        );
      }
      return c;
    }).toList();
  }

  Future<void> _reactComment(Comment c, {required bool like}) async {
    final ok = await ensureLoggedIn(context);
    if (!ok) return;
    // 乐观更新（点赞/点踩互斥）；基于当前评论树计算状态，避免双击漂移
    setState(() {
      _comments = _mapCommentTree(_comments, c.id, (old) {
        final nowActive = like ? !old.likedByMe : !old.dislikedByMe;
        if (like) {
          return old.copyWithReaction(
            likedByMe: nowActive,
            likeCount: old.likeCount + (nowActive ? 1 : -1),
            dislikedByMe: nowActive ? false : old.dislikedByMe,
            dislikeCount: (nowActive && old.dislikedByMe)
                ? old.dislikeCount - 1
                : old.dislikeCount,
          );
        } else {
          return old.copyWithReaction(
            dislikedByMe: nowActive,
            dislikeCount: old.dislikeCount + (nowActive ? 1 : -1),
            likedByMe: nowActive ? false : old.likedByMe,
            likeCount: (nowActive && old.likedByMe)
                ? old.likeCount - 1
                : old.likeCount,
          );
        }
      });
    });
    try {
      await ApiClient.post(
        '/api/comments/${c.id}/${like ? 'like' : 'dislike'}',
      );
    } catch (_) {
      await _load();
    }
  }

  void _showCommentMenu(Comment c) {
    showModalBottomSheet(
      context: context,
      builder: (_) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: Icon(
                c.likedByMe ? Icons.thumb_up : Icons.thumb_up_outlined,
                color: c.likedByMe ? Colors.indigo : null,
              ),
              title: Text('赞 (${c.likeCount})'),
              onTap: () {
                Navigator.pop(context);
                _reactComment(c, like: true);
              },
            ),
            ListTile(
              leading: Icon(
                c.dislikedByMe ? Icons.thumb_down : Icons.thumb_down_outlined,
                color: c.dislikedByMe ? Colors.red : null,
              ),
              title: Text('踩 (${c.dislikeCount})'),
              onTap: () {
                Navigator.pop(context);
                _reactComment(c, like: false);
              },
            ),
            ListTile(
              leading: const Icon(Icons.content_copy_outlined),
              title: const Text('复制'),
              onTap: () {
                Navigator.pop(context);
                Clipboard.setData(ClipboardData(text: c.content));
                _toast('评论已复制');
              },
            ),
            ListTile(
              leading: const Icon(Icons.flag_outlined),
              title: const Text('举报'),
              onTap: () {
                Navigator.pop(context);
                _reportContent(isPost: false, commentId: c.id);
              },
            ),
            if (c.canDelete)
              ListTile(
                leading: const Icon(Icons.delete_outline, color: Colors.red),
                title: const Text('删除', style: TextStyle(color: Colors.red)),
                onTap: () {
                  Navigator.pop(context);
                  _deleteComment(c);
                },
              ),
          ],
        ),
      ),
    );
  }

  void _resetPress() {
    if (_pressedCommentId != null) {
      setState(() => _pressedCommentId = null);
    }
    if (_pressAnim.isAnimating) {
      _pressAnim.stop();
      _pressAnim.reset();
    }
  }

  Widget _buildComment(Comment c) {
    final highlighted = c.id == widget.highlightCommentId;
    final bg = highlighted ? Colors.orange.withOpacity(0.15) : null;
    return Container(
      key: highlighted ? _highlightKey : null,
      color: bg,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            GestureDetector(
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => UserHomeScreen(userId: c.author.id),
                ),
              ),
              child: CircleAvatar(
                radius: 14,
                backgroundImage:
                    c.author.avatarUrl != null && c.author.avatarUrl!.isNotEmpty
                    ? NetworkImage(ApiClient.resourceUrl(c.author.avatarUrl))
                    : null,
                child: c.author.avatarUrl == null || c.author.avatarUrl!.isEmpty
                    ? Text(c.author.displayName.characters.first)
                    : null,
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      GestureDetector(
                        onTap: () => Navigator.of(context).push(
                          MaterialPageRoute(
                            builder: (_) => UserHomeScreen(userId: c.author.id),
                          ),
                        ),
                        child: Text(
                          c.author.displayName,
                          style: const TextStyle(
                            fontWeight: FontWeight.w500,
                            fontSize: 13,
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        DateFormat('MM-dd HH:mm').format(c.createdAt),
                        style: TextStyle(fontSize: 11, color: Colors.grey[500]),
                      ),
                    ],
                  ),
                  const SizedBox(height: 2),
                  GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTap: () => _startReply(c),
                    onLongPress: () => _showCommentMenu(c),
                    child: MentionText(content: c.content),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 4),
                    child: Row(
                      children: [
                        TextButton.icon(
                          onPressed: () => _startReply(c),
                          icon: const Icon(Icons.reply_outlined, size: 14),
                          label: const Text('回复'),
                          style: TextButton.styleFrom(
                            padding: EdgeInsets.zero,
                            minimumSize: const Size(44, 30),
                            tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                          ),
                        ),
                        const SizedBox(width: 10),
                        GestureDetector(
                          onTap: () => _reactComment(c, like: true),
                          child: Row(
                            children: [
                              Icon(
                                c.likedByMe
                                    ? Icons.thumb_up
                                    : Icons.thumb_up_outlined,
                                size: 14,
                                color: c.likedByMe
                                    ? Colors.indigo
                                    : Colors.grey[500],
                              ),
                              const SizedBox(width: 3),
                              Text(
                                '${c.likeCount}',
                                style: TextStyle(
                                  fontSize: 11,
                                  color: Colors.grey[500],
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 14),
                        GestureDetector(
                          onTap: () => _reactComment(c, like: false),
                          child: Row(
                            children: [
                              Icon(
                                c.dislikedByMe
                                    ? Icons.thumb_down
                                    : Icons.thumb_down_outlined,
                                size: 14,
                                color: c.dislikedByMe
                                    ? Colors.red
                                    : Colors.grey[500],
                              ),
                              const SizedBox(width: 3),
                              Text(
                                '${c.dislikeCount}',
                                style: TextStyle(
                                  fontSize: 11,
                                  color: Colors.grey[500],
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 14),
                        GestureDetector(
                          onTap: () => _showCommentMenu(c),
                          behavior: HitTestBehavior.opaque,
                          child: Padding(
                            padding: const EdgeInsets.symmetric(vertical: 4),
                            child: Icon(
                              Icons.more_horiz,
                              size: 16,
                              color: Colors.grey[500],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  if (c.replies.isNotEmpty)
                    ...c.replies.map((r) => _buildReply(r)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildReply(Comment r) {
    return Container(
      child: Padding(
        padding: const EdgeInsets.only(left: 8, top: 6),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            GestureDetector(
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => UserHomeScreen(userId: r.author.id),
                ),
              ),
              child: CircleAvatar(
                radius: 11,
                backgroundImage:
                    r.author.avatarUrl != null && r.author.avatarUrl!.isNotEmpty
                    ? NetworkImage(ApiClient.resourceUrl(r.author.avatarUrl))
                    : null,
                child: r.author.avatarUrl == null || r.author.avatarUrl!.isEmpty
                    ? Text(r.author.displayName.characters.first)
                    : null,
              ),
            ),
            const SizedBox(width: 6),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTap: () => _startReply(r),
                    onLongPress: () => _showCommentMenu(r),
                    child: MentionText(
                      prefix: '${r.author.displayName}: ',
                      prefixStyle: const TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w500,
                      ),
                      content: r.content,
                      style: const TextStyle(fontSize: 13),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 2),
                    child: Row(
                      children: [
                        GestureDetector(
                          onTap: () => _reactComment(r, like: true),
                          behavior: HitTestBehavior.opaque,
                          child: Padding(
                            padding: const EdgeInsets.symmetric(vertical: 2),
                            child: Row(
                              children: [
                                Icon(
                                  r.likedByMe
                                      ? Icons.thumb_up
                                      : Icons.thumb_up_outlined,
                                  size: 13,
                                  color: r.likedByMe
                                      ? Colors.indigo
                                      : Colors.grey[500],
                                ),
                                const SizedBox(width: 3),
                                Text(
                                  '${r.likeCount}',
                                  style: TextStyle(
                                    fontSize: 11,
                                    color: Colors.grey[500],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        GestureDetector(
                          onTap: () => _reactComment(r, like: false),
                          behavior: HitTestBehavior.opaque,
                          child: Padding(
                            padding: const EdgeInsets.symmetric(vertical: 2),
                            child: Row(
                              children: [
                                Icon(
                                  r.dislikedByMe
                                      ? Icons.thumb_down
                                      : Icons.thumb_down_outlined,
                                  size: 13,
                                  color: r.dislikedByMe
                                      ? Colors.red
                                      : Colors.grey[500],
                                ),
                                const SizedBox(width: 3),
                                Text(
                                  '${r.dislikeCount}',
                                  style: TextStyle(
                                    fontSize: 11,
                                    color: Colors.grey[500],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        GestureDetector(
                          onTap: () => _showCommentMenu(r),
                          behavior: HitTestBehavior.opaque,
                          child: Padding(
                            padding: const EdgeInsets.symmetric(vertical: 2),
                            child: Icon(
                              Icons.more_horiz,
                              size: 15,
                              color: Colors.grey[500],
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        GestureDetector(
                          onTap: () => _startReply(r),
                          behavior: HitTestBehavior.opaque,
                          child: Padding(
                            padding: const EdgeInsets.symmetric(vertical: 2),
                            child: Row(
                              children: [
                                Icon(
                                  Icons.reply_outlined,
                                  size: 13,
                                  color: Colors.grey[500],
                                ),
                                const SizedBox(width: 3),
                                Text(
                                  '回复',
                                  style: TextStyle(
                                    fontSize: 11,
                                    color: Colors.grey[500],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInputBar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        border: Border(top: BorderSide(color: Colors.grey[300]!)),
      ),
      child: SafeArea(
        child: Row(
          children: [
            if (_replyToId != null)
              IconButton(
                icon: const Icon(Icons.close, size: 20),
                tooltip: '取消回复',
                onPressed: _cancelReply,
              ),
            Expanded(
              child: TextField(
                controller: _commentCtrl,
                focusNode: _commentFocus,
                decoration: InputDecoration(
                  hintText: _replyToId == null
                      ? '写下你的评论...'
                      : (_replyIsChild
                            ? '回复 @$_replyTargetUsername:'
                            : '回复 $_replyToName:'),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(24),
                  ),
                  contentPadding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 8,
                  ),
                ),
              ),
            ),
            IconButton(icon: const Icon(Icons.send), onPressed: _submitComment),
          ],
        ),
      ),
    );
  }
}

/// 投票组件：未投票显示选项，已投票显示结果。
class _PollWidget extends StatefulWidget {
  final Map<String, dynamic> poll;
  final bool canManage;
  final ValueChanged<Map<String, dynamic>> onChanged;

  const _PollWidget({
    required this.poll,
    required this.canManage,
    required this.onChanged,
  });

  @override
  State<_PollWidget> createState() => _PollWidgetState();
}

class _PollWidgetState extends State<_PollWidget> {
  final Set<int> _selected = {};
  bool _submitting = false;

  @override
  void initState() {
    super.initState();
    final votes = (widget.poll['myVotes'] as List?) ?? [];
    _selected.addAll(votes.map((e) => e as int));
  }

  Future<void> _vote() async {
    if (_selected.isEmpty || _submitting) return;
    final ok = await ensureLoggedIn(context);
    if (!ok) return;
    setState(() => _submitting = true);
    try {
      final d = await ApiClient.post(
        '/api/polls/${widget.poll['id']}/vote',
        body: {'optionIds': _selected.toList()},
      );
      widget.onChanged(d['data'] as Map<String, dynamic>);
      _toast('投票成功');
    } on ApiException catch (e) {
      _toast(e.message);
    } catch (_) {
      _toast('投票失败');
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  void _toast(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }

  @override
  Widget build(BuildContext context) {
    final p = widget.poll;
    final multiple = (p['multiple'] as bool?) ?? false;
    final voted = (p['voted'] as bool?) ?? false;
    final total = (p['totalVotes'] as int?) ?? 0;
    final options = (p['options'] as List?) ?? [];

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surfaceContainerHighest
            .withOpacity(0.5),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.indigo.shade100),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.how_to_vote, size: 18, color: Colors.indigo.shade400),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  p['question']?.toString() ?? '投票',
                  style: const TextStyle(fontWeight: FontWeight.w600),
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Text(
            multiple ? '多选 · 已 ${total} 人参与' : '单选 · 已 ${total} 人参与',
            style: TextStyle(fontSize: 12, color: Colors.grey[600]),
          ),
          const SizedBox(height: 10),
          ...options.map((o) {
            final opt = o as Map<String, dynamic>;
            final id = opt['id'] as int;
            final count = (opt['count'] as int?) ?? 0;
            final percent = (opt['percent'] as int?) ?? 0;
            final chosen = _selected.contains(id);
            if (voted) {
              return Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        if (chosen)
                          const Icon(
                            Icons.check_circle,
                            size: 16,
                            color: Colors.green,
                          ),
                        const SizedBox(width: 4),
                        Expanded(child: Text(opt['text']?.toString() ?? '')),
                        Text(
                          '$count 票 · $percent%',
                          style: TextStyle(
                            fontSize: 12,
                            color: Colors.grey[600],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 3),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(4),
                      child: LinearProgressIndicator(
                        value: total == 0 ? 0 : (count / total).clamp(0.0, 1.0),
                        minHeight: 6,
                        backgroundColor: Colors.grey.shade200,
                      ),
                    ),
                  ],
                ),
              );
            }
            return InkWell(
              onTap: multiple
                  ? () => setState(() {
                      _selected.contains(id)
                          ? _selected.remove(id)
                          : _selected.add(id);
                    })
                  : () => setState(() {
                      _selected
                        ..clear()
                        ..add(id);
                    }),
              borderRadius: BorderRadius.circular(8),
              child: Container(
                margin: const EdgeInsets.only(bottom: 8),
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 10,
                ),
                decoration: BoxDecoration(
                  color: chosen ? Colors.indigo.withOpacity(0.1) : Colors.white,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                    color: chosen ? Colors.indigo : Colors.grey.shade300,
                  ),
                ),
                child: Row(
                  children: [
                    Icon(
                      chosen
                          ? Icons.radio_button_checked
                          : Icons.radio_button_unchecked,
                      size: 18,
                      color: chosen ? Colors.indigo : Colors.grey,
                    ),
                    const SizedBox(width: 8),
                    Expanded(child: Text(opt['text']?.toString() ?? '')),
                  ],
                ),
              ),
            );
          }),
          if (!voted) ...[
            const SizedBox(height: 4),
            Row(
              children: [
                Expanded(
                  child: FilledButton(
                    onPressed: (_selected.isEmpty || _submitting)
                        ? null
                        : _vote,
                    child: _submitting
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : const Text('提交投票'),
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }
}

/// 按 PUID 加载帖子：供分享深链、搜索、@PUID 跳转复用。
class PuidPostScreen extends StatelessWidget {
  final String puid;
  const PuidPostScreen({super.key, required this.puid});

  @override
  Widget build(BuildContext context) {
    final p = puid.replaceFirst('PUID:', '');
    return FutureBuilder<Map<String, dynamic>>(
      future: ApiClient.get('/api/posts/puid/$p'),
      builder: (context, snapshot) {
        if (snapshot.connectionState != ConnectionState.done) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }
        if (snapshot.hasError || snapshot.data?['data'] == null) {
          return Scaffold(
            appBar: AppBar(title: const Text('帖子不存在')),
            body: const Center(child: Text('没有找到对应的帖子')),
          );
        }
        final data = snapshot.data!['data'] as Map<String, dynamic>;
        return PostDetailScreen(postId: data['id'] as int);
      },
    );
  }
}
