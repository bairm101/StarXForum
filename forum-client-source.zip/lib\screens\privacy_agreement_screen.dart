import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../main.dart';

/// 隐私政策同意标记存储键（版本号升级后可换键重新弹出）
const String kPrivacyAgreedKey = 'privacy_agreed_v2';

/// 首次进入应用的《用户协议与隐私政策》同意界面。
/// 同意 → 保存标记并进入应用；不同意 → 退出应用。
class PrivacyAgreementScreen extends StatefulWidget {
  const PrivacyAgreementScreen({super.key});

  @override
  State<PrivacyAgreementScreen> createState() => _PrivacyAgreementScreenState();
}

class _PrivacyAgreementScreenState extends State<PrivacyAgreementScreen> {
  bool _busy = false;

  Future<void> _agree() async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool(kPrivacyAgreedKey, true);
      if (!mounted) return;
      Navigator.of(context)
          .pushReplacement(MaterialPageRoute(builder: (_) => const SplashScreen()));
    } catch (_) {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _disagree() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('提示'),
        content: const Text('如不同意本协议，将无法使用本应用。确定退出吗？'),
        actions: [
          TextButton(
              onPressed: () => Navigator.of(context).pop(false), child: const Text('再想想')),
          FilledButton(
              onPressed: () => Navigator.of(context).pop(true), child: const Text('退出')),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    try {
      await SystemNavigator.pop();
    } catch (_) {}
    if (kIsWeb) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('请关闭本页面以退出')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('用户协议与隐私政策')),
      body: Column(
        children: [
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: SelectionArea(
                child: Text(
                  _policyText,
                  style: const TextStyle(fontSize: 14, height: 1.7),
                ),
              ),
            ),
          ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: _busy ? null : _disagree,
                      child: const Text('不同意并退出'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: FilledButton(
                      onPressed: _busy ? null : _agree,
                      child: _busy
                          ? const SizedBox(
                              width: 18, height: 18,
                              child: CircularProgressIndicator(strokeWidth: 2))
                          : const Text('同意并继续'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

const String _policyText = '''
更新日期：2026 年 8 月 27 日
生效日期：2026 年 8 月 27 日

欢迎您使用本论坛应用（以下简称"本应用"）。我们深知个人信息对您的重要性，将严格遵守法律法规要求，采取相应的安全保护措施，尽力保护您的个人信息安全可控。在使用本应用前，请您仔细阅读并充分理解本《用户协议与隐私政策》的全部内容。您点击"同意并继续"即表示您已阅读并同意接受本协议的全部条款。

一、用户协议要点

1. 您通过注册或登录获得的账号仅限本人使用。请妥善保管账号与密码，因您个人保管不当造成的损失由您自行承担。
2. 您在本应用发布的内容（包括但不限于帖子、评论、签名、头像、私信）应遵守中华人民共和国法律法规，不得发布以下内容：
   （1）违反宪法确定的基本原则的；
   （2）危害国家安全、泄露国家秘密、颠覆国家政权、破坏国家统一的；
   （3）损害国家荣誉和利益的；
   （4）煽动民族仇恨、民族歧视，破坏民族团结的；
   （5）破坏国家宗教政策，宣扬邪教和封建迷信的；
   （6）散布谣言，扰乱社会秩序，破坏社会稳定的；
   （7）散布淫秽、色情、赌博、暴力、凶杀、恐怖或者教唆犯罪的；
   （8）侮辱或者诽谤他人，侵害他人合法权益的；
   （9）含有法律、行政法规禁止的其他内容的。
3. 对于违反上述规定的内容与账号，管理方有权不经通知直接采取删除内容、禁言、封禁账号等措施。
4. 您发布的内容授予本应用在平台内展示、传播的非独占许可。您应对所发布内容的真实性、合法性负责。
5. 金币与打赏：金币为本应用内虚拟道具，可通过签到等方式免费获得，仅可用于打赏帖子作者，不可兑换现金、不可转让。打赏一经完成不予退回，请您在打赏前确认金额（每次最多 2 金币，每帖最多 3 次）。
6. 签名与内容审核：根据站点设置，您修改的签名或二次编辑的帖子可能进入人工审核流程，审核通过后方可见。

二、账号注销与删除

1. 您可以在"我的"页面自助注销账号。注销后：您发布的所有帖子将被永久删除；您上传的图片、视频、文件将被永久删除；您的历史评论将保留但署名显示为"账号已注销"；账号将无法再登录。注销操作不可恢复，请谨慎操作。
2. 管理方有权对违反本协议的账号执行删除处理，处理方式与上述注销一致。
3. 忘记密码时，可通过登录页"忘记密码"功能，凭账号绑定的邮箱收取验证码重置密码；未绑定邮箱的账号将无法找回，请及时绑定邮箱。

三、我们收集的信息

为向您提供服务，我们会在以下场景中收集相应信息：

1. 注册与登录：用户名、密码（加密存储）、邮箱（用于验证、找回密码与换绑，可自愿填写）、昵称。支持使用用户名、邮箱或 UID 任一方式登录。
2. 使用社区功能：您发布的帖子、评论、点赞、收藏、打赏、投票、签到等行为数据，以及您上传的图片、视频、文件。
3. 私信：您与其他用户的私信内容。私信仅收发双方与平台管理方（在受理举报等必要场景）可见。
4. 安全验证：为保障账号安全，新设备登录时我们会记录设备标识信息，并向您的绑定邮箱发送验证码；发送验证码存在 60 秒冷却间隔。
5. 设备与日志信息：设备型号、操作系统版本、网络状态、访问日志等，用于故障排查与安全防护。

四、我们如何使用信息

1. 为您提供内容发布、浏览、互动、通知等核心服务；
2. 用于身份验证、安全防护、反作弊与违规处置；
3. 改进产品功能与体验；
4. 履行法律法规规定的义务。

五、信息的存储与保护

1. 您的信息存储于本应用运营者的服务器，存储于中华人民共和国境内。
2. 我们采用加密传输（HTTPS）、密码加盐哈希存储、访问权限控制等措施保护您的信息。
3. 我们仅在实现服务目的所必需的最短时间内保留您的个人信息；法律法规另有规定的除外。

六、信息的共享与披露

1. 我们不会向任何第三方出售您的个人信息。
2. 除以下情形外，我们不会向第三方共享您的个人信息：
   （1）事先获得您的明确授权同意；
   （2）根据法律法规、诉讼争议解决需要，或按行政、司法机关依法提出的要求。
3. 您发布的公开内容（帖子、评论等）将对平台所有用户可见，请您谨慎发布。

七、您的权利

1. 您可以在"我的"页面访问、修改您的个人资料（昵称、头像、签名等）；
2. 您可以删除自己发布的帖子与评论；
3. 您可以管理已登录设备（查看、下线），并可一键退登全部设备；
4. 您可以在"我的"页面自助注销账号（详见第二条）；
5. 您可以举报违规内容与用户，管理方将依规处理。

八、未成年人保护

若您为未满 14 周岁的未成年人，请在监护人的陪同和指导下阅读本协议，并在取得监护人同意后使用本应用。

九、本协议的变更

我们可能适时修订本协议内容。变更后的协议将在应用内公布并重新征求您的同意，若您继续使用本应用，即表示接受修订后的协议。

十、联系我们

如您对本协议或个人信息保护有任何疑问、意见或建议，可通过应用"关于"页面中的联系方式与我们联系。

感谢您的信任，我们将竭力保护您的合法权益。
''';
