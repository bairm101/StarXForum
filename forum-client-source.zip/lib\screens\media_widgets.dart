import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';
import 'package:flutter_markdown/flutter_markdown.dart';
import '../api/api_client.dart';
import '../services/video_cache.dart';
import 'post_detail_screen.dart';
import 'user_home_screen.dart';

/// 内嵌视频播放器：在线播放、播放/暂停、进度条拖动。
/// 首次播放走网络并后台缓存到应用私有目录，再次播放直接读本地文件。
class InlineVideo extends StatefulWidget {
  final String url;
  const InlineVideo({super.key, required this.url});

  @override
  State<InlineVideo> createState() => _InlineVideoState();
}

class _InlineVideoState extends State<InlineVideo> {
  VideoPlayerController? controller;
  String _cur = '00:00';
  String _dur = '00:00';
  bool _showControls = true;
  bool _failed = false;
  Timer? _hideTimer;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    // 命中本地缓存则直接本地播放，否则在线播放并后台下载缓存
    File? cached;
    try {
      cached = await VideoCache.cachedFile(widget.url);
    } catch (_) {}
    if (!mounted) return;
    final VideoPlayerController c;
    if (cached != null) {
      c = VideoPlayerController.file(cached);
    } else {
      c = VideoPlayerController.networkUrl(Uri.parse(widget.url));
      unawaited(VideoCache.ensureCached(widget.url));
    }
    controller = c;
    try {
      await c.initialize();
    } catch (_) {
      if (mounted) setState(() => _failed = true);
      return;
    }
    if (!mounted) {
      await c.dispose();
      return;
    }
    _dur = _fmt(c.value.duration);
    c.addListener(_onUpdate);
    setState(() {});
    _scheduleHide();
  }

  @override
  void dispose() {
    _hideTimer?.cancel();
    controller?.removeListener(_onUpdate);
    controller?.dispose();
    super.dispose();
  }

  /// 3 秒后自动隐藏控制栏
  void _scheduleHide() {
    _hideTimer?.cancel();
    _hideTimer = Timer(const Duration(seconds: 3), () {
      if (mounted && _showControls) setState(() => _showControls = false);
    });
  }

  /// 点击视频：切换控制栏显隐
  void _toggleControls() {
    setState(() => _showControls = !_showControls);
    if (_showControls) _scheduleHide();
  }

  void _onUpdate() {
    if (!mounted) return;
    setState(() => _cur = _fmt(controller!.value.position));
  }

  void _toggle() {
    final c = controller!;
    setState(() => c.value.isPlaying ? c.pause() : c.play());
    _scheduleHide();
  }

  String _fmt(Duration d) {
    final h = d.inHours;
    final m = (d.inMinutes % 60).toString().padLeft(2, '0');
    final s = (d.inSeconds % 60).toString().padLeft(2, '0');
    return h > 0 ? '${d.inHours}:$m:$s' : '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    final c = controller;
    if (_failed) {
      return Container(
        height: 140,
        color: Colors.grey.shade100,
        alignment: Alignment.center,
        child: const Column(
          mainAxisSize: MainAxisSize.min,
          children: [Icon(Icons.broken_image, size: 32), SizedBox(height: 6), Text('视频加载失败')],
        ),
      );
    }
    if (c == null || !c.value.isInitialized) {
      return Container(
        height: 180,
        color: Colors.grey.shade100,
        alignment: Alignment.center,
        child: const Column(
          mainAxisSize: MainAxisSize.min,
          children: [CircularProgressIndicator(), SizedBox(height: 8), Text('视频加载中')],
        ),
      );
    }
    return ClipRRect(
      borderRadius: BorderRadius.circular(8),
      child: AspectRatio(
        aspectRatio: c.value.aspectRatio,
        child: Stack(
          children: [
            // 视频区域：点击切换控制栏显隐
            Positioned.fill(
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: _toggleControls,
                child: VideoPlayer(c),
              ),
            ),
            // 中央播放/暂停按钮（可隐藏）
            IgnorePointer(
              ignoring: !_showControls,
              child: AnimatedOpacity(
                opacity: _showControls ? 1 : 0,
                duration: const Duration(milliseconds: 250),
                child: Center(
                  child: GestureDetector(
                    onTap: () {
                      _toggle();
                      _scheduleHide();
                    },
                    child: Container(
                      decoration: const BoxDecoration(
                        color: Colors.black38,
                        shape: BoxShape.circle,
                      ),
                      padding: const EdgeInsets.all(16),
                      child: Icon(
                        c.value.isPlaying ? Icons.pause : Icons.play_arrow,
                        color: Colors.white,
                        size: 46,
                      ),
                    ),
                  ),
                ),
              ),
            ),
            // 底部：进度条（视频内部）+ 全屏按钮（右下角）（可隐藏）
            Positioned(
              left: 0, right: 0, bottom: 0,
              child: IgnorePointer(
                ignoring: !_showControls,
                child: AnimatedOpacity(
                  opacity: _showControls ? 1 : 0,
                  duration: const Duration(milliseconds: 250),
                  child: Container(
                    color: Colors.black45,
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    child: Row(
                      children: [
                        Text(_cur, style: const TextStyle(fontSize: 11, color: Colors.white)),
                        const SizedBox(width: 6),
                        Expanded(
                          child: GestureDetector(
                            onTapDown: (_) => _scheduleHide(),
                            child: VideoProgressIndicator(c, allowScrubbing: true, colors: VideoProgressColors(
                              playedColor: Colors.white,
                              bufferedColor: Colors.white38,
                              backgroundColor: Colors.white24,
                            )),
                          ),
                        ),
                        const SizedBox(width: 6),
                        Text(_dur, style: const TextStyle(fontSize: 11, color: Colors.white)),
                        const SizedBox(width: 2),
                        GestureDetector(
                          onTap: _openFullscreen,
                          child: const Padding(
                            padding: EdgeInsets.all(4),
                            child: Icon(Icons.fullscreen, color: Colors.white, size: 22),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _openFullscreen() {
    final c = controller;
    if (c == null) return;
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => FullscreenVideoScreen(controller: c),
    ));
  }
}

/// 全屏视频播放器：复用已初始化的 controller（不重新缓冲、保留进度），强制横屏。
class FullscreenVideoScreen extends StatefulWidget {
  final VideoPlayerController controller;
  const FullscreenVideoScreen({super.key, required this.controller});

  @override
  State<FullscreenVideoScreen> createState() => _FullscreenVideoScreenState();
}

class _FullscreenVideoScreenState extends State<FullscreenVideoScreen> {
  String _cur = '00:00';
  String _dur = '00:00';
  bool _showControls = true;
  Timer? _hideTimer;

  @override
  void initState() {
    super.initState();
    final c = widget.controller;
    if (c.value.isInitialized) {
      _dur = _fmt(c.value.duration);
      _cur = _fmt(c.value.position);
    }
    c.addListener(_onUpdate);
    // 强制横屏（横版视频全屏不再竖屏）；web 不支持方向锁定，跳过
    if (!kIsWeb) {
      SystemChrome.setPreferredOrientations([
        DeviceOrientation.landscapeLeft,
        DeviceOrientation.landscapeRight,
      ]);
    }
    // 保持播放状态
    if (c.value.isInitialized && !c.value.isPlaying) {
      c.play();
    }
    _scheduleHide();
  }

  @override
  void dispose() {
    _hideTimer?.cancel();
    widget.controller.removeListener(_onUpdate);
    if (!kIsWeb) {
      SystemChrome.setPreferredOrientations(DeviceOrientation.values);
    }
    super.dispose();
  }

  /// 3 秒后自动隐藏控制栏
  void _scheduleHide() {
    _hideTimer?.cancel();
    _hideTimer = Timer(const Duration(seconds: 3), () {
      if (mounted && _showControls) setState(() => _showControls = false);
    });
  }

  /// 点击视频：切换控制栏显隐
  void _toggleControls() {
    setState(() => _showControls = !_showControls);
    if (_showControls) _scheduleHide();
  }

  void _onUpdate() {
    if (!mounted) return;
    // controller 可能已被底层组件释放，访问 value 时防御性兜底
    try {
      setState(() => _cur = _fmt(widget.controller.value.position));
    } catch (_) {}
  }

  void _toggle() {
    final c = widget.controller;
    try {
      setState(() => c.value.isPlaying ? c.pause() : c.play());
    } catch (_) {}
  }

  String _fmt(Duration d) {
    final h = d.inHours;
    final m = (d.inMinutes % 60).toString().padLeft(2, '0');
    final s = (d.inSeconds % 60).toString().padLeft(2, '0');
    return h > 0 ? '${d.inHours}:$m:$s' : '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    final c = widget.controller;
    bool ok;
    try {
      ok = c.value.isInitialized;
    } catch (_) {
      ok = false;
    }
    if (!ok) {
      return const Scaffold(
        backgroundColor: Colors.black,
        body: Center(child: Text('视频已失效', style: TextStyle(color: Colors.white))),
      );
    }
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Stack(
          children: [
            // 视频铺满，点击切换控制栏显隐
            Positioned.fill(
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: _toggleControls,
                child: FittedBox(
                  fit: BoxFit.contain,
                  child: SizedBox(
                    width: 100,
                    height: 100 / (c.value.aspectRatio == 0 ? 1 : c.value.aspectRatio),
                    child: VideoPlayer(c),
                  ),
                ),
              ),
            ),
            // 中央播放/暂停（可隐藏）
            IgnorePointer(
              ignoring: !_showControls,
              child: AnimatedOpacity(
                opacity: _showControls ? 1 : 0,
                duration: const Duration(milliseconds: 250),
                child: Center(
                  child: GestureDetector(
                    onTap: () {
                      _toggle();
                      _scheduleHide();
                    },
                    child: Container(
                      decoration: const BoxDecoration(color: Colors.black38, shape: BoxShape.circle),
                      padding: const EdgeInsets.all(20),
                      child: Icon(c.value.isPlaying ? Icons.pause : Icons.play_arrow, color: Colors.white, size: 56),
                    ),
                  ),
                ),
              ),
            ),
            // 底部进度条（可隐藏）
            Positioned(
              left: 0, right: 0, bottom: 0,
              child: IgnorePointer(
                ignoring: !_showControls,
                child: AnimatedOpacity(
                  opacity: _showControls ? 1 : 0,
                  duration: const Duration(milliseconds: 250),
                  child: Container(
                    color: Colors.black45,
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    child: Row(
                      children: [
                        Text(_cur, style: const TextStyle(fontSize: 12, color: Colors.white)),
                        const SizedBox(width: 8),
                        Expanded(
                          child: GestureDetector(
                            onTapDown: (_) => _scheduleHide(),
                            child: VideoProgressIndicator(c, allowScrubbing: true, colors: VideoProgressColors(
                              playedColor: Colors.white,
                              bufferedColor: Colors.white38,
                              backgroundColor: Colors.white24,
                            )),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Text(_dur, style: const TextStyle(fontSize: 12, color: Colors.white)),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            // 右上角退出（可隐藏）
            Positioned(
              top: 4, right: 4,
              child: IgnorePointer(
                ignoring: !_showControls,
                child: AnimatedOpacity(
                  opacity: _showControls ? 1 : 0,
                  duration: const Duration(milliseconds: 250),
                  child: IconButton(
                    onPressed: () => Navigator.of(context).pop(),
                    icon: const Icon(Icons.close, color: Colors.white),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// 从正文中提取所有 [视频](xxx) 媒体代号/链接。
List<String> extractVideoUrls(String content) {
  return RegExp(r'\[视频\]\(([^)]+)\)')
      .allMatches(content)
      .map((m) => m.group(1)!)
      .map((raw) => ApiClient.resourceUrl(raw))
      .toList();
}

/// 大图查看：点击放大、缩放、拖动。
class ImageViewer extends StatelessWidget {
  final String url;
  const ImageViewer({super.key, required this.url});

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.black,
      insetPadding: const EdgeInsets.all(8),
      child: Stack(
        children: [
          Positioned.fill(
            child: InteractiveViewer(
              minScale: 0.5,
              maxScale: 6,
              child: Center(
                child: Image.network(
                  url,
                  fit: BoxFit.contain,
                  loadingBuilder: (_, child, p) =>
                      p == null ? child : const Center(child: CircularProgressIndicator()),
                  errorBuilder: (_, __, ___) =>
                      const Icon(Icons.broken_image, color: Colors.white, size: 64),
                ),
              ),
            ),
          ),
          Positioned(
            top: 4,
            right: 4,
            child: IconButton(
              onPressed: () => Navigator.of(context).pop(),
              icon: const Icon(Icons.close, color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }
}

/// 构建帖子正文渲染：Markdown + 图片点击放大 + 内嵌视频 + @提及可点击跳转。
class PostContentRenderer extends StatelessWidget {
  final String content;
  final BuildContext hostContext;

  const PostContentRenderer({super.key, required this.content, required this.hostContext});

  /// 把 @PUID:xxx / @UID:xxx / @username 转成自定义 scheme 的 markdown 链接
  static String _mentionsToLinks(String content) {
    return content.replaceAllMapped(
      RegExp(r'@PUID:(P[A-Za-z0-9]{10})|@UID:([A-Za-z0-9]{4,32})|@([\w\u4e00-\u9fa5\-]{3,32})'),
      (m) {
        if (m.group(1) != null) {
          return '[@PUID:${m.group(1)}](forum://puid/${m.group(1)})';
        }
        if (m.group(2) != null) {
          return '[@UID:${m.group(2)}](forum://uid/${m.group(2)})';
        }
        return '[@${m.group(3)}](forum://user/${Uri.encodeComponent(m.group(3)!)})';
      },
    );
  }

  Future<void> _handleLink(BuildContext context, String url) async {
    if (url.startsWith('forum://puid/')) {
      Navigator.of(context).push(MaterialPageRoute(
        builder: (_) => PuidPostScreen(
            puid: url.substring('forum://puid/'.length))));
    } else if (url.startsWith('forum://uid/')) {
      try {
        final d = await ApiClient.get('/api/users/by-uid/${url.substring('forum://uid/'.length)}');
        final id = (d['data'] as Map<String, dynamic>)['id'] as int;
        if (!context.mounted) return;
        Navigator.of(context).push(MaterialPageRoute(
            builder: (_) => UserHomeScreen(userId: id)));
      } catch (_) {
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('用户不存在')));
        }
      }
    } else if (url.startsWith('forum://user/')) {
      try {
        final name = Uri.decodeComponent(url.substring('forum://user/'.length));
        final d = await ApiClient.get('/api/users/by-name/${Uri.encodeComponent(name)}');
        final id = (d['data'] as Map<String, dynamic>)['id'] as int;
        if (!context.mounted) return;
        Navigator.of(context).push(MaterialPageRoute(
            builder: (_) => UserHomeScreen(userId: id)));
      } catch (_) {
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('用户不存在')));
        }
      }
    } else if (RegExp(r'^[a-zA-Z0-9]{12}$').hasMatch(url) ||
        url.startsWith('/uploads/') ||
        url.startsWith('/media/')) {
      // 附件（媒体代号/上传路径）：交给系统浏览器下载
      final full = ApiClient.resourceUrl(url);
      try {
        await launchUrl(Uri.parse(full), mode: LaunchMode.externalApplication);
      } catch (_) {
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('无法打开文件')));
        }
      }
    } else if (url.startsWith('http')) {
      // 普通外链交给系统浏览器
      try {
        await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
      } catch (_) {}
    }
  }

  @override
  Widget build(BuildContext context) {
    final videos = extractVideoUrls(content);
    // 剥离 [视频] 标记并转换 @提及为可点击链接
    final markdownContent = _mentionsToLinks(
        content.replaceAll(RegExp(r'\[视频\]\([^)]+\)\s*'), ''));
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // SelectionArea 提供长按选择/复制，MarkdownBody 保持 selectable:false 以支持链接点击
        SelectionArea(
          child: MarkdownBody(
            data: markdownContent,
            selectable: false,
            onTapLink: (text, href, title) => _handleLink(context, href ?? ''),
            imageBuilder: (uri, title, alt) {
            final url = ApiClient.resourceUrl(uri.toString());
            return GestureDetector(
              onTap: () => showDialog(
                context: context,
                builder: (_) => ImageViewer(url: url),
              ),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxHeight: 480),
                child: Image.network(
                  url,
                  fit: BoxFit.contain,
                  loadingBuilder: (_, child, p) => p == null
                      ? child
                      : const SizedBox(
                          height: 140,
                          child: Center(
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [CircularProgressIndicator(), SizedBox(height: 6), Text('图片加载中')],
                            ),
                          ),
                        ),
                  errorBuilder: (_, __, ___) =>
                      const SizedBox(height: 120, child: Center(child: Icon(Icons.broken_image))),
                ),
              ),
            );
          },
          ),
        ),
        if (videos.isNotEmpty) ...[
          const SizedBox(height: 8),
          ...videos.map((v) => Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: InlineVideo(url: v),
              )),
        ],
      ],
    );
  }
}
