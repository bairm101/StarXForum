import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../api/api_client.dart';
import '../auth/auth_state.dart';
import 'login_screen.dart';

/// 设备管理：查看已登录设备与历史登录设备，删除设备即强制退出该设备。
class DevicesScreen extends StatefulWidget {
  const DevicesScreen({super.key});

  @override
  State<DevicesScreen> createState() => _DevicesScreenState();
}

class _DevicesScreenState extends State<DevicesScreen> {
  List<Map<String, dynamic>> _devices = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final d = await ApiClient.get('/api/auth/me/devices');
      _devices = ((d['data'] as List).map((e) => e as Map<String, dynamic>)).toList();
    } catch (_) {
      _devices = [];
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _revoke(Map<String, dynamic> device) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('删除设备'),
        content: Text('删除后该设备将立即退出登录。\n设备：${device['deviceName'] ?? '未知设备'}'),
        actions: [
          TextButton(onPressed: () => Navigator.of(context).pop(false), child: const Text('取消')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () => Navigator.of(context).pop(true),
            child: const Text('删除'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    try {
      await ApiClient.delete('/api/auth/me/devices/${device['sid']}');
      await _load();
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('设备已删除，该设备已退出登录')));
    } on ApiException catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    }
  }

  Future<void> _logoutAll() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('一键退出所有设备'),
        content: const Text('将清空所有已保存设备并退出当前账号，确定继续？'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('取消')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('全部退出')),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await ApiClient.post('/api/auth/me/logout-all');
      if (!mounted) return;
      await context.read<AuthState>().logout();
      Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) => const LoginScreen()), (route) => false);
    } on ApiException catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('登录设备管理'),
        actions: [IconButton(icon: const Icon(Icons.logout), tooltip: '一键退出所有设备', onPressed: _logoutAll)],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _devices.isEmpty
              ? const Center(child: Text('暂无登录设备记录'))
              : RefreshIndicator(
                  onRefresh: _load,
                  child: ListView.builder(
                    itemCount: _devices.length,
                    itemBuilder: (_, i) {
                      final d = _devices[i];
                      final revoked = d['revoked'] == true;
                      return Card(
                        margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        child: ListTile(
                          leading: Icon(
                            revoked ? Icons.devices_other : Icons.smartphone,
                            color: revoked ? Colors.grey : Colors.indigo,
                          ),
                          title: Text(
                            d['deviceName']?.toString() ?? '未知设备',
                            style: TextStyle(
                              color: revoked ? Colors.grey : null,
                              decoration: revoked ? TextDecoration.lineThrough : null,
                            ),
                          ),
                          subtitle: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('登录时间：${_fmt(d['loginAt'])}'),
                              Text('最近活跃：${_fmt(d['lastSeenAt'])}'),
                              if (revoked) const Text('已退出登录', style: TextStyle(color: Colors.grey)),
                            ],
                          ),
                          trailing: revoked
                              ? null
                              : IconButton(
                                  icon: const Icon(Icons.logout, color: Colors.red),
                                  tooltip: '删除该设备',
                                  onPressed: () => _revoke(d),
                                ),
                        ),
                      );
                    },
                  ),
                ),
    );
  }

  String _fmt(dynamic v) {
    if (v == null) return '-';
    final dt = DateTime.tryParse(v.toString());
    if (dt == null) return v.toString();
    return '${dt.year}-${dt.month.toString().padLeft(2, '0')}-${dt.day.toString().padLeft(2, '0')} '
        '${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
  }
}
