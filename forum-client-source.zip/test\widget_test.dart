import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:forum_client/main.dart';

void main() {
  testWidgets('Forum app smoke test', (WidgetTester tester) async {
    await tester.pumpWidget(const ForumApp());
    expect(find.byType(MaterialApp), findsOneWidget);
  });
}
