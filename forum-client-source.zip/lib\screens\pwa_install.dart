import 'package:flutter/foundation.dart';

/// 非 Web 平台：不支持 PWA 安装。
bool pwaInstallable() => false;

void requestPwaInstall() {
  if (kIsWeb) return;
}
