import 'package:flutter/foundation.dart';
import '../api/api_client.dart';

class AuthState extends ChangeNotifier {
  String? _token;
  int? _userId;
  String? _uid;
  String? _username;
  String? _displayName;
  String _role = 'USER';
  String? _avatarUrl;
  bool _initialized = false;

  int? get userId => _userId;
  String? get uid => _uid;
  String? get username => _username;
  String? get displayName => _displayName;
  String get role => _role;
  String? get avatarUrl => _avatarUrl;
  bool get isLoggedIn => _token != null;
  bool get initialized => _initialized;

  bool get isOwner => _role == 'OWNER';
  bool get isSuperAdmin => _role == 'SUPER_ADMIN';
  bool get isAdmin => _role == 'ADMIN';

  /// 站长/超管/管理员任一
  bool get isStaff => isOwner || isSuperAdmin || isAdmin;

  Future<void> init() async {
    await ApiClient.init();
    _token = ApiClient.token;
    _initialized = true;
    if (_token != null) {
      try {
        final d = await ApiClient.get('/api/auth/me');
        final user = d['data'] as Map<String, dynamic>;
        _userId = user['id'] as int?;
        _uid = user['uid'] as String?;
        _username = user['username'] as String?;
        _displayName = user['displayName'] as String? ?? _username;
        _role = (user['role'] as String?) ?? 'USER';
        _avatarUrl = user['avatarUrl'] as String?;
      } catch (_) {
        await logout();
      }
    }
    notifyListeners();
  }

  void _applyUser(Map<String, dynamic> user) {
    _userId = user['id'] as int?;
    _uid = user['uid'] as String?;
    _username = user['username'] as String?;
    _displayName = user['displayName'] as String? ?? _username;
    _role = (user['role'] as String?) ?? 'USER';
    _avatarUrl = user['avatarUrl'] as String?;
  }

  /// 登录。返回服务端登录响应；若 pendingDeviceId 非空，表示需要换设备二次验证，
  /// 此时未设置 token，调用方应引导用户输入邮箱验证码。
  Future<Map<String, dynamic>> login(String username, String password,
      {String? deviceId, String? deviceName}) async {
    final d = await ApiClient.post('/api/auth/login', body: {
      'username': username,
      'password': password,
      'deviceId': deviceId,
      'deviceName': deviceName,
    });
    final data = d['data'] as Map<String, dynamic>;
    final pending = data['pendingDeviceId'] as String?;
    if (pending != null && pending.isNotEmpty) {
      return data; // 需要二次验证
    }
    final token = data['token'] as String;
    await ApiClient.setToken(token);
    _token = token;
    _applyUser(data['user'] as Map<String, dynamic>);
    notifyListeners();
    return data;
  }

  /// 换设备二次验证：提交邮箱验证码完成登录。
  Future<void> verifyDevice(String username, String code,
      {String? deviceId, String? deviceName}) async {
    final d = await ApiClient.post('/api/auth/verify-device', body: {
      'username': username,
      'code': code,
      'deviceId': deviceId,
      'deviceName': deviceName,
    });
    final data = d['data'] as Map<String, dynamic>;
    final token = data['token'] as String;
    await ApiClient.setToken(token);
    _token = token;
    _applyUser(data['user'] as Map<String, dynamic>);
    notifyListeners();
  }

  Future<void> register(String username, String password, String nickname, {String? email, String? emailCode}) async {
    final d = await ApiClient.post('/api/auth/register',
        body: {'username': username, 'password': password, 'nickname': nickname, 'email': email, 'emailCode': emailCode});
    final data = d['data'] as Map<String, dynamic>;
    final token = data['token'] as String;
    await ApiClient.setToken(token);
    _token = token;
    _applyUser(data['user'] as Map<String, dynamic>);
    notifyListeners();
  }

  Future<void> logout() async {
    await ApiClient.setToken(null);
    _token = null;
    _userId = null;
    _uid = null;
    _username = null;
    _displayName = null;
    _role = 'USER';
    _avatarUrl = null;
    notifyListeners();
  }

  Future<void> refresh() async {
    if (!isLoggedIn) return;
    final d = await ApiClient.get('/api/auth/me');
    _applyUser(d['data'] as Map<String, dynamic>);
    notifyListeners();
  }

  Future<void> applyToken(String token) async {
    await ApiClient.setToken(token);
    _token = token;
    await refresh();
  }
}
