import 'package:flutter/material.dart';
import '../api/api_client.dart';
import '../models/models.dart';
import 'post_list_screen.dart';
import 'common.dart';

/// 板块列表页：点击板块进入该板块的帖子列表
class BoardsScreen extends StatefulWidget {
  const BoardsScreen({super.key});

  @override
  State<BoardsScreen> createState() => _BoardsScreenState();
}

class _BoardsScreenState extends State<BoardsScreen> {
  List<Board> _boards = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final d = await ApiClient.get('/api/boards');
      final list = (d['data'] as List)
          .map((e) => Board.fromJson(e as Map<String, dynamic>))
          .toList();
      setState(() {
        _boards = list;
        _loading = false;
      });
    } catch (e) {
      setState(() => _loading = false);
      _toast('加载板块失败');
    }
  }

  void _toast(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('板块')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _boards.isEmpty
              ? const Center(child: Text('暂无板块'))
              : RefreshIndicator(
                  onRefresh: _load,
                  child: ListView.separated(
                    padding: const EdgeInsets.all(12),
                    itemCount: _boards.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 10),
                    itemBuilder: (_, i) {
                      final b = _boards[i];
                      return Card(
                        elevation: 0,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14),
                          side: BorderSide(color: Colors.grey.shade200),
                        ),
                        child: ListTile(
                          leading: CircleAvatar(
                            backgroundColor: Colors.indigo.shade50,
                            child: Icon(Icons.forum, color: Colors.indigo.shade400),
                          ),
                          title: Text(b.name,
                              style: const TextStyle(fontWeight: FontWeight.w600)),
                          subtitle: Text(b.description ?? '',
                              maxLines: 1, overflow: TextOverflow.ellipsis),
                          trailing: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text('${b.postCount}',
                                  style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.indigo.shade400)),
                              Text('帖子',
                                  style: TextStyle(
                                      fontSize: 11, color: Colors.grey[600])),
                            ],
                          ),
                          onTap: () => Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (_) =>
                                  BoardPostsScreen(board: b),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
    );
  }
}

/// 单个板块的帖子列表
class BoardPostsScreen extends StatelessWidget {
  final Board board;
  const BoardPostsScreen({super.key, required this.board});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(board.name)),
      body: PostListScreen(boardId: board.id),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          final ok = await ensureLoggedIn(context);
          if (!ok) return;
          if (!context.mounted) return;
          await Navigator.of(context).push(
            MaterialPageRoute(builder: (_) => const PostEditorScreen()),
          );
        },
        child: const Icon(Icons.create),
      ),
    );
  }
}
