import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../auth/auth_state.dart';
import '../api/api_client.dart';
import '../models/models.dart';
import 'login_screen.dart';
import 'common.dart';
import 'admin_screen.dart';
import '../theme_state.dart';
import 'devices_screen.dart';
import 'notifications_screen.dart';
import 'about_screen.dart';
import 'user_home_screen.dart';
import 'favorites_screen.dart';
import 'blocked_users_screen.dart';
import 'package:image_picker/image_picker.dart';
import 'package:mobile_scanner/mobile_scanner.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthState>();

    if (!auth.isLoggedIn) {
      return Scaffold(
        appBar: AppBar(title: const Text('我的')),
        body: const LoginPrompt(text: '登录后查看个人资料'),
      );
    }

    return Scaffold(
      appBar: AppBar(title: const Text('我的')),
      body: ListView(
        children: [
          Padding(
            padding: const EdgeInsets.all(24),
            child: GestureDetector(
              onTap: () {
                final uid = auth.userId;
                if (uid != null) {
                  Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => UserHomeScreen(userId: uid)),
                  );
                }
              },
              child: Row(
                children: [
                  CircleAvatar(
                    radius: 30,
                    backgroundImage: auth.avatarUrl == null || auth.avatarUrl!.isEmpty
                        ? null
                        : NetworkImage(ApiClient.resourceUrl(auth.avatarUrl)),
                    child: Text(
                      auth.avatarUrl == null || auth.avatarUrl!.isEmpty ? (auth.displayName ?? '?').characters.first : '',
                      style: const TextStyle(fontSize: 24),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text(auth.displayName ?? '未登录',
                              style: Theme.of(context).textTheme.titleLarge),
                          if (auth.isStaff) ...[
                            const SizedBox(width: 8),
                            _roleBadge(auth.role),
                          ],
                        ],
                      ),
                      const SizedBox(height: 4),
                      Text(
                        '@${auth.username ?? ''}',
                        style: TextStyle(color: Colors.grey[600]),
                      ),
                      if (auth.uid != null && auth.uid!.isNotEmpty) ...[
                        const SizedBox(height: 2),
                        GestureDetector(
                          onTap: () async {
                            await Clipboard.setData(ClipboardData(text: auth.uid!));
                            if (context.mounted) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(content: Text('UID ${auth.uid} 已复制')));
                            }
                          },
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text('UID: ${auth.uid}',
                                  style: TextStyle(fontSize: 12, color: Colors.indigo.shade600)),
                              const SizedBox(width: 4),
                              const Icon(Icons.copy, size: 13, color: Colors.grey),
                            ],
                          ),
                        ),
                      ],
                    ],
                  ),
                  const Spacer(),
                  Icon(Icons.chevron_right, color: Colors.grey[400]),
                ],
              ),
            ),
          ),
          const CheckinCard(),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.brightness_6),
            title: const Text('日夜主题'),
            trailing: DropdownButton<ThemeMode>(
              value: context.watch<ThemeState>().mode,
              underline: const SizedBox.shrink(),
              items: const [
                DropdownMenuItem(value: ThemeMode.system, child: Text('跟随系统')),
                DropdownMenuItem(value: ThemeMode.light, child: Text('日间')),
                DropdownMenuItem(value: ThemeMode.dark, child: Text('夜间')),
              ],
              onChanged: (v) { if (v != null) context.read<ThemeState>().set(v); },
            ),
          ),
          ListTile(
            leading: const Icon(Icons.lock_reset),
            title: const Text('修改密码'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => _showChangePassword(context),
          ),
          ListTile(
            leading: const Icon(Icons.email_outlined),
            title: const Text('修改邮箱'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => _showChangeEmail(context),
          ),
          ListTile(
            leading: const Icon(Icons.edit),
            title: const Text('编辑资料、头像与签名'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => _editProfile(context),
          ),
          ListTile(leading:const Icon(Icons.qr_code_scanner),title:const Text('扫码授权登录'),trailing:const Icon(Icons.chevron_right),onTap:()=>_scanQr(context)),
          ListTile(
            leading: const Icon(Icons.bookmark_outline),
            title: const Text('我的收藏'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const FavoritesScreen()),
            ),
          ),
          ListTile(
            leading: const Icon(Icons.notifications_outlined),
            title: const Text('消息通知'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const NotificationsScreen()),
            ),
          ),
          ListTile(
            leading: const Icon(Icons.block_outlined),
            title: const Text('我的黑名单'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () {
              final uid = auth.userId;
              if (uid != null) {
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => BlockedUsersScreen(userId: uid)),
                );
              }
            },
          ),
          ListTile(
            leading: const Icon(Icons.devices),
            title: const Text('登录设备管理'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const DevicesScreen()),
            ),
          ),
          if (auth.isStaff)
            ListTile(
              leading: const Icon(Icons.admin_panel_settings),
              title: const Text('管理后台'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const AdminScreen()),
              ),
            ),
          ListTile(
            leading: const Icon(Icons.info_outline),
            title: const Text('关于'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const AboutScreen()),
            ),
          ),
          ListTile(
            leading: const Icon(Icons.person_remove_outlined, color: Colors.red),
            title: const Text('注销账号', style: TextStyle(color: Colors.red)),
            onTap: () => _cancelAccount(context, auth),
          ),
          ListTile(
            leading: const Icon(Icons.logout),
            title: const Text('退出登录'),
            onTap: () async {
              await auth.logout();
              if (!context.mounted) return;
              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const LoginScreen()),
                (route) => false,
              );
            },
          ),
        ],
      ),
    );
  }

  /// 注销账号：二次确认后调用后端级联删除，随后清除本地登录态
  Future<void> _cancelAccount(BuildContext context, AuthState auth) async {
    final step1 = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('注销账号'),
        content: const Text(
          '注销后：\n'
          '· 您发布的所有帖子将被永久删除；\n'
          '· 您上传的图片、视频、文件将被永久删除；\n'
          '· 您的评论将保留，但署名显示为「账号已注销」；\n'
          '· 账号无法再登录，用户名与邮箱信息将被清除。\n\n'
          '此操作不可恢复，确定继续吗？',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.of(context).pop(false), child: const Text('再想想')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () => Navigator.of(context).pop(true),
            child: const Text('继续注销'),
          ),
        ],
      ),
    );
    if (step1 != true || !context.mounted) return;
    final step2 = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('最后确认'),
        content: const Text('所有帖子与上传文件将被立即删除且无法找回。确认注销吗？'),
        actions: [
          TextButton(onPressed: () => Navigator.of(context).pop(false), child: const Text('取消')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () => Navigator.of(context).pop(true),
            child: const Text('确认注销'),
          ),
        ],
      ),
    );
    if (step2 != true || !context.mounted) return;
    try {
      await ApiClient.post('/api/auth/cancel');
      await auth.logout();
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('账号已注销')));
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const LoginScreen()),
        (route) => false,
      );
    } on ApiException catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
      }
    } catch (_) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('注销失败，请稍后重试')));
      }
    }
  }

  Widget _roleBadge(String role) {
    final (label, color) = switch (role) {
      'OWNER' => ('站长', Colors.deepOrange),
      'SUPER_ADMIN' => ('超级管理员', Colors.purple),
      'ADMIN' => ('管理员', Colors.blue),
      _ => ('', Colors.grey),
    };
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Text(label, style: TextStyle(fontSize: 11, color: color, fontWeight: FontWeight.w600)),
    );
  }

  Future<void> _showChangePassword(BuildContext context) async {
    final oldCtrl = TextEditingController();
    final newCtrl = TextEditingController();
    final confirmCtrl = TextEditingController();

    final submit = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('修改密码'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: oldCtrl, obscureText: true,
                decoration: const InputDecoration(labelText: '原密码', border: OutlineInputBorder())),
            const SizedBox(height: 10),
            TextField(controller: newCtrl, obscureText: true,
                decoration: const InputDecoration(labelText: '新密码（至少8位）', border: OutlineInputBorder())),
            const SizedBox(height: 10),
            TextField(controller: confirmCtrl, obscureText: true,
                decoration: const InputDecoration(labelText: '确认新密码', border: OutlineInputBorder())),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.of(context).pop(false), child: const Text('取消')),
          FilledButton(onPressed: () => Navigator.of(context).pop(true), child: const Text('确定')),
        ],
      ),
    );

    if (submit != true) return;
    if (newCtrl.text != confirmCtrl.text) {
      _toast(context, '两次输入的新密码不一致');
      return;
    }
    try {
      await ApiClient.post('/api/auth/change-password',
          body: {'oldPassword': oldCtrl.text, 'newPassword': newCtrl.text});
      if (context.mounted) _toast(context, '密码修改成功');
    } on ApiException catch (e) {
      if (context.mounted) _toast(context, e.message);
    } catch (e) {
      if (context.mounted) _toast(context, '修改失败');
    }
  }

  /// 修改邮箱：先发送验证码到新邮箱，再确认。
  Future<void> _showChangeEmail(BuildContext context) async {
    final emailCtrl = TextEditingController();
    final codeCtrl = TextEditingController();
    var codeSent = false;
    var cooldown = 0;
    Timer? cdTimer;

    final result = await showDialog<String>(
      context: context,
      builder: (dialog) => StatefulBuilder(
        builder: (dialogContext, setDialogState) {
          void startCooldown() {
            cooldown = 60;
            cdTimer?.cancel();
            cdTimer = Timer.periodic(const Duration(seconds: 1), (t) {
              if (cooldown <= 1) {
                t.cancel();
                if (dialogContext.mounted) setDialogState(() => cooldown = 0);
              } else {
                cooldown--;
                if (dialogContext.mounted) setDialogState(() {});
              }
            });
          }

          return AlertDialog(
          title: const Text('修改邮箱'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: emailCtrl,
                keyboardType: TextInputType.emailAddress,
                decoration: const InputDecoration(
                    labelText: '新邮箱', border: OutlineInputBorder()),
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: codeCtrl,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(
                          labelText: '验证码', border: OutlineInputBorder()),
                    ),
                  ),
                  const SizedBox(width: 8),
                  OutlinedButton(
                    onPressed: (cooldown > 0)
                        ? null
                        : () async {
                            if (emailCtrl.text.trim().isEmpty) {
                              ScaffoldMessenger.of(dialogContext).showSnackBar(
                                  const SnackBar(content: Text('请先填写新邮箱')));
                              return;
                            }
                            try {
                              await ApiClient.post('/api/auth/change-email/send',
                                  body: {'newEmail': emailCtrl.text.trim()});
                              setDialogState(() => codeSent = true);
                              if (dialogContext.mounted) {
                                ScaffoldMessenger.of(dialogContext).showSnackBar(
                                    const SnackBar(content: Text('验证码已发送')));
                                startCooldown();
                              }
                            } on ApiException catch (e) {
                              if (dialogContext.mounted) {
                                ScaffoldMessenger.of(dialogContext)
                                    .showSnackBar(SnackBar(content: Text(e.message)));
                              }
                            }
                          },
                    child: Text(cooldown > 0
                        ? '${cooldown}s'
                        : (codeSent ? '重新发送' : '发送验证码')),
                  ),
                ],
              ),
            ],
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.of(dialogContext).pop(),
                child: const Text('取消')),
            FilledButton(
                onPressed: () =>
                    Navigator.of(dialogContext).pop('confirm'),
                child: const Text('确认修改')),
          ],
        );
        },
      ),
    );
    cdTimer?.cancel();

    if (result != 'confirm') return;
    if (emailCtrl.text.trim().isEmpty || codeCtrl.text.trim().isEmpty) {
      _toast(context, '请填写邮箱和验证码');
      return;
    }
    try {
      await ApiClient.post('/api/auth/change-email',
          body: {'newEmail': emailCtrl.text.trim(), 'code': codeCtrl.text.trim()});
      if (context.mounted) _toast(context, '邮箱修改成功');
    } on ApiException catch (e) {
      if (context.mounted) _toast(context, e.message);
    } catch (e) {
      if (context.mounted) _toast(context, '修改失败');
    }
  }

  Future<void> _editProfile(BuildContext context) async {
    final me = await ApiClient.get('/api/auth/me');
    final u = me['data'] as Map<String, dynamic>;
    final username = TextEditingController(text: u['username']?.toString());
    final nick = TextEditingController(text: u['nickname']?.toString());
    final sig = TextEditingController(text: u['signature']?.toString());
    String avatar = u['avatarUrl']?.toString() ?? '';
    final ok = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('编辑资料'),
        content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: username, decoration: const InputDecoration(labelText: '用户名')),
          TextField(controller: nick, decoration: const InputDecoration(labelText: '昵称')),
          TextField(controller: sig, maxLines: 3, decoration: const InputDecoration(labelText: '签名')),
          OutlinedButton.icon(
            onPressed: () async {
              final x = await ImagePicker().pickImage(source: ImageSource.gallery);
              if (x == null) return;
              final d = await ApiClient.upload('/api/files/media', await x.readAsBytes(), x.name, type: 'avatar');
              avatar = (d['data'] as Map<String, dynamic>)['url'].toString();
            },
            icon: const Icon(Icons.photo), label: const Text('上传头像')),
        ])),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('取消')),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('保存')),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await ApiClient.put('/api/auth/me', body: {'username': username.text, 'nickname': nick.text, 'signature': sig.text, 'avatarUrl': avatar});
      if (context.mounted) await context.read<AuthState>().refresh();
      _toast(context, '资料已更新，签名如需审核会进入待审');
    } on ApiException catch (e) { _toast(context, e.message); }
  }

  void _toast(BuildContext context, String m) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }


  Future<void> _scanQr(BuildContext context) async {
    final controller=MobileScannerController();
    final result = await Navigator.push<String>(
      context,
      MaterialPageRoute(builder: (scanContext) => Scaffold(
        appBar: AppBar(title: const Text('扫描登录二维码')),
        body: MobileScanner(controller: controller,
          errorBuilder: (context, error) => Center(child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children:[
            const Icon(Icons.camera_alt_outlined, size:56),
            const SizedBox(height:12),
            const Text('无法打开摄像头，请检查相机权限'),
            const SizedBox(height:8),
            Text('${error.errorCode.name}: ${error.errorDetails?.message ?? error.errorCode.message}', style: const TextStyle(fontSize:12), textAlign: TextAlign.center),
          ]))),
          onDetect: (capture) {
          for (final b in capture.barcodes) {
            final v = b.rawValue;
            if (v != null && v.startsWith('forum://qr-login')) {
              Navigator.pop(scanContext, v);
              break;
            }
          }
        }),
      )),
    );
    controller.dispose(); if(result==null)return;
    final u=Uri.tryParse(result);if(u==null)return;final session=u.queryParameters['session'];final token=u.queryParameters['token'];if(session==null||token==null){_toast(context,'二维码无效');return;}
    final ok=await showDialog<bool>(context:context,builder:(_)=>AlertDialog(title:const Text('确认登录授权'),content:const Text('确认后，另一台设备将登录当前账号。'),actions:[TextButton(onPressed:()=>Navigator.pop(context,false),child:const Text('取消')),FilledButton(onPressed:()=>Navigator.pop(context,true),child:const Text('确认'))]));
    if(ok==true){try{await ApiClient.post('/api/qr-login/approve',body:{'sessionId':session,'token':token});_toast(context,'已授权');}on ApiException catch(e){_toast(context,e.message);}}
  }
}

/// 签到卡片：等级进度、金币、连续签到、签到按钮
class CheckinCard extends StatefulWidget {
  const CheckinCard({super.key});

  @override
  State<CheckinCard> createState() => _CheckinCardState();
}

class _CheckinCardState extends State<CheckinCard> {
  CheckinStatus? _status;
  bool _loading = true;
  bool _submitting = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final d = await ApiClient.get('/api/checkin/status');
      setState(() {
        _status = CheckinStatus.fromJson(d['data'] as Map<String, dynamic>);
        _loading = false;
      });
    } catch (e) {
      setState(() => _loading = false);
    }
  }

  Future<void> _checkin() async {
    if (_submitting) return;
    setState(() => _submitting = true);
    try {
      final d = await ApiClient.post('/api/checkin');
      final r = CheckinResult.fromJson(d['data'] as Map<String, dynamic>);
      await _load();
      if (!mounted) return;
      _showResult(r);
    } on ApiException catch (e) {
      if (!mounted) return;
      _toast(e.message);
    } catch (e) {
      if (!mounted) return;
      _toast('签到失败');
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  void _showResult(CheckinResult r) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Row(
          children: [
            const Icon(Icons.celebration, color: Colors.amber),
            const SizedBox(width: 8),
            Text(r.leveledUp ? '签到成功，升级啦！' : '签到成功'),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('获得金币 +${r.goldGain}'),
            Text('获得经验 +${r.expGain}'),
            if (r.leveledUp)
              Text('当前等级 Lv.${r.level}',
                  style: const TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text('连续签到 ${r.streak} 天'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('好的'),
          ),
        ],
      ),
    );
  }

  void _toast(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Padding(
        padding: EdgeInsets.all(16),
        child: Center(child: CircularProgressIndicator()),
      );
    }
    final s = _status;
    if (s == null) {
      return const SizedBox.shrink();
    }

    final maxLevel = 10;
    final isMax = s.level >= maxLevel;
    final progress = isMax || s.nextLevelExp <= 0
        ? 1.0
        : (s.exp / s.nextLevelExp).clamp(0.0, 1.0);

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Colors.indigo.shade400, Colors.indigo.shade600],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CircleAvatar(
                backgroundColor: Colors.white,
                child: Text('Lv${s.level}',
                    style: TextStyle(
                        color: Colors.indigo.shade700,
                        fontWeight: FontWeight.bold)),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(isMax ? '已满级' : 'Lv.${s.level} → Lv.${s.level + 1}',
                        style: const TextStyle(
                            color: Colors.white, fontWeight: FontWeight.w600)),
                    const SizedBox(height: 4),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(6),
                      child: LinearProgressIndicator(
                        value: progress,
                        minHeight: 8,
                        backgroundColor: Colors.white24,
                        valueColor:
                            const AlwaysStoppedAnimation<Color>(Colors.amber),
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      isMax
                          ? '经验 ${s.exp}'
                          : '经验 ${s.exp} / ${s.nextLevelExp}（停留 ${s.daysStayedAtLevel} 天）',
                      style: const TextStyle(color: Colors.white70, fontSize: 12),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              _chip(Icons.monetization_on, '${s.gold}', Colors.amber),
              const SizedBox(width: 10),
              _chip(Icons.local_fire_department, '连签 ${s.streak} 天', Colors.orange),
              const Spacer(),
              FilledButton(
                onPressed: (s.checkedToday || _submitting) ? null : _checkin,
                style: FilledButton.styleFrom(
                  backgroundColor: Colors.white,
                  foregroundColor: Colors.indigo.shade700,
                ),
                child: _submitting
                    ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : Text(s.checkedToday ? '今日已签到' : '签到'),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _chip(IconData icon, String text, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.white24,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        children: [
          Icon(icon, size: 16, color: color),
          const SizedBox(width: 4),
          Text(text, style: const TextStyle(color: Colors.white, fontSize: 13)),
        ],
      ),
    );
  }
}

