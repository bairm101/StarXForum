import 'package:flutter/material.dart';
import '../api/api_client.dart';
import 'post_detail_screen.dart';

/// 系统通知列表 + 通知偏好开关。
class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({super.key});

  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  List<Map<String, dynamic>> _items = [];
  Map<String, dynamic> _settings = {};
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final d = await ApiClient.get('/api/notifications', query: {'size': '50'});
      _items = ((d['data'] as Map<String, dynamic>)['items'] as List)
          .map((e) => e as Map<String, dynamic>)
          .toList();
      final s = await ApiClient.get('/api/notifications/settings');
      _settings = s['data'] as Map<String, dynamic>;
    } catch (_) {
      _items = [];
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _markAllRead() async {
    try {
      await ApiClient.patch('/api/notifications/read-all');
      await _load();
    } catch (_) {}
  }

  Future<void> _toggle(String key, bool value) async {
    setState(() => _settings[key] = value);
    try {
      await ApiClient.patch('/api/notifications/settings', body: {key: value});
    } catch (_) {
      await _load();
    }
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('消息通知'),
          actions: [
            IconButton(
              icon: const Icon(Icons.done_all),
              tooltip: '全部标为已读',
              onPressed: _markAllRead,
            ),
          ],
          bottom: const TabBar(
            tabs: [Tab(text: '通知'), Tab(text: '公告'), Tab(text: '通知设置')],
            labelColor: Colors.indigo,
            indicatorColor: Colors.indigo,
          ),
        ),
        body: TabBarView(
          children: [
            _buildList(null),
            _buildList('ANNOUNCEMENT'),
            ListView(
              children: [
                SwitchListTile(
                  title: const Text('系统公告'),
                  subtitle: const Text('站长发布的系统公告'),
                  value: _settings['enableAnnouncement'] == true,
                  onChanged: (v) => _toggle('enableAnnouncement', v),
                ),
                SwitchListTile(
                  title: const Text('审核结果'),
                  subtitle: const Text('帖子审核通过/驳回时通知'),
                  value: _settings['enableModeration'] == true,
                  onChanged: (v) => _toggle('enableModeration', v),
                ),
                SwitchListTile(
                  title: const Text('被评论与@提及'),
                  subtitle: const Text('有人回复你的帖子或 @ 你时通知'),
                  value: _settings['enableComment'] == true,
                  onChanged: (v) => _toggle('enableComment', v),
                ),
                SwitchListTile(
                  title: const Text('被点赞'),
                  subtitle: const Text('有人赞你的帖子/评论时通知'),
                  value: _settings['enableLike'] == true,
                  onChanged: (v) => _toggle('enableLike', v),
                ),
                SwitchListTile(
                  title: const Text('新设备登录'),
                  subtitle: const Text('检测到新设备登录时通知'),
                  value: _settings['enableDeviceLogin'] == true,
                  onChanged: (v) => _toggle('enableDeviceLogin', v),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildList(String? typeFilter) {
    if (_loading) return const Center(child: CircularProgressIndicator());
    final items = typeFilter == null
        ? _items
        : _items.where((e) => e['type']?.toString() == typeFilter).toList();
    if (items.isEmpty) return const Center(child: Text('暂无'));
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView.builder(
        itemCount: items.length,
        itemBuilder: (_, i) {
          final n = items[i];
          final read = n['read'] == true;
          return Card(
            margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            child: ListTile(
              leading: Icon(_icon(n['type']?.toString()),
                  color: read ? Colors.grey : Colors.indigo),
              title: Text(n['title']?.toString() ?? '',
                  style: TextStyle(
                    fontWeight: read ? FontWeight.normal : FontWeight.w600,
                    color: read ? Colors.grey : null,
                  )),
              subtitle: Text(n['content']?.toString() ?? ''),
              onTap: () async {
                try {
                  await ApiClient.patch('/api/notifications/${n['id']}/read');
                } catch (_) {}
                setState(() => n['read'] = true);
                final ref = n['refId'] as int?;
                if (ref != null && context.mounted) {
                  await Navigator.of(context).push(MaterialPageRoute(
                    builder: (_) => PostDetailScreen(postId: ref),
                  ));
                }
              },
            ),
          );
        },
      ),
    );
  }

  IconData _icon(String? type) => switch (type) {
        'ANNOUNCEMENT' => Icons.campaign,
        'MODERATION_APPROVED' => Icons.check_circle,
        'MODERATION_REJECTED' => Icons.cancel,
        'COMMENT' => Icons.comment,
        'MENTION' => Icons.alternate_email,
        'REPORT' => Icons.flag,
        'LIKE' => Icons.thumb_up,
        'DEVICE_LOGIN' => Icons.phonelink_lock,
        _ => Icons.notifications,
      };
}
