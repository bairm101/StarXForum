import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

import '../api/api_client.dart';
import '../auth/auth_state.dart';
import '../models/models.dart';
import 'post_detail_screen.dart';
import 'media_widgets.dart';
import 'follow_list_screen.dart';

/// 用户主页：展示用户资料、帖子、评论。
class UserHomeScreen extends StatefulWidget {
  final int userId;
  const UserHomeScreen({super.key, required this.userId});

  @override
  State<UserHomeScreen> createState() => _UserHomeScreenState();
}

class _UserHomeScreenState extends State<UserHomeScreen>
    with SingleTickerProviderStateMixin {
  late final TabController _tabCtrl;
  Map<String, dynamic>? _profile;
  List<PostSummary> _posts = [];
  List<Map<String, dynamic>> _comments = [];
  bool _loading = true;
  Map<String, dynamic>? _followStatus;
  bool _profileError = false;

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: 3, vsync: this);
    _load();
  }

  @override
  void dispose() {
    _tabCtrl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final p = await ApiClient.get('/api/users/${widget.userId}/profile');
      final posts = await ApiClient.get(
        '/api/users/${widget.userId}/posts',
        query: {'size': '50'},
      );
      final comments = await ApiClient.get(
        '/api/users/${widget.userId}/comments',
        query: {'size': '50'},
      );
      Map<String, dynamic>? fs;
      if (context.read<AuthState>().isLoggedIn) {
        try {
          final f = await ApiClient.get(
            '/api/users/${widget.userId}/follow-status',
          );
          fs = f['data'] as Map<String, dynamic>;
        } catch (_) {}
      }
      setState(() {
        _profile = p['data'] as Map<String, dynamic>;
        _posts = ((posts['data'] as Map<String, dynamic>)['items'] as List)
            .map((e) => PostSummary.fromJson(e as Map<String, dynamic>))
            .toList();
        _comments =
            ((comments['data'] as Map<String, dynamic>)['items'] as List)
                .map((e) => e as Map<String, dynamic>)
                .toList();
        _followStatus = fs;
        _profileError = false;
        _loading = false;
      });
    } on ApiException catch (e) {
      if (mounted) {
        setState(() {
          _loading = false;
          _profileError = true;
          _profile = {'__error': e.message};
        });
      }
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _toggleFollow() async {
    final loggedIn = context.read<AuthState>().isLoggedIn;
    if (!loggedIn) return;
    final cur = (_followStatus?['isFollowing'] as bool?) ?? false;
    // 乐观更新：点击立即反馈
    setState(() => _followStatus = {...?_followStatus, 'isFollowing': !cur});
    try {
      await ApiClient.post('/api/users/${widget.userId}/follow');
      await _load();
    } catch (e) {
      if (mounted) {
        setState(() => _followStatus = {...?_followStatus, 'isFollowing': cur});
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('操作失败')));
      }
    }
  }

  Future<void> _toggleBlock() async {
    final ok = context.read<AuthState>().isLoggedIn;
    if (!ok) return;
    final blocking = (_followStatus?['iBlocked'] as bool?) ?? false;
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(blocking ? '解除拉黑' : '拉黑用户'),
        content: Text(
          blocking ? '解除对该用户的拉黑？' : '拉黑后对方将无法给你发私信、查看你的主页和帖子。确定继续？',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('取消'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            style: FilledButton.styleFrom(
              backgroundColor: blocking ? null : Colors.red,
            ),
            child: Text(blocking ? '解除拉黑' : '拉黑'),
          ),
        ],
      ),
    );
    if (confirm != true) return;
    try {
      await ApiClient.post('/api/users/${widget.userId}/block');
      await _load();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('操作失败')));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return Scaffold(
        appBar: AppBar(title: const Text('用户主页')),
        body: const Center(child: CircularProgressIndicator()),
      );
    }
    final profile = _profile;
    if (profile == null || _profileError) {
      final msg = _profileError
          ? (profile?['__error']?.toString() ?? '无法查看该用户')
          : '用户不存在';
      return Scaffold(
        appBar: AppBar(title: const Text('用户主页')),
        body: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.block, color: Colors.grey, size: 48),
              const SizedBox(height: 12),
              Text(msg),
            ],
          ),
        ),
      );
    }
    return Scaffold(
      appBar: AppBar(
        title: Text(profile['displayName']?.toString() ?? '用户主页'),
        actions: [
          IconButton(
            icon: const Icon(Icons.share_outlined),
            tooltip: '分享用户',
            onPressed: () async {
              final uid = profile['uid']?.toString();
              if (uid == null || uid.isEmpty) return;
              await Clipboard.setData(ClipboardData(text: 'UID:$uid'));
              if (context.mounted)
                ScaffoldMessenger.of(context)
                    .showSnackBar(const SnackBar(content: Text('UID 已复制')));
            },
          ),
          IconButton(
            icon: const Icon(Icons.flag_outlined),
            tooltip: '举报用户',
            onPressed: _reportUser,
          ),
        ],
      ),
      body: Column(
        children: [
          _buildHeader(profile),
          TabBar(
            controller: _tabCtrl,
            labelColor: Colors.indigo,
            indicatorColor: Colors.indigo,
            tabs: [
              Tab(text: '帖子 ${_posts.length}'),
              Tab(text: '评论 ${_comments.length}'),
              const Tab(text: '资料'),
            ],
          ),
          Expanded(
            child: TabBarView(
              controller: _tabCtrl,
              children: [
                _buildPosts(),
                _buildComments(),
                _buildProfile(profile),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _reportUser() async {
    if (!mounted) return;
    final ctrl = TextEditingController();
    final reason = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('举报用户'),
        content: TextField(
          controller: ctrl,
          maxLines: 3,
          decoration: const InputDecoration(
            labelText: '举报原因',
            hintText: '请填写违规原因，我们会尽快处理',
            border: OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('取消'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, ctrl.text.trim()),
            child: const Text('提交'),
          ),
        ],
      ),
    );
    if (reason == null || reason.isEmpty) return;
    try {
      await ApiClient.post(
        '/api/users/${widget.userId}/report',
        body: {'reason': reason},
      );
      if (mounted)
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('举报已提交')));
    } on ApiException catch (e) {
      if (mounted)
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(e.message)));
    } catch (_) {
      if (mounted)
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('提交失败')));
    }
  }

  Widget _buildHeader(Map<String, dynamic> profile) {
    final avatarUrl = profile['avatarUrl'] as String?;
    final fs = _followStatus;
    final followingCount = (fs?['followingCount'] as num?)?.toInt() ?? 0;
    final followerCount = (fs?['followerCount'] as num?)?.toInt() ?? 0;
    final isFollowing = (fs?['isFollowing'] as bool?) ?? false;
    final isMutual = (fs?['isMutual'] as bool?) ?? false;
    final iBlocked = (fs?['iBlocked'] as bool?) ?? false;
    final isSelf = context.read<AuthState>().userId == widget.userId;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      color: Colors.indigo.shade50,
      child: Column(
        children: [
          Row(
            children: [
              CircleAvatar(
                radius: 36,
                backgroundImage: avatarUrl != null && avatarUrl.isNotEmpty
                    ? NetworkImage(ApiClient.resourceUrl(avatarUrl))
                    : null,
                child: avatarUrl == null || avatarUrl.isEmpty
                    ? Text(
                        (profile['displayName']?.toString() ?? '?')
                            .characters
                            .first,
                        style: const TextStyle(fontSize: 28),
                      )
                    : null,
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      profile['displayName']?.toString() ?? '',
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '@${profile['username'] ?? ''}',
                      style: TextStyle(color: Colors.grey[600]),
                    ),
                    if ((profile['uid'] as String?) != null) ...[
                      const SizedBox(height: 2),
                      GestureDetector(
                        onTap: () async {
                          await Clipboard.setData(
                            ClipboardData(text: profile['uid'].toString()),
                          );
                          if (context.mounted) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content: Text('UID ${profile['uid']} 已复制'),
                              ),
                            );
                          }
                        },
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              'UID: ${profile['uid']}',
                              style: TextStyle(
                                fontSize: 12,
                                color: Colors.indigo.shade600,
                              ),
                            ),
                            const SizedBox(width: 4),
                            const Icon(
                              Icons.copy,
                              size: 13,
                              color: Colors.grey,
                            ),
                          ],
                        ),
                      ),
                    ],
                    if ((profile['signature'] as String?) != null) ...[
                      const SizedBox(height: 4),
                      Text(
                        profile['signature'].toString(),
                        style: TextStyle(color: Colors.grey[700], fontSize: 13),
                      ),
                    ],
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              GestureDetector(
                onTap: () => _openFollowList(widget.userId, follow: true),
                child: Text(
                  '关注 $followingCount',
                  style: const TextStyle(fontSize: 13, color: Colors.indigo),
                ),
              ),
              const SizedBox(width: 20),
              GestureDetector(
                onTap: () => _openFollowList(widget.userId, follow: false),
                child: Text(
                  '粉丝 $followerCount',
                  style: const TextStyle(fontSize: 13, color: Colors.indigo),
                ),
              ),
              if (isMutual)
                const Padding(
                  padding: EdgeInsets.only(left: 12),
                  child: Text(
                    '互关',
                    style: TextStyle(fontSize: 12, color: Colors.orange),
                  ),
                ),
              const Spacer(),
            ],
          ),
          if (!isSelf) ...[
            const SizedBox(height: 10),
            Row(
              children: [
                OutlinedButton.icon(
                  onPressed: _toggleFollow,
                  icon: Icon(
                    isFollowing ? Icons.check : Icons.person_add,
                    size: 16,
                  ),
                  label: Text(isFollowing ? '已关注' : '关注'),
                ),
                const SizedBox(width: 8),
                OutlinedButton.icon(
                  onPressed: _toggleBlock,
                  style: OutlinedButton.styleFrom(
                    foregroundColor: iBlocked ? null : Colors.red,
                  ),
                  icon: Icon(
                    iBlocked ? Icons.block : Icons.block_outlined,
                    size: 16,
                  ),
                  label: Text(iBlocked ? '已拉黑' : '拉黑'),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }

  void _openFollowList(int userId, {required bool follow}) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => FollowListScreen(userId: userId, follow: follow),
      ),
    );
  }

  Widget _buildPosts() {
    if (_posts.isEmpty) return const Center(child: Text('暂无帖子'));
    return ListView.builder(
      itemCount: _posts.length,
      itemBuilder: (_, i) {
        final p = _posts[i];
        return InkWell(
          onTap: () => Navigator.of(context).push(
            MaterialPageRoute(builder: (_) => PostDetailScreen(postId: p.id)),
          ),
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  p.title,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  p.excerpt,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(color: Colors.grey[600], fontSize: 13),
                ),
                if (p.thumbnailUrl != null && p.thumbnailUrl!.isNotEmpty) ...[
                  const SizedBox(height: 8),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: AspectRatio(
                      aspectRatio: 16 / 7,
                      child: Image.network(
                        ApiClient.resourceUrl(p.thumbnailUrl),
                        fit: BoxFit.cover,
                        loadingBuilder: (_, child, pr) => pr == null
                            ? child
                            : const SizedBox(
                                height: 120,
                                child: Center(
                                  child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      CircularProgressIndicator(),
                                      SizedBox(height: 6),
                                      Text('图片加载中'),
                                    ],
                                  ),
                                ),
                              ),
                        errorBuilder: (_, __, ___) => const SizedBox(
                          height: 100,
                          child: Center(child: Icon(Icons.broken_image)),
                        ),
                      ),
                    ),
                  ),
                ],
                const SizedBox(height: 8),
                Row(
                  children: [
                    Text(
                      p.boardName,
                      style: TextStyle(fontSize: 12, color: Colors.grey[600]),
                    ),
                    const SizedBox(width: 12),
                    Icon(
                      Icons.remove_red_eye_outlined,
                      size: 14,
                      color: Colors.grey[600],
                    ),
                    const SizedBox(width: 2),
                    Text(
                      '${p.viewCount}',
                      style: TextStyle(fontSize: 12, color: Colors.grey[600]),
                    ),
                    const SizedBox(width: 12),
                    Icon(
                      Icons.chat_bubble_outline,
                      size: 14,
                      color: Colors.grey[600],
                    ),
                    const SizedBox(width: 2),
                    Text(
                      '${p.commentCount}',
                      style: TextStyle(fontSize: 12, color: Colors.grey[600]),
                    ),
                    const Spacer(),
                    Text(
                      DateFormat('MM-dd HH:mm').format(p.createdAt),
                      style: TextStyle(fontSize: 12, color: Colors.grey[500]),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildComments() {
    if (_comments.isEmpty) return const Center(child: Text('暂无评论'));
    return ListView.builder(
      itemCount: _comments.length,
      itemBuilder: (_, i) {
        final c = _comments[i];
        return ListTile(
          title: Text(
            c['content']?.toString() ?? '',
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
          subtitle: Text(
            '${c['postId'] != null ? '帖子 #${c['postId']}' : ''} · ${DateFormat('MM-dd HH:mm').format(DateTime.parse(c['createdAt'].toString()))}',
            style: TextStyle(fontSize: 12, color: Colors.grey[600]),
          ),
        );
      },
    );
  }

  Widget _buildProfile(Map<String, dynamic> profile) {
    final items = <Widget>[
      _infoRow('用户名', profile['username']?.toString() ?? ''),
      _infoRow('等级', 'Lv.${profile['level'] ?? 1}'),
      _infoRow('经验', '${profile['exp'] ?? 0}'),
      _infoRow('金币', '${profile['gold'] ?? 0}'),
      _infoRow('帖子数', '${profile['postCount'] ?? 0}'),
      _infoRow('评论数', '${profile['commentCount'] ?? 0}'),
      _infoRow('注册时间', _fmtDate(profile['createdAt'])),
    ];
    return ListView(padding: const EdgeInsets.all(16), children: items);
  }

  Widget _infoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          SizedBox(
            width: 80,
            child: Text(label, style: TextStyle(color: Colors.grey[600])),
          ),
          Expanded(child: Text(value)),
        ],
      ),
    );
  }

  String _fmtDate(dynamic v) {
    if (v == null) return '-';
    final dt = DateTime.tryParse(v.toString());
    if (dt == null) return v.toString();
    return DateFormat('yyyy-MM-dd').format(dt);
  }
}
