import 'package:flutter/foundation.dart';
import 'api/api_client.dart';
import 'models/models.dart';

/// 站点全局配置（站长可在后台修改）
class SiteConfig extends ChangeNotifier {
  SiteSettings _settings = SiteSettings(
      siteName: '论坛', siteDescription: '', allowRegister: true);
  bool _loaded = false;

  SiteSettings get settings => _settings;
  bool get loaded => _loaded;
  String get siteName => _settings.siteName;
  String get pageTitle => _settings.pageTitle;
  String? get announcement => _settings.announcement;
  bool get allowRegister => _settings.allowRegister;
  String? get footerText => _settings.footerText;
  String? get footerIcp => _settings.footerIcp;
  String get footerLinksJson => _settings.footerLinksJson;
  String get officialWebsite => _settings.officialWebsite;
  String get webShareBaseUrl => _settings.webShareBaseUrl;
  String get contactEmail => _settings.contactEmail;
  String? get aboutIcp => _settings.aboutIcp;
  int get autoRefreshSeconds => _settings.autoRefreshSeconds;

  Future<void> load() async {
    try {
      final d = await ApiClient.get('/api/settings');
      _settings = SiteSettings.fromJson(d['data'] as Map<String, dynamic>);
    } catch (_) {
      // 保留默认
    }
    _loaded = true;
    notifyListeners();
  }
}
