import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'auth/auth_state.dart';
import 'site_config.dart';
import 'theme_state.dart';
import 'screens/home_screen.dart';
import 'screens/post_detail_screen.dart';
import 'screens/privacy_agreement_screen.dart';
import 'api/api_client.dart';

// 应用品牌色
const _brandPrimary = Color(0xFF4F46E5); // 靛紫蓝
const _brandSecondary = Color(0xFF0EA5E9); // 天蓝
const _brandSurfaceLight = Color(0xFFF8FAFC);
const _brandSurfaceDark = Color(0xFF0F172A);
const _brandError = Color(0xFFEF4444);

/// 构建浅色主题
ThemeData _buildLightTheme() {
  final scheme = ColorScheme.fromSeed(
    seedColor: _brandPrimary,
    brightness: Brightness.light,
    secondary: _brandSecondary,
    error: _brandError,
    surface: _brandSurfaceLight,
  );
  return ThemeData(
    colorScheme: scheme,
    useMaterial3: true,
    brightness: Brightness.light,
    scaffoldBackgroundColor: const Color(0xFFF1F5F9),
    cardTheme: CardThemeData(
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      color: Colors.white,
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      clipBehavior: Clip.antiAlias,
    ),
    appBarTheme: AppBarTheme(
      elevation: 0,
      scrolledUnderElevation: 0.5,
      centerTitle: true,
      backgroundColor: Colors.white,
      foregroundColor: scheme.onSurface,
      titleTextStyle: TextStyle(
        color: scheme.onSurface,
        fontSize: 18,
        fontWeight: FontWeight.w600,
      ),
    ),
    bottomNavigationBarTheme: BottomNavigationBarThemeData(
      backgroundColor: Colors.white,
      selectedItemColor: scheme.primary,
      unselectedItemColor: Colors.grey.shade500,
      type: BottomNavigationBarType.fixed,
      elevation: 2,
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: Colors.white,
      indicatorColor: scheme.primaryContainer,
      labelTextStyle: WidgetStateProperty.resolveWith((states) {
        final selected = states.contains(WidgetState.selected);
        return TextStyle(
          fontSize: 11,
          fontWeight: selected ? FontWeight.w600 : FontWeight.w500,
          color: selected ? scheme.primary : Colors.grey.shade600,
        );
      }),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: const Color(0xFFF8FAFC),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: Colors.grey.shade300),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: Colors.grey.shade300),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: scheme.primary, width: 2),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: scheme.error),
      ),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        textStyle: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        side: BorderSide(color: scheme.primary.withOpacity(0.5)),
      ),
    ),
    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      ),
    ),
    chipTheme: ChipThemeData(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      side: BorderSide.none,
      backgroundColor: Colors.grey.shade200,
      selectedColor: scheme.primaryContainer,
      labelStyle: const TextStyle(fontWeight: FontWeight.w500),
    ),
    dividerTheme: DividerThemeData(
      color: Colors.grey.shade200,
      thickness: 1,
      space: 1,
    ),
    snackBarTheme: SnackBarThemeData(
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      backgroundColor: _brandSurfaceDark,
    ),
    dialogTheme: DialogThemeData(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      backgroundColor: Colors.white,
    ),
    listTileTheme: ListTileThemeData(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
    ),
    textTheme: _buildTextTheme(Brightness.light),
  );
}

/// 构建深色主题
ThemeData _buildDarkTheme() {
  final scheme = ColorScheme.fromSeed(
    seedColor: _brandPrimary,
    brightness: Brightness.dark,
    secondary: _brandSecondary,
    error: _brandError,
    surface: _brandSurfaceDark,
  );
  return ThemeData(
    colorScheme: scheme,
    useMaterial3: true,
    brightness: Brightness.dark,
    scaffoldBackgroundColor: const Color(0xFF0B1120),
    cardTheme: CardThemeData(
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      color: const Color(0xFF1E293B),
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      clipBehavior: Clip.antiAlias,
    ),
    appBarTheme: AppBarTheme(
      elevation: 0,
      scrolledUnderElevation: 0.5,
      centerTitle: true,
      backgroundColor: _brandSurfaceDark,
      foregroundColor: scheme.onSurface,
      titleTextStyle: TextStyle(
        color: scheme.onSurface,
        fontSize: 18,
        fontWeight: FontWeight.w600,
      ),
    ),
    bottomNavigationBarTheme: BottomNavigationBarThemeData(
      backgroundColor: _brandSurfaceDark,
      selectedItemColor: scheme.primary,
      unselectedItemColor: Colors.grey.shade500,
      type: BottomNavigationBarType.fixed,
      elevation: 2,
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: _brandSurfaceDark,
      indicatorColor: scheme.primaryContainer.withOpacity(0.3),
      labelTextStyle: WidgetStateProperty.resolveWith((states) {
        final selected = states.contains(WidgetState.selected);
        return TextStyle(
          fontSize: 11,
          fontWeight: selected ? FontWeight.w600 : FontWeight.w500,
          color: selected ? scheme.primary : Colors.grey.shade500,
        );
      }),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: const Color(0xFF1E293B),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: Colors.grey.shade700),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: Colors.grey.shade700),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: scheme.primary, width: 2),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: scheme.error),
      ),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        textStyle: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        side: BorderSide(color: scheme.primary.withOpacity(0.5)),
      ),
    ),
    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      ),
    ),
    chipTheme: ChipThemeData(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      side: BorderSide.none,
      backgroundColor: const Color(0xFF334155),
      selectedColor: scheme.primaryContainer.withOpacity(0.3),
      labelStyle: const TextStyle(fontWeight: FontWeight.w500),
    ),
    dividerTheme: DividerThemeData(
      color: Colors.grey.shade800,
      thickness: 1,
      space: 1,
    ),
    snackBarTheme: SnackBarThemeData(
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      backgroundColor: const Color(0xFF1E293B),
    ),
    dialogTheme: DialogThemeData(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      backgroundColor: const Color(0xFF1E293B),
    ),
    listTileTheme: ListTileThemeData(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
    ),
    textTheme: _buildTextTheme(Brightness.dark),
  );
}

TextTheme _buildTextTheme(Brightness brightness) {
  final color = brightness == Brightness.light
      ? const Color(0xFF1E293B)
      : const Color(0xFFF1F5F9);
  final secondary = brightness == Brightness.light
      ? const Color(0xFF64748B)
      : const Color(0xFF94A3B8);
  return TextTheme(
    headlineLarge: TextStyle(
        fontSize: 32, fontWeight: FontWeight.bold, color: color, height: 1.2),
    headlineMedium: TextStyle(
        fontSize: 26, fontWeight: FontWeight.bold, color: color, height: 1.2),
    headlineSmall: TextStyle(
        fontSize: 22, fontWeight: FontWeight.w600, color: color, height: 1.3),
    titleLarge: TextStyle(
        fontSize: 18, fontWeight: FontWeight.w600, color: color, height: 1.3),
    titleMedium: TextStyle(
        fontSize: 16, fontWeight: FontWeight.w600, color: color, height: 1.4),
    titleSmall: TextStyle(
        fontSize: 14, fontWeight: FontWeight.w600, color: color, height: 1.4),
    bodyLarge: TextStyle(fontSize: 16, color: color, height: 1.5),
    bodyMedium: TextStyle(fontSize: 14, color: color, height: 1.5),
    bodySmall: TextStyle(fontSize: 12, color: secondary, height: 1.4),
    labelLarge: TextStyle(
        fontSize: 13, fontWeight: FontWeight.w600, color: color, height: 1.4),
    labelMedium: TextStyle(
        fontSize: 12, fontWeight: FontWeight.w500, color: secondary, height: 1.4),
    labelSmall: TextStyle(
        fontSize: 10, fontWeight: FontWeight.w500, color: secondary, height: 1.4),
  );
}

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const ForumApp());
}

final navigatorKey = GlobalKey<NavigatorState>();

class ForumApp extends StatelessWidget {
  const ForumApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthState()),
        ChangeNotifierProvider(create: (_) => SiteConfig()),
        ChangeNotifierProvider(create: (_) => ThemeState()),
      ],
      child: Consumer2<SiteConfig, ThemeState>(
        builder: (context, site, theme, _) {
          return MaterialApp(
            navigatorKey: navigatorKey,
            title: site.pageTitle,
            debugShowCheckedModeBanner: false,
            theme: _buildLightTheme(),
            darkTheme: _buildDarkTheme(),
            themeMode: theme.mode,
            home: const SplashScreen(),
          );
        },
      ),
    );
  }
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<String?> _clipboardPuid() async {
    try {
      final data = await Clipboard.getData(Clipboard.kTextPlain);
      final text = data?.text?.trim();
      if (text == null || text.isEmpty) return null;
      // 仅接受三种明确形式，避免任意文本误触发：
      // 1) 整段 = PUID:P1234567890
      var m = RegExp(r'^PUID\s*[:：]\s*(P[A-Za-z0-9]{10})$', caseSensitive: false).firstMatch(text);
      if (m != null) return m.group(1)!.toUpperCase();
      // 2) 整段 = 裸 P1234567890
      m = RegExp(r'^(P[A-Za-z0-9]{10})$', caseSensitive: false).firstMatch(text);
      if (m != null) return m.group(1)!.toUpperCase();
      // 3) 分享链接 ?puid=P1234567890 或 &puid=
      m = RegExp(r'[?&]puid=(P[A-Za-z0-9]{10})', caseSensitive: false).firstMatch(text);
      if (m != null) return m.group(1)!.toUpperCase();
      return null;
    } catch (_) {
      return null;
    }
  }

  Future<void> _init() async {
    // 首次进入需同意《用户协议与隐私政策》
    final prefs = await SharedPreferences.getInstance();
    final agreed = prefs.getBool(kPrivacyAgreedKey) ?? false;
    if (!mounted) return;
    if (!agreed) {
      navigatorKey.currentState?.pushReplacement(
          MaterialPageRoute(builder: (_) => const PrivacyAgreementScreen()));
      return;
    }
    // 并行加载站点配置与登录态
    await Future.wait([
      context.read<SiteConfig>().load(),
      context.read<AuthState>().init(),
      context.read<ThemeState>().init(),
    ]);
    if (!mounted) return;
    // 不强制登录：未登录也可直接浏览论坛首页
    final nav = navigatorKey.currentState;
    // 深链仅在 Web 从 URL 读取；移动/桌面从剪贴板读取
    String? puid;
    if (kIsWeb) {
      puid = Uri.base.queryParameters['puid'];
    }
    if (puid == null) {
      puid = await _clipboardPuid();
    }
    nav?.pushReplacement(MaterialPageRoute(builder: (_) => const HomeScreen()));
    final code = puid;
    if (code != null && code.isNotEmpty) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        final n = navigatorKey.currentState;
        if (n != null) {
          n.push(MaterialPageRoute(builder: (_) => PuidPostScreen(puid: code)));
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: isDark
                ? [const Color(0xFF0F172A), const Color(0xFF1E1B4B)]
                : [const Color(0xFFEEF2FF), const Color(0xFFF0F9FF)],
          ),
        ),
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 84,
                height: 84,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(24),
                  gradient: const LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [Color(0xFF4F46E5), Color(0xFF0EA5E9)],
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFF4F46E5).withOpacity(0.35),
                      blurRadius: 24,
                      offset: const Offset(0, 10),
                    ),
                  ],
                ),
                child: const Icon(Icons.forum, size: 44, color: Colors.white),
              ),
              const SizedBox(height: 24),
              Text(
                '论坛',
                style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                      color: isDark ? Colors.white : const Color(0xFF1E293B),
                    ),
              ),
              const SizedBox(height: 12),
              SizedBox(
                width: 28,
                height: 28,
                child: CircularProgressIndicator(
                  strokeWidth: 3,
                  valueColor: AlwaysStoppedAnimation<Color>(
                    isDark ? const Color(0xFF818CF8) : const Color(0xFF4F46E5),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
