import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../auth/auth_state.dart';
import '../api/api_client.dart';
import '../site_config.dart';
import 'post_list_screen.dart';
import 'boards_screen.dart';
import 'search_screen.dart';
import 'messages_screen.dart';
import 'profile_screen.dart';
import 'common.dart';
import 'dart:convert';
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _tabIndex = 0;
  bool _announcementChecked = false;
  int _msgUnread = 0;
  int _notifUnread = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _showAnnouncementIfNeeded());
    _refreshUnread();
    // 定期刷新未读数
    Timer.periodic(const Duration(seconds: 30), (_) => _refreshUnread());
  }

  Future<void> _refreshUnread() async {
    if (!context.read<AuthState>().isLoggedIn) return;
    try {
      final m = await ApiClient.get('/api/messages/unread');
      final n = await ApiClient.get('/api/notifications/unread');
      if (!mounted) return;
      setState(() {
        _msgUnread = ((m['data'] as Map<String, dynamic>)['unread'] as int?) ?? 0;
        _notifUnread = ((n['data'] as Map<String, dynamic>)['unread'] as int?) ?? 0;
      });
    } catch (_) {}
  }

  Future<void> _showAnnouncementIfNeeded() async {
    if (!mounted || _announcementChecked) return;
    _announcementChecked = true;
    final announcement = context.read<SiteConfig>().announcement;
    if (announcement == null || announcement.trim().isEmpty) return;

    final prefs = await SharedPreferences.getInstance();
    const key = 'forum_acknowledged_announcement';
    if (prefs.getString(key) == announcement) return;
    if (!mounted) return;

    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => AlertDialog(
        title: const Row(
          children: [
            Icon(Icons.campaign_outlined),
            SizedBox(width: 8),
            Text('站点公告'),
          ],
        ),
        content: SingleChildScrollView(child: Text(announcement)),
        actions: [
          FilledButton(
            onPressed: () async {
              await prefs.setString(key, announcement);
              if (dialogContext.mounted) Navigator.of(dialogContext).pop();
            },
            child: const Text('确认，不再提示'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      const HomeFeedTab(),
      const BoardsScreen(),
      const SearchScreen(),
      const MessagesScreen(),
      const ProfileScreen(),
    ];

    return Scaffold(
      body: IndexedStack(index: _tabIndex, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tabIndex,
        onDestinationSelected: (i) => setState(() => _tabIndex = i),
        destinations: [
          const NavigationDestination(
              icon: Icon(Icons.home_outlined),
              selectedIcon: Icon(Icons.home),
              label: '首页'),
          const NavigationDestination(
              icon: Icon(Icons.dashboard_outlined),
              selectedIcon: Icon(Icons.dashboard),
              label: '板块'),
          const NavigationDestination(icon: Icon(Icons.search), label: '搜索'),
          NavigationDestination(
              icon: Badge(
                isLabelVisible: _msgUnread + _notifUnread > 0,
                label: Text('${_msgUnread + _notifUnread}'),
                child: const Icon(Icons.mail_outline),
              ),
              selectedIcon: Badge(
                isLabelVisible: _msgUnread + _notifUnread > 0,
                label: Text('${_msgUnread + _notifUnread}'),
                child: const Icon(Icons.mail),
              ),
              label: '私信'),
          const NavigationDestination(
              icon: Icon(Icons.person_outline),
              selectedIcon: Icon(Icons.person),
              label: '我的'),
        ],
      ),
    );
  }
}

/// 首页：全部帖子，支持 推荐/最新 排序切换
class HomeFeedTab extends StatefulWidget {
  const HomeFeedTab({super.key});

  @override
  State<HomeFeedTab> createState() => _HomeFeedTabState();
}

class _HomeFeedTabState extends State<HomeFeedTab> {
  String _sort = 'recommend'; // recommend | latest
  int _refreshKey = 0;

  @override
  Widget build(BuildContext context) {
    final loggedIn = context.watch<AuthState>().isLoggedIn;
    final site = context.watch<SiteConfig>();
    return Scaffold(
      appBar: AppBar(
        title: Text(site.siteName),
        actions: [
          IconButton(
            icon: const Icon(Icons.create),
            tooltip: '发帖',
            onPressed: () async {
              final ok = await ensureLoggedIn(context);
              if (!ok) return;
              if (!mounted) return;
              await Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const PostEditorScreen()),
              );
              if (mounted) setState(() => _refreshKey++);
            },
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(44),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
            child: Row(
              children: [
                _sortChip('推荐', 'recommend'),
                const SizedBox(width: 8),
                _sortChip('最新', 'latest'),
                const SizedBox(width: 8),
                _sortChip('热门', 'hot'),
                if (loggedIn) ...[
                  const SizedBox(width: 8),
                  _sortChip('关注', 'following'),
                ],
              ],
            ),
          ),
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: PostListScreen(
              key: ValueKey('${loggedIn}_${_sort}_$_refreshKey'),
              sort: _sort,
            ),
          ),
          // 固定页脚：版权/友情链接，不会被长列表遮挡（备案号移至关于页）
          if (site.footerText != null || site.footerLinksJson != '[]')
            Container(
              width: double.infinity,
              color: Theme.of(context).colorScheme.surfaceContainerHighest.withOpacity(0.4),
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (site.footerText != null && site.footerText!.isNotEmpty)
                    Text(
                      site.footerText!,
                      textAlign: TextAlign.center,
                      style: Theme.of(context).textTheme.labelSmall?.copyWith(
                            color: Theme.of(context).colorScheme.onSurfaceVariant,
                          ),
                    ),
                  Wrap(alignment: WrapAlignment.center, children: _footerLinks(site.footerLinksJson)),
                ],
              ),
            ),
        ],
      ),
    );
  }

  Widget _sortChip(String label, String value) {
    final selected = _sort == value;
    final theme = Theme.of(context);
    return ChoiceChip(
      label: Text(label),
      selected: selected,
      onSelected: (_) => setState(() => _sort = value),
      labelStyle: TextStyle(
        fontSize: 13,
        fontWeight: selected ? FontWeight.w600 : FontWeight.w500,
        color: selected ? theme.colorScheme.onPrimaryContainer : theme.colorScheme.onSurfaceVariant,
      ),
      checkmarkColor: theme.colorScheme.onPrimaryContainer,
    );
  }

  List<Widget> _footerLinks(String raw) {
    try {
      final list=jsonDecode(raw) as List;
      return list.map((e){final m=e as Map<String,dynamic>;return TextButton(onPressed:()async{final u=Uri.tryParse(m['url']?.toString()??'');if(u!=null)await launchUrl(u,mode:LaunchMode.externalApplication);},child:Text(m['name']?.toString()??'链接',style:Theme.of(context).textTheme.labelSmall?.copyWith(color:Theme.of(context).colorScheme.primary)));}).toList();
    } catch(_){return const [];}
  }
}
