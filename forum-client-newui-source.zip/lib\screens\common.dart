import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../auth/auth_state.dart';
import '../api/api_client.dart';
import 'login_screen.dart';

/// 检查登录状态；未登录时弹出登录页。返回是否已登录。
Future<bool> ensureLoggedIn(BuildContext context) async {
  final auth = context.read<AuthState>();
  if (auth.isLoggedIn) return true;
  final ok = await Navigator.of(context).push<bool>(
    MaterialPageRoute(builder: (_) => const LoginScreen()),
  );
  return ok == true;
}

Future<Map<String, String>?> solveChallenge(BuildContext context, String purpose) async {
  try {
    final d = await ApiClient.get('/api/verification/challenge', query: {'purpose': purpose});
    final c = d['data'] as Map<String, dynamic>;
    final ctrl = TextEditingController();
    final answer = await showDialog<String>(context: context, builder: (_) => AlertDialog(
      title: const Text('安全验证'), content: Column(mainAxisSize: MainAxisSize.min, children: [
        Text(c['expression'] as String? ?? ''), const SizedBox(height: 10),
        TextField(controller: ctrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: '答案', border: OutlineInputBorder())),
      ]), actions: [TextButton(onPressed: ()=>Navigator.pop(context), child: const Text('取消')), FilledButton(onPressed: ()=>Navigator.pop(context, ctrl.text), child: const Text('确定'))]));
    if (answer == null || answer.isEmpty) return null;
    return {'X-Challenge-Id': c['id'].toString(), 'X-Challenge-Answer': answer};
  } catch (_) { return {}; }
}

/// 未登录时展示的提示组件
class LoginPrompt extends StatelessWidget {
  final String text;
  const LoginPrompt({super.key, this.text = '该功能需要登录'});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    return Center(
      child: Container(
        margin: const EdgeInsets.all(32),
        padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 36),
        decoration: BoxDecoration(
          color: colorScheme.surface,
          borderRadius: BorderRadius.circular(24),
          boxShadow: [
            BoxShadow(
              color: colorScheme.shadow.withOpacity(0.06),
              blurRadius: 24,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 72,
              height: 72,
              decoration: BoxDecoration(
                color: colorScheme.primaryContainer.withOpacity(0.5),
                borderRadius: BorderRadius.circular(22),
              ),
              child: Icon(Icons.lock_outline, size: 34, color: colorScheme.primary),
            ),
            const SizedBox(height: 20),
            Text(
              text,
              textAlign: TextAlign.center,
              style: theme.textTheme.titleMedium?.copyWith(
                    color: theme.textTheme.bodyMedium?.color,
                  ),
            ),
            const SizedBox(height: 20),
            FilledButton.icon(
              onPressed: () async {
                await ensureLoggedIn(context);
              },
              icon: const Icon(Icons.login, size: 18),
              label: const Text('去登录'),
            ),
          ],
        ),
      ),
    );
  }
}
