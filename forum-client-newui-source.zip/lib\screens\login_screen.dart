import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../auth/auth_state.dart';
import '../api/api_client.dart';
import '../site_config.dart';
import 'common.dart';
import 'home_screen.dart';
import 'package:qr_flutter/qr_flutter.dart';

/// 获取/生成持久化设备标识，用于换设备二次验证判断。
Future<String> _deviceId() async {
  final prefs = await SharedPreferences.getInstance();
  var id = prefs.getString('device_id');
  if (id == null || id.isEmpty) {
    id = 'dev-${DateTime.now().millisecondsSinceEpoch}-${DateTime.now().microsecond}';
    await prefs.setString('device_id', id);
  }
  return id;
}

Future<String> _deviceName() async {
  if (kIsWeb) return 'Web 浏览器';
  if (defaultTargetPlatform == TargetPlatform.android) return 'Android 设备';
  if (defaultTargetPlatform == TargetPlatform.windows) return 'Windows 设备';
  return '未知设备';
}

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _usernameCtrl = TextEditingController();
  final _passwordCtrl = TextEditingController();
  final _nicknameCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _emailCodeCtrl = TextEditingController();
  bool _isRegister = false;
  bool _loading = false;
  int _emailCd = 0;
  Timer? _emailCdTimer;

  @override
  void dispose() {
    _usernameCtrl.dispose();
    _passwordCtrl.dispose();
    _nicknameCtrl.dispose();
    _emailCtrl.dispose(); _emailCodeCtrl.dispose();
    _emailCdTimer?.cancel();
    super.dispose();
  }

  Future<void> _submit() async {
    final username = _usernameCtrl.text.trim();
    final password = _passwordCtrl.text;
    if (username.isEmpty || password.isEmpty) {
      _toast('请填写用户名和密码');
      return;
    }
    setState(() => _loading = true);
    try {
      final auth = context.read<AuthState>();
      if (_isRegister) {
        await auth.register(username, password, _nicknameCtrl.text.trim(), email:_emailCtrl.text.trim(), emailCode:_emailCodeCtrl.text.trim());
        await _afterLogin();
      } else {
        final deviceId = await _deviceId();
        final deviceName = await _deviceName();
        final data = await auth.login(username, password, deviceId: deviceId, deviceName: deviceName);
        final pending = data['pendingDeviceId'] as String?;
        if (pending != null && pending.isNotEmpty) {
          await _verifyDeviceFlow(username, pending, deviceName);
          return;
        }
        await _afterLogin();
      }
    } on ApiException catch (e) {
      _toast(e.message);
    } catch (e) {
      _toast('请求失败，请检查网络');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  /// 换设备二次验证：提示邮箱验证码已发送，输入验证码完成登录。
  Future<void> _verifyDeviceFlow(String username, String deviceId, String deviceName) async {
    final codeCtrl = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (dialog) => AlertDialog(
        title: const Text('新设备验证'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('检测到新设备登录，验证码已发送到你绑定的邮箱。'),
            const SizedBox(height: 12),
            TextField(
              controller: codeCtrl,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: '邮箱验证码', border: OutlineInputBorder()),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.of(dialog).pop(false), child: const Text('取消')),
          FilledButton(onPressed: () => Navigator.of(dialog).pop(true), child: const Text('验证登录')),
        ],
      ),
    );
    if (ok != true) {
      setState(() => _loading = false);
      return;
    }
    try {
      await context.read<AuthState>().verifyDevice(username, codeCtrl.text.trim(),
          deviceId: deviceId, deviceName: deviceName);
      await _afterLogin();
    } on ApiException catch (e) {
      _toast(e.message);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _afterLogin() async {
    if (!mounted) return;
    // 登录成功后返回上一页，由调用方继续原操作
    if (Navigator.of(context).canPop()) {
      Navigator.of(context).pop(true);
    } else {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const HomeScreen()),
      );
    }
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final isDark = theme.brightness == Brightness.dark;
    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 420),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // 顶部品牌区
                Container(
                  padding: const EdgeInsets.all(28),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: isDark
                          ? [const Color(0xFF312E81), const Color(0xFF0EA5E9)]
                          : [const Color(0xFF4F46E5), const Color(0xFF0EA5E9)],
                    ),
                    borderRadius: BorderRadius.circular(24),
                    boxShadow: [
                      BoxShadow(
                        color: const Color(0xFF4F46E5).withOpacity(0.3),
                        blurRadius: 24,
                        offset: const Offset(0, 12),
                      ),
                    ],
                  ),
                  child: Column(
                    children: [
                      const Icon(Icons.forum, size: 56, color: Colors.white),
                      const SizedBox(height: 14),
                      Text(
                        _isRegister ? '注册账号' : '论坛登录',
                        textAlign: TextAlign.center,
                        style: theme.textTheme.headlineSmall?.copyWith(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        _isRegister ? '加入我们的社区' : '欢迎回到论坛',
                        textAlign: TextAlign.center,
                        style: theme.textTheme.bodyMedium?.copyWith(
                              color: Colors.white.withOpacity(0.85),
                            ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 28),
                // 表单卡片
                Container(
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    color: colorScheme.surface,
                    borderRadius: BorderRadius.circular(24),
                    boxShadow: [
                      BoxShadow(
                        color: colorScheme.shadow.withOpacity(0.05),
                        blurRadius: 20,
                        offset: const Offset(0, 8),
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      TextField(
                        controller: _usernameCtrl,
                        decoration: const InputDecoration(
                          labelText: '用户名 / 邮箱 / UID',
                          prefixIcon: Icon(Icons.person_outline),
                        ),
                      ),
                      const SizedBox(height: 14),
                      if (_isRegister) ...[
                        TextField(
                          controller: _nicknameCtrl,
                          decoration: const InputDecoration(
                            labelText: '昵称（可选）',
                            prefixIcon: Icon(Icons.badge_outlined),
                          ),
                        ),
                        const SizedBox(height: 14),
                        if (context.read<SiteConfig>().allowRegister) ...[
                          TextField(
                            controller: _emailCtrl,
                            decoration: const InputDecoration(
                              labelText: '邮箱（启用验证时必填）',
                              prefixIcon: Icon(Icons.email_outlined),
                            ),
                          ),
                          const SizedBox(height: 14),
                          Row(
                            children: [
                              Expanded(
                                child: TextField(
                                  controller: _emailCodeCtrl,
                                  decoration: const InputDecoration(
                                    labelText: '邮箱验证码',
                                    prefixIcon: Icon(Icons.verified_outlined),
                                  ),
                                ),
                              ),
                              const SizedBox(width: 10),
                              OutlinedButton(
                                onPressed: _emailCd > 0 ? null : _sendEmailCode,
                                child: Text(_emailCd > 0 ? '${_emailCd}s' : '发送'),
                              ),
                            ],
                          ),
                          const SizedBox(height: 14),
                        ],
                      ],
                      TextField(
                        controller: _passwordCtrl,
                        obscureText: true,
                        decoration: const InputDecoration(
                          labelText: '密码',
                          prefixIcon: Icon(Icons.lock_outline),
                        ),
                        onSubmitted: (_) => _submit(),
                      ),
                      const SizedBox(height: 22),
                      FilledButton(
                        onPressed: _loading ? null : _submit,
                        style: FilledButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 16),
                        ),
                        child: _loading
                            ? const SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(strokeWidth: 2),
                              )
                            : Text(_isRegister ? '注册并登录' : '登录'),
                      ),
                      const SizedBox(height: 12),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          TextButton(
                            onPressed: () => setState(() => _isRegister = !_isRegister),
                            child: Text(_isRegister ? '已有账号？去登录' : '没有账号？去注册'),
                          ),
                          if (!_isRegister) ...[
                            const SizedBox(width: 8),
                            TextButton(
                              onPressed: _forgotPassword,
                              child: const Text('忘记密码？'),
                            ),
                          ],
                        ],
                      ),
                      const SizedBox(height: 8),
                      OutlinedButton.icon(
                        onPressed: _showQrLogin,
                        icon: const Icon(Icons.qr_code_scanner),
                        label: const Text('扫码登录'),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _sendEmailCode() async {
    if(_emailCtrl.text.trim().isEmpty){_toast('请先填写邮箱');return;}
    if(_emailCd>0)return;
    final challenge=await solveChallenge(context,'EMAIL'); if(challenge==null)return;
    try{await ApiClient.post('/api/verification/email/code',body:{'email':_emailCtrl.text.trim(),'challengeId':challenge['X-Challenge-Id'],'answer':int.tryParse(challenge['X-Challenge-Answer']??'')});_toast('验证码已发送');_startEmailCooldown();}
    on ApiException catch(e){_toast(e.message);}
  }

  void _startEmailCooldown() {
    if (!mounted) return;
    setState(() => _emailCd = 60);
    _emailCdTimer?.cancel();
    _emailCdTimer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) { t.cancel(); return; }
      if (_emailCd <= 1) { t.cancel(); setState(() => _emailCd = 0); }
      else { setState(() => _emailCd--); }
    });
  }

  /// 忘记密码：发送验证码到绑定邮箱，校验后重置密码
  Future<void> _forgotPassword() async {
    final account = TextEditingController();
    final code = TextEditingController();
    final newPwd = TextEditingController();
    var countdown = 0;
    Timer? timer;
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (dialogContext, setLocal) {
          void startCooldown() {
            countdown = 60;
            timer?.cancel();
            timer = Timer.periodic(const Duration(seconds: 1), (t) {
              if (countdown <= 1) {
                t.cancel();
                if (dialogContext.mounted) setLocal(() => countdown = 0);
              } else {
                countdown--;
                if (dialogContext.mounted) setLocal(() {});
              }
            });
          }

          return AlertDialog(
          title: const Text('忘记密码'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: account,
                  decoration: const InputDecoration(
                    labelText: '用户名或邮箱',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: code,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(
                          labelText: '验证码',
                          border: OutlineInputBorder(),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    OutlinedButton(
                      onPressed: (countdown > 0)
                          ? null
                          : () async {
                              if (account.text.trim().isEmpty) {
                                ScaffoldMessenger.of(dialogContext).showSnackBar(
                                    const SnackBar(content: Text('请先填写用户名或邮箱')));
                                return;
                              }
                              try {
                                await ApiClient.post('/api/auth/forgot-password/send',
                                    body: {'account': account.text.trim()});
                                if (dialogContext.mounted) {
                                  ScaffoldMessenger.of(dialogContext).showSnackBar(
                                      const SnackBar(content: Text('验证码已发送到绑定邮箱')));
                                  startCooldown();
                                }
                              } on ApiException catch (e) {
                                if (dialogContext.mounted) {
                                  ScaffoldMessenger.of(dialogContext)
                                      .showSnackBar(SnackBar(content: Text(e.message)));
                                }
                              }
                            },
                      child: Text(countdown > 0 ? '${countdown}s' : '发送验证码'),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: newPwd,
                  obscureText: true,
                  decoration: const InputDecoration(
                    labelText: '新密码（至少 8 位）',
                    border: OutlineInputBorder(),
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                timer?.cancel();
                Navigator.pop(dialogContext);
              },
              child: const Text('取消'),
            ),
            FilledButton(
              onPressed: () async {
                if (account.text.trim().isEmpty ||
                    code.text.trim().isEmpty ||
                    newPwd.text.length < 8) {
                  ScaffoldMessenger.of(dialogContext).showSnackBar(
                      const SnackBar(content: Text('请完整填写，新密码至少 8 位')));
                  return;
                }
                try {
                  await ApiClient.post('/api/auth/forgot-password', body: {
                    'account': account.text.trim(),
                    'code': code.text.trim(),
                    'newPassword': newPwd.text,
                  });
                  if (dialogContext.mounted) {
                    timer?.cancel();
                    Navigator.pop(dialogContext);
                    ScaffoldMessenger.of(context)
                        .showSnackBar(const SnackBar(content: Text('密码重置成功，请用新密码登录')));
                  }
                } on ApiException catch (e) {
                  if (dialogContext.mounted) {
                    ScaffoldMessenger.of(dialogContext)
                        .showSnackBar(SnackBar(content: Text(e.message)));
                  }
                }
              },
              child: const Text('重置密码'),
            ),
          ],
        );
        },
      ),
    );
    timer?.cancel();
  }

  Future<void> _showQrLogin() async {
    try {
      final d=await ApiClient.post('/api/qr-login/create'); final q=d['data'] as Map<String,dynamic>;
      if(!mounted)return;
      showDialog(context:context,builder:(_)=>AlertDialog(title:const Text('扫码登录'),content:Column(mainAxisSize:MainAxisSize.min,children:[QrImageView(data:q['payload'].toString(),size:220),const SizedBox(height:8),const Text('请使用已登录设备扫描并确认')])));
      for (var i=0; mounted && i<60; i++) { await Future.delayed(const Duration(seconds:2));
        try { final s=await ApiClient.get('/api/qr-login/status',query:{'sessionId':q['sessionId'].toString(),'token':q['token'].toString()});final x=s['data'] as Map<String,dynamic>;if(x['status']=='APPROVED'){await context.read<AuthState>().applyToken(x['token'].toString());if(mounted){Navigator.pop(context);Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>const HomeScreen()));}break;} }
        on ApiException catch(e) { if(mounted)_toast(e.message); break; }
      }
    }on ApiException catch(e){_toast(e.message);} catch(e){_toast('扫码登录初始化失败，请检查网络');}
  }
}
