package com.forum.controller;

import com.forum.dto.ApiResponse;
import com.forum.dto.ForumDtos;
import com.forum.entity.Like;
import com.forum.entity.Report;
import com.forum.security.ForumUserPrincipal;
import com.forum.service.ReactionService;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class ReactionController {
    private final ReactionService service;
    public ReactionController(ReactionService service) { this.service = service; }

    @PostMapping("/posts/{id}/dislike")
    public ApiResponse<ForumDtos.LikeResult> dislikePost(@PathVariable Long id,
            @AuthenticationPrincipal ForumUserPrincipal p) {
        return ApiResponse.ok(service.toggleDislike(Like.TargetType.POST, id, p.getId()));
    }
    @PostMapping("/comments/{id}/dislike")
    public ApiResponse<ForumDtos.LikeResult> dislikeComment(@PathVariable Long id,
            @AuthenticationPrincipal ForumUserPrincipal p) {
        return ApiResponse.ok(service.toggleDislike(Like.TargetType.COMMENT, id, p.getId()));
    }
    @PostMapping("/posts/{id}/report")
    public ApiResponse<Void> reportPost(@PathVariable Long id, @RequestBody ReportRequest req,
            @AuthenticationPrincipal ForumUserPrincipal p) {
        service.report(Report.TargetType.POST, id, req.reason(), p.getId());
        return ApiResponse.okMessage("举报已提交");
    }
    @PostMapping("/comments/{id}/report")
    public ApiResponse<Void> reportComment(@PathVariable Long id, @RequestBody ReportRequest req,
            @AuthenticationPrincipal ForumUserPrincipal p) {
        service.report(Report.TargetType.COMMENT, id, req.reason(), p.getId());
        return ApiResponse.okMessage("举报已提交");
    }
    @PostMapping("/users/{id}/report")
    public ApiResponse<Void> reportUser(@PathVariable Long id, @RequestBody ReportRequest req,
            @AuthenticationPrincipal ForumUserPrincipal p) {
        service.report(Report.TargetType.USER, id, req.reason(), p.getId());
        return ApiResponse.okMessage("举报已提交");
    }
    public record ReportRequest(String reason) {}
}
