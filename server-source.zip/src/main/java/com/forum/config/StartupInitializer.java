package com.forum.config;

import com.forum.service.BoardService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

/**
 * 启动时初始化：
 *  1. 首次启动创建默认板块
 *  2. 确保帖子表存在 ngram 全文索引以支持中文搜索
 */
@Component
public class StartupInitializer implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(StartupInitializer.class);

    private final BoardService boardService;
    private final JdbcTemplate jdbcTemplate;

    public StartupInitializer(BoardService boardService, JdbcTemplate jdbcTemplate) {
        this.boardService = boardService;
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public void run(String... args) {
        boardService.ensureDefaults();
        migrateLegacyUsers();
        migrateRolesAndPostStatus();
        ensureSiteSettings();
        migrateExtendedSettings();
        migrateMediaCodes();
        ensureFullTextIndexes();
    }

    /**
     * 角色体系升级迁移：
     *  - 旧的 ADMIN（首个管理员）升级为 OWNER 站长
     *  - 新增的帖子审核状态列补齐为 APPROVED
     *  - 头衔/管辖板块列为新增字段，默认 null 即可
     */
    private void migrateRolesAndPostStatus() {
        try {
            // 旧管理员角色值仍为 ADMIN；把最早的一名管理员升级为站长
            Integer adminCount = jdbcTemplate.queryForObject(
                    "SELECT COUNT(*) FROM users WHERE role = 'ADMIN'", Integer.class);
            Integer ownerCount = jdbcTemplate.queryForObject(
                    "SELECT COUNT(*) FROM users WHERE role = 'OWNER'", Integer.class);
            if (ownerCount != null && ownerCount == 0 && adminCount != null && adminCount > 0) {
                jdbcTemplate.update("""
                        UPDATE users SET role = 'OWNER'
                        WHERE id = (SELECT id FROM (SELECT MIN(id) AS id FROM users WHERE role = 'ADMIN') t)
                        """);
                log.info("已将最早的管理员升级为站长");
            }

            // 帖子审核状态补默认值
            jdbcTemplate.update("""
                    UPDATE posts SET status = 'APPROVED'
                    WHERE status IS NULL OR status = '' OR status NOT IN ('PENDING','APPROVED','REJECTED')
                    """);
        } catch (Exception e) {
            log.warn("角色/帖子状态迁移跳过: {}", e.getMessage());
        }
    }

    private void ensureSiteSettings() {
        try {
            Integer count = jdbcTemplate.queryForObject(
                    "SELECT COUNT(*) FROM site_settings", Integer.class);
            if (count == null || count == 0) {
                jdbcTemplate.update("""
                        INSERT INTO site_settings (site_name, site_description, allow_register)
                        VALUES ('论坛', '交流分享社区', 1)
                        """);
                log.info("已初始化站点设置");
            }
        } catch (Exception e) {
            log.warn("站点设置初始化跳过: {}", e.getMessage());
        }
    }

    private void migrateExtendedSettings() {
        try {
            jdbcTemplate.update("UPDATE users SET ranking_weight = 1.0 WHERE ranking_weight IS NULL OR ranking_weight <= 0");
            jdbcTemplate.update("""
                    UPDATE site_settings SET
                      page_title = COALESCE(NULLIF(page_title, ''), site_name),
                      default_theme = COALESCE(NULLIF(default_theme, ''), 'SYSTEM'),
                      footer_links_json = COALESCE(NULLIF(footer_links_json, ''), '[]'),
                      signature_audit_mode = COALESCE(NULLIF(signature_audit_mode, ''), 'OFF'),
                      arithmetic_email_enabled = 1,
                      arithmetic_post_enabled = 1,
                      arithmetic_comment_enabled = 1,
                      image_max_mb = IF(image_max_mb IS NULL OR image_max_mb <= 0, 5, image_max_mb),
                      video_max_mb = IF(video_max_mb IS NULL OR video_max_mb <= 0, 15, video_max_mb),
                      role_upload_quota_json = COALESCE(NULLIF(role_upload_quota_json, ''), '{"USER":100,"ADMIN":500,"SUPER_ADMIN":2048,"OWNER":4096}')
                    WHERE id = 1
                    """);
        } catch (Exception e) { log.warn("扩展配置迁移跳过: {}", e.getMessage()); }
    }

    private void migrateMediaCodes() {
        try {
            jdbcTemplate.update("UPDATE upload_records SET public_code = LOWER(SUBSTRING(REPLACE(UUID(), '-', ''), 1, 12)) WHERE public_code IS NULL OR public_code = ''");
            jdbcTemplate.update("""
                    UPDATE posts p JOIN upload_records u
                    ON (p.thumbnail_url = u.path OR p.thumbnail_url LIKE CONCAT('%', u.path))
                    SET p.thumbnail_url = CONCAT('/media/', u.public_code)
                    WHERE u.public_code IS NOT NULL
                    """);
            jdbcTemplate.update("""
                    UPDATE posts p JOIN upload_records u
                    ON p.content LIKE CONCAT('%', u.path, '%')
                    SET p.thumbnail_url = CONCAT('/media/', u.public_code)
                    WHERE (p.thumbnail_url IS NULL OR p.thumbnail_url = '') AND u.type IN ('image','avatar')
                    """);
            for (var media : jdbcTemplate.queryForList("SELECT path, public_code FROM upload_records WHERE public_code IS NOT NULL")) {
                String path = (String) media.get("path");
                String code = (String) media.get("public_code");
                jdbcTemplate.update("UPDATE posts SET content = REPLACE(content, ?, ?) WHERE content LIKE ?", path, "/media/" + code, "%" + path + "%");
                jdbcTemplate.update("UPDATE posts SET content = REPLACE(content, ?, ?) WHERE content LIKE ?", "http://103.36.220.143:8080" + path, "/media/" + code, "%" + path + "%");
            }
            log.info("媒体随机代号迁移完成");
        } catch (Exception e) { log.warn("媒体代号迁移跳过: {}", e.getMessage()); }
    }

    /**
     * 历史用户（等级字段加入前注册）的等级/经验/金币列默认为 0，
     * 统一修正为合理的初始值：等级 1、经验 0、金币 0，并初始化升级时间。
     */
    private void migrateLegacyUsers() {
        try {
            Integer badCount = jdbcTemplate.queryForObject(
                    "SELECT COUNT(*) FROM users WHERE level < 1 OR level IS NULL", Integer.class);
            if (badCount != null && badCount > 0) {
                jdbcTemplate.update("""
                        UPDATE users
                        SET level = 1,
                            exp = COALESCE(exp, 0),
                            gold = COALESCE(gold, 0),
                            checkin_streak = COALESCE(checkin_streak, 0),
                            level_up_at = COALESCE(level_up_at, created_at)
                        WHERE level < 1 OR level IS NULL
                        """);
                log.info("已修正 {} 名历史用户的等级数据", badCount);
            }
        } catch (Exception e) {
            log.warn("历史用户等级迁移跳过: {}", e.getMessage());
        }
    }

    private void ensureFullTextIndexes() {
        try {
            // 检查表是否已存在（JPA ddl-auto=update 会在稍后建表）
            Integer tableCount = jdbcTemplate.queryForObject(
                    "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'posts'",
                    Integer.class);
            if (tableCount == null || tableCount == 0) {
                log.info("posts 表尚未创建，跳过全文索引初始化");
                return;
            }

            // 检查全文索引是否已存在
            Integer idxCount = jdbcTemplate.queryForObject(
                    "SELECT COUNT(*) FROM information_schema.statistics "
                            + "WHERE table_schema = DATABASE() AND table_name = 'posts' "
                            + "AND index_name = 'ft_posts_title_content'",
                    Integer.class);

            if (idxCount != null && idxCount > 0) {
                log.info("帖子全文索引已存在，跳过");
                return;
            }

            // MySQL 8.0 的 CREATE FULLTEXT INDEX 不支持 IF NOT EXISTS，因此先判存在再创建
            jdbcTemplate.execute("""
                    ALTER TABLE posts ADD FULLTEXT INDEX ft_posts_title_content (title, content) WITH PARSER ngram
                    """);
            log.info("帖子全文索引创建成功 (ngram)");
        } catch (Exception e) {
            log.warn("全文索引初始化失败（搜索将回退 LIKE）: {}", e.getMessage());
        }
    }
}
