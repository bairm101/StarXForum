package com.forum.repository;

import com.forum.entity.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {

    Optional<User> findByUsername(String username);

    Optional<User> findByEmail(String email);

    Optional<User> findByUid(String uid);

    boolean existsByUsername(String username);

    boolean existsByEmail(String email);

    boolean existsByUid(String uid);

    @Query(
            value = """
                    SELECT * FROM users
                    WHERE username LIKE CONCAT('%', :kw, '%')
                       OR COALESCE(nickname, '') LIKE CONCAT('%', :kw, '%')
                    ORDER BY username ASC
                    """,
            countQuery = """
                    SELECT COUNT(*) FROM users
                    WHERE username LIKE CONCAT('%', :kw, '%')
                       OR COALESCE(nickname, '') LIKE CONCAT('%', :kw, '%')
                    """,
            nativeQuery = true
    )
    Page<User> searchByKeyword(@Param("kw") String keyword, Pageable pageable);
}
