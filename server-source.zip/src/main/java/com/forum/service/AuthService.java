package com.forum.service;

import com.forum.dto.auth.AuthDtos;
import com.forum.dto.auth.UserDtos;
import com.forum.entity.SiteSettings;
import com.forum.entity.User;
import com.forum.exception.BusinessException;
import com.forum.repository.SiteSettingsRepository;
import com.forum.repository.UserRepository;
import com.forum.security.JwtService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AuthService {

    private static final Logger log = LoggerFactory.getLogger(AuthService.class);
    private static final int MAX_FAILED_ATTEMPTS = 5;
    private static final int LOCKOUT_MINUTES = 15;

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;
    private final SiteSettingsRepository siteSettingsRepository;
    private final VerificationService verificationService;
    private final DeviceService deviceService;

    public AuthService(UserRepository userRepository,
                       PasswordEncoder passwordEncoder,
                       JwtService jwtService,
                       SiteSettingsRepository siteSettingsRepository,
                       VerificationService verificationService,
                       DeviceService deviceService) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtService = jwtService;
        this.siteSettingsRepository = siteSettingsRepository;
        this.verificationService = verificationService;
        this.deviceService = deviceService;
    }

    @Transactional
    public AuthDtos.LoginResponse register(AuthDtos.RegisterRequest req) {
        // 站长可关闭注册
        SiteSettings settings = siteSettingsRepository.findById(1L).orElse(null);
        if (settings != null && Boolean.FALSE.equals(settings.getAllowRegister())
                && userRepository.count() > 0) {
            throw BusinessException.forbidden("当前已关闭新用户注册");
        }

        String username = req.username().trim();

        if (userRepository.existsByUsername(username)) {
            throw BusinessException.conflict("用户名已被占用");
        }
        String email = (req.email() == null || req.email().isBlank()) ? null : req.email().trim();
        if (email != null && userRepository.existsByEmail(email)) {
            throw BusinessException.conflict("邮箱已被注册");
        }
        if (settings != null && Boolean.TRUE.equals(settings.getEmailVerificationEnabled())) {
            if (email == null || !verificationService.verifyEmailCode(email, req.emailCode())) {
                throw new BusinessException("邮箱验证码错误或已过期");
            }
        }

        User user = new User();
        user.setUsername(username);
        user.setUid(generateUid());
        user.setPasswordHash(passwordEncoder.encode(req.password()));
        user.setEmail(email);
        user.setEmailVerified(settings != null && Boolean.TRUE.equals(settings.getEmailVerificationEnabled()));
        user.setNickname(req.nickname() == null || req.nickname().isBlank() ? null : req.nickname().trim());

        // 首个注册用户自动成为站长，便于初始化管理
        boolean isFirstUser = userRepository.count() == 0;
        user.setRole(isFirstUser ? User.Role.OWNER : User.Role.USER);

        User saved = userRepository.save(user);
        log.info("新用户注册: id={} role={}", saved.getId(), saved.getRole());

        return buildLoginResponse(saved);
    }

    /** 生成唯一公开 UID（注册后不可修改）。 */
    private String generateUid() {
        final String alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
        java.util.Random rnd = new java.util.Random();
        for (int attempt = 0; attempt < 50; attempt++) {
            StringBuilder sb = new StringBuilder("U");
            for (int i = 0; i < 9; i++) sb.append(alphabet.charAt(rnd.nextInt(alphabet.length())));
            String uid = sb.toString();
            if (!userRepository.existsByUid(uid)) return uid;
        }
        return "U" + System.currentTimeMillis();
    }

    @Transactional(noRollbackFor = BusinessException.class)
    public AuthDtos.LoginResponse login(AuthDtos.LoginRequest req) {
        User user = userRepository.findByUsername(req.username().trim())
                .orElse(null);

        // 用户不存在也走统一错误，避免枚举
        if (user == null) {
            throw BusinessException.unauthorized("用户名或密码错误");
        }

        // 登录锁定检查
        if (user.getLockedUntil() != null && user.getLockedUntil().isAfter(java.time.LocalDateTime.now())) {
            long remain = java.time.Duration.between(java.time.LocalDateTime.now(), user.getLockedUntil()).toMinutes() + 1;
            throw BusinessException.forbidden("登录失败次数过多，账号已锁定，请 " + remain + " 分钟后再试");
        }

        // 密码校验
        if (!passwordEncoder.matches(req.password(), user.getPasswordHash())) {
            int failed = (user.getFailedLoginCount() == null ? 0 : user.getFailedLoginCount()) + 1;
            user.setFailedLoginCount(failed);
            if (failed >= MAX_FAILED_ATTEMPTS) {
                user.setLockedUntil(java.time.LocalDateTime.now().plusMinutes(LOCKOUT_MINUTES));
                userRepository.save(user);
                throw BusinessException.forbidden("登录失败次数过多，账号已锁定 " + LOCKOUT_MINUTES + " 分钟");
            }
            userRepository.save(user);
            throw BusinessException.unauthorized("用户名或密码错误");
        }

        // 登录成功，重置计数与锁定
        if (user.getFailedLoginCount() != null && user.getFailedLoginCount() > 0) {
            user.setFailedLoginCount(0);
        }
        user.setLockedUntil(null);
        userRepository.save(user);

        if (user.getStatus() == User.UserStatus.BANNED) {
            throw BusinessException.forbidden("账号已被封禁，请联系管理员");
        }

        // 换设备二次验证：开启且设备标识为空或不在历史记录中，则要求邮箱验证码
        if (deviceService.deviceVerificationEnabled()
                && (req.deviceId() == null || req.deviceId().isBlank()
                    || !deviceService.isKnownDevice(user, req.deviceId()))) {
            deviceService.sendDeviceCode(user);
            return AuthDtos.LoginResponse.pending(req.deviceId());
        }

        return buildLoginResponse(user, req.deviceId(), req.deviceName());
    }

    @Transactional
    public AuthDtos.LoginResponse verifyDevice(AuthDtos.DeviceVerifyRequest req) {
        User user = userRepository.findByUsername(req.username().trim())
                .orElseThrow(() -> BusinessException.unauthorized("用户不存在"));
        if (user.getStatus() == User.UserStatus.BANNED) {
            throw BusinessException.forbidden("账号已被封禁，请联系管理员");
        }
        String token = deviceService.verifyDeviceAndLogin(
                user, req.deviceId(), req.code(), req.deviceName(), null);
        return AuthDtos.LoginResponse.ok(token, jwtService.getExpirationSeconds(),
                UserDtos.UserProfile.from(user));
    }

    @Transactional
    public void changePassword(Long userId, AuthDtos.ChangePasswordRequest req) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> BusinessException.notFound("用户不存在"));

        if (!passwordEncoder.matches(req.oldPassword(), user.getPasswordHash())) {
            throw new BusinessException("原密码不正确");
        }
        if (passwordEncoder.matches(req.newPassword(), user.getPasswordHash())) {
            throw new BusinessException("新密码不能与原密码相同");
        }

        user.setPasswordHash(passwordEncoder.encode(req.newPassword()));
        userRepository.save(user);
        log.info("用户修改密码: id={}", userId);
    }

    /** 发送改邮箱验证码到新邮箱 */
    public void sendChangeEmailCode(Long userId, String newEmail) {
        if (newEmail == null || newEmail.isBlank()) {
            throw new BusinessException("请填写新邮箱");
        }
        String email = newEmail.trim();
        userRepository.findByEmail(email).ifPresent(existing -> {
            if (!existing.getId().equals(userId)) throw BusinessException.conflict("该邮箱已被其他用户使用");
        });
        userRepository.findById(userId).orElseThrow(() -> BusinessException.notFound("用户不存在"));
        verificationService.sendRawCode(email, "邮箱变更验证码",
                "您正在修改绑定邮箱，验证码：",
                "emailchange:" + userId);
    }

    /** 确认改邮箱 */
    @Transactional
    public void changeEmail(Long userId, String newEmail, String code) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> BusinessException.notFound("用户不存在"));
        String email = newEmail == null ? null : newEmail.trim();
        if (email == null || email.isBlank()) {
            throw new BusinessException("请填写新邮箱");
        }
        userRepository.findByEmail(email).ifPresent(existing -> {
            if (!existing.getId().equals(userId)) throw BusinessException.conflict("该邮箱已被其他用户使用");
        });
        if (!verificationService.verifyCode("emailchange:" + userId, code)) {
            throw new BusinessException("验证码错误或已过期");
        }
        user.setEmail(email);
        user.setEmailVerified(true);
        userRepository.save(user);
        log.info("用户修改邮箱: id={} email={}", userId, email);
    }

    private AuthDtos.LoginResponse buildLoginResponse(User user) {
        return buildLoginResponse(user, null, null);
    }

    private AuthDtos.LoginResponse buildLoginResponse(User user, String deviceId, String deviceName) {
        String token = deviceService.createSession(user, deviceId, deviceName, null);
        return AuthDtos.LoginResponse.ok(token, jwtService.getExpirationSeconds(),
                UserDtos.UserProfile.from(user));
    }
}
