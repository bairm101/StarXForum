package com.forum.service;

import com.forum.dto.ForumDtos;
import com.forum.dto.AdminDtos;
import com.forum.dto.PageResponse;
import com.forum.dto.auth.UserDtos;
import com.forum.entity.Post;
import com.forum.entity.SiteSettings;
import com.forum.entity.User;
import com.forum.exception.BusinessException;
import com.forum.repository.BoardRepository;
import com.forum.repository.CommentRepository;
import com.forum.repository.PostRepository;
import com.forum.repository.SiteSettingsRepository;
import com.forum.repository.UserRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 管理后台服务。权限分层：
 *  - 站长(OWNER)：最高权限，可任命超管/管理员、改站点设置
 *  - 超级管理员(SUPER_ADMIN)：全部板块 + 可任命管理员
 *  - 管理员(ADMIN)：仅所辖板块
 */
@Service
public class AdminService {

    private final UserRepository userRepository;
    private final BoardRepository boardRepository;
    private final PostRepository postRepository;
    private final CommentRepository commentRepository;
    private final SiteSettingsRepository siteSettingsRepository;
    private final PasswordEncoder passwordEncoder;
    private final CheckinService checkinService;

    public AdminService(UserRepository userRepository,
                        BoardRepository boardRepository,
                        PostRepository postRepository,
                        CommentRepository commentRepository,
                        SiteSettingsRepository siteSettingsRepository,
                        PasswordEncoder passwordEncoder,
                        CheckinService checkinService) {
        this.userRepository = userRepository;
        this.boardRepository = boardRepository;
        this.postRepository = postRepository;
        this.commentRepository = commentRepository;
        this.siteSettingsRepository = siteSettingsRepository;
        this.passwordEncoder = passwordEncoder;
        this.checkinService = checkinService;
    }

    private User requireOperator(Long operatorId) {
        User op = userRepository.findById(operatorId)
                .orElseThrow(() -> BusinessException.notFound("操作者不存在"));
        if (!op.isStaff()) {
            throw BusinessException.forbidden("需要管理员权限");
        }
        return op;
    }

    /** 供控制器校验访问者具备管理权限 */
    public void ensureStaff(Long operatorId) {
        requireOperator(operatorId);
    }

    /** 仅站长/超管可执行（敏感词管理等全局配置） */
    public void ensureOwnerOrSuperAdmin(Long operatorId) {
        User op = requireOperator(operatorId);
        if (!op.isOwner() && !op.isSuperAdmin()) {
            throw BusinessException.forbidden("仅站长/超级管理员可操作");
        }
    }

    // ---------- 用户管理 ----------

    @Transactional(readOnly = true)
    public PageResponse<UserDtos.UserProfile> listUsers(int page, int size) {
        Pageable pageable = PageRequest.of(page, UserService.normalizeSize(size),
                Sort.by(Sort.Direction.DESC, "createdAt"));
        Page<User> result = userRepository.findAll(pageable);
        return PageResponse.of(result.getContent().stream().map(UserDtos.UserProfile::from).toList(),
                page, UserService.normalizeSize(size), result.getTotalElements());
    }

    @Transactional
    public void banUser(Long operatorId, Long userId, boolean banned) {
        User op = requireOperator(operatorId);
        User user = userRepository.findById(userId)
                .orElseThrow(() -> BusinessException.notFound("用户不存在"));

        if (rankOf(user.getRole()) >= rankOf(op.getRole())) {
            throw BusinessException.forbidden("不能封禁同级或更高级别的管理者");
        }
        user.setStatus(banned ? User.UserStatus.BANNED : User.UserStatus.ACTIVE);
        userRepository.save(user);
    }

    /**
     * 任命角色。
     *  - 站长可任命 超管/管理员/普通用户
     *  - 超管可任命 管理员/普通用户
     *  - 任命管理员时必须指定所辖板块
     */
    @Transactional
    public UserDtos.UserProfile setRole(Long operatorId, Long userId, String role, Long managedBoardId) {
        User op = requireOperator(operatorId);
        User user = userRepository.findById(userId)
                .orElseThrow(() -> BusinessException.notFound("用户不存在"));

        User.Role target;
        try {
            target = User.Role.valueOf(role.toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new BusinessException("非法角色");
        }
        if (target == User.Role.OWNER) {
            throw BusinessException.forbidden("不能任命站长");
        }
        if (!op.canAssignRole(target)) {
            throw BusinessException.forbidden("无权任命该角色");
        }
        if (user.getId().equals(op.getId()) && target != op.getRole()) {
            throw BusinessException.conflict("不能修改自己的角色");
        }
        // 降级高权限者需更高级别操作者
        if (rankOf(user.getRole()) >= rankOf(op.getRole())) {
            throw BusinessException.forbidden("不能修改同级或更高级别的管理者");
        }
        // 任命管理员必须指定板块
        if (target == User.Role.ADMIN) {
            if (managedBoardId == null) {
                throw new BusinessException("任命管理员需指定所辖板块");
            }
            boardRepository.findById(managedBoardId)
                    .orElseThrow(() -> BusinessException.notFound("板块不存在"));
            user.setManagedBoardId(managedBoardId);
        } else {
            user.setManagedBoardId(null);
        }

        user.setRole(target);
        User saved = userRepository.save(user);
        return UserDtos.UserProfile.from(saved);
    }

    /** 设置头衔（站长/超管） */
    @Transactional
    public UserDtos.UserProfile setTitle(Long operatorId, Long userId, String title) {
        User op = requireOperator(operatorId);
        if (!op.isOwner() && !op.isSuperAdmin()) {
            throw BusinessException.forbidden("仅站长或超级管理员可设置头衔");
        }
        User user = userRepository.findById(userId)
                .orElseThrow(() -> BusinessException.notFound("用户不存在"));
        String t = title == null ? null : title.trim();
        if (t != null && t.length() > 32) {
            throw new BusinessException("头衔最长 32 字");
        }
        user.setTitle(t == null || t.isEmpty() ? null : t);
        return UserDtos.UserProfile.from(userRepository.save(user));
    }

    private int rankOf(User.Role role) {
        return switch (role) {
            case OWNER -> 3;
            case SUPER_ADMIN -> 2;
            case ADMIN -> 1;
            default -> 0;
        };
    }

    // ---------- 帖子审核队列 ----------

    /**
     * 待审核帖子队列：管理员只看所辖板块，超管/站长看全部。
     */
    @Transactional(readOnly = true)
    public PageResponse<ForumDtos.PostSummary> pendingPosts(Long operatorId, int page, int size) {
        User op = requireOperator(operatorId);
        Pageable pageable = PageRequest.of(page, UserService.normalizeSize(size),
                Sort.by(Sort.Direction.ASC, "createdAt"));

        Page<Post> result = (op.isOwner() || op.isSuperAdmin())
                ? postRepository.findByStatusAndDeletedFalse(Post.PostStatus.PENDING, pageable)
                : postRepository.findByBoardIdAndStatusAndDeletedFalse(
                        op.getManagedBoardId(), Post.PostStatus.PENDING, pageable);

        List<ForumDtos.PostSummary> items = result.getContent().stream()
                .map(p -> ForumDtos.PostSummary.from(p, false)).toList();
        return PageResponse.of(items, page, UserService.normalizeSize(size), result.getTotalElements());
    }

    @Transactional(readOnly = true)
    public PageResponse<ForumDtos.PostSummary> listPosts(Long operatorId, int page, int size) {
        requireOperator(operatorId);
        Pageable pageable = PageRequest.of(page, UserService.normalizeSize(size),
                Sort.by(Sort.Direction.DESC, "createdAt"));
        Page<Post> result = postRepository.findByDeletedFalse(pageable);
        List<ForumDtos.PostSummary> items = result.getContent().stream()
                .map(p -> ForumDtos.PostSummary.from(p, false)).toList();
        return PageResponse.of(items, page, UserService.normalizeSize(size), result.getTotalElements());
    }

    // ---------- 站点设置 ----------

    @Transactional(readOnly = true)
    public SiteSettings getSettings() {
        return siteSettingsRepository.findById(1L).orElseGet(this::createDefaultSettings);
    }

    @Transactional
    public SiteSettings updateSettings(Long operatorId, ForumDtos.SiteSettingsRequest req) {
        User op = requireOperator(operatorId);
        if (!op.isOwner()) {
            throw BusinessException.forbidden("仅站长可修改站点设置");
        }
        SiteSettings s = getSettings();
        if (req.siteName() != null && !req.siteName().isBlank()) {
            s.setSiteName(req.siteName().trim());
        }
        if (req.siteDescription() != null) {
            s.setSiteDescription(req.siteDescription().trim());
        }
        if (req.announcement() != null) {
            String a = req.announcement().trim();
            s.setAnnouncement(a.isEmpty() ? null : a);
        }
        if (req.allowRegister() != null) {
            s.setAllowRegister(req.allowRegister());
        }
        s.setUpdatedAt(LocalDateTime.now());
        return siteSettingsRepository.save(s);
    }

    @Transactional
    public AdminDtos.SettingsView updateFullSettings(Long operatorId, AdminDtos.SettingsRequest r) {
        User op = requireOperator(operatorId);
        if (!op.isOwner()) throw BusinessException.forbidden("仅站长可修改站点设置");
        SiteSettings s = getSettings();
        if (r.siteName() != null && !r.siteName().isBlank()) s.setSiteName(r.siteName().trim());
        if (r.pageTitle() != null && !r.pageTitle().isBlank()) s.setPageTitle(r.pageTitle().trim());
        if (r.siteDescription() != null) s.setSiteDescription(r.siteDescription().trim());
        if (r.announcement() != null) s.setAnnouncement(blankToNull(r.announcement()));
        if (r.allowRegister() != null) s.setAllowRegister(r.allowRegister());
        if (r.defaultTheme() != null && List.of("SYSTEM", "LIGHT", "DARK").contains(r.defaultTheme())) s.setDefaultTheme(r.defaultTheme());
        if (r.footerText() != null) s.setFooterText(blankToNull(r.footerText()));
        if (r.footerIcp() != null) s.setFooterIcp(blankToNull(r.footerIcp()));
        if (r.footerLinksJson() != null) s.setFooterLinksJson(r.footerLinksJson());
        if (r.signatureAuditMode() != null && List.of("OFF", "FIRST", "ALWAYS").contains(r.signatureAuditMode())) s.setSignatureAuditMode(r.signatureAuditMode());
        if (r.emailVerificationEnabled() != null) s.setEmailVerificationEnabled(r.emailVerificationEnabled());
        if (r.arithmeticEmailEnabled() != null) s.setArithmeticEmailEnabled(r.arithmeticEmailEnabled());
        if (r.arithmeticPostEnabled() != null) s.setArithmeticPostEnabled(r.arithmeticPostEnabled());
        if (r.arithmeticCommentEnabled() != null) s.setArithmeticCommentEnabled(r.arithmeticCommentEnabled());
        if (r.smtpEnabled() != null) s.setSmtpEnabled(r.smtpEnabled());
        if (r.smtpHost() != null) s.setSmtpHost(blankToNull(r.smtpHost()));
        if (r.smtpPort() != null && r.smtpPort() > 0 && r.smtpPort() <= 65535) s.setSmtpPort(r.smtpPort());
        if (r.smtpUsername() != null) s.setSmtpUsername(blankToNull(r.smtpUsername()));
        if (r.smtpPassword() != null && !r.smtpPassword().isBlank()) s.setSmtpPassword(r.smtpPassword());
        if (r.smtpSsl() != null) s.setSmtpSsl(r.smtpSsl());
        if (r.imageCompressEnabled() != null) s.setImageCompressEnabled(r.imageCompressEnabled());
        if (r.videoCompressEnabled() != null) s.setVideoCompressEnabled(r.videoCompressEnabled());
        if (r.postEditAuditEnabled() != null) s.setPostEditAuditEnabled(r.postEditAuditEnabled());
        if (r.deviceVerificationEnabled() != null) s.setDeviceVerificationEnabled(r.deviceVerificationEnabled());
        if (r.imageMaxMb() != null && r.imageMaxMb() >= 1 && r.imageMaxMb() <= 100) s.setImageMaxMb(r.imageMaxMb());
        if (r.videoMaxMb() != null && r.videoMaxMb() >= 1 && r.videoMaxMb() <= 2048) s.setVideoMaxMb(r.videoMaxMb());
        if (r.officialWebsite() != null) s.setOfficialWebsite(blankToNull(r.officialWebsite()));
        if (r.webShareBaseUrl() != null) s.setWebShareBaseUrl(blankToNull(r.webShareBaseUrl()));
        if (r.contactEmail() != null) s.setContactEmail(blankToNull(r.contactEmail()));
        if (r.aboutIcp() != null) s.setAboutIcp(blankToNull(r.aboutIcp()));
        if (r.autoRefreshSeconds() != null && r.autoRefreshSeconds() >= 0 && r.autoRefreshSeconds() <= 3600) s.setAutoRefreshSeconds(r.autoRefreshSeconds());
        s.setUpdatedAt(LocalDateTime.now());
        return AdminDtos.SettingsView.from(siteSettingsRepository.save(s));
    }

    @Transactional(readOnly = true)
    public AdminDtos.SettingsView fullSettings(Long operatorId) {
        requireOperator(operatorId);
        return AdminDtos.SettingsView.from(getSettings());
    }

    @Transactional
    public UserDtos.UserProfile updateUserParameters(Long operatorId, Long userId, AdminDtos.UserParametersRequest r) {
        User op = requireOperator(operatorId);
        if (!op.isOwner()) throw BusinessException.forbidden("仅站长可调整用户参数");
        User u = userRepository.findById(userId).orElseThrow(() -> BusinessException.notFound("用户不存在"));
        if (r.username() != null && !r.username().isBlank() && !r.username().equals(u.getUsername())) {
            if (userRepository.existsByUsername(r.username().trim())) throw BusinessException.conflict("用户名已被占用");
            u.setUsername(r.username().trim());
        }
        if (r.signature() != null) u.setSignature(blankToNull(r.signature()));
        if (r.password() != null && r.password().length() >= 8) u.setPasswordHash(passwordEncoder.encode(r.password()));
        if (r.email() != null) {
            String email = blankToNull(r.email());
            if (email != null) {
                userRepository.findByEmail(email).ifPresent(existing -> {
                    if (!existing.getId().equals(u.getId())) throw BusinessException.conflict("邮箱已被其他用户占用");
                });
                u.setEmail(email);
            } else {
                u.setEmail(null);
            }
        }
        if (r.level() != null) u.setLevel(Math.max(1, Math.min(10, r.level())));
        if (r.exp() != null) u.setExp(Math.max(0, r.exp()));
        if (r.gold() != null) u.setGold(Math.max(0, r.gold()));
        if (r.rankingWeight() != null) u.setRankingWeight(Math.max(0.1, Math.min(10.0, r.rankingWeight())));
        if (r.maxUploadMb() != null) u.setMaxUploadMb(r.maxUploadMb() > 0 ? r.maxUploadMb() : null);
        if (r.level() != null || r.exp() != null) checkinService.normalizeLevel(u);
        return UserDtos.UserProfile.from(userRepository.save(u));
    }

    @Transactional
    public UserDtos.UserProfile moderateSignature(Long operatorId, Long userId, boolean approve) {
        User op = requireOperator(operatorId);
        if (!op.isOwner() && !op.isSuperAdmin()) throw BusinessException.forbidden("仅站长或超级管理员可审核签名");
        User u = userRepository.findById(userId).orElseThrow(() -> BusinessException.notFound("用户不存在"));
        if (u.getPendingSignature() == null) throw BusinessException.conflict("没有待审核签名");
        if (approve) { u.setSignature(u.getPendingSignature()); u.setSignatureApprovedOnce(true); }
        u.setPendingSignature(null);
        return UserDtos.UserProfile.from(userRepository.save(u));
    }

    private String blankToNull(String value) {
        String v = value == null ? null : value.trim();
        return v == null || v.isEmpty() ? null : v;
    }

    private SiteSettings createDefaultSettings() {
        SiteSettings s = new SiteSettings();
        return siteSettingsRepository.save(s);
    }

    // ---------- 统计 ----------

    @Transactional(readOnly = true)
    public ForumDtos.OverviewStats overview() {
        return new ForumDtos.OverviewStats(
                userRepository.count(),
                postRepository.countByDeletedFalse(),
                commentRepository.countByDeletedFalse(),
                boardRepository.count()
        );
    }
}
