package com.forum.service;

import com.forum.dto.PageResponse;
import com.forum.dto.auth.UserDtos;
import com.forum.entity.User;
import com.forum.exception.BusinessException;
import com.forum.repository.UserRepository;
import com.forum.repository.SiteSettingsRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Duration;

@Service
public class UserService {

    private static final Logger log = LoggerFactory.getLogger(UserService.class);
    /** 24h 内命中敏感词次数达到该值即降权 */
    private static final int SENSITIVE_THRESHOLD = 5;
    /** 降权系数：权重 * 0.5，最低 0.1 */
    private static final double WEIGHT_DECAY = 0.5;
    private static final double WEIGHT_FLOOR = 0.1;

    private final UserRepository userRepository;
    private final SiteSettingsRepository settingsRepository;
    private final StringRedisTemplate redis;

    public UserService(UserRepository userRepository, SiteSettingsRepository settingsRepository, StringRedisTemplate redis) {
        this.userRepository = userRepository;
        this.settingsRepository = settingsRepository;
        this.redis = redis;
    }

    /** 记录一次敏感词使用，24h 内达到阈值则降低推荐权重。 */
    @Transactional
    public void recordSensitiveViolation(Long userId) {
        if (userId == null) return;
        String key = "sens:viol:user:" + userId;
        try {
            Long count = redis.opsForValue().increment(key);
            if (count != null && count == 1L) {
                redis.expire(key, Duration.ofHours(24));
            }
            if (count != null && count >= SENSITIVE_THRESHOLD) {
                User user = requireUser(userId);
                double w = user.getRankingWeight() == null ? 1.0 : user.getRankingWeight();
                double next = Math.max(WEIGHT_FLOOR, w * WEIGHT_DECAY);
                user.setRankingWeight(next);
                userRepository.save(user);
                redis.delete(key);
                log.info("用户 {} 频繁使用敏感词，权重降至 {}", userId, next);
            }
        } catch (Exception e) {
            log.warn("敏感词降权记录失败: {}", e.getMessage());
        }
    }

    @Transactional(readOnly = true)
    public User requireUser(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> BusinessException.notFound("用户不存在"));
    }

    @Transactional(readOnly = true)
    public UserDtos.UserProfile getProfile(Long id) {
        return UserDtos.UserProfile.from(requireUser(id));
    }

    @Transactional
    public UserDtos.UserProfile updateProfile(Long userId, UserDtos.UpdateProfileRequest req) {
        User user = requireUser(userId);

        if (req.username() != null && !req.username().isBlank() && !req.username().trim().equals(user.getUsername())) {
            if (userRepository.existsByUsername(req.username().trim())) throw BusinessException.conflict("用户名已被占用");
            user.setUsername(req.username().trim());
        }

        if (req.nickname() != null) {
            String nick = req.nickname().trim();
            user.setNickname(nick.isEmpty() ? null : nick);
        }
        if (req.signature() != null) {
            String sig = req.signature().trim();
            var mode = settingsRepository.findById(1L).map(s -> s.getSignatureAuditMode()).orElse("OFF");
            boolean audit = "ALWAYS".equals(mode) || ("FIRST".equals(mode) && !Boolean.TRUE.equals(user.getSignatureApprovedOnce()));
            if (audit && !sig.isEmpty()) user.setPendingSignature(sig);
            else user.setSignature(sig.isEmpty() ? null : sig);
        }
        if (req.avatarUrl() != null) {
            String url = req.avatarUrl().trim();
            user.setAvatarUrl(url.isEmpty() ? null : url);
        }

        return UserDtos.UserProfile.from(userRepository.save(user));
    }

    @Transactional(readOnly = true)
    public PageResponse<UserDtos.AuthorSummary> search(String keyword, int page, int size) {
        Pageable pageable = PageRequest.of(page, normalizeSize(size), Sort.by(Sort.Direction.ASC, "username"));
        if (keyword == null || keyword.isBlank()) {
            return PageResponse.of(userRepository.findAll(pageable), UserDtos.AuthorSummary::from);
        }
        Page<User> result = userRepository.searchByKeyword(keyword.trim(), pageable);
        return PageResponse.of(result, UserDtos.AuthorSummary::from);
    }

    @Transactional
    public void incrementPostCount(Long userId, int delta) {
        User user = requireUser(userId);
        user.setPostCount(Math.max(0, user.getPostCount() + delta));
        userRepository.save(user);
    }

    @Transactional
    public void incrementCommentCount(Long userId, int delta) {
        User user = requireUser(userId);
        user.setCommentCount(Math.max(0, user.getCommentCount() + delta));
        userRepository.save(user);
    }

    static int normalizeSize(int size) {
        if (size <= 0) {
            return 20;
        }
        return Math.min(size, 100);
    }
}
