package com.forum.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Index;
import jakarta.persistence.Table;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(
        name = "users",
        indexes = {
                @Index(name = "idx_users_username", columnList = "username", unique = true),
                @Index(name = "idx_users_email", columnList = "email", unique = true)
        }
)
public class User extends BaseEntity {

    @Column(nullable = false, length = 32, unique = true)
    private String username;

    /** 公开唯一标识，注册后不可修改 */
    @Column(length = 32, unique = true)
    private String uid;

    /** BCrypt 哈希，绝不存明文 */
    @Column(name = "password_hash", nullable = false, length = 100)
    private String passwordHash;

    @Column(length = 128, unique = true)
    private String email;

    @Column(length = 32)
    private String nickname;

    @Column(name = "avatar_url", length = 255)
    private String avatarUrl;

    @Column(length = 200)
    private String signature;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 16)
    private Role role = Role.USER;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 16)
    private UserStatus status = UserStatus.ACTIVE;

    @Column(name = "post_count", nullable = false)
    private Integer postCount = 0;

    @Column(name = "comment_count", nullable = false)
    private Integer commentCount = 0;

    /** 等级 1-10 */
    @Column(nullable = false)
    private Integer level = 1;

    /** 当前等级内累计经验（未满升级所需） */
    @Column(nullable = false)
    private Integer exp = 0;

    /** 金币余额 */
    @Column(nullable = false)
    private Long gold = 0L;

    /** 连续签到天数（可选展示） */
    @Column(name = "checkin_streak", nullable = false)
    private Integer checkinStreak = 0;

    /** 最近一次签到日期（用于每日一次判定） */
    @Column(name = "last_checkin_date")
    private LocalDate lastCheckinDate;

    /** 达到当前等级的时间（用于计算停留天数） */
    @Column(name = "level_up_at")
    private LocalDateTime levelUpAt;

    /** 头衔（管理员/站长授予，展示在昵称旁） */
    @Column(length = 32)
    private String title;

    /** ADMIN 角色所管辖的板块（仅 ADMIN 使用） */
    @Column(name = "managed_board_id")
    private Long managedBoardId;

    /** 推荐算法中的作者权重，站长可调，默认 1.0 */
    @Column(name = "ranking_weight", nullable = false)
    private Double rankingWeight = 1.0;

    /** 待审核的新签名 */
    @Column(name = "pending_signature", length = 200)
    private String pendingSignature;

    @Column(name = "signature_approved_once", nullable = false)
    private Boolean signatureApprovedOnce = false;

    @Column(name = "email_verified", nullable = false)
    private Boolean emailVerified = false;

    /** 单个用户最大上传大小（MB），null 表示使用角色默认配额 */
    @Column(name = "max_upload_mb")
    private Integer maxUploadMb;

    /** 连续登录失败次数（用于限流锁定） */
    @Column(name = "failed_login_count", nullable = false)
    private Integer failedLoginCount = 0;

    /** 登录锁定截止时间，null 表示未锁定 */
    @Column(name = "locked_until")
    private LocalDateTime lockedUntil;

    public enum Role {
        /** 站长：最高权限，可修改站点、任命超管与管理员 */
        OWNER,
        /** 超级管理员：管理全部板块，可任命管理员 */
        SUPER_ADMIN,
        /** 管理员：仅管理所辖板块（删帖/审核/删评论） */
        ADMIN,
        /** 普通用户 */
        USER
    }

    public enum UserStatus {
        /** 正常 */
        ACTIVE,
        /** 已封禁，禁止登录与发言 */
        BANNED
    }

    public String getDisplayName() {
        return (nickname == null || nickname.isBlank()) ? username : nickname;
    }

    public boolean isOwner() {
        return role == Role.OWNER;
    }

    public boolean isSuperAdmin() {
        return role == Role.SUPER_ADMIN;
    }

    public boolean isAdmin() {
        return role == Role.ADMIN;
    }

    /** 是否具备管理员及以上权限 */
    public boolean isStaff() {
        return role == Role.OWNER || role == Role.SUPER_ADMIN || role == Role.ADMIN;
    }

    /** 是否能管理指定板块（站长/超管全部，管理员仅所辖） */
    public boolean canManageBoard(Long boardId) {
        if (role == Role.OWNER || role == Role.SUPER_ADMIN) {
            return true;
        }
        if (role == Role.ADMIN) {
            return managedBoardId != null && managedBoardId.equals(boardId);
        }
        return false;
    }

    /** 是否能任命角色（站长可任超管/管理，超管可任管理） */
    public boolean canAssignRole(Role target) {
        if (this.role == Role.OWNER) {
            return target == Role.SUPER_ADMIN || target == Role.ADMIN || target == Role.USER;
        }
        if (this.role == Role.SUPER_ADMIN) {
            return target == Role.ADMIN || target == Role.USER;
        }
        return false;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public void setPasswordHash(String passwordHash) {
        this.passwordHash = passwordHash;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getAvatarUrl() {
        return avatarUrl;
    }

    public void setAvatarUrl(String avatarUrl) {
        this.avatarUrl = avatarUrl;
    }

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public UserStatus getStatus() {
        return status;
    }

    public void setStatus(UserStatus status) {
        this.status = status;
    }

    public Integer getPostCount() {
        return postCount;
    }

    public void setPostCount(Integer postCount) {
        this.postCount = postCount;
    }

    public Integer getCommentCount() {
        return commentCount;
    }

    public void setCommentCount(Integer commentCount) {
        this.commentCount = commentCount;
    }

    public Integer getLevel() {
        return level;
    }

    public void setLevel(Integer level) {
        this.level = level;
    }

    public Integer getExp() {
        return exp;
    }

    public void setExp(Integer exp) {
        this.exp = exp;
    }

    public Long getGold() {
        return gold;
    }

    public void setGold(Long gold) {
        this.gold = gold;
    }

    public Integer getCheckinStreak() {
        return checkinStreak;
    }

    public void setCheckinStreak(Integer checkinStreak) {
        this.checkinStreak = checkinStreak;
    }

    public LocalDate getLastCheckinDate() {
        return lastCheckinDate;
    }

    public void setLastCheckinDate(LocalDate lastCheckinDate) {
        this.lastCheckinDate = lastCheckinDate;
    }

    public LocalDateTime getLevelUpAt() {
        return levelUpAt;
    }

    public void setLevelUpAt(LocalDateTime levelUpAt) {
        this.levelUpAt = levelUpAt;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Long getManagedBoardId() {
        return managedBoardId;
    }

    public void setManagedBoardId(Long managedBoardId) {
        this.managedBoardId = managedBoardId;
    }

    public Double getRankingWeight() { return rankingWeight; }
    public void setRankingWeight(Double rankingWeight) { this.rankingWeight = rankingWeight; }
    public String getPendingSignature() { return pendingSignature; }
    public void setPendingSignature(String pendingSignature) { this.pendingSignature = pendingSignature; }
    public Boolean getSignatureApprovedOnce() { return signatureApprovedOnce; }
    public void setSignatureApprovedOnce(Boolean value) { this.signatureApprovedOnce = value; }
    public Boolean getEmailVerified() { return emailVerified; }
    public void setEmailVerified(Boolean value) { this.emailVerified = value; }
    public Integer getMaxUploadMb() { return maxUploadMb; }
    public void setMaxUploadMb(Integer value) { this.maxUploadMb = value; }
    public Integer getFailedLoginCount() { return failedLoginCount; }
    public void setFailedLoginCount(Integer value) { this.failedLoginCount = value; }
    public LocalDateTime getLockedUntil() { return lockedUntil; }
    public void setLockedUntil(LocalDateTime value) { this.lockedUntil = value; }
}
