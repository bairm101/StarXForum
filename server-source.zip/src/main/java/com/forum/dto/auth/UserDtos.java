package com.forum.dto.auth;

import com.forum.entity.User;
import jakarta.validation.constraints.Size;

import java.time.LocalDateTime;

public class UserDtos {

    /** 对外用户资料，绝不包含密码哈希 */
    public record UserProfile(
            Long id,
            String uid,
            String username,
            String nickname,
            String displayName,
            String avatarUrl,
            String signature,
            String role,
            String status,
            Integer postCount,
            Integer commentCount,
            Integer level,
            Integer exp,
            Long gold,
            Integer checkinStreak,
            String title,
            Long managedBoardId,
            Double rankingWeight,
            String pendingSignature,
            Boolean emailVerified,
            Integer maxUploadMb,
            LocalDateTime createdAt
    ) {
        public static UserProfile from(User u) {
            return new UserProfile(
                    u.getId(),
                    u.getUid(),
                    u.getUsername(),
                    u.getNickname(),
                    u.getDisplayName(),
                    u.getAvatarUrl(),
                    u.getSignature(),
                    u.getRole().name(),
                    u.getStatus().name(),
                    u.getPostCount(),
                    u.getCommentCount(),
                    u.getLevel(),
                    u.getExp(),
                    u.getGold(),
                    u.getCheckinStreak(),
                    u.getTitle(),
                    u.getManagedBoardId(),
                    u.getRankingWeight(),
                    u.getPendingSignature(),
                    u.getEmailVerified(),
                    u.getMaxUploadMb(),
                    u.getCreatedAt()
            );
        }
    }

    /** 帖子/评论中内嵌的作者摘要 */
    public record AuthorSummary(
            Long id,
            String uid,
            String username,
            String displayName,
            String avatarUrl,
            String title,
            String role
    ) {
        public static AuthorSummary from(User u) {
            if (u == null) {
                return null;
            }
            return new AuthorSummary(u.getId(), u.getUid(), u.getUsername(), u.getDisplayName(),
                    u.getAvatarUrl(), u.getTitle(),
                    u.getRole() != null ? u.getRole().name() : "USER");
        }
    }

    public record UpdateProfileRequest(
            @Size(min = 3, max = 32, message = "用户名长度需在 3-32 之间")
            String username,

            @Size(max = 32, message = "昵称最长 32 字")
            String nickname,

            @Size(max = 200, message = "签名最长 200 字")
            String signature,

            @Size(max = 255, message = "头像地址过长")
            String avatarUrl
    ) {
    }
}
