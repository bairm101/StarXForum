package com.forum.dto;

import com.forum.entity.SiteSettings;
import com.forum.entity.User;

import java.util.Map;

public class AdminDtos {
    public record SettingsRequest(
            String siteName, String pageTitle, String siteDescription, String announcement,
            Boolean allowRegister, String defaultTheme, String footerText, String footerIcp,
            String footerLinksJson, String signatureAuditMode,
            Boolean emailVerificationEnabled, Boolean arithmeticEmailEnabled,
            Boolean arithmeticPostEnabled, Boolean arithmeticCommentEnabled,
            Boolean smtpEnabled, String smtpHost, Integer smtpPort, String smtpUsername,
            String smtpPassword, Boolean smtpSsl,
            Boolean imageCompressEnabled, Boolean videoCompressEnabled,
            Boolean postEditAuditEnabled,
            Boolean deviceVerificationEnabled,
            Integer imageMaxMb, Integer videoMaxMb,
            String officialWebsite, String webShareBaseUrl, String contactEmail, String aboutIcp,
            Integer autoRefreshSeconds
    ) {}

    /** SMTP 密码永不返回，仅返回 configured 标记。 */
    public record SettingsView(
            String siteName, String pageTitle, String siteDescription, String announcement,
            Boolean allowRegister, String defaultTheme, String footerText, String footerIcp,
            String footerLinksJson, String signatureAuditMode,
            Boolean emailVerificationEnabled, Boolean arithmeticEmailEnabled,
            Boolean arithmeticPostEnabled, Boolean arithmeticCommentEnabled,
            Boolean smtpEnabled, String smtpHost, Integer smtpPort, String smtpUsername,
            Boolean smtpPasswordConfigured, Boolean smtpSsl,
            Boolean imageCompressEnabled, Boolean videoCompressEnabled,
            Boolean postEditAuditEnabled,
            Boolean deviceVerificationEnabled,
            Integer imageMaxMb, Integer videoMaxMb,
            String officialWebsite, String webShareBaseUrl, String contactEmail, String aboutIcp,
            Integer autoRefreshSeconds
    ) {
        public static SettingsView from(SiteSettings s) {
            return new SettingsView(s.getSiteName(), s.getPageTitle(), s.getSiteDescription(), s.getAnnouncement(),
                    s.getAllowRegister(), s.getDefaultTheme(), s.getFooterText(), s.getFooterIcp(),
                    s.getFooterLinksJson(), s.getSignatureAuditMode(), s.getEmailVerificationEnabled(),
                    s.getArithmeticEmailEnabled(), s.getArithmeticPostEnabled(), s.getArithmeticCommentEnabled(),
                    s.getSmtpEnabled(), s.getSmtpHost(), s.getSmtpPort(), s.getSmtpUsername(),
                    s.getSmtpPassword() != null && !s.getSmtpPassword().isBlank(), s.getSmtpSsl(),
                    s.getImageCompressEnabled(), s.getVideoCompressEnabled(), s.getPostEditAuditEnabled(),
                    s.getDeviceVerificationEnabled(), s.getImageMaxMb(), s.getVideoMaxMb(),
                    s.getOfficialWebsite(), s.getWebShareBaseUrl(), s.getContactEmail(), s.getAboutIcp(),
                    s.getAutoRefreshSeconds());
        }
    }

    public record UserParametersRequest(
            String username, String signature, String password,
            Integer level, Integer exp, Long gold, Double rankingWeight,
            String email, Integer maxUploadMb
    ) {}

    public record ChallengeView(String id, String expression, String purpose, long expiresInSeconds) {}
    public record ChallengeAnswer(String challengeId, Integer answer) {}
    public record EmailCodeRequest(String email, String challengeId, Integer answer) {}
    public record EmailCodeVerifyRequest(String email, String code) {}
    public record UploadView(String url, String type, long originalBytes, long storedBytes,
                             boolean compressed, long usedBytes, long quotaBytes) {}
}
