package com.forum.controller;

import com.forum.exception.BusinessException;
import com.forum.repository.UploadRecordRepository;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.nio.file.Path;
import java.nio.file.Paths;

@RestController
@RequestMapping("/media")
public class MediaController {
    private final UploadRecordRepository uploads;
    public MediaController(UploadRecordRepository uploads) { this.uploads = uploads; }

    @GetMapping("/{code}")
    public ResponseEntity<Resource> get(@PathVariable String code) {
        var record = uploads.findByPublicCode(code).orElseThrow(() -> BusinessException.notFound("媒体不存在"));
        Path root = Paths.get("/opt/server/uploads").toAbsolutePath().normalize();
        Path file = root.resolve(record.getPath().replaceFirst("^/uploads/", "")).normalize();
        if (!file.startsWith(root) || !file.toFile().isFile()) throw BusinessException.notFound("媒体不存在");
        String type = record.getContentType();
        if (type == null || type.isBlank() || type.equals(MediaType.APPLICATION_OCTET_STREAM_VALUE)) {
            type = guessContentType(file.getFileName().toString());
        }
        return ResponseEntity.ok().cacheControl(CacheControl.maxAge(java.time.Duration.ofDays(7)).cachePublic())
                .contentType(MediaType.parseMediaType(type)).body(new FileSystemResource(file));
    }

    /** 按扩展名推断 Content-Type，避免图片返回 octet-stream 导致无法渲染。 */
    private String guessContentType(String filename) {
        String lower = filename.toLowerCase(java.util.Locale.ROOT);
        if (lower.endsWith(".jpg") || lower.endsWith(".jpeg")) return "image/jpeg";
        if (lower.endsWith(".png")) return "image/png";
        if (lower.endsWith(".gif")) return "image/gif";
        if (lower.endsWith(".webp")) return "image/webp";
        if (lower.endsWith(".mp4")) return "video/mp4";
        if (lower.endsWith(".webm")) return "video/webm";
        if (lower.endsWith(".mov")) return "video/quicktime";
        if (lower.endsWith(".md") || lower.endsWith(".txt")) return "text/plain; charset=utf-8";
        if (lower.endsWith(".json")) return "application/json";
        if (lower.endsWith(".pdf")) return "application/pdf";
        return MediaType.APPLICATION_OCTET_STREAM_VALUE;
    }
}
