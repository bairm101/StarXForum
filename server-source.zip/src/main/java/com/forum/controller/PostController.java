package com.forum.controller;

import com.forum.dto.ApiResponse;
import com.forum.dto.CheckinDtos;
import com.forum.dto.ForumDtos;
import com.forum.dto.PageResponse;
import com.forum.entity.Post;
import com.forum.security.ForumUserPrincipal;
import com.forum.service.CheckinService;
import com.forum.service.PostService;
import com.forum.service.UserService;
import com.forum.service.VerificationService;
import com.forum.service.PostGateService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import java.util.List;
import java.util.Map;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class PostController {

    private final PostService postService;
    private final UserService userService;
    private final CheckinService checkinService;
    private final VerificationService verificationService;
    private final PostGateService postGateService;
    private final com.forum.repository.PollRepository pollRepository;
    private final com.forum.service.PollService pollService;
    private final com.forum.service.SocialService socialService;

    public PostController(PostService postService, UserService userService,
                          CheckinService checkinService, VerificationService verificationService, PostGateService postGateService,
                          com.forum.repository.PollRepository pollRepository, com.forum.service.PollService pollService,
                          com.forum.service.SocialService socialService) {
        this.postService = postService;
        this.userService = userService;
        this.checkinService = checkinService;
        this.verificationService = verificationService;
        this.postGateService = postGateService;
        this.pollRepository = pollRepository;
        this.pollService = pollService;
        this.socialService = socialService;
    }

    /** 关注的人的帖子流 */
    @GetMapping("/feed/following")
    public ApiResponse<PageResponse<ForumDtos.PostSummary>> followingFeed(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size,
            @AuthenticationPrincipal ForumUserPrincipal principal) {
        Long me = idOrNull(principal);
        if (me == null) throw new com.forum.exception.BusinessException("请先登录", org.springframework.http.HttpStatus.UNAUTHORIZED);
        return ApiResponse.ok(postService.followingFeed(socialService.followingIds(me), me, page, size));
    }

    /** 帖子关联的投票（无则返回 null） */
    @GetMapping("/posts/{id}/poll")
    public ApiResponse<Map<String, Object>> poll(@PathVariable Long id,
                                                 @AuthenticationPrincipal ForumUserPrincipal principal) {
        var poll = pollRepository.findByPostId(id).orElse(null);
        if (poll == null) return ApiResponse.ok(null);
        return ApiResponse.ok(pollService.getResult(poll.getId(),
                principal == null ? null : principal.getId()));
    }

    @GetMapping("/posts")
    public ApiResponse<PageResponse<ForumDtos.PostSummary>> list(
            @RequestParam(required = false) Long boardId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size,
            @RequestParam(defaultValue = "latest") String sort,
            @AuthenticationPrincipal ForumUserPrincipal principal) {
        return ApiResponse.ok(postService.list(boardId, page, size, sort, idOrNull(principal)));
    }

    @GetMapping("/topics/{topic}/posts")
    public ApiResponse<PageResponse<ForumDtos.PostSummary>> listByTopic(
            @PathVariable String topic,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size,
            @AuthenticationPrincipal ForumUserPrincipal principal) {
        return ApiResponse.ok(postService.listByTopic(topic, page, size, idOrNull(principal)));
    }

    @GetMapping("/posts/{id}")
    public ApiResponse<ForumDtos.PostDetail> detail(
            @PathVariable Long id,
            HttpServletRequest request,
            @RequestParam(defaultValue = "false") boolean moderation,
            @AuthenticationPrincipal ForumUserPrincipal principal) {
        String viewerKey = clientKey(request, principal);
        var detail = postService.getDetail(id, idOrNull(principal), viewerKey, moderation);
        return ApiResponse.ok(detail);
    }

    /** 帖子编辑历史 */
    @GetMapping("/posts/{id}/history")
    public ApiResponse<List<Map<String, Object>>> history(@PathVariable Long id) {
        return ApiResponse.ok(postService.history(id));
    }

    @GetMapping("/posts/puid/{puid}")
    public ApiResponse<ForumDtos.PostDetail> detailByPuid(@PathVariable String puid,
                                                          HttpServletRequest request,
                                                          @AuthenticationPrincipal ForumUserPrincipal principal) {
        var post = postService.findByPuid(puid);
        return ApiResponse.ok(postService.getDetail(post.getId(), idOrNull(principal), clientKey(request, principal), false));
    }

    @PostMapping("/posts")
    public ApiResponse<ForumDtos.PostDetail> create(
            @Valid @RequestBody ForumDtos.CreatePostRequest req,
            @RequestHeader(value = "X-Challenge-Id", required = false) String challengeId,
            @RequestHeader(value = "X-Challenge-Answer", required = false) Integer challengeAnswer,
            @AuthenticationPrincipal ForumUserPrincipal principal) {
        verificationService.requireChallenge("POST", challengeId, challengeAnswer);
        return ApiResponse.ok(postService.create(req, principal.getId()), "发布成功");
    }

    @PostMapping("/posts/{id}/unlock")
    public ApiResponse<Void> unlock(@PathVariable Long id, @AuthenticationPrincipal ForumUserPrincipal principal) {
        postGateService.unlock(id, principal.getId()); return ApiResponse.okMessage("内容已解锁");
    }

    @PutMapping("/posts/{id}")
    public ApiResponse<ForumDtos.PostDetail> update(
            @PathVariable Long id,
            @Valid @RequestBody ForumDtos.UpdatePostRequest req,
            @AuthenticationPrincipal ForumUserPrincipal principal) {
        return ApiResponse.ok(postService.update(id, req, principal.getId()));
    }

    @DeleteMapping("/posts/{id}")
    public ApiResponse<Void> delete(@PathVariable Long id,
                                    @AuthenticationPrincipal ForumUserPrincipal principal) {
        postService.delete(id, principal.getId());
        return ApiResponse.okMessage("删除成功");
    }

    @PostMapping("/posts/{id}/like")
    public ApiResponse<ForumDtos.LikeResult> toggleLike(@PathVariable Long id,
                                                        @AuthenticationPrincipal ForumUserPrincipal principal) {
        return ApiResponse.ok(postService.toggleLike(id, principal.getId()));
    }

    @PostMapping("/posts/{id}/tip")
    public ApiResponse<CheckinDtos.TipResult> tip(@PathVariable Long id,
                                                  @RequestBody CheckinDtos.TipRequest req,
                                                  @AuthenticationPrincipal ForumUserPrincipal principal) {
        return ApiResponse.ok(checkinService.tip(id, req.amount(), principal.getId()), "打赏成功");
    }

    @GetMapping("/users/{authorId}/posts")
    public ApiResponse<PageResponse<ForumDtos.PostSummary>> listByAuthor(
            @PathVariable Long authorId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size,
            @AuthenticationPrincipal ForumUserPrincipal principal) {
        userService.requireUser(authorId);
        return ApiResponse.ok(postService.listByAuthor(authorId, page, size, idOrNull(principal)));
    }

    @GetMapping("/search")
    public ApiResponse<PageResponse<ForumDtos.PostSummary>> search(
            @RequestParam String q,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size,
            @AuthenticationPrincipal ForumUserPrincipal principal) {
        return ApiResponse.ok(postService.search(q, page, size, idOrNull(principal)));
    }

    // ---------- 管理员帖子操作 ----------

    @PatchMapping("/admin/posts/{id}/pin")
    public ApiResponse<Void> setPinned(@PathVariable Long id, @RequestParam boolean pinned,
                                       @AuthenticationPrincipal ForumUserPrincipal principal) {
        postService.setPinned(id, pinned, principal.getId());
        return ApiResponse.okMessage(pinned ? "已置顶" : "已取消置顶");
    }

    @PatchMapping("/admin/posts/{id}/lock")
    public ApiResponse<Void> setLocked(@PathVariable Long id, @RequestParam boolean locked,
                                       @AuthenticationPrincipal ForumUserPrincipal principal) {
        postService.setLocked(id, locked, principal.getId());
        return ApiResponse.okMessage(locked ? "已锁定" : "已解锁");
    }

    private Long idOrNull(ForumUserPrincipal principal) {
        return principal == null ? null : principal.getId();
    }

    private String clientKey(HttpServletRequest request, ForumUserPrincipal principal) {
        if (principal != null) {
            return "user:" + principal.getId();
        }
        String ip = request.getRemoteAddr();
        return ip == null ? "unknown" : ip;
    }
}
