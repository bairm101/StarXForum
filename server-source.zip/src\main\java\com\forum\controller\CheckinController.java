package com.forum.controller;

import com.forum.dto.ApiResponse;
import com.forum.dto.CheckinDtos;
import com.forum.security.ForumUserPrincipal;
import com.forum.service.CheckinService;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/checkin")
public class CheckinController {

    private final CheckinService checkinService;

    public CheckinController(CheckinService checkinService) {
        this.checkinService = checkinService;
    }

    @GetMapping("/status")
    public ApiResponse<CheckinDtos.CheckinStatus> status(
            @AuthenticationPrincipal ForumUserPrincipal principal) {
        return ApiResponse.ok(checkinService.status(principal.getId()));
    }

    @PostMapping
    public ApiResponse<CheckinDtos.CheckinResult> checkin(
            @AuthenticationPrincipal ForumUserPrincipal principal) {
        return ApiResponse.ok(checkinService.checkin(principal.getId()), "签到成功");
    }
}
