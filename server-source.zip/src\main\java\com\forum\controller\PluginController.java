package com.forum.controller;

import com.forum.dto.ApiResponse;
import com.forum.plugin.PluginManager;
import com.forum.security.ForumUserPrincipal;
import com.forum.service.UserService;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api/admin/plugins")
public class PluginController {
    private final PluginManager manager; private final UserService users;
    public PluginController(PluginManager manager, UserService users) { this.manager = manager; this.users = users; }
    @GetMapping
    public ApiResponse<List<Map<String, String>>> list(@AuthenticationPrincipal ForumUserPrincipal p) {
        if (!users.requireUser(p.getId()).isOwner()) throw com.forum.exception.BusinessException.forbidden("仅站长可管理插件");
        return ApiResponse.ok(manager.loaded());
    }
}
