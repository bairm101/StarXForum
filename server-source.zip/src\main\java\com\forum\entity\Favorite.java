package com.forum.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Index;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

/**
 * 帖子收藏。同一用户对同一帖子唯一收藏。
 */
@Entity
@Table(name = "favorites",
        uniqueConstraints = @UniqueConstraint(columnNames = {"user_id", "post_id"}),
        indexes = {
                @Index(name = "idx_fav_user", columnList = "user_id"),
                @Index(name = "idx_fav_post", columnList = "post_id")
        })
public class Favorite extends BaseEntity {

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(name = "post_id", nullable = false)
    private Long postId;

    public Long getUserId() { return userId; }
    public void setUserId(Long v) { this.userId = v; }
    public Long getPostId() { return postId; }
    public void setPostId(Long v) { this.postId = v; }
}
