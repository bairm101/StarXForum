package com.forum.service;

import com.forum.entity.Post;
import com.forum.entity.PostUnlock;
import com.forum.entity.User;
import com.forum.exception.BusinessException;
import com.forum.repository.CommentRepository;
import com.forum.repository.PostRepository;
import com.forum.repository.PostUnlockRepository;
import com.forum.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class PostGateService {
    private final PostRepository posts; private final CommentRepository comments; private final PostUnlockRepository unlocks; private final UserRepository users;
    public PostGateService(PostRepository posts, CommentRepository comments, PostUnlockRepository unlocks, UserRepository users){this.posts=posts;this.comments=comments;this.unlocks=unlocks;this.users=users;}
    @Transactional
    public boolean unlock(Long postId, Long userId){
        Post p=posts.findByIdAndDeletedFalse(postId).orElseThrow(()->BusinessException.notFound("帖子不存在"));
        if(!"PAID".equals(p.getGateType())) return true;
        if(unlocks.existsByPostIdAndUserId(postId,userId)) return true;
        User u=users.findById(userId).orElseThrow(()->BusinessException.notFound("用户不存在")); long price=p.getGatePrice()==null?0:p.getGatePrice();
        if(u.getGold()<price)throw new BusinessException("金币不足");
        u.setGold(u.getGold()-price);p.getAuthor().setGold(p.getAuthor().getGold()+price);
        PostUnlock x=new PostUnlock();x.setPostId(postId);x.setUserId(userId);x.setAmount(price);unlocks.save(x);users.save(u);users.save(p.getAuthor());return true;
    }
    public boolean canView(Post p,Long userId){
        if(!"REPLY".equals(p.getGateType())&&!"PAID".equals(p.getGateType()))return true;
        if(userId==null)return false;
        if(p.getAuthor().getId().equals(userId)||unlocks.existsByPostIdAndUserId(p.getId(),userId))return true;
        return "REPLY".equals(p.getGateType())&&comments.existsByPostIdAndAuthorIdAndDeletedFalse(p.getId(),userId);
    }
}
