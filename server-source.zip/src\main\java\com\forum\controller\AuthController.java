package com.forum.controller;

import com.forum.dto.ApiResponse;
import com.forum.dto.auth.AuthDtos;
import com.forum.dto.auth.UserDtos;
import com.forum.exception.BusinessException;
import com.forum.security.ForumUserPrincipal;
import com.forum.service.AuthService;
import com.forum.service.DeviceService;
import com.forum.service.RateLimitService;
import com.forum.service.UserService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.Duration;
import java.util.List;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthService authService;
    private final UserService userService;
    private final DeviceService deviceService;
    private final RateLimitService rateLimitService;

    public AuthController(AuthService authService, UserService userService,
                          DeviceService deviceService, RateLimitService rateLimitService) {
        this.authService = authService;
        this.userService = userService;
        this.deviceService = deviceService;
        this.rateLimitService = rateLimitService;
    }

    @PostMapping("/register")
    public ApiResponse<AuthDtos.LoginResponse> register(@Valid @RequestBody AuthDtos.RegisterRequest req,
                                                        HttpServletRequest request) {
        String ip = clientIp(request);
        if (rateLimitService.isLimited("rl:register:" + ip, 5, Duration.ofHours(1))) {
            throw new BusinessException("注册过于频繁，请稍后再试", HttpStatus.TOO_MANY_REQUESTS);
        }
        return ApiResponse.ok(authService.register(req), "注册成功");
    }

    @PostMapping("/login")
    public ApiResponse<AuthDtos.LoginResponse> login(@Valid @RequestBody AuthDtos.LoginRequest req,
                                                     HttpServletRequest request) {
        String ip = clientIp(request);
        // IP 级限流：5 分钟内最多 10 次尝试，防暴力破解/撞库
        if (rateLimitService.isLimited("rl:login:" + ip, 10, Duration.ofMinutes(5))) {
            throw new BusinessException("登录尝试过于频繁，请 5 分钟后再试", HttpStatus.TOO_MANY_REQUESTS);
        }
        // 用户名的补充限流：10 分钟内最多 20 次（配合按用户名锁定，防分布式撞库）
        if (req.username() != null && !req.username().isBlank()
                && rateLimitService.isLimited("rl:login:user:" + req.username().trim().toLowerCase(),
                        20, Duration.ofMinutes(10))) {
            throw new BusinessException("该账号登录尝试过于频繁，请稍后再试", HttpStatus.TOO_MANY_REQUESTS);
        }
        return ApiResponse.ok(authService.login(req), "登录成功");
    }

    /** 一键退登：吊销本人全部设备会话（当前设备也会退出） */
    @PostMapping("/me/logout-all")
    public ApiResponse<Void> logoutAll(@AuthenticationPrincipal ForumUserPrincipal principal) {
        int n = deviceService.revokeAllDevices(principal.getId());
        return ApiResponse.okMessage(n > 0 ? "已退出全部 " + n + " 个设备" : "当前无其他登录设备");
    }

    /** 取真实客户端 IP。forward-headers-strategy=native 已将 X-Forwarded-For 解析进 remoteAddr。 */
    private String clientIp(HttpServletRequest request) {
        String remote = request.getRemoteAddr();
        if (remote != null && !remote.isBlank()) {
            return remote;
        }
        String xff = request.getHeader("X-Forwarded-For");
        if (xff != null && !xff.isBlank()) {
            return xff.split(",")[0].trim();
        }
        return "unknown";
    }

    @PostMapping("/verify-device")
    public ApiResponse<AuthDtos.LoginResponse> verifyDevice(@Valid @RequestBody AuthDtos.DeviceVerifyRequest req) {
        return ApiResponse.ok(authService.verifyDevice(req), "验证成功");
    }

    @GetMapping("/me/devices")
    public ApiResponse<List<DeviceView>> myDevices(@AuthenticationPrincipal ForumUserPrincipal principal) {
        List<DeviceView> devices = deviceService.listDevices(principal.getId()).stream()
                .map(s -> new DeviceView(s.getSid(), s.getDeviceName(), s.getUserAgent(),
                        s.getLoginAt() == null ? null : s.getLoginAt().toString(),
                        s.getLastSeenAt() == null ? null : s.getLastSeenAt().toString(),
                        s.getRevoked()))
                .toList();
        return ApiResponse.ok(devices);
    }

    @DeleteMapping("/me/devices/{sid}")
    public ApiResponse<Void> revokeDevice(@AuthenticationPrincipal ForumUserPrincipal principal,
                                          @PathVariable String sid) {
        deviceService.revokeDevice(principal.getId(), sid);
        return ApiResponse.okMessage("设备已删除，该设备已退出登录");
    }

    public record DeviceView(String sid, String deviceName, String userAgent,
                             String loginAt, String lastSeenAt, Boolean revoked) {
    }

    @GetMapping("/me")
    public ApiResponse<UserDtos.UserProfile> me(@AuthenticationPrincipal ForumUserPrincipal principal) {
        return ApiResponse.ok(userService.getProfile(principal.getId()));
    }

    @PutMapping("/me")
    public ApiResponse<UserDtos.UserProfile> updateProfile(
            @AuthenticationPrincipal ForumUserPrincipal principal,
            @Valid @RequestBody UserDtos.UpdateProfileRequest req) {
        return ApiResponse.ok(userService.updateProfile(principal.getId(), req));
    }

    @PostMapping("/change-password")
    public ApiResponse<Void> changePassword(
            @AuthenticationPrincipal ForumUserPrincipal principal,
            @Valid @RequestBody AuthDtos.ChangePasswordRequest req) {
        authService.changePassword(principal.getId(), req);
        return ApiResponse.okMessage("密码修改成功");
    }

    /** 发送改邮箱验证码到新邮箱 */
    @PostMapping("/change-email/send")
    public ApiResponse<Void> sendChangeEmailCode(
            @AuthenticationPrincipal ForumUserPrincipal principal,
            @RequestBody ChangeEmailRequest req) {
        authService.sendChangeEmailCode(principal.getId(), req.newEmail());
        return ApiResponse.okMessage("验证码已发送到新邮箱");
    }

    /** 确认改邮箱 */
    @PostMapping("/change-email")
    public ApiResponse<Void> changeEmail(
            @AuthenticationPrincipal ForumUserPrincipal principal,
            @RequestBody ChangeEmailRequest req) {
        authService.changeEmail(principal.getId(), req.newEmail(), req.code());
        return ApiResponse.okMessage("邮箱修改成功");
    }

    /** 注销账号：删除帖子与上传文件，历史评论匿名化，账号不可再登录 */
    @PostMapping("/cancel")
    public ApiResponse<Void> cancelAccount(@AuthenticationPrincipal ForumUserPrincipal principal) {
        authService.cancelAccount(principal.getId());
        return ApiResponse.okMessage("账号已注销");
    }

    /** 忘记密码：发送重置验证码到账号绑定邮箱 */
    @PostMapping("/forgot-password/send")
    public ApiResponse<Void> sendForgotPasswordCode(@RequestBody ForgotPasswordRequest req) {
        authService.sendForgotPasswordCode(req.account());
        return ApiResponse.okMessage("验证码已发送到绑定邮箱");
    }

    /** 忘记密码：校验验证码并重置密码 */
    @PostMapping("/forgot-password")
    public ApiResponse<Void> resetPassword(@RequestBody ForgotPasswordRequest req) {
        authService.resetPassword(req.account(), req.code(), req.newPassword());
        return ApiResponse.okMessage("密码重置成功");
    }

    public record ChangeEmailRequest(String newEmail, String code) {
    }

    public record ForgotPasswordRequest(String account, String code, String newPassword) {
    }
}
