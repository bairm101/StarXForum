package com.forum.repository;

import com.forum.entity.UserSession;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface UserSessionRepository extends JpaRepository<UserSession, Long> {

    Optional<UserSession> findBySid(String sid);

    List<UserSession> findByUserIdOrderByLoginAtDesc(Long userId);

    List<UserSession> findByUserIdAndRevokedFalseOrderByLoginAtDesc(Long userId);

    boolean existsByUserIdAndDeviceIdAndRevokedFalse(Long userId, String deviceId);

    Optional<UserSession> findByUserIdAndDeviceIdAndRevokedFalse(Long userId, String deviceId);

    long countByUserId(Long userId);

    long countByRevokedTrue();
    long deleteByRevokedTrue();
}
