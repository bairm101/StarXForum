package com.forum.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Index;
import jakarta.persistence.Table;

/**
 * 系统通知。
 */
@Entity
@Table(
        name = "notifications",
        indexes = {
                @Index(name = "idx_notif_user", columnList = "user_id,read_flag"),
                @Index(name = "idx_notif_user_created", columnList = "user_id,created_at")
        }
)
public class Notification extends BaseEntity {

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 32)
    private Type type;

    @Column(nullable = false, length = 128)
    private String title;

    @Column(length = 500)
    private String content;

    /** 关联帖子/评论/会话等目标，可为空 */
    @Column(name = "ref_id")
    private Long refId;

    @Column(name = "read_flag", nullable = false)
    private Boolean read = false;

    public enum Type {
        /** 站长系统公告 */
        ANNOUNCEMENT,
        /** 审核通过 */
        MODERATION_APPROVED,
        /** 审核驳回 */
        MODERATION_REJECTED,
        /** 被评论 */
        COMMENT,
        /** 被点赞 */
        LIKE,
        /** 被 @ 提及 */
        MENTION,
        /** 举报处理结果 */
        REPORT,
        /** 新设备登录/异常登录 */
        DEVICE_LOGIN
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Type getType() {
        return type;
    }

    public void setType(Type type) {
        this.type = type;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Long getRefId() {
        return refId;
    }

    public void setRefId(Long refId) {
        this.refId = refId;
    }

    public Boolean getRead() {
        return read;
    }

    public void setRead(Boolean read) {
        this.read = read;
    }
}
