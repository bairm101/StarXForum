package com.forum.controller;

import com.forum.dto.ApiResponse;
import com.forum.security.ForumUserPrincipal;
import com.forum.service.PollService;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/polls")
public class PollController {

    private final PollService pollService;

    public PollController(PollService pollService) {
        this.pollService = pollService;
    }

    @PostMapping("/{postId}")
    public ApiResponse<Map<String, Object>> create(@PathVariable Long postId,
                                                   @RequestBody PollCreateReq req,
                                                   @AuthenticationPrincipal ForumUserPrincipal principal) {
        return ApiResponse.ok(pollService.create(postId, req.question(), req.multiple(),
                req.options(), req.deadline(), principal.getId()), "投票已创建");
    }

    @GetMapping("/{pollId}")
    public ApiResponse<Map<String, Object>> result(@PathVariable Long pollId,
                                                   @AuthenticationPrincipal ForumUserPrincipal principal) {
        return ApiResponse.ok(pollService.getResult(pollId,
                principal == null ? null : principal.getId()));
    }

    @PostMapping("/{pollId}/vote")
    public ApiResponse<Map<String, Object>> vote(@PathVariable Long pollId,
                                                 @RequestBody VoteReq req,
                                                 @AuthenticationPrincipal ForumUserPrincipal principal) {
        return ApiResponse.ok(pollService.vote(pollId, req.optionIds(), principal.getId()), "投票成功");
    }

    public record PollCreateReq(String question, boolean multiple, List<String> options,
                                java.time.LocalDateTime deadline) {
    }

    public record VoteReq(List<Long> optionIds) {
    }
}
