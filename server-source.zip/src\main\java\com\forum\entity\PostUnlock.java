package com.forum.entity;
import jakarta.persistence.*;
@Entity @Table(name="post_unlocks", uniqueConstraints=@UniqueConstraint(columnNames={"post_id","user_id"}))
public class PostUnlock extends BaseEntity {
 @Column(name="post_id",nullable=false) private Long postId;
 @Column(name="user_id",nullable=false) private Long userId;
 @Column(nullable=false) private Long amount=0L;
 public Long getPostId(){return postId;} public void setPostId(Long v){postId=v;}
 public Long getUserId(){return userId;} public void setUserId(Long v){userId=v;}
 public Long getAmount(){return amount;} public void setAmount(Long v){amount=v;}
}
