package com.forum.service;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 数据统计看板。
 */
@Service
public class StatsService {

    private final JdbcTemplate jdbc;

    public StatsService(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public Map<String, Object> overview() {
        Map<String, Object> m = new HashMap<>();
        m.put("users", jdbc.queryForObject("SELECT COUNT(*) FROM users", Long.class));
        m.put("posts", jdbc.queryForObject("SELECT COUNT(*) FROM posts WHERE deleted=0", Long.class));
        m.put("comments", jdbc.queryForObject("SELECT COUNT(*) FROM comments WHERE deleted=0", Long.class));
        m.put("boards", jdbc.queryForObject("SELECT COUNT(*) FROM boards", Long.class));
        m.put("likes", jdbc.queryForObject("SELECT COUNT(*) FROM likes", Long.class));
        m.put("messages", jdbc.queryForObject("SELECT COUNT(*) FROM messages", Long.class));
        return m;
    }

    /** 近 N 天每日注册数 */
    public List<Map<String, Object>> registrationsDaily(int days) {
        return dailyAgg("users", "created_at", days);
    }

    /** 近 N 天每日发帖数 */
    public List<Map<String, Object>> postsDaily(int days) {
        return dailyAgg("posts", "created_at", days);
    }

    /** 近 N 天每日评论数 */
    public List<Map<String, Object>> commentsDaily(int days) {
        return dailyAgg("comments", "created_at", days);
    }

    /** 活跃用户 Top */
    public List<Map<String, Object>> activeUsers(int limit) {
        List<Map<String, Object>> result = new ArrayList<>();
        jdbc.queryForList("""
                SELECT u.username, u.nickname, COUNT(p.id) AS posts, COUNT(c.id) AS comments
                FROM users u
                LEFT JOIN posts p ON p.author_id = u.id AND p.deleted = 0
                LEFT JOIN comments c ON c.author_id = u.id AND c.deleted = 0
                GROUP BY u.id, u.username, u.nickname
                ORDER BY (COUNT(p.id) + COUNT(c.id)) DESC
                LIMIT ?
                """, limit).forEach(row -> result.add(row));
        return result;
    }

    private List<Map<String, Object>> dailyAgg(String table, String col, int days) {
        String safeTable = table; // 白名单调用方传入
        String sql = String.format("""
                SELECT DATE(%s) AS d, COUNT(*) AS c
                FROM %s
                WHERE %s >= DATE_SUB(CURDATE(), INTERVAL %d DAY)
                GROUP BY DATE(%s)
                ORDER BY DATE(%s)
                """, col, safeTable, col, days, col, col);
        return jdbc.queryForList(sql);
    }
}
