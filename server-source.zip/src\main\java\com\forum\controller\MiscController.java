package com.forum.controller;

import com.forum.dto.ApiResponse;
import com.forum.dto.ForumDtos;
import com.forum.service.AdminService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/api")
public class MiscController {

    private final AdminService adminService;

    public MiscController(AdminService adminService) {
        this.adminService = adminService;
    }

    @GetMapping("/health")
    public ApiResponse<Map<String, Object>> health() {
        return ApiResponse.ok(Map.of(
                "status", "UP",
                "time", java.time.LocalDateTime.now().toString()
        ));
    }

    /** 公开站点设置（站点名、公告等） */
    @GetMapping("/settings")
    public ApiResponse<ForumDtos.SiteSettingsView> settings() {
        return ApiResponse.ok(ForumDtos.SiteSettingsView.from(adminService.getSettings()));
    }
}
