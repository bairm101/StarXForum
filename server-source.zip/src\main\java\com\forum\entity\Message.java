package com.forum.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Lob;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

/**
 * 私信。conversationKey 由双方 id 排序拼接，便于按会话检索。
 */
@Entity
@Table(
        name = "messages",
        indexes = {
                @Index(name = "idx_messages_conversation", columnList = "conversation_key,created_at"),
                @Index(name = "idx_messages_recipient", columnList = "recipient_id,read_flag"),
                @Index(name = "idx_messages_sender", columnList = "sender_id")
        }
)
public class Message extends BaseEntity {

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "sender_id", nullable = false)
    private User sender;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "recipient_id", nullable = false)
    private User recipient;

    @Lob
    @Column(nullable = false, columnDefinition = "TEXT")
    private String content;

    @Column(name = "read_flag", nullable = false)
    private Boolean read = false;

    @Column(name = "conversation_key", nullable = false, length = 64)
    private String conversationKey;

    /** 发送方软删除（仅对自己隐藏） */
    @Column(name = "deleted_by_sender", nullable = false)
    private Boolean deletedBySender = false;

    /** 接收方软删除 */
    @Column(name = "deleted_by_recipient", nullable = false)
    private Boolean deletedByRecipient = false;

    /**
     * 生成会话键：小 id 在前，保证双向一致。
     */
    public static String buildConversationKey(Long a, Long b) {
        long lo = Math.min(a, b);
        long hi = Math.max(a, b);
        return lo + "_" + hi;
    }

    public User getSender() {
        return sender;
    }

    public void setSender(User sender) {
        this.sender = sender;
    }

    public User getRecipient() {
        return recipient;
    }

    public void setRecipient(User recipient) {
        this.recipient = recipient;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Boolean getRead() {
        return read;
    }

    public void setRead(Boolean read) {
        this.read = read;
    }

    public String getConversationKey() {
        return conversationKey;
    }

    public void setConversationKey(String conversationKey) {
        this.conversationKey = conversationKey;
    }

    public Boolean getDeletedBySender() {
        return deletedBySender;
    }

    public void setDeletedBySender(Boolean deletedBySender) {
        this.deletedBySender = deletedBySender;
    }

    public Boolean getDeletedByRecipient() {
        return deletedByRecipient;
    }

    public void setDeletedByRecipient(Boolean deletedByRecipient) {
        this.deletedByRecipient = deletedByRecipient;
    }
}
