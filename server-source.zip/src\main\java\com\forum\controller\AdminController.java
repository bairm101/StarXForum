package com.forum.controller;

import com.forum.dto.ApiResponse;
import com.forum.dto.AdminDtos;
import com.forum.dto.ForumDtos;
import com.forum.dto.PageResponse;
import com.forum.dto.auth.UserDtos;
import com.forum.security.ForumUserPrincipal;
import com.forum.service.AdminLogService;
import com.forum.service.AdminService;
import com.forum.service.DeviceService;
import com.forum.service.NotificationService;
import com.forum.service.PostService;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/admin")
public class AdminController {

    private final AdminService adminService;
    private final PostService postService;
    private final AdminLogService logService;
    private final DeviceService deviceService;
    private final NotificationService notificationService;

    public AdminController(AdminService adminService, PostService postService, AdminLogService logService,
                           DeviceService deviceService, NotificationService notificationService) {
        this.adminService = adminService;
        this.postService = postService;
        this.logService = logService;
        this.deviceService = deviceService;
        this.notificationService = notificationService;
    }

    // ---------- 用户管理 ----------

    @GetMapping("/users")
    public ApiResponse<PageResponse<UserDtos.UserProfile>> listUsers(
            @AuthenticationPrincipal ForumUserPrincipal principal,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size,
            @RequestParam(required = false) String keyword) {
        adminService.ensureStaff(principal.getId());
        return ApiResponse.ok(adminService.listUsers(page, size, keyword));
    }

    /** 后台创建用户 */
    @PostMapping("/users")
    public ApiResponse<UserDtos.UserProfile> createUser(
            @AuthenticationPrincipal ForumUserPrincipal principal,
            @RequestBody AdminDtos.CreateUserRequest req) {
        adminService.ensureStaff(principal.getId());
        UserDtos.UserProfile p = adminService.createUser(principal.getId(), req);
        logService.log(principal.getId(), principal.getUsername(), "CREATE_USER",
                "user:" + p.id(), "创建用户 " + p.username());
        return ApiResponse.ok(p, "用户创建成功");
    }

    /** 后台删除用户：帖子/上传文件全部删除，历史评论匿名化 */
    @DeleteMapping("/users/{id}")
    public ApiResponse<Void> deleteUser(
            @AuthenticationPrincipal ForumUserPrincipal principal,
            @PathVariable Long id) {
        adminService.deleteUser(principal.getId(), id);
        logService.log(principal.getId(), principal.getUsername(), "DELETE_USER",
                "user:" + id, "删除用户");
        return ApiResponse.okMessage("用户已删除");
    }

    @PatchMapping("/users/{id}/ban")
    public ApiResponse<Void> ban(@AuthenticationPrincipal ForumUserPrincipal principal,
                                 @PathVariable Long id, @RequestParam boolean banned,
                                 @RequestParam(required = false) String reason) {
        adminService.banUser(principal.getId(), id, banned);
        // 封禁时通知被处理用户（违规处理模板/原因）
        if (banned && reason != null && !reason.isBlank()) {
            notificationService.notify(id, principal.getId(),
                    com.forum.entity.Notification.Type.MODERATION_REJECTED,
                    "账号已被封禁",
                    "你的账号因「" + reason + "」被管理员封禁。如有异议请联系管理员。",
                    id);
        }
        logService.log(principal.getId(), principal.getUsername(), "BAN_USER", "user:" + id,
                banned ? "封禁用户" + (reason != null ? "（" + reason + "）" : "") : "解封用户");
        return ApiResponse.okMessage(banned ? "已封禁" : "已解封");
    }

    /** 任命角色：任命管理员需同时传 boardId */
    @PatchMapping("/users/{id}/role")
    public ApiResponse<UserDtos.UserProfile> setRole(@AuthenticationPrincipal ForumUserPrincipal principal,
                                                     @PathVariable Long id,
                                                     @RequestParam String role,
                                                     @RequestParam(required = false) Long boardId) {
        UserDtos.UserProfile result = adminService.setRole(principal.getId(), id, role, boardId);
        logService.log(principal.getId(), principal.getUsername(), "SET_ROLE", "user:" + id,
                "角色设置为 " + role + (boardId != null ? " (板块 " + boardId + ")" : ""));
        return ApiResponse.ok(result, "角色已更新");
    }

    /** 设置头衔（站长/超管） */
    @PatchMapping("/users/{id}/title")
    public ApiResponse<UserDtos.UserProfile> setTitle(@AuthenticationPrincipal ForumUserPrincipal principal,
                                                      @PathVariable Long id,
                                                      @RequestParam(required = false) String title) {
        UserDtos.UserProfile result = adminService.setTitle(principal.getId(), id, title);
        logService.log(principal.getId(), principal.getUsername(), "SET_TITLE", "user:" + id,
                "头衔设置为 " + title);
        return ApiResponse.ok(result, "头衔已更新");
    }

    // ---------- 帖子审核 ----------

    /** 待审核队列（管理员仅所辖板块） */
    @GetMapping("/posts/pending")
    public ApiResponse<PageResponse<ForumDtos.PostSummary>> pendingPosts(
            @AuthenticationPrincipal ForumUserPrincipal principal,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        return ApiResponse.ok(adminService.pendingPosts(principal.getId(), page, size));
    }

    @GetMapping("/posts")
    public ApiResponse<PageResponse<ForumDtos.PostSummary>> listPosts(
            @AuthenticationPrincipal ForumUserPrincipal principal,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        return ApiResponse.ok(adminService.listPosts(principal.getId(), page, size));
    }

    /** 审核通过/驳回 */
    @PostMapping("/posts/{id}/moderate")
    public ApiResponse<ForumDtos.PostSummary> moderate(@AuthenticationPrincipal ForumUserPrincipal principal,
                                                       @PathVariable Long id,
                                                       @RequestParam boolean approve) {
        ForumDtos.PostSummary result = postService.moderate(id, approve, principal.getId());
        logService.log(principal.getId(), principal.getUsername(),
                approve ? "POST_APPROVE" : "POST_REJECT", "post:" + id,
                approve ? "审核通过帖子" : "驳回帖子");
        return ApiResponse.ok(result, approve ? "已通过" : "已驳回");
    }

    @DeleteMapping("/posts/{id}")
    public ApiResponse<Void> deletePost(@AuthenticationPrincipal ForumUserPrincipal principal,
                                        @PathVariable Long id) {
        postService.deleteByModerator(id, principal.getId());
        logService.log(principal.getId(), principal.getUsername(), "DELETE_POST", "post:" + id, "删除帖子");
        return ApiResponse.okMessage("已删除");
    }

    @PatchMapping("/posts/{id}/move")
    public ApiResponse<Void> movePost(@AuthenticationPrincipal ForumUserPrincipal principal,
                                      @PathVariable Long id, @RequestParam Long boardId) {
        postService.movePost(id, boardId, principal.getId());
        logService.log(principal.getId(), principal.getUsername(), "MOVE_POST", "post:" + id,
                "转移到板块 " + boardId);
        return ApiResponse.okMessage("板块已转移");
    }

    // ---------- 站点设置 ----------

    @GetMapping("/settings")
    public ApiResponse<AdminDtos.SettingsView> getSettings(
            @AuthenticationPrincipal ForumUserPrincipal principal) {
        return ApiResponse.ok(adminService.fullSettings(principal.getId()));
    }

    @PutMapping("/settings")
    public ApiResponse<AdminDtos.SettingsView> updateSettings(
            @AuthenticationPrincipal ForumUserPrincipal principal,
            @RequestBody AdminDtos.SettingsRequest req) {
        return ApiResponse.ok(adminService.updateFullSettings(principal.getId(), req), "已保存");
    }

    @PatchMapping("/users/{id}/parameters")
    public ApiResponse<UserDtos.UserProfile> parameters(@AuthenticationPrincipal ForumUserPrincipal principal,
                                                        @PathVariable Long id,
                                                        @RequestBody AdminDtos.UserParametersRequest req) {
        return ApiResponse.ok(adminService.updateUserParameters(principal.getId(), id, req), "用户参数已更新");    }

    @PostMapping("/users/{id}/signature")
    public ApiResponse<UserDtos.UserProfile> signature(@AuthenticationPrincipal ForumUserPrincipal principal,
                                                       @PathVariable Long id,
                                                       @RequestParam boolean approve) {
        return ApiResponse.ok(adminService.moderateSignature(principal.getId(), id, approve), approve ? "签名已通过" : "签名已驳回");
    }

    /** 站长/超管强制退登：清空该用户所有已保存设备 */
    @PostMapping("/users/{id}/logout-all")
    public ApiResponse<Void> logoutAll(@AuthenticationPrincipal ForumUserPrincipal principal,
                                       @PathVariable Long id) {
        adminService.ensureStaff(principal.getId());
        int n = deviceService.revokeAllDevices(id);
        logService.log(principal.getId(), principal.getUsername(), "LOGOUT_ALL", "user:" + id,
                "强制退登，清空 " + n + " 个设备");
        return ApiResponse.okMessage("已强制退出全部 " + n + " 个设备");
    }

    @GetMapping("/overview")
    public ApiResponse<ForumDtos.OverviewStats> overview(
            @AuthenticationPrincipal ForumUserPrincipal principal) {
        adminService.ensureStaff(principal.getId());
        return ApiResponse.ok(adminService.overview());
    }
}
