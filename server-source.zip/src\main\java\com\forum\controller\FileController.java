package com.forum.controller;

import com.forum.config.ForumProperties;
import com.forum.dto.ApiResponse;
import com.forum.dto.AdminDtos;
import com.forum.service.FileStorageService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import com.forum.security.ForumUserPrincipal;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.util.Comparator;
import java.util.Map;

@RestController
@RequestMapping("/api/files")
public class FileController {

    private final FileStorageService fileStorageService;
    private final ForumProperties properties;

    public FileController(FileStorageService fileStorageService, ForumProperties properties) {
        this.fileStorageService = fileStorageService;
        this.properties = properties;
    }

    @PostMapping("/upload")
    public ApiResponse<String> upload(@RequestParam("file") MultipartFile file,
                                      @AuthenticationPrincipal ForumUserPrincipal principal) {
        String path = fileStorageService.store(file);
        String base = resolvePublicBase();
        return ApiResponse.ok(base + path, "上传成功");
    }

    @PostMapping("/media")
    public ApiResponse<AdminDtos.UploadView> uploadMedia(@RequestParam("file") MultipartFile file,
                                                         @RequestParam(defaultValue = "image") String type,
                                                         @AuthenticationPrincipal ForumUserPrincipal principal) {
        return ApiResponse.ok(fileStorageService.store(file, principal.getId(), type), "上传成功");
    }

    /**
     * 大文件分片上传。每片单独确认，避免 CDN/反代对单个大请求超时。
     */
    @PostMapping("/media/chunk")
    public ApiResponse<Map<String, Object>> uploadChunk(
            @RequestParam("file") MultipartFile file,
            @RequestParam String uploadId,
            @RequestParam int index,
            @RequestParam int total,
            @AuthenticationPrincipal ForumUserPrincipal principal) throws IOException {
        if (!uploadId.matches("[A-Za-z0-9_-]{8,80}")) {
            throw new com.forum.exception.BusinessException("非法上传标识");
        }
        if (index < 0 || total < 1 || index >= total || total > 5000) {
            throw new com.forum.exception.BusinessException("非法分片参数");
        }
        Path dir = chunkRoot().resolve(principal.getId().toString()).resolve(uploadId).normalize();
        if (!dir.startsWith(chunkRoot())) throw new com.forum.exception.BusinessException("非法路径");
        Files.createDirectories(dir);
        Path part = dir.resolve(String.format("%06d.part", index));
        try (InputStream in = file.getInputStream()) {
            Files.copy(in, part, StandardCopyOption.REPLACE_EXISTING);
        }
        return ApiResponse.ok(Map.of("index", index, "received", Files.size(part)), "分片已接收");
    }

    /** 合并全部分片，再复用原上传校验/配额/媒体记录逻辑。 */
    @PostMapping("/media/chunk/complete")
    public ApiResponse<AdminDtos.UploadView> completeChunkUpload(
            @RequestParam String uploadId,
            @RequestParam int total,
            @RequestParam String filename,
            @RequestParam(defaultValue = "image") String type,
            @AuthenticationPrincipal ForumUserPrincipal principal) throws IOException {
        if (!uploadId.matches("[A-Za-z0-9_-]{8,80}") || total < 1 || total > 5000) {
            throw new com.forum.exception.BusinessException("非法分片参数");
        }
        Path dir = chunkRoot().resolve(principal.getId().toString()).resolve(uploadId).normalize();
        if (!dir.startsWith(chunkRoot()) || !Files.isDirectory(dir)) {
            throw com.forum.exception.BusinessException.notFound("上传分片不存在或已过期");
        }
        Path merged = Files.createTempFile(chunkRoot(), "merge-", ".tmp");
        try {
            for (int i = 0; i < total; i++) {
                Path part = dir.resolve(String.format("%06d.part", i));
                if (!Files.isRegularFile(part)) throw new com.forum.exception.BusinessException("缺少分片：" + i);
                Files.write(merged, Files.readAllBytes(part), StandardOpenOption.APPEND);
            }
            MultipartFile assembled = new PathMultipartFile(merged, filename, contentType(filename));
            return ApiResponse.ok(fileStorageService.store(assembled, principal.getId(), type), "上传成功");
        } finally {
            deleteTree(dir);
            Files.deleteIfExists(merged);
        }
    }

    private Path chunkRoot() throws IOException {
        Path root = Paths.get(properties.getUpload().getDir()).toAbsolutePath().normalize().resolve(".chunks");
        Files.createDirectories(root);
        return root;
    }

    private void deleteTree(Path path) {
        if (path == null || !Files.exists(path)) return;
        try (var walk = Files.walk(path)) {
            walk.sorted(Comparator.reverseOrder()).forEach(p -> { try { Files.deleteIfExists(p); } catch (IOException ignored) {} });
        } catch (IOException ignored) {}
    }

    private String contentType(String name) {
        String n = name == null ? "" : name.toLowerCase();
        if (n.endsWith(".mp4")) return "video/mp4";
        if (n.endsWith(".webm")) return "video/webm";
        if (n.endsWith(".jpg") || n.endsWith(".jpeg")) return "image/jpeg";
        if (n.endsWith(".png")) return "image/png";
        if (n.endsWith(".gif")) return "image/gif";
        return "application/octet-stream";
    }

    private static class PathMultipartFile implements MultipartFile {
        private final Path path; private final String name; private final String contentType;
        PathMultipartFile(Path path, String name, String contentType) { this.path=path; this.name=name; this.contentType=contentType; }
        public String getName() { return "file"; }
        public String getOriginalFilename() { return name; }
        public String getContentType() { return contentType; }
        public boolean isEmpty() { try { return Files.size(path)==0; } catch(IOException e){ return true; } }
        public long getSize() { try { return Files.size(path); } catch(IOException e){ return 0; } }
        public byte[] getBytes() throws IOException { return Files.readAllBytes(path); }
        public InputStream getInputStream() throws IOException { return Files.newInputStream(path); }
        public void transferTo(File dest) throws IOException { Files.copy(path, dest.toPath(), StandardCopyOption.REPLACE_EXISTING); }
    }

    private String resolvePublicBase() {
        // 返回相对路径优先；由前端拼接到其 API base
        return "";
    }
}
