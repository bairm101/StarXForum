package com.forum.security;

import com.forum.config.ForumProperties;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.Date;

@Component
public class JwtService {

    private static final Logger log = LoggerFactory.getLogger(JwtService.class);
    private static final String CLAIM_ROLE = "role";
    private static final String CLAIM_USERNAME = "username";
    private static final String CLAIM_SID = "sid";
    private static final String CLAIM_DEVICE = "dev";

    private final ForumProperties properties;
    private SecretKey key;

    public JwtService(ForumProperties properties) {
        this.properties = properties;
    }

    @PostConstruct
    void init() {
        String secret = properties.getJwt().getSecret();
        if (secret == null || secret.getBytes(StandardCharsets.UTF_8).length < 32) {
            throw new IllegalStateException(
                    "JWT 密钥长度不足（至少 32 字节），请通过 JWT_SECRET 环境变量提供足够长度的随机密钥");
        }
        if (secret.startsWith("change-me")) {
            throw new IllegalStateException(
                    "检测到默认 JWT 密钥，存在伪造登录风险；请通过 JWT_SECRET 环境变量提供随机密钥");
        }
        this.key = Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8));
    }

    public String generateToken(Long userId, String username, String role) {
        return generateToken(userId, username, role, null, null);
    }

    public String generateToken(Long userId, String username, String role, String sid, String deviceId) {
        Instant now = Instant.now();
        Instant exp = now.plusSeconds(properties.getJwt().getExpirationSeconds());
        var builder = Jwts.builder()
                .subject(String.valueOf(userId))
                .claim(CLAIM_USERNAME, username)
                .claim(CLAIM_ROLE, role)
                .issuer(properties.getJwt().getIssuer())
                .issuedAt(Date.from(now))
                .expiration(Date.from(exp))
                .signWith(key);
        if (sid != null) {
            builder.claim(CLAIM_SID, sid);
        }
        if (deviceId != null) {
            builder.claim(CLAIM_DEVICE, deviceId);
        }
        return builder.compact();
    }

    /**
     * 解析并校验令牌。失败返回 null，不抛异常给上层过滤器。
     */
    public ParsedToken parse(String token) {
        try {
            Claims claims = Jwts.parser()
                    .verifyWith(key)
                    .requireIssuer(properties.getJwt().getIssuer())
                    .build()
                    .parseSignedClaims(token)
                    .getPayload();

            return new ParsedToken(
                    Long.parseLong(claims.getSubject()),
                    claims.get(CLAIM_USERNAME, String.class),
                    claims.get(CLAIM_ROLE, String.class),
                    claims.get(CLAIM_SID, String.class),
                    claims.get(CLAIM_DEVICE, String.class)
            );
        } catch (JwtException | IllegalArgumentException e) {
            // 令牌无效属正常业务流，仅在 debug 级别记录，避免日志噪音与信息泄露
            log.debug("JWT 校验失败: {}", e.getMessage());
            return null;
        }
    }

    public long getExpirationSeconds() {
        return properties.getJwt().getExpirationSeconds();
    }

    public record ParsedToken(Long userId, String username, String role, String sid, String deviceId) {
    }
}
