package com.forum.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

/**
 * 敏感词过滤规则。
 */
@Entity
@Table(name = "sensitive_words")
public class SensitiveWord extends BaseEntity {

    @Column(nullable = false, length = 64, unique = true)
    private String word;

    /** 替换显示内容 */
    @Column(nullable = false, length = 32)
    private String replacement = "***";

    @Column(nullable = false)
    private Boolean enabled = true;

    public String getWord() { return word; }
    public void setWord(String v) { this.word = v; }
    public String getReplacement() { return replacement; }
    public void setReplacement(String v) { this.replacement = v; }
    public Boolean getEnabled() { return enabled; }
    public void setEnabled(Boolean v) { this.enabled = v; }
}
