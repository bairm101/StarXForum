package com.forum.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

/**
 * 打赏记录。同一用户对同一帖子最多打赏 3 次（业务层校验）。
 */
@Entity
@Table(
        name = "tips",
        indexes = {
                @Index(name = "idx_tips_post", columnList = "post_id"),
                @Index(name = "idx_tips_user", columnList = "user_id"),
                @Index(name = "idx_tips_user_post", columnList = "user_id,post_id")
        }
)
public class Tip extends BaseEntity {

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "post_id", nullable = false)
    private Post post;

    /** 打赏金币数量 */
    @Column(nullable = false)
    private Long amount;

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Post getPost() {
        return post;
    }

    public void setPost(Post post) {
        this.post = post;
    }

    public Long getAmount() {
        return amount;
    }

    public void setAmount(Long amount) {
        this.amount = amount;
    }
}
