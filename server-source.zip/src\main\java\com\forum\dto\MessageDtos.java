package com.forum.dto;

import com.forum.dto.auth.UserDtos;
import com.forum.entity.Message;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.time.LocalDateTime;

public class MessageDtos {

    public record MessageView(
            Long id,
            UserDtos.AuthorSummary sender,
            UserDtos.AuthorSummary recipient,
            String content,
            Boolean read,
            Boolean mine,
            LocalDateTime createdAt
    ) {
        public static MessageView from(Message m, Long currentUserId) {
            boolean mine = m.getSender() != null && m.getSender().getId().equals(currentUserId);
            return new MessageView(
                    m.getId(),
                    UserDtos.AuthorSummary.from(m.getSender()),
                    UserDtos.AuthorSummary.from(m.getRecipient()),
                    m.getContent(),
                    m.getRead(),
                    mine,
                    m.getCreatedAt()
            );
        }
    }

    /** 会话列表项 */
    public record ConversationView(
            String conversationKey,
            UserDtos.AuthorSummary peer,
            String lastContent,
            Boolean lastFromMe,
            Boolean lastRead,
            long unreadCount,
            LocalDateTime lastAt
    ) {
    }

    public record SendMessageRequest(
            @NotNull(message = "请指定收件人")
            Long recipientId,

            @NotBlank(message = "消息内容不能为空")
            @Size(max = 2000, message = "消息最长 2000 字")
            String content
    ) {
    }

    public record UnreadCount(long unread) {
    }
}
