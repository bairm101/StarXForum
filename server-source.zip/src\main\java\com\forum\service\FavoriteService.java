package com.forum.service;

import com.forum.dto.PageResponse;
import com.forum.entity.Favorite;
import com.forum.entity.Post;
import com.forum.exception.BusinessException;
import com.forum.repository.FavoriteRepository;
import com.forum.repository.PostRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

import java.util.List;

/**
 * 帖子收藏。
 */
@Service
public class FavoriteService {

    private final FavoriteRepository favoriteRepository;
    private final PostRepository postRepository;

    public FavoriteService(FavoriteRepository favoriteRepository, PostRepository postRepository) {
        this.favoriteRepository = favoriteRepository;
        this.postRepository = postRepository;
    }

    @Transactional
    public boolean toggle(Long userId, Long postId) {
        if (favoriteRepository.existsByUserIdAndPostId(userId, postId)) {
            favoriteRepository.deleteByUserIdAndPostId(userId, postId);
            return false;
        }
        Post post = postRepository.findByIdAndDeletedFalse(postId)
                .orElseThrow(() -> BusinessException.notFound("帖子不存在或已删除"));
        Favorite fav = new Favorite();
        fav.setUserId(userId);
        fav.setPostId(postId);
        favoriteRepository.save(fav);
        return true;
    }

    @Transactional(readOnly = true)
    public boolean isFavorited(Long userId, Long postId) {
        return userId != null && favoriteRepository.existsByUserIdAndPostId(userId, postId);
    }

    @Transactional(readOnly = true)
    public List<Long> favoritedIds(Long userId, List<Long> postIds) {
        if (userId == null || postIds.isEmpty()) return List.of();
        return favoriteRepository.findByUserIdOrderByCreatedAtDesc(userId, PageRequest.of(0, 100000))
                .getContent().stream().map(Favorite::getPostId).filter(postIds::contains).toList();
    }

    @Transactional(readOnly = true)
    public Page<Post> myFavorites(Long userId, int page, int size) {
        Pageable pageable = PageRequest.of(page, Math.max(1, Math.min(size, 50)));
        Page<Favorite> favs = favoriteRepository.findByUserIdOrderByCreatedAtDesc(userId, pageable);
        List<Long> postIds = favs.getContent().stream().map(Favorite::getPostId).toList();
        if (postIds.isEmpty()) {
            return favs.map(f -> (Post) null);
        }
        List<Post> loaded = postRepository.findByIdsWithBoard(postIds);
        Map<Long, Post> byId = loaded.stream().collect(java.util.stream.Collectors.toMap(Post::getId, p -> p));
        List<Post> ordered = new java.util.ArrayList<>();
        for (Long id : postIds) {
            ordered.add(byId.get(id));
        }
        return new org.springframework.data.domain.PageImpl<>(ordered, pageable, favs.getTotalElements());
    }
}
