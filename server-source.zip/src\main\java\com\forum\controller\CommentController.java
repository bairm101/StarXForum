package com.forum.controller;

import com.forum.dto.ApiResponse;
import com.forum.dto.ForumDtos;
import com.forum.dto.PageResponse;
import com.forum.security.ForumUserPrincipal;
import com.forum.service.CommentService;
import com.forum.service.VerificationService;
import jakarta.validation.Valid;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class CommentController {

    private final CommentService commentService;
    private final VerificationService verificationService;

    public CommentController(CommentService commentService, VerificationService verificationService) {
        this.commentService = commentService;
        this.verificationService = verificationService;
    }

    @GetMapping("/posts/{postId}/comments")
    public ApiResponse<PageResponse<ForumDtos.CommentView>> listByPost(
            @PathVariable Long postId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size,
            @RequestParam(defaultValue = "latest") String sort,
            @AuthenticationPrincipal ForumUserPrincipal principal) {
        return ApiResponse.ok(commentService.listByPost(postId, page, size, sort, idOrNull(principal)));
    }

    @PostMapping("/posts/{postId}/comments")
    public ApiResponse<ForumDtos.CommentView> create(
            @PathVariable Long postId,
            @Valid @RequestBody ForumDtos.CreateCommentRequest req,
            @RequestHeader(value = "X-Challenge-Id", required = false) String challengeId,
            @RequestHeader(value = "X-Challenge-Answer", required = false) Integer challengeAnswer,
            @AuthenticationPrincipal ForumUserPrincipal principal) {
        verificationService.requireChallenge("COMMENT", challengeId, challengeAnswer);
        return ApiResponse.ok(commentService.create(postId, req, principal.getId()), "回复成功");
    }

    @PutMapping("/comments/{id}")
    public ApiResponse<ForumDtos.CommentView> update(
            @PathVariable Long id,
            @Valid @RequestBody ForumDtos.UpdateCommentRequest req,
            @AuthenticationPrincipal ForumUserPrincipal principal) {
        return ApiResponse.ok(commentService.update(id, req, principal.getId()));
    }

    @DeleteMapping("/comments/{id}")
    public ApiResponse<Void> delete(@PathVariable Long id,
                                    @AuthenticationPrincipal ForumUserPrincipal principal) {
        commentService.delete(id, principal.getId());
        return ApiResponse.okMessage("删除成功");
    }

    @PostMapping("/comments/{id}/like")
    public ApiResponse<ForumDtos.LikeResult> toggleLike(@PathVariable Long id,
                                                        @AuthenticationPrincipal ForumUserPrincipal principal) {
        return ApiResponse.ok(commentService.toggleLike(id, principal.getId()));
    }

    @GetMapping("/users/{authorId}/comments")
    public ApiResponse<PageResponse<ForumDtos.CommentView>> listByAuthor(
            @PathVariable Long authorId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size,
            @AuthenticationPrincipal ForumUserPrincipal principal) {
        return ApiResponse.ok(commentService.listByAuthor(authorId, page, size, idOrNull(principal)));
    }

    private Long idOrNull(ForumUserPrincipal principal) {
        return principal == null ? null : principal.getId();
    }
}
