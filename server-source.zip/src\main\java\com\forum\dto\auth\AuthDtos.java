package com.forum.dto.auth;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public class AuthDtos {

    public record RegisterRequest(
            @NotBlank(message = "用户名不能为空")
            @Size(min = 3, max = 32, message = "用户名长度需在 3-32 之间")
            @Pattern(regexp = "^[A-Za-z0-9_\\-\\u4e00-\\u9fa5]+$",
                    message = "用户名只能包含字母、数字、下划线、连字符或中文")
            String username,

            @NotBlank(message = "密码不能为空")
            @Size(min = 8, max = 72, message = "密码长度需在 8-72 之间")
            String password,

            @Email(message = "邮箱格式不正确")
            @Size(max = 128, message = "邮箱过长")
            String email,

            @Size(max = 32, message = "昵称最长 32 字")
            String nickname,

            String emailCode
    ) {
    }

    public record LoginRequest(
            @NotBlank(message = "用户名不能为空")
            String username,

            @NotBlank(message = "密码不能为空")
            String password,

            String deviceId,
            String deviceName
    ) {
    }

    public record LoginResponse(
            String token,
            long expiresInSeconds,
            UserDtos.UserProfile user,
            /** 非空表示需要换设备二次验证（邮箱验证码），客户端应调用 /api/auth/verify-device */
            String pendingDeviceId,
            boolean emailSent
    ) {
        public static LoginResponse ok(String token, long expires, UserDtos.UserProfile user) {
            return new LoginResponse(token, expires, user, null, false);
        }

        public static LoginResponse pending(String deviceId) {
            return new LoginResponse(null, 0, null, deviceId, true);
        }
    }

    public record DeviceVerifyRequest(
            @NotBlank(message = "用户名不能为空")
            String username,

            String deviceId,
            String deviceName,

            @NotBlank(message = "验证码不能为空")
            String code
    ) {
    }

    public record ChangePasswordRequest(
            @NotBlank(message = "原密码不能为空")
            String oldPassword,

            @NotBlank(message = "新密码不能为空")
            @Size(min = 8, max = 72, message = "新密码长度需在 8-72 之间")
            String newPassword
    ) {
    }
}
