package com.forum.dto;

import java.time.LocalDate;

public class CheckinDtos {

    /** 签到状态（我的页展示） */
    public record CheckinStatus(
            Integer level,
            Integer exp,
            Long gold,
            Integer streak,
            boolean checkedToday,
            LocalDate lastCheckinDate,
            int nextLevelExp,
            long daysStayedAtLevel
    ) {
    }

    /** 签到结果 */
    public record CheckinResult(
            int goldGain,
            int expGain,
            boolean leveledUp,
            Integer level,
            Integer exp,
            Long gold,
            Integer streak,
            int nextLevelExp
    ) {
    }

    /** 打赏请求 */
    public record TipRequest(Long amount) {
    }

    /** 打赏结果 */
    public record TipResult(
            Long amount,
            Long totalTipGold,
            Integer tipCount,
            Long myGold,
            int myTipTimes,
            int maxTipTimes
    ) {
    }
}
