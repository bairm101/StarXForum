package com.forum.repository;

import com.forum.entity.Comment;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface CommentRepository extends JpaRepository<Comment, Long> {
    boolean existsByPostIdAndAuthorIdAndDeletedFalse(Long postId, Long authorId);

    /** 顶层评论分页 */
    Page<Comment> findByPostIdAndParentIsNullAndDeletedFalseOrderByCreatedAtAsc(Long postId, Pageable pageable);

    /** 热门评论：按点赞数降序 */
    Page<Comment> findByPostIdAndParentIsNullAndDeletedFalseOrderByLikeCountDescCreatedAtAsc(Long postId, Pageable pageable);

    /** 批量取子回复，避免 N+1 */
    List<Comment> findByParentIdInAndDeletedFalseOrderByCreatedAtAsc(List<Long> parentIds);

    Page<Comment> findByAuthorIdAndDeletedFalse(Long authorId, Pageable pageable);

    Optional<Comment> findByIdAndDeletedFalse(Long id);

    long countByPostIdAndDeletedFalse(Long postId);

    long countByDeletedFalse();

    @Modifying
    @Query("UPDATE Comment c SET c.likeCount = c.likeCount + :delta WHERE c.id = :id")
    void addLikeCount(@Param("id") Long id, @Param("delta") int delta);

    @Modifying
    @Query("UPDATE Comment c SET c.dislikeCount = c.dislikeCount + :delta WHERE c.id = :id")
    void addDislikeCount(@Param("id") Long id, @Param("delta") int delta);

    /** 帖子被删除时级联软删其评论 */
    @Modifying
    @Query("UPDATE Comment c SET c.deleted = true WHERE c.post.id = :postId")
    void softDeleteByPostId(@Param("postId") Long postId);
}
