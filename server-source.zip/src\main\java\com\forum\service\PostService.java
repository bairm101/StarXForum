package com.forum.service;

import com.forum.dto.ForumDtos;
import com.forum.dto.PageResponse;
import com.forum.entity.Board;
import com.forum.entity.Like;
import com.forum.entity.Post;
import com.forum.entity.PostRevision;
import com.forum.entity.User;
import com.forum.exception.BusinessException;
import com.forum.repository.CommentRepository;
import com.forum.repository.DislikeRepository;
import com.forum.repository.LikeRepository;
import com.forum.repository.PostRepository;
import com.forum.repository.PostRevisionRepository;
import com.forum.repository.TipRepository;
import com.forum.repository.SiteSettingsRepository;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
public class PostService {

    @PersistenceContext
    private EntityManager entityManager;

    private static final Logger log = LoggerFactory.getLogger(PostService.class);

    private final PostRepository postRepository;
    private final CommentRepository commentRepository;
    private final LikeRepository likeRepository;
    private final DislikeRepository dislikeRepository;
    private final TipRepository tipRepository;
    private final BoardService boardService;
    private final UserService userService;
    private final CacheService cacheService;
    private final PostGateService postGateService;
    private final SiteSettingsRepository settingsRepository;
    private final MediaUrlService mediaUrls;
    private final NotificationService notificationService;
    private final ContentFilterService contentFilterService;
    private final SocialService socialService;
    private final PostRevisionRepository postRevisionRepository;

    public PostService(PostRepository postRepository,
                       CommentRepository commentRepository,
                       LikeRepository likeRepository,
                       DislikeRepository dislikeRepository,
                       TipRepository tipRepository,
                       BoardService boardService,
                       UserService userService,
                       CacheService cacheService, PostGateService postGateService,
                       SiteSettingsRepository settingsRepository, MediaUrlService mediaUrls,
                       NotificationService notificationService, ContentFilterService contentFilterService,
                       SocialService socialService, PostRevisionRepository postRevisionRepository) {
        this.postRepository = postRepository;
        this.commentRepository = commentRepository;
        this.likeRepository = likeRepository;
        this.dislikeRepository = dislikeRepository;
        this.tipRepository = tipRepository;
        this.boardService = boardService;
        this.userService = userService;
        this.cacheService = cacheService;
        this.postGateService = postGateService;
        this.settingsRepository = settingsRepository;
        this.mediaUrls = mediaUrls;
        this.notificationService = notificationService;
        this.contentFilterService = contentFilterService;
        this.socialService = socialService;
        this.postRevisionRepository = postRevisionRepository;
    }

    /** 该作者是否拉黑了我（被拉黑后无法查看其帖子） */
    private boolean authorBlockedMe(Post p, Long currentUserId) {
        return currentUserId != null && p.getAuthor() != null
                && socialService.iAmBlockedBy(currentUserId, p.getAuthor().getId());
    }

    // ---------- 查询 ----------

    @Transactional(readOnly = true)
    public PageResponse<ForumDtos.PostSummary> list(Long boardId, int page, int size,
                                                    String sort, Long currentUserId) {
        // 推荐排序走独立的加权打分算法（参考 X 推荐算法）
        if ("recommend".equalsIgnoreCase(sort)) {
            return recommend(boardId, page, size, currentUserId);
        }

        Pageable pageable = PageRequest.of(page, UserService.normalizeSize(size), resolveSort(sort));

        // 公开列表只展示已审核通过的帖子
        Page<Post> result = (boardId == null)
                ? postRepository.findByDeletedFalseAndStatus(Post.PostStatus.APPROVED, pageable)
                : postRepository.findByBoardIdAndDeletedFalseAndStatus(boardId, Post.PostStatus.APPROVED, pageable);

        return toSummaryPage(result, currentUserId);
    }

    @Transactional(readOnly = true)
    public PageResponse<ForumDtos.PostSummary> listByAuthor(Long authorId, int page, int size, Long currentUserId) {
        Pageable pageable = PageRequest.of(page, UserService.normalizeSize(size),
                Sort.by(Sort.Direction.DESC, "createdAt"));
        return toSummaryPage(
                postRepository.findByAuthorIdAndDeletedFalseAndStatus(authorId, Post.PostStatus.APPROVED, pageable),
                currentUserId);
    }

    /** 关注的人的帖子流 */
    @Transactional(readOnly = true)
    public PageResponse<ForumDtos.PostSummary> followingFeed(java.util.Set<Long> followingIds,
                                                             Long currentUserId, int page, int size) {
        if (followingIds == null || followingIds.isEmpty()) {
            return PageResponse.of(List.of(), page, UserService.normalizeSize(size), 0);
        }
        Pageable pageable = PageRequest.of(page, UserService.normalizeSize(size),
                Sort.by(Sort.Direction.DESC, "lastActivityAt"));
        return toSummaryPage(
                postRepository.findByAuthorIdInAndDeletedFalseAndStatus(followingIds, Post.PostStatus.APPROVED, pageable),
                currentUserId);
    }

    @Transactional(readOnly = true)
    public PageResponse<ForumDtos.PostSummary> listByTopic(String topic, int page, int size, Long currentUserId) {
        String clean = topic == null ? "" : topic.trim().replaceFirst("^#", "");
        if (clean.isBlank()) throw new BusinessException("请输入话题");
        Pageable pageable = PageRequest.of(page, UserService.normalizeSize(size),
                Sort.by(Sort.Direction.DESC, "lastActivityAt"));
        return toSummaryPage(
                postRepository.findByTopicsContainingAndDeletedFalseAndStatus(clean, Post.PostStatus.APPROVED, pageable),
                currentUserId);
    }

    /**
     * 全文搜索：优先 MySQL ngram 全文索引，索引不可用或无结果时回退 LIKE。
     */
    @Transactional(readOnly = true)
    public PageResponse<ForumDtos.PostSummary> search(String keyword, int page, int size, Long currentUserId) {
        if (keyword == null || keyword.isBlank()) {
            throw new BusinessException("请输入搜索关键词");
        }
        String kw = keyword.trim();
        Pageable pageable = PageRequest.of(page, UserService.normalizeSize(size));

        Page<Post> result = null;
        try {
            result = postRepository.fullTextSearch(kw, pageable);
        } catch (org.springframework.dao.DataAccessException e) {
            log.warn("全文索引不可用，回退 LIKE 查询: {}", e.getMessage());
        }

        if (result == null || result.isEmpty()) {
            Pageable likePageable = PageRequest.of(page, UserService.normalizeSize(size),
                    Sort.by(Sort.Direction.DESC, "lastActivityAt"));
            result = postRepository.likeSearch(kw, likePageable);
        }

        return toSummaryPage(result, currentUserId);
    }

    @Transactional
    public ForumDtos.PostDetail getDetail(Long id, Long currentUserId, String viewerKey) {
        return getDetail(id, currentUserId, viewerKey, false);
    }

    @Transactional
    public ForumDtos.PostDetail getDetail(Long id, Long currentUserId, String viewerKey, boolean moderation) {
        Post post = postRepository.findByIdAndDeletedFalse(id)
                .orElseThrow(() -> BusinessException.notFound("帖子不存在或已删除"));

        // 兼容旧帖子：无 PUID 时懒生成，保证分享可用
        if (post.getPuid() == null || post.getPuid().isEmpty()) {
            post.setPuid(generatePuid());
            post = postRepository.save(post);
        }

        // 被拉黑者无法查看拉黑者的帖子
        if (currentUserId != null && post.getAuthor() != null
                && socialService.iAmBlockedBy(currentUserId, post.getAuthor().getId())) {
            throw BusinessException.forbidden("你已被该用户拉黑，无法查看其帖子");
        }

        // 同一访客 30 分钟内重复访问不重复计数
        if (viewerKey != null && cacheService.markOnce("post:view:" + id + ":" + viewerKey, Duration.ofMinutes(30))) {
            postRepository.incrementViewCount(id);
            post.setViewCount(post.getViewCount() + 1);
        }

        boolean liked = currentUserId != null && likeRepository
                .existsByUserIdAndTargetTypeAndTargetId(currentUserId, Like.TargetType.POST, id);
        boolean disliked = currentUserId != null && dislikeRepository
                .existsByUserIdAndTargetTypeAndTargetId(currentUserId, Like.TargetType.POST, id);
        boolean canEdit = canModify(post, currentUserId);
        int myTipTimes = currentUserId == null ? 0
                : (int) tipRepository.countByUserIdAndPostId(currentUserId, id);

        boolean unlocked = postGateService.canView(post, currentUserId);
        // 仅板块管理员/站长在审核时可绕过隐藏内容，防止任意登录用户传 moderation=true 越权查看
        boolean effectiveModeration = moderation && currentUserId != null
                && canModerateBoard(post, currentUserId);
        if (effectiveModeration) unlocked = true;
        return detail(post, liked, disliked, canEdit, myTipTimes, unlocked, currentUserId, effectiveModeration);
    }

    @Transactional(readOnly = true)
    public Post findByPuid(String puid) {
        if (puid == null || !puid.matches("P[A-Za-z0-9]{10}")) {
            throw BusinessException.notFound("PUID 无效");
        }
        return postRepository.findByPuidAndDeletedFalse(puid.toUpperCase())
                .orElseThrow(() -> BusinessException.notFound("帖子不存在"));
    }

    // ---------- 写入 ----------

    @Transactional
    public ForumDtos.PostDetail create(ForumDtos.CreatePostRequest req, Long authorId) {
        Board board = boardService.requireBoard(req.boardId());
        if (!Boolean.TRUE.equals(board.getVisible())) {
            throw new BusinessException("该板块当前不可发帖");
        }
        User author = userService.requireUser(authorId);
        String filteredContent = contentFilterService.filter(req.content());

        // 使用敏感词：记录违规，频繁使用自动降权
        if (contentFilterService.containsSensitive(req.content())) {
            userService.recordSensitiveViolation(authorId);
        }

        Post post = new Post();
        post.setTitle(contentFilterService.filter(req.title().trim()));
        post.setContent(mediaUrls.normalizeContent(filteredContent));
        post.setBoard(board);
        post.setAuthor(author);
        post.setTopics(normalizeTopics(req.topics(), filteredContent));
        post.setPuid(generatePuid());
        post.setLastActivityAt(LocalDateTime.now());
        configureGate(post, req.gateType(), req.gatedContent(), req.gatePrice());
        post.setThumbnailUrl(mediaUrls.publicUrl(extractFirstImage(filteredContent)));

        // 板块开启审核则进入待审核，否则直接公开
        boolean needsModeration = Boolean.TRUE.equals(board.getRequireModeration());
        post.setStatus(needsModeration ? Post.PostStatus.PENDING : Post.PostStatus.APPROVED);

        Post saved = postRepository.save(post);
        if (!needsModeration) {
            boardService.adjustPostCount(board.getId(), 1);
            userService.incrementPostCount(authorId, 1);
        }

        contentFilterService.notifyMentions(filteredContent, authorId, author.getDisplayName(),
                saved.getTitle(), saved.getId());

        return detail(saved, false, false, true, 0, true, authorId, false);
    }

    @Transactional
    public ForumDtos.PostDetail update(Long id, ForumDtos.UpdatePostRequest req, Long currentUserId) {
        Post post = postRepository.findByIdAndDeletedFalse(id)
                .orElseThrow(() -> BusinessException.notFound("帖子不存在或已删除"));

        if (!canModify(post, currentUserId)) {
            throw BusinessException.forbidden("只能编辑自己的帖子");
        }
        if (Boolean.TRUE.equals(post.getLocked()) && !canModerateBoard(post, currentUserId)) {
            throw BusinessException.forbidden("帖子已被锁定，无法编辑");
        }

        // 保存编辑前快照（编辑历史）
        saveRevision(post, currentUserId);

        post.setTitle(contentFilterService.filter(req.title().trim()));
        post.setContent(mediaUrls.normalizeContent(contentFilterService.filter(req.content())));
        post.setTopics(normalizeTopics(req.topics(), req.content()));
        post.setThumbnailUrl(mediaUrls.publicUrl(extractFirstImage(req.content())));

        if (req.boardId() != null && !req.boardId().equals(post.getBoard().getId())) {
            Long oldBoardId = post.getBoard().getId();
            Board newBoard = boardService.requireBoard(req.boardId());
            post.setBoard(newBoard);
            boardService.adjustPostCount(oldBoardId, -1);
            boardService.adjustPostCount(newBoard.getId(), 1);
        }

        Post saved = postRepository.save(post);
        boolean liked = likeRepository.existsByUserIdAndTargetTypeAndTargetId(
                currentUserId, Like.TargetType.POST, id);
        boolean disliked = dislikeRepository.existsByUserIdAndTargetTypeAndTargetId(
                currentUserId, Like.TargetType.POST, id);
        int myTipTimes = (int) tipRepository.countByUserIdAndPostId(currentUserId, id);
        boolean editAudit = settingsRepository.findById(1L).map(s -> Boolean.TRUE.equals(s.getPostEditAuditEnabled())).orElse(false);
        if (editAudit && saved.getBoard().getRequireModeration() && !canModerateBoard(saved, currentUserId)) {
            if (saved.getStatus() == Post.PostStatus.APPROVED) {
                boardService.adjustPostCount(saved.getBoard().getId(), -1);
                userService.incrementPostCount(saved.getAuthor().getId(), -1);
            }
            saved.setStatus(Post.PostStatus.PENDING);
            postRepository.save(saved);
        }
        return detail(saved, liked, disliked, true, myTipTimes, true, currentUserId, false);
    }

    @Transactional
    public void delete(Long id, Long currentUserId) {
        Post post = postRepository.findByIdAndDeletedFalse(id)
                .orElseThrow(() -> BusinessException.notFound("帖子不存在或已删除"));

        if (!canModify(post, currentUserId)) {
            throw BusinessException.forbidden("只能删除自己的帖子");
        }

        hardDelete(id);

        boardService.adjustPostCount(post.getBoard().getId(), -1);
        userService.incrementPostCount(post.getAuthor().getId(), -1);
    }

    // ---------- 点赞 ----------

    @Transactional
    public ForumDtos.LikeResult toggleLike(Long postId, Long userId) {
        Post post = postRepository.findByIdAndDeletedFalse(postId)
                .orElseThrow(() -> BusinessException.notFound("帖子不存在或已删除"));

        boolean exists = likeRepository.existsByUserIdAndTargetTypeAndTargetId(
                userId, Like.TargetType.POST, postId);

        if (exists) {
            likeRepository.deleteByUserIdAndTargetTypeAndTargetId(userId, Like.TargetType.POST, postId);
            postRepository.addLikeCount(postId, -1);
            return new ForumDtos.LikeResult(false, Math.max(0, post.getLikeCount() - 1));
        }

        // 点赞时取消已点踩（互斥）
        if (dislikeRepository.existsByUserIdAndTargetTypeAndTargetId(userId, Like.TargetType.POST, postId)) {
            dislikeRepository.deleteByUserIdAndTargetTypeAndTargetId(userId, Like.TargetType.POST, postId);
            postRepository.addDislikeCount(postId, -1);
        }

        Like like = new Like();
        like.setUserId(userId);
        like.setTargetType(Like.TargetType.POST);
        like.setTargetId(postId);
        likeRepository.save(like);
        postRepository.addLikeCount(postId, 1);

        // 被点赞通知：通知帖子作者
        User liker = userService.requireUser(userId);
        notificationService.notify(post.getAuthor().getId(), userId, com.forum.entity.Notification.Type.LIKE,
                "有人赞了你的帖子",
                liker.getDisplayName() + " 赞了你的帖子《" + post.getTitle() + "》", postId);

        return new ForumDtos.LikeResult(true, post.getLikeCount() + 1);
    }

    // ---------- 管理操作 ----------

    @Transactional
    public void setPinned(Long id, boolean pinned, Long operatorId) {
        Post post = postRepository.findByIdAndDeletedFalse(id)
                .orElseThrow(() -> BusinessException.notFound("帖子不存在或已删除"));
        User op = userService.requireUser(operatorId);
        if (!op.canManageBoard(post.getBoard().getId())) {
            throw BusinessException.forbidden("无权管理该板块的帖子");
        }
        post.setPinned(pinned);
        postRepository.save(post);
    }

    @Transactional
    public void setLocked(Long id, boolean locked, Long operatorId) {
        Post post = postRepository.findByIdAndDeletedFalse(id)
                .orElseThrow(() -> BusinessException.notFound("帖子不存在或已删除"));
        User op = userService.requireUser(operatorId);
        if (!op.canManageBoard(post.getBoard().getId())) {
            throw BusinessException.forbidden("无权管理该板块的帖子");
        }
        post.setLocked(locked);
        postRepository.save(post);
    }

    @Transactional
    public void touchActivity(Long postId) {
        postRepository.findByIdAndDeletedFalse(postId).ifPresent(p -> {
            p.setLastActivityAt(LocalDateTime.now());
            postRepository.save(p);
        });
    }

    // ---------- 审核（版主/超管/站长） ----------

    /**
     * 审核帖子：批准或驳回。需要对该板块有管理权限。
     */
    @Transactional
    public ForumDtos.PostSummary moderate(Long postId, boolean approve, Long moderatorId) {
        User moderator = userService.requireUser(moderatorId);
        Post post = postRepository.findByIdAndDeletedFalse(postId)
                .orElseThrow(() -> BusinessException.notFound("帖子不存在或已删除"));

        if (!moderator.canManageBoard(post.getBoard().getId())) {
            throw BusinessException.forbidden("无权管理该板块的帖子");
        }
        if (post.getStatus() == Post.PostStatus.APPROVED && approve) {
            throw BusinessException.conflict("帖子已是通过状态");
        }

        Post.PostStatus before = post.getStatus();
        post.setStatus(approve ? Post.PostStatus.APPROVED : Post.PostStatus.REJECTED);
        postRepository.save(post);

        // 通过时补上计数（发帖时若是待审核则未计数）
        if (approve && before == Post.PostStatus.PENDING) {
            boardService.adjustPostCount(post.getBoard().getId(), 1);
            userService.incrementPostCount(post.getAuthor().getId(), 1);
        }
        // 从通过改为驳回时回退计数
        if (!approve && before == Post.PostStatus.APPROVED) {
            boardService.adjustPostCount(post.getBoard().getId(), -1);
            userService.incrementPostCount(post.getAuthor().getId(), -1);
        }

        // 审核结果通知帖子作者
        notificationService.notify(post.getAuthor().getId(), moderatorId,
                approve ? com.forum.entity.Notification.Type.MODERATION_APPROVED
                        : com.forum.entity.Notification.Type.MODERATION_REJECTED,
                approve ? "你的帖子已通过审核" : "你的帖子被驳回",
                "《" + post.getTitle() + "》" + (approve ? "已通过审核，现在公开可见。" : "未通过审核。"),
                postId);

        return ForumDtos.PostSummary.from(post, false);
    }

    /**
     * 版主删除帖子（软删）。需要对该板块有管理权限。
     */
    @Transactional
    public void deleteByModerator(Long postId, Long moderatorId) {
        User moderator = userService.requireUser(moderatorId);
        Post post = postRepository.findByIdAndDeletedFalse(postId)
                .orElseThrow(() -> BusinessException.notFound("帖子不存在或已删除"));

        if (!moderator.canManageBoard(post.getBoard().getId())) {
            throw BusinessException.forbidden("无权管理该板块的帖子");
        }

        boolean wasVisible = post.getStatus() == Post.PostStatus.APPROVED;
        hardDelete(postId);

        if (wasVisible) {
            boardService.adjustPostCount(post.getBoard().getId(), -1);
            userService.incrementPostCount(post.getAuthor().getId(), -1);
        }
        log.info("版主 {} 删除帖子 {}", moderator.getUsername(), postId);
    }

    /** Permanent deletion. The database schema is unchanged; all dependent rows are removed first. */
    private void hardDelete(Long postId) {
        entityManager.createNativeQuery("DELETE FROM likes WHERE target_type='POST' AND target_id=:id")
                .setParameter("id", postId).executeUpdate();
        entityManager.createNativeQuery("DELETE FROM dislikes WHERE target_type='POST' AND target_id=:id")
                .setParameter("id", postId).executeUpdate();
        entityManager.createNativeQuery("DELETE FROM favorites WHERE post_id=:id")
                .setParameter("id", postId).executeUpdate();
        entityManager.createNativeQuery("DELETE FROM tips WHERE post_id=:id")
                .setParameter("id", postId).executeUpdate();
        entityManager.createNativeQuery("DELETE FROM poll_votes WHERE poll_id IN (SELECT id FROM polls WHERE post_id=:id)")
                .setParameter("id", postId).executeUpdate();
        entityManager.createNativeQuery("DELETE FROM poll_options WHERE poll_id IN (SELECT id FROM polls WHERE post_id=:id)")
                .setParameter("id", postId).executeUpdate();
        entityManager.createNativeQuery("DELETE FROM polls WHERE post_id=:id")
                .setParameter("id", postId).executeUpdate();
        entityManager.createNativeQuery("DELETE FROM post_revisions WHERE post_id=:id")
                .setParameter("id", postId).executeUpdate();
        entityManager.createNativeQuery("DELETE FROM post_unlocks WHERE post_id=:id")
                .setParameter("id", postId).executeUpdate();
        entityManager.createNativeQuery("UPDATE comments SET parent_id=NULL WHERE post_id=:id")
                .setParameter("id", postId).executeUpdate();
        entityManager.createNativeQuery("DELETE FROM comments WHERE post_id=:id")
                .setParameter("id", postId).executeUpdate();
        entityManager.createNativeQuery("DELETE FROM posts WHERE id=:id")
                .setParameter("id", postId).executeUpdate();
    }

    @Transactional
    public void movePost(Long postId, Long boardId, Long operatorId) {
        User op = userService.requireUser(operatorId);
        Post post = postRepository.findByIdAndDeletedFalse(postId)
                .orElseThrow(() -> BusinessException.notFound("帖子不存在或已删除"));
        if (!op.canManageBoard(post.getBoard().getId())) throw BusinessException.forbidden("无权管理原板块");
        Board target = boardService.requireBoard(boardId);
        if (target.getId().equals(post.getBoard().getId())) return;
        Long old = post.getBoard().getId();
        post.setBoard(target);
        postRepository.save(post);
        if (post.getStatus() == Post.PostStatus.APPROVED) {
            boardService.adjustPostCount(old, -1);
            boardService.adjustPostCount(target.getId(), 1);
        }
    }

    // ---------- 推荐排序（参考 X 推荐算法） ----------

    /** 互动权重（参考 X 最后公开的权重表量级） */
    private static final double W_COMMENT = 13.5;   // 评论（对话）权重最高
    private static final double W_LIKE = 0.5;       // 点赞最弱
    private static final double W_TIP = 2.0;        // 打赏是论坛特有的强信号
    private static final double W_VIEW = 3.0;       // 浏览/停留（对数）
    private static final double HALF_LIFE_HOURS = 48.0; // 热度半衰期（X 的 UTEG 传播窗口）

    /**
     * 推荐排序：候选池打分 → 时间衰减 → 同作者多样性衰减 → 分页。
     * 参考 X 算法：得分=Σ(互动×权重)；关注外/时间衰减；同作者第 2 条起按 0.75*0.5^n+0.25 递减。
     */
    @Transactional(readOnly = true)
    public PageResponse<ForumDtos.PostSummary> recommend(Long boardId, int page, int size, Long currentUserId) {
        int pageSize = UserService.normalizeSize(size);

        List<Post> candidates = new ArrayList<>(
                postRepository.findTop200ByDeletedFalseAndStatusOrderByIdDesc(Post.PostStatus.APPROVED));
        if (boardId != null) {
            candidates.removeIf(p -> p.getBoard() == null || !boardId.equals(p.getBoard().getId()));
        }

        // 1. 打分 + 时间衰减
        List<Scored> scored = new ArrayList<>();
        for (Post p : candidates) {
            double raw = rawScore(p);
            scored.add(new Scored(p, raw, raw));
        }

        // 2. 同作者多样性衰减：先按原始分排序，再按出现次序打折
        scored.sort((a, b) -> Double.compare(b.raw, a.raw));
        Map<Long, Integer> authorShown = new HashMap<>();
        List<Scored> discounted = new ArrayList<>();
        for (Scored s : scored) {
            Long authorId = s.post.getAuthor().getId();
            int n = authorShown.getOrDefault(authorId, 0);
            double discount = Math.max(0.25, 0.75 * Math.pow(0.5, n) + 0.25);
            discounted.add(new Scored(s.post, s.raw, s.raw * discount));
            authorShown.put(authorId, n + 1);
        }

        // 3. 按有效分排序并分页
        discounted.sort((a, b) -> Double.compare(b.effective, a.effective));

        int total = discounted.size();
        int from = Math.min(page * pageSize, total);
        int to = Math.min(from + pageSize, total);
        List<Post> pageItems = new ArrayList<>();
        for (int i = from; i < to; i++) {
            pageItems.add(discounted.get(i).post);
        }

        Set<Long> likedIds = resolveLikedIds(pageItems.stream().map(Post::getId).toList(),
                currentUserId, Like.TargetType.POST);
        pageItems.forEach(this::normalizeMediaForView);
        List<ForumDtos.PostSummary> items = pageItems.stream()
                .map(p -> ForumDtos.PostSummary.from(p, likedIds.contains(p.getId())))
                .toList();

        return PageResponse.of(items, page, pageSize, total);
    }

    private double rawScore(Post p) {
        double s = 0;
        s += n(p.getCommentCount()) * W_COMMENT;
        s += n(p.getLikeCount()) * W_LIKE;
        s += (p.getTotalTipGold() == null ? 0 : p.getTotalTipGold()) * W_TIP;
        s += Math.log(1 + n(p.getViewCount())) * W_VIEW;

        // 时间衰减：半衰期 48 小时，保留 30% 基础分避免老帖完全沉底
        double ageHours = ChronoUnit.MINUTES.between(p.getLastActivityAt(), LocalDateTime.now()) / 60.0;
        double decay = Math.pow(0.5, ageHours / HALF_LIFE_HOURS);
        s *= (0.3 + 0.7 * decay);

        // 作者等级小幅加成（高等级作者内容略加权）
        if (p.getAuthor() != null && p.getAuthor().getLevel() != null) {
            s *= (1 + p.getAuthor().getLevel() * 0.02);
            s *= p.getAuthor().getRankingWeight() == null ? 1.0 : p.getAuthor().getRankingWeight();
        }
        return s;
    }

    private int n(Integer v) {
        return v == null ? 0 : v;
    }

    private void configureGate(Post post, String type, String content, Long price) {
        String gate = type == null ? "NONE" : type.toUpperCase();
        if (!Set.of("NONE", "REPLY", "PAID").contains(gate)) throw new BusinessException("非法内容权限类型");
        if (!"NONE".equals(gate) && (content == null || content.isBlank())) throw new BusinessException("请输入受限内容");
        if ("PAID".equals(gate) && (price == null || price < 1)) throw new BusinessException("付费内容金币必须大于0");
        post.setGateType(gate); post.setGatedContent("NONE".equals(gate)?null:content); post.setGatePrice("PAID".equals(gate)?price:0L);
    }

    private String extractFirstImage(String content) {
        if (content == null) return null;
        var m = java.util.regex.Pattern.compile("!\\[[^]]*]\\((https?://[^)]+|/uploads/[^)]+|/media/[^)]+|[A-Za-z0-9]{12})\\)").matcher(content);
        return m.find() ? m.group(1) : null;
    }

    /** 合并显式话题与正文 #话题，去重 */
    private String normalizeTopics(String requested, String content) {
        java.util.LinkedHashSet<String> result = new java.util.LinkedHashSet<>();
        if (requested != null) {
            for (String raw : requested.split("[,，\\s]+")) addTopic(result, raw);
        }
        if (content != null) {
            var m = java.util.regex.Pattern.compile("#([\\p{L}\\p{N}_-]{1,32})").matcher(content);
            while (m.find()) addTopic(result, m.group(1));
        }
        return result.isEmpty() ? null : String.join(",", result);
    }

    private void addTopic(java.util.Set<String> result, String raw) {
        if (raw == null) return;
        String topic = raw.trim().replaceFirst("^#", "");
        if (!topic.isBlank() && topic.length() <= 32) result.add(topic);
    }

    private String generatePuid() {
        for (int i = 0; i < 20; i++) {
            String value = "P" + java.util.UUID.randomUUID().toString().replace("-", "").substring(0, 10).toUpperCase();
            if (postRepository.findByPuidAndDeletedFalse(value).isEmpty()) return value;
        }
        return "P" + System.nanoTime();
    }

    /** 记录帖子编辑前快照 */
    private void saveRevision(Post post, Long editorId) {
        PostRevision r = new PostRevision();
        r.setPostId(post.getId());
        r.setTitle(post.getTitle());
        r.setContent(post.getContent());
        r.setEditorId(editorId);
        r.setCreatedAt(java.time.LocalDateTime.now());
        postRevisionRepository.save(r);
    }

    /** 帖子编辑历史 */
    @Transactional(readOnly = true)
    public List<Map<String, Object>> history(Long postId) {
        return postRevisionRepository.findByPostIdOrderByCreatedAtDesc(postId).stream()
                .map(r -> {
                    Map<String, Object> m = new java.util.HashMap<>();
                    m.put("id", r.getId());
                    m.put("title", r.getTitle());
                    m.put("content", r.getContent());
                    m.put("editorId", r.getEditorId());
                    m.put("createdAt", r.getCreatedAt());
                    return m;
                })
                .toList();
    }

    private ForumDtos.PostDetail detail(Post post, boolean liked, boolean disliked, boolean editable, int tips, boolean unlocked, Long currentUserId, boolean moderation) {
        String content = maskHiddenContent(mediaUrls.normalizeContent(contentFilterService.filter(post.getContent())), post.getId(), currentUserId, moderation);
        post.setTitle(contentFilterService.filter(post.getTitle()));
        return ForumDtos.PostDetail.from(post, liked, editable, tips, unlocked, disliked, content, mediaUrls.publicUrl(post.getThumbnailUrl()));
    }

    private String maskHiddenContent(String content, Long postId, Long userId, boolean moderation) {
        if (content == null) return null;
        // 管理员/站长在审核或浏览时均可免隐藏直接查看
        boolean staffBypass = userId != null && userService.requireUser(userId).isStaff();
        var pattern = java.util.regex.Pattern.compile("!\\[隐藏内容_([^]]+)]\\((.*?)\\)", java.util.regex.Pattern.DOTALL);
        var matcher = pattern.matcher(content); var out = new StringBuffer();
        while (matcher.find()) {
            String condition = matcher.group(1).trim();
            boolean allowed = staffBypass || (moderation && userId != null);
            if (!allowed) {
                if (condition.contains("公开") || condition.equalsIgnoreCase("free")) allowed = true;
                if (userId != null && condition.contains("登录")) allowed = true;
                if (userId != null && condition.contains("回复")) allowed = commentRepository.existsByPostIdAndAuthorIdAndDeletedFalse(postId, userId);
                if (userId != null && condition.contains("站长")) allowed = userService.requireUser(userId).isStaff();
            }
            // 解锁时直接显示隐藏内容本身（而非 ![隐藏内容](...) 图片语法，避免被渲染成损坏图片）
            String replacement = allowed ? "\n\n" + matcher.group(2) + "\n\n"
                    : "\n\n> 🔒 隐藏内容\n> 条件：" + condition + "\n> 该信息已被隐藏，满足条件后可查看。\n\n";
            matcher.appendReplacement(out, java.util.regex.Matcher.quoteReplacement(replacement));
        }
        matcher.appendTail(out); return out.toString();
    }

    private void normalizeMediaForView(Post p) {
        String thumb = p.getThumbnailUrl();
        if (thumb == null) thumb = extractFirstImage(p.getContent());
        p.setThumbnailUrl(mediaUrls.publicUrl(thumb));
        p.setContent(mediaUrls.normalizeContent(contentFilterService.filter(p.getContent())));
        p.setTitle(contentFilterService.filter(p.getTitle()));
    }

    private record Scored(Post post, double raw, double effective) {
    }

    // ---------- 内部工具 ----------

    private PageResponse<ForumDtos.PostSummary> toSummaryPage(Page<Post> page, Long currentUserId) {
        List<Post> posts = page.getContent().stream()
                .filter(p -> !authorBlockedMe(p, currentUserId))
                .toList();
        posts.forEach(this::normalizeMediaForView);
        Set<Long> likedIds = resolveLikedIds(posts.stream().map(Post::getId).toList(),
                currentUserId, Like.TargetType.POST);

        List<ForumDtos.PostSummary> items = posts.stream()
                .map(p -> ForumDtos.PostSummary.from(p, likedIds.contains(p.getId())))
                .toList();

        return PageResponse.of(items, page.getNumber(), page.getSize(), page.getTotalElements());
    }

    /** 收藏列表专用：过滤 null（帖子可能已删除） */
    @org.springframework.transaction.annotation.Transactional(readOnly = true)
    public PageResponse<ForumDtos.PostSummary> toSummaryPageForFavorites(Page<Post> page, Long currentUserId) {
        List<Post> posts = page.getContent().stream()
                .filter(java.util.Objects::nonNull)
                .filter(p -> !authorBlockedMe(p, currentUserId))
                .toList();
        posts.forEach(this::normalizeMediaForView);
        Set<Long> likedIds = resolveLikedIds(posts.stream().map(Post::getId).toList(),
                currentUserId, Like.TargetType.POST);
        List<ForumDtos.PostSummary> items = posts.stream()
                .map(p -> ForumDtos.PostSummary.from(p, likedIds.contains(p.getId())))
                .toList();
        return PageResponse.of(items, page.getNumber(), page.getSize(), page.getTotalElements());
    }

    Set<Long> resolveLikedIds(List<Long> targetIds, Long currentUserId, Like.TargetType type) {
        if (currentUserId == null || targetIds.isEmpty()) {
            return Set.of();
        }
        return likeRepository.findByUserIdAndTargetTypeAndTargetIdIn(currentUserId, type, targetIds)
                .stream().map(Like::getTargetId).collect(Collectors.toSet());
    }

    /**
     * 作者本人或对该板块有管理权限者可编辑/删除。
     */
    private boolean canModify(Post post, Long currentUserId) {
        if (currentUserId == null) {
            return false;
        }
        if (post.getAuthor().getId().equals(currentUserId)) {
            return true;
        }
        try {
            User u = userService.requireUser(currentUserId);
            return u.canManageBoard(post.getBoard().getId());
        } catch (BusinessException e) {
            return false;
        }
    }

    /** 当前用户是否对该帖所在板块有管理权限 */
    private boolean canModerateBoard(Post post, Long currentUserId) {
        if (currentUserId == null) {
            return false;
        }
        try {
            User u = userService.requireUser(currentUserId);
            return u.canManageBoard(post.getBoard().getId());
        } catch (BusinessException e) {
            return false;
        }
    }

    private Sort resolveSort(String sort) {
        // 置顶始终优先
        Sort pinnedFirst = Sort.by(Sort.Direction.DESC, "pinned");
        Map<String, Sort> options = Map.of(
                "latest", Sort.by(Sort.Direction.DESC, "createdAt"),
                "active", Sort.by(Sort.Direction.DESC, "lastActivityAt"),
                "hot", Sort.by(Sort.Direction.DESC, "likeCount").and(Sort.by(Sort.Direction.DESC, "commentCount")),
                "views", Sort.by(Sort.Direction.DESC, "viewCount")
        );
        Sort chosen = options.getOrDefault(sort == null ? "" : sort.toLowerCase(),
                Sort.by(Sort.Direction.DESC, "lastActivityAt"));
        return pinnedFirst.and(chosen);
    }
}
