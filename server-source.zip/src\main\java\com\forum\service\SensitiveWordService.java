package com.forum.service;

import com.forum.entity.SensitiveWord;
import com.forum.exception.BusinessException;
import com.forum.repository.SensitiveWordRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * 敏感词过滤：后台可配置，发帖/评论时替换敏感词。
 */
@Service
public class SensitiveWordService {

    private final SensitiveWordRepository repository;

    public SensitiveWordService(SensitiveWordRepository repository) {
        this.repository = repository;
    }

    /** 过滤内容，将命中的敏感词替换为配置的替换文本 */
    public String filter(String content) {
        if (content == null || content.isBlank()) return content;
        List<SensitiveWord> words = repository.findByEnabledTrue();
        if (words.isEmpty()) return content;
        String result = content;
        for (SensitiveWord w : words) {
            if (w.getWord() == null || w.getWord().isBlank()) continue;
            result = result.replaceAll(
                    java.util.regex.Pattern.quote(w.getWord()),
                    java.util.regex.Matcher.quoteReplacement(
                            w.getReplacement() == null ? "***" : w.getReplacement()));
        }
        return result;
    }

    /** 内容是否命中任意启用中的敏感词（用于降权惩罚） */
    public boolean containsSensitive(String content) {
        if (content == null || content.isBlank()) return false;
        List<SensitiveWord> words = repository.findByEnabledTrue();
        if (words.isEmpty()) return false;
        return words.stream().anyMatch(w ->
                w.getWord() != null && !w.getWord().isBlank() && content.contains(w.getWord()));
    }

    public List<SensitiveWord> list() {
        return repository.findAll();
    }

    public SensitiveWord add(String word, String replacement) {
        if (word == null || word.isBlank()) throw new BusinessException("敏感词不能为空");
        String w = word.trim();
        if (repository.existsByWord(w)) throw BusinessException.conflict("敏感词已存在");
        SensitiveWord sw = new SensitiveWord();
        sw.setWord(w);
        sw.setReplacement(replacement == null || replacement.isBlank() ? "***" : replacement.trim());
        sw.setEnabled(true);
        return repository.save(sw);
    }

    public SensitiveWord update(Long id, String replacement, Boolean enabled) {
        SensitiveWord sw = repository.findById(id).orElseThrow(() -> BusinessException.notFound("敏感词不存在"));
        if (replacement != null) sw.setReplacement(replacement.isBlank() ? "***" : replacement.trim());
        if (enabled != null) sw.setEnabled(enabled);
        return repository.save(sw);
    }

    public void delete(Long id) {
        repository.deleteById(id);
    }
}
