package com.forum.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Lob;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

import java.time.LocalDateTime;

@Entity
@Table(
        name = "posts",
        indexes = {
                @Index(name = "idx_posts_board", columnList = "board_id"),
                @Index(name = "idx_posts_author", columnList = "author_id"),
                @Index(name = "idx_posts_last_activity", columnList = "last_activity_at"),
                @Index(name = "idx_posts_deleted", columnList = "deleted")
        }
)
public class Post extends BaseEntity {

    @Column(nullable = false, length = 200)
    private String title;

    @Lob
    @Column(nullable = false, columnDefinition = "LONGTEXT")
    private String content;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "board_id", nullable = false)
    private Board board;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "author_id", nullable = false)
    private User author;

    @Column(name = "view_count", nullable = false)
    private Integer viewCount = 0;

    @Column(name = "comment_count", nullable = false)
    private Integer commentCount = 0;

    @Column(name = "like_count", nullable = false)
    private Integer likeCount = 0;

    @Column(name = "dislike_count", nullable = false)
    private Integer dislikeCount = 0;

    /** 逗号分隔的话题名，不含 #。 */
    @Column(length = 500)
    private String topics;

    /** 收到的打赏金币总额 */
    @Column(name = "total_tip_gold", nullable = false)
    private Long totalTipGold = 0L;

    /** 打赏次数 */
    @Column(name = "tip_count", nullable = false)
    private Integer tipCount = 0;

    /** 置顶 */
    @Column(nullable = false)
    private Boolean pinned = false;

    /** 仅在当前板块置顶 */
    @Column(name = "board_pinned", nullable = false)
    private Boolean boardPinned = false;

    /** 列表首图（从正文第一张图片自动提取） */
    @Column(name = "thumbnail_url", length = 500)
    private String thumbnailUrl;

    /** NONE / REPLY / PAID；一个帖子只允许一种内容门槛 */
    @Column(name = "gate_type", nullable = false, length = 16)
    private String gateType = "NONE";

    @Column(name = "gated_content", columnDefinition = "LONGTEXT")
    private String gatedContent;

    @Column(name = "gate_price", nullable = false)
    private Long gatePrice = 0L;

    /** 锁定后禁止回帖 */
    @Column(nullable = false)
    private Boolean locked = false;

    /** 分享快捷码（全局唯一，用于复制分享） */
    @Column(length = 16, unique = true)
    private String puid;

    /** 软删除标记 */
    @Column(nullable = false)
    private Boolean deleted = false;

    /** 审核状态：仅当板块开启审核时，新帖为 PENDING，需管理员批准后才公开可见 */
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 16)
    private PostStatus status = PostStatus.APPROVED;

    public enum PostStatus {
        /** 待审核 */
        PENDING,
        /** 已通过（公开可见） */
        APPROVED,
        /** 已驳回 */
        REJECTED
    }

    /** 最后活动时间，用于列表排序（发帖或回帖都会刷新） */
    @Column(name = "last_activity_at", nullable = false)
    private LocalDateTime lastActivityAt = LocalDateTime.now();

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Board getBoard() {
        return board;
    }

    public void setBoard(Board board) {
        this.board = board;
    }

    public User getAuthor() {
        return author;
    }

    public void setAuthor(User author) {
        this.author = author;
    }

    public Integer getViewCount() {
        return viewCount;
    }

    public void setViewCount(Integer viewCount) {
        this.viewCount = viewCount;
    }

    public Integer getCommentCount() {
        return commentCount;
    }

    public void setCommentCount(Integer commentCount) {
        this.commentCount = commentCount;
    }

    public Integer getLikeCount() {
        return likeCount;
    }

    public void setLikeCount(Integer likeCount) {
        this.likeCount = likeCount;
    }

    public Integer getDislikeCount() { return dislikeCount; }
    public void setDislikeCount(Integer dislikeCount) { this.dislikeCount = dislikeCount; }
    public String getTopics() { return topics; }
    public void setTopics(String topics) { this.topics = topics; }

    public Long getTotalTipGold() {
        return totalTipGold;
    }

    public void setTotalTipGold(Long totalTipGold) {
        this.totalTipGold = totalTipGold;
    }

    public Integer getTipCount() {
        return tipCount;
    }

    public void setTipCount(Integer tipCount) {
        this.tipCount = tipCount;
    }

    public Boolean getPinned() {
        return pinned;
    }

    public void setPinned(Boolean pinned) {
        this.pinned = pinned;
    }
    public Boolean getBoardPinned() { return boardPinned; }
    public void setBoardPinned(Boolean value) { boardPinned = value; }
    public String getThumbnailUrl() { return thumbnailUrl; }
    public void setThumbnailUrl(String value) { thumbnailUrl = value; }
    public String getGateType() { return gateType; }
    public void setGateType(String value) { gateType = value; }
    public String getGatedContent() { return gatedContent; }
    public void setGatedContent(String value) { gatedContent = value; }
    public Long getGatePrice() { return gatePrice; }
    public void setGatePrice(Long value) { gatePrice = value; }

    public Boolean getLocked() {
        return locked;
    }

    public void setLocked(Boolean locked) {
        this.locked = locked;
    }

    public String getPuid() { return puid; }
    public void setPuid(String value) { this.puid = value; }

    public Boolean getDeleted() {
        return deleted;
    }

    public void setDeleted(Boolean deleted) {
        this.deleted = deleted;
    }

    public PostStatus getStatus() {
        return status;
    }

    public void setStatus(PostStatus status) {
        this.status = status;
    }

    public LocalDateTime getLastActivityAt() {
        return lastActivityAt;
    }

    public void setLastActivityAt(LocalDateTime lastActivityAt) {
        this.lastActivityAt = lastActivityAt;
    }
}
