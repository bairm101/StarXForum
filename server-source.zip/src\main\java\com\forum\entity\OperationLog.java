package com.forum.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Index;
import jakarta.persistence.Table;

/**
 * 管理员操作日志。
 */
@Entity
@Table(name = "operation_logs", indexes = {
        @Index(name = "idx_oplog_user", columnList = "operator_id"),
        @Index(name = "idx_oplog_created", columnList = "created_at")
})
public class OperationLog extends BaseEntity {

    @Column(name = "operator_id", nullable = false)
    private Long operatorId;

    @Column(name = "operator_name", length = 64)
    private String operatorName;

    @Column(nullable = false, length = 32)
    private String action;

    @Column(length = 255)
    private String target;

    @Column(length = 1000)
    private String detail;

    public Long getOperatorId() { return operatorId; }
    public void setOperatorId(Long v) { this.operatorId = v; }
    public String getOperatorName() { return operatorName; }
    public void setOperatorName(String v) { this.operatorName = v; }
    public String getAction() { return action; }
    public void setAction(String v) { this.action = v; }
    public String getTarget() { return target; }
    public void setTarget(String v) { this.target = v; }
    public String getDetail() { return detail; }
    public void setDetail(String v) { this.detail = v; }
}
