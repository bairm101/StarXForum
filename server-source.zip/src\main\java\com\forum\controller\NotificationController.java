package com.forum.controller;

import com.forum.dto.ApiResponse;
import com.forum.dto.PageResponse;
import com.forum.entity.Notification;
import com.forum.entity.NotificationSettings;
import com.forum.security.ForumUserPrincipal;
import com.forum.service.NotificationService;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api")
public class NotificationController {

    private final NotificationService notificationService;

    public NotificationController(NotificationService notificationService) {
        this.notificationService = notificationService;
    }

    @GetMapping("/notifications")
    public ApiResponse<PageResponse<Notification>> list(
            @AuthenticationPrincipal ForumUserPrincipal principal,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        return ApiResponse.ok(notificationService.list(principal.getId(), page, size));
    }

    @GetMapping("/notifications/unread")
    public ApiResponse<UnreadCount> unread(@AuthenticationPrincipal ForumUserPrincipal principal) {
        return ApiResponse.ok(new UnreadCount(notificationService.unreadCount(principal.getId())));
    }

    @PatchMapping("/notifications/read-all")
    public ApiResponse<Void> readAll(@AuthenticationPrincipal ForumUserPrincipal principal) {
        notificationService.markAllRead(principal.getId());
        return ApiResponse.okMessage("已全部标记为已读");
    }

    @PatchMapping("/notifications/{id}/read")
    public ApiResponse<Void> read(@PathVariable Long id, @AuthenticationPrincipal ForumUserPrincipal principal) {
        notificationService.markRead(id, principal.getId());
        return ApiResponse.okMessage("已读");
    }

    @GetMapping("/notifications/settings")
    public ApiResponse<NotificationSettings> settings(@AuthenticationPrincipal ForumUserPrincipal principal) {
        return ApiResponse.ok(notificationService.settingsFor(principal.getId()));
    }

    @PatchMapping("/notifications/settings")
    public ApiResponse<NotificationSettings> updateSettings(
            @AuthenticationPrincipal ForumUserPrincipal principal,
            @RequestBody NotificationSettings req) {
        return ApiResponse.ok(notificationService.updateSettings(principal.getId(), req));
    }

    /** 站长群发系统公告 */
    @PostMapping("/admin/broadcast")
    public ApiResponse<BroadcastResult> broadcast(
            @AuthenticationPrincipal ForumUserPrincipal principal,
            @RequestBody BroadcastRequest req) {
        int count = notificationService.broadcast(principal.getId(), req.title(), req.content());
        return ApiResponse.ok(new BroadcastResult(count), "公告已发送");
    }

    public record UnreadCount(long unread) {
    }

    public record BroadcastRequest(String title, String content) {
    }

    public record BroadcastResult(int delivered) {
    }
}
