package com.forum.service;

import com.forum.repository.MessageRepository;
import com.forum.repository.UserSessionRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.nio.file.*;
import java.util.*;

@Service
public class MaintenanceService {
    private final CacheService cacheService;
    private final UserSessionRepository sessions;
    private final MessageRepository messages;

    public MaintenanceService(CacheService cacheService, UserSessionRepository sessions, MessageRepository messages) {
        this.cacheService = cacheService; this.sessions = sessions; this.messages = messages;
    }

    public Map<String, Object> stats() {
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("revokedDevices", sessions.countByRevokedTrue());
        out.put("messages", messages.count());
        out.put("logFiles", logFiles().size());
        return out;
    }

    @Transactional
    public Map<String, Object> clear(String target) {
        Map<String, Object> out = new LinkedHashMap<>();
        switch (target.toLowerCase()) {
            case "cache" -> out.put("redisKeys", cacheService.clearForumKeys());
            case "devices" -> out.put("revokedDevices", sessions.deleteByRevokedTrue());
            case "messages" -> { long n = messages.count(); messages.deleteAllInBatch(); out.put("messages", n); }
            case "logs" -> out.put("logFiles", clearLogs());
            default -> throw new com.forum.exception.BusinessException("不支持的清理类型");
        }
        return out;
    }

    private List<Path> logFiles() {
        Path configured = Paths.get(Optional.ofNullable(System.getenv("LOG_FILE"))
                .orElse("./logs/forum-server.log")).toAbsolutePath().normalize();
        Path dir = configured.getParent();
        if (dir == null || !Files.isDirectory(dir)) return List.of();
        try (var stream = Files.list(dir)) { return stream.filter(p -> p.getFileName().toString().endsWith(".log")).toList(); }
        catch (IOException e) { return List.of(); }
    }

    private long clearLogs() {
        long n = 0;
        for (Path p : logFiles()) {
            try { Files.newByteChannel(p, StandardOpenOption.TRUNCATE_EXISTING).close(); n++; }
            catch (IOException ignored) {}
        }
        return n;
    }
}
