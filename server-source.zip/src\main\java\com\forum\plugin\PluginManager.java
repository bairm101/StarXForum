package com.forum.plugin;

import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.net.URLClassLoader;
import java.nio.file.*;
import java.util.*;

@Component
public class PluginManager {
    private static final Logger log = LoggerFactory.getLogger(PluginManager.class);
    private final List<Map<String, String>> loaded = new ArrayList<>();
    private final Path dir = Paths.get("/opt/server/plugins");

    @PostConstruct
    void load() {
        try {
            Files.createDirectories(dir);
            try (var files = Files.list(dir)) {
                for (Path jar : files.filter(p -> p.toString().endsWith(".jar")).toList()) loadJar(jar);
            }
        } catch (Exception e) { log.error("插件扫描失败", e); }
    }

    private void loadJar(Path jar) {
        try {
            URLClassLoader loader = new URLClassLoader(new java.net.URL[]{jar.toUri().toURL()}, ForumPlugin.class.getClassLoader());
            for (ForumPlugin plugin : ServiceLoader.load(ForumPlugin.class, loader)) {
                Path data = dir.resolve("data").resolve(plugin.id()); Files.createDirectories(data);
                plugin.initialize(new PluginContext(data, Map.of("serverVersion", "1.0.0")));
                loaded.add(Map.of("id", plugin.id(), "name", plugin.name(), "version", plugin.version(), "jar", jar.getFileName().toString()));
                log.info("插件已加载: {} {}", plugin.name(), plugin.version());
            }
        } catch (Exception e) { log.error("插件加载失败: " + jar, e); }
    }

    public List<Map<String, String>> loaded() { return List.copyOf(loaded); }
}
