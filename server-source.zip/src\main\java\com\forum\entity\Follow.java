package com.forum.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Index;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

/**
 * 用户关注关系。userId 关注 followingId。
 */
@Entity
@Table(name = "follows",
        uniqueConstraints = @UniqueConstraint(name = "uk_follow", columnNames = {"user_id", "following_id"}),
        indexes = {
                @Index(name = "idx_follow_user", columnList = "user_id"),
                @Index(name = "idx_follow_target", columnList = "following_id")
        })
public class Follow extends BaseEntity {

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(name = "following_id", nullable = false)
    private Long followingId;

    public Long getUserId() { return userId; }
    public void setUserId(Long v) { this.userId = v; }
    public Long getFollowingId() { return followingId; }
    public void setFollowingId(Long v) { this.followingId = v; }
}
