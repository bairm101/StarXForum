package com.forum.exception;

import com.forum.dto.ApiResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.validation.FieldError;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.multipart.MaxUploadSizeExceededException;
import org.springframework.web.servlet.resource.NoResourceFoundException;

import java.util.stream.Collectors;

@RestControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    private static final MediaType JSON_UTF8 =
            new MediaType("application", "json", java.nio.charset.StandardCharsets.UTF_8);

    private ResponseEntity<ApiResponse<Void>> reply(HttpStatus status, String message) {
        return ResponseEntity.status(status).contentType(JSON_UTF8).body(ApiResponse.fail(message));
    }

    @ExceptionHandler(BusinessException.class)
    public ResponseEntity<ApiResponse<Void>> handleBusiness(BusinessException e) {
        return reply(e.getStatus(), e.getMessage());
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ApiResponse<Void>> handleValidation(MethodArgumentNotValidException e) {
        String message = e.getBindingResult().getFieldErrors().stream()
                .map(FieldError::getDefaultMessage)
                .distinct()
                .collect(Collectors.joining("；"));
        return reply(HttpStatus.BAD_REQUEST, message.isEmpty() ? "参数校验失败" : message);
    }

    @ExceptionHandler(BadCredentialsException.class)
    public ResponseEntity<ApiResponse<Void>> handleBadCredentials(BadCredentialsException e) {
        // 不区分用户名不存在与密码错误，防止枚举
        return reply(HttpStatus.UNAUTHORIZED, "用户名或密码错误");
    }

    @ExceptionHandler(AccessDeniedException.class)
    public ResponseEntity<ApiResponse<Void>> handleAccessDenied(AccessDeniedException e) {
        return reply(HttpStatus.FORBIDDEN, "没有操作权限");
    }

    @ExceptionHandler(MaxUploadSizeExceededException.class)
    public ResponseEntity<ApiResponse<Void>> handleUploadTooLarge(MaxUploadSizeExceededException e) {
        return reply(HttpStatus.PAYLOAD_TOO_LARGE, "上传文件超过大小限制");
    }

    /** 请求方法不允许（如对仅 POST 的接口发 GET），返回 405 而非 500 */
    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    public ResponseEntity<ApiResponse<Void>> handleMethodNotAllowed(HttpRequestMethodNotSupportedException e) {
        return reply(HttpStatus.METHOD_NOT_ALLOWED, "请求方法不允许");
    }

    /** 缺少必需的请求参数，返回 400 而非 500 */
    @ExceptionHandler(MissingServletRequestParameterException.class)
    public ResponseEntity<ApiResponse<Void>> handleMissingParam(MissingServletRequestParameterException e) {
        return reply(HttpStatus.BAD_REQUEST, "缺少参数：" + e.getParameterName());
    }

    /** 请求体不可读/JSON 格式错误，返回 400 而非 500 */
    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<ApiResponse<Void>> handleUnreadable(HttpMessageNotReadableException e) {
        return reply(HttpStatus.BAD_REQUEST, "请求体格式错误");
    }

    /** 参数类型不匹配，返回 400 而非 500 */
    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    public ResponseEntity<ApiResponse<Void>> handleTypeMismatch(MethodArgumentTypeMismatchException e) {
        return reply(HttpStatus.BAD_REQUEST, "参数类型错误：" + e.getName());
    }

    /** 资源不存在（静态资源/未匹配路由），返回 404 而非 500 */
    @ExceptionHandler(NoResourceFoundException.class)
    public ResponseEntity<ApiResponse<Void>> handleNoResource(NoResourceFoundException e) {
        return reply(HttpStatus.NOT_FOUND, "资源不存在");
    }

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<ApiResponse<Void>> handleIllegalArgument(IllegalArgumentException e) {
        return reply(HttpStatus.BAD_REQUEST, e.getMessage());
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ApiResponse<Void>> handleUnexpected(Exception e) {
        // 内部错误细节只进日志，不返回给客户端
        log.error("未处理异常", e);
        return reply(HttpStatus.INTERNAL_SERVER_ERROR, "服务器内部错误");
    }
}
