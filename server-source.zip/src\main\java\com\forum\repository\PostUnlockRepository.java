package com.forum.repository;
import com.forum.entity.PostUnlock;
import org.springframework.data.jpa.repository.JpaRepository;
public interface PostUnlockRepository extends JpaRepository<PostUnlock,Long>{boolean existsByPostIdAndUserId(Long postId,Long userId);}
