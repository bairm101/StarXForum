package com.forum.service;

import com.forum.config.ForumProperties;
import com.forum.dto.AdminDtos;
import com.forum.entity.SiteSettings;
import com.forum.entity.UploadRecord;
import com.forum.entity.User;
import com.forum.exception.BusinessException;
import com.forum.repository.SiteSettingsRepository;
import com.forum.repository.UploadRecordRepository;
import com.forum.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import java.util.Map;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;

/**
 * 本地文件存储：图片上传到 UPLOAD_DIR，对外通过 /uploads/** 静态映射访问。
 * 文件名使用随机 UUID + 白名单扩展名，杜绝路径穿越与可执行文件。
 */
@Service
public class FileStorageService {

    private static final Logger log = LoggerFactory.getLogger(FileStorageService.class);

    private final Path rootDir;
    private final Set<String> allowedExtensions;
    private final long maxSizeBytes;
    private final SiteSettingsRepository settingsRepository;
    private final UploadRecordRepository uploadRepository;
    private final UserRepository userRepository;

    public FileStorageService(ForumProperties properties, SiteSettingsRepository settingsRepository,
                              UploadRecordRepository uploadRepository, UserRepository userRepository) {
        this.rootDir = Paths.get(properties.getUpload().getDir()).toAbsolutePath().normalize();
        this.allowedExtensions = Set.of(properties.getUpload().getAllowedExtensions()
                .toLowerCase(Locale.ROOT).split(","));
        this.maxSizeBytes = properties.getUpload().getMaxSizeBytes();
        this.settingsRepository = settingsRepository;
        this.uploadRepository = uploadRepository;
        this.userRepository = userRepository;
        init();
    }

    private void init() {
        try {
            Files.createDirectories(rootDir);
            log.info("Upload directory: {}", rootDir);
        } catch (IOException e) {
            throw new IllegalStateException("Cannot create upload directory: " + rootDir, e);
        }
    }

    /** Delete all upload files of the specified user (physical files + DB records). Returns number of records deleted. */
    @org.springframework.transaction.annotation.Transactional
    public int deleteAllByUser(Long userId) {
        java.util.List<UploadRecord> records = uploadRepository.findByUserId(userId);
        for (UploadRecord r : records) {
            try {
                String rel = r.getPath() == null ? "" : r.getPath().replaceFirst("^/uploads/", "");
                Path f = rootDir.resolve(rel).normalize();
                if (f.startsWith(rootDir)) {
                    Files.deleteIfExists(f);
                }
            } catch (Exception e) {
                log.warn("Failed to delete upload file: {}", e.getMessage());
            }
        }
        uploadRepository.deleteAll(records);
        return records.size();
    }

    /**
     * @return 相对访问路径，如 /uploads/uuid.jpg
     */
    public String store(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new BusinessException("文件不能为空");
        }
        if (file.getSize() > maxSizeBytes) {
            throw new BusinessException("文件超过大小限制");
        }

        String original = file.getOriginalFilename();
        String ext = extractExtension(original);
        if (!allowedExtensions.contains(ext)) {
            throw new BusinessException("不支持的文件类型: " + ext);
        }

        // 文件头魔数校验，进一步防伪装扩展名
        validateMagic(file, ext);

        String filename = UUID.randomUUID().toString().replace("-", "") + "." + ext;
        Path target = rootDir.resolve(filename).normalize();
        if (!target.startsWith(rootDir)) {
            throw new BusinessException("非法路径");
        }

        try (InputStream in = file.getInputStream()) {
            Files.copy(in, target, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            log.error("文件保存失败: {}", e.getMessage());
            throw new BusinessException("文件保存失败");
        }

        return "/uploads/" + filename;
    }

    /** 用户组配额版本：支持 avatar/image/video，返回上传元数据。 */
    public AdminDtos.UploadView store(MultipartFile file, Long userId, String requestedType) {
        if (file == null || file.isEmpty()) throw new BusinessException("文件不能为空");
        User user = userRepository.findById(userId).orElseThrow(() -> BusinessException.notFound("用户不存在"));
        SiteSettings s = settingsRepository.findById(1L).orElseGet(SiteSettings::new);
        String type = requestedType == null ? detectType(file.getOriginalFilename()) : requestedType.toLowerCase(Locale.ROOT);
        long maxMb = "video".equals(type) ? safe(s.getVideoMaxMb(), 15) : safe(s.getImageMaxMb(), 5);
        if ("avatar".equals(type)) maxMb = Math.min(maxMb, 5);
        // 单个用户自定义上传上限优先于类型默认值
        if (user.getMaxUploadMb() != null && user.getMaxUploadMb() > 0) {
            maxMb = user.getMaxUploadMb();
        }
        long size = file.getSize();
        if (size > maxMb * 1024L * 1024L) throw new BusinessException("文件超过大小限制（上限 " + maxMb + "MB）");
        // 不限制用户组总空间，仅限制当前用户组的单文件大小。
        long used = uploadRepository.usedBytes(userId) == null ? 0 : uploadRepository.usedBytes(userId);
        String ext = extractExtension(file.getOriginalFilename());
        Set<String> images = Set.of("jpg", "jpeg", "png", "gif", "webp");
        Set<String> videos = Set.of("mp4", "webm", "mov", "m4v");
        Set<String> documents = Set.of("md", "markdown", "txt", "json", "csv", "pdf", "doc", "docx",
                "xls", "xlsx", "ppt", "pptx", "zip", "rar", "7z", "tar", "gz", "apk");
        if (("video".equals(type) && !videos.contains(ext)) || ("file".equals(type) && !documents.contains(ext)) || (!"video".equals(type) && !"file".equals(type) && !images.contains(ext))) {
            throw new BusinessException("不支持的文件类型");
        }
        if (Set.of("php", "phtml", "php3", "php4", "php5", "phar", "jsp", "asp", "aspx", "cgi", "pl", "py", "sh", "bat", "cmd", "exe", "dll", "com", "msi", "js", "html", "htm").contains(ext)) {
            throw new BusinessException("出于安全原因禁止上传该类型文件");
        }
        if (!"video".equals(type) && !"file".equals(type)) validateMagic(file, ext);
        String filename = UUID.randomUUID().toString().replace("-", "") + "." + ext;
        Path target = rootDir.resolve(filename).normalize();
        if (!target.startsWith(rootDir)) throw new BusinessException("非法路径");
        try (InputStream in = file.getInputStream()) {
            Files.copy(in, target, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            throw new BusinessException("文件保存失败");
        }
        String path = "/uploads/" + filename;
        String publicCode = UUID.randomUUID().toString().replace("-", "").substring(0, 12);
        UploadRecord record = new UploadRecord();
        record.setUserId(userId); record.setType(type); record.setPath(path); record.setSizeBytes(size);
        record.setPublicCode(publicCode); record.setOriginalName(file.getOriginalFilename()); record.setContentType(file.getContentType());
        record = uploadRepository.save(record);

        boolean imageCompress = !"video".equals(type) && Boolean.TRUE.equals(s.getImageCompressEnabled());
        boolean videoCompress = "video".equals(type) && Boolean.TRUE.equals(s.getVideoCompressEnabled());
        boolean compressed = imageCompress || videoCompress;
        long stored = size;
        try { stored = Files.size(target); } catch (IOException ignored) {}

        if (compressed) {
            // 压缩可能很耗时（尤其大视频 ffmpeg），改为后台异步，避免阻塞上传响应导致 CDN/反代超时
            final Path tf = target;
            final String te = ext;
            final UploadRecord rec = record;
            java.util.concurrent.CompletableFuture.runAsync(() -> {
                try {
                    boolean ok = videoCompress ? compressVideo(tf) : compressImage(tf, te);
                    long ns = Files.size(tf);
                    rec.setSizeBytes(ns);
                    uploadRepository.save(rec);
                } catch (Exception ignored) {}
            });
        }

        return new AdminDtos.UploadView(publicCode, type, size, stored, compressed, used + stored, 0);
    }

    private int safe(Integer value, int fallback) { return value == null || value < 1 ? fallback : value; }
    private String detectType(String name) {
        String ext = extractExtension(name);
        return Set.of("mp4", "webm", "mov", "m4v").contains(ext) ? "video" : "image";
    }

    private boolean compressImage(Path target, String ext) {
        if (!Set.of("jpg", "jpeg", "png").contains(ext)) return false;
        try {
            BufferedImage image = ImageIO.read(target.toFile());
            if (image == null) return false;
            String format = "png".equals(ext) ? "png" : "jpg";
            Path tmp = target.resolveSibling(target.getFileName() + ".compress");
            if (!ImageIO.write(image, format, tmp.toFile())) return false;
            if (Files.size(tmp) < Files.size(target)) Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING);
            else Files.deleteIfExists(tmp);
            return true;
        } catch (Exception e) { return false; }
    }

    private boolean compressVideo(Path target) {
        try {
            Process probe = new ProcessBuilder("ffmpeg", "-version").redirectErrorStream(true).start();
            if (probe.waitFor() != 0) return false;
            Path tmp = target.resolveSibling(target.getFileName() + ".compressed.mp4");
            Process p = new ProcessBuilder("ffmpeg", "-y", "-i", target.toString(), "-c:v", "libx264", "-crf", "28", "-preset", "fast", "-c:a", "aac", "-b:a", "96k", tmp.toString())
                    .redirectErrorStream(true).start();
            p.getInputStream().transferTo(java.io.OutputStream.nullOutputStream());
            if (p.waitFor() == 0 && Files.exists(tmp) && Files.size(tmp) < Files.size(target)) {
                Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING); return true;
            }
            Files.deleteIfExists(tmp); return false;
        } catch (Exception e) { return false; }
    }

    private String extractExtension(String filename) {
        if (filename == null || !filename.contains(".")) {
            throw new BusinessException("文件缺少扩展名");
        }
        String ext = filename.substring(filename.lastIndexOf('.') + 1).toLowerCase(Locale.ROOT);
        if (ext.isEmpty()) {
            throw new BusinessException("文件缺少扩展名");
        }
        return ext;
    }

    private void validateMagic(MultipartFile file, String ext) {
        try (InputStream in = file.getInputStream()) {
            byte[] head = in.readNBytes(8);
            if (head.length < 4) {
                throw new BusinessException("文件内容无效");
            }
            boolean ok = switch (ext) {
                case "jpg", "jpeg" -> (head[0] & 0xFF) == 0xFF && (head[1] & 0xFF) == 0xD8;
                case "png" -> (head[0] & 0xFF) == 0x89 && head[1] == 'P' && head[2] == 'N' && head[3] == 'G';
                case "gif" -> head[0] == 'G' && head[1] == 'I' && head[2] == 'F' && head[3] == '8';
                case "webp" -> head[0] == 'R' && head[1] == 'I' && head[2] == 'F' && head[3] == 'F';
                default -> false;
            };
            if (!ok) {
                throw new BusinessException("文件内容与扩展名不符");
            }
        } catch (IOException e) {
            throw new BusinessException("文件读取失败");
        }
    }
}
