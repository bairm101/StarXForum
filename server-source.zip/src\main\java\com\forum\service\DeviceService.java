package com.forum.service;

import com.forum.entity.SiteSettings;
import com.forum.entity.User;
import com.forum.entity.UserSession;
import com.forum.exception.BusinessException;
import com.forum.repository.SiteSettingsRepository;
import com.forum.repository.UserSessionRepository;
import com.forum.security.JwtService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * 设备会话与换设备二次验证。
 */
@Service
public class DeviceService {

    private static final Logger log = LoggerFactory.getLogger(DeviceService.class);

    private final UserSessionRepository sessionRepository;
    private final SiteSettingsRepository settingsRepository;
    private final JwtService jwtService;
    private final VerificationService verificationService;
    private final NotificationService notificationService;

    public DeviceService(UserSessionRepository sessionRepository,
                         SiteSettingsRepository settingsRepository,
                         JwtService jwtService,
                         VerificationService verificationService,
                         NotificationService notificationService) {
        this.sessionRepository = sessionRepository;
        this.settingsRepository = settingsRepository;
        this.jwtService = jwtService;
        this.verificationService = verificationService;
        this.notificationService = notificationService;
    }

    public boolean deviceVerificationEnabled() {
        return settingsRepository.findById(1L)
                .map(s -> Boolean.TRUE.equals(s.getDeviceVerificationEnabled()))
                .orElse(false);
    }

    /** 该设备是否已在该用户的历史会话中（换设备判断）。空设备标识视为已知设备，不触发验证。 */
    public boolean isKnownDevice(User user, String deviceId) {
        if (deviceId == null || deviceId.isBlank()) {
            return true;
        }
        return sessionRepository.existsByUserIdAndDeviceIdAndRevokedFalse(user.getId(), deviceId);
    }

    /** 发送换设备二次验证的邮箱验证码。 */
    public void sendDeviceCode(User user) {
        if (user.getEmail() == null || user.getEmail().isBlank()) {
            throw new BusinessException("该账号未绑定邮箱，无法进行换设备验证");
        }
        verificationService.sendRawCode(user.getEmail(), "换设备登录验证码",
                "您的换设备登录验证码是：",
                "device:" + user.getId());
        // 新设备登录通知
        notificationService.notify(user.getId(), null,
                com.forum.entity.Notification.Type.DEVICE_LOGIN,
                "检测到新设备登录",
                "检测到新设备尝试登录你的账号，已要求邮箱验证。若非本人操作请立即修改密码。",
                null);
    }

    /** 校验换设备验证码，通过后创建会话并返回带 sid 的 JWT。 */
    @Transactional
    public String verifyDeviceAndLogin(User user, String deviceId, String code,
                                       String deviceName, String userAgent) {
        if (user.getEmail() == null || user.getEmail().isBlank()) {
            throw new BusinessException("该账号未绑定邮箱");
        }
        if (!verificationService.verifyCode("device:" + user.getId(), code)) {
            throw new BusinessException("验证码错误或已过期");
        }
        return createSession(user, deviceId, deviceName, userAgent);
    }

    /** 创建会话并签发携带 sid 的 JWT。 */
    @Transactional
    public String createSession(User user, String deviceId, String deviceName, String userAgent) {
        String sid = UUID.randomUUID().toString().replace("-", "");
        UserSession session = new UserSession();
        session.setSid(sid);
        session.setUserId(user.getId());
        session.setDeviceId(deviceId == null || deviceId.isBlank() ? null : deviceId);
        session.setDeviceName(deviceName);
        session.setUserAgent(userAgent);
        session.setLoginAt(LocalDateTime.now());
        session.setLastSeenAt(LocalDateTime.now());
        session.setRevoked(false);
        sessionRepository.save(session);
        return jwtService.generateToken(user.getId(), user.getUsername(), user.getRole().name(), sid, deviceId);
    }

    public List<UserSession> listDevices(Long userId) {
        return sessionRepository.findByUserIdOrderByLoginAtDesc(userId);
    }

    /** 删除（吊销）设备会话，该设备立即退出登录。 */
    @Transactional
    public void revokeDevice(Long userId, String sid) {
        UserSession session = sessionRepository.findBySid(sid)
                .orElseThrow(() -> BusinessException.notFound("会话不存在"));
        if (!session.getUserId().equals(userId)) {
            throw BusinessException.forbidden("只能删除自己的设备");
        }
        session.setRevoked(true);
        sessionRepository.save(session);
        log.info("用户 {} 删除设备会话 {}", userId, sid);
    }

    /** 一键退登：吊销该用户全部设备会话。 */
    @Transactional
    public int revokeAllDevices(Long userId) {
        List<UserSession> sessions = sessionRepository.findByUserIdAndRevokedFalseOrderByLoginAtDesc(userId);
        for (UserSession s : sessions) {
            s.setRevoked(true);
            sessionRepository.save(s);
        }
        if (!sessions.isEmpty()) {
            log.info("用户 {} 已一键退登，吊销 {} 个设备会话", userId, sessions.size());
        }
        return sessions.size();
    }
}
