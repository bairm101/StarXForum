package com.forum.controller;

import com.forum.dto.ApiResponse;
import com.forum.dto.PageResponse;
import com.forum.dto.ReportDtos;
import com.forum.entity.Comment;
import com.forum.entity.Post;
import com.forum.entity.Report;
import com.forum.entity.User;
import com.forum.repository.CommentRepository;
import com.forum.repository.PostRepository;
import com.forum.repository.ReportRepository;
import com.forum.repository.UserRepository;
import com.forum.security.ForumUserPrincipal;
import com.forum.service.AdminLogService;
import com.forum.service.AdminService;
import com.forum.service.CommentService;
import com.forum.service.NotificationService;
import com.forum.service.PostService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 举报处理（管理员）。
 */
@RestController
@RequestMapping("/api/admin/reports")
public class ReportAdminController {

    private final ReportRepository reportRepository;
    private final PostRepository postRepository;
    private final CommentRepository commentRepository;
    private final UserRepository userRepository;
    private final PostService postService;
    private final CommentService commentService;
    private final AdminService adminService;
    private final AdminLogService logService;
    private final NotificationService notificationService;

    public ReportAdminController(ReportRepository reportRepository,
                                 PostRepository postRepository,
                                 CommentRepository commentRepository,
                                 UserRepository userRepository,
                                 PostService postService,
                                 CommentService commentService,
                                 AdminService adminService,
                                 AdminLogService logService,
                                 NotificationService notificationService) {
        this.reportRepository = reportRepository;
        this.postRepository = postRepository;
        this.commentRepository = commentRepository;
        this.userRepository = userRepository;
        this.postService = postService;
        this.commentService = commentService;
        this.adminService = adminService;
        this.logService = logService;
        this.notificationService = notificationService;
    }

    @org.springframework.transaction.annotation.Transactional(readOnly = true)
    @GetMapping
    public ApiResponse<PageResponse<ReportDtos.ReportView>> list(@RequestParam(defaultValue = "PENDING") String status,
                                                                  @RequestParam(defaultValue = "0") int page,
                                                                  @RequestParam(defaultValue = "20") int size) {
        Report.Status st;
        try { st = Report.Status.valueOf(status.toUpperCase()); }
        catch (IllegalArgumentException e) { st = Report.Status.PENDING; }
        Page<Report> result = reportRepository.findByStatusOrderByCreatedAtDesc(st,
                PageRequest.of(page, Math.max(1, Math.min(size, 50))));
        List<ReportDtos.ReportView> views = result.getContent().stream().map(this::toView).toList();
        return ApiResponse.ok(PageResponse.of(views, page, result.getSize(), result.getTotalElements()));
    }

    /** 组装报告视图：附带被举报目标内容与跳转信息。 */
    private ReportDtos.ReportView toView(Report r) {
        String reporter = userRepository.findById(r.getReporterId())
                .map(User::getDisplayName).orElse(null);
        String summary = null;
        Long postId = null, commentId = null, userId = null;
        String targetAuthor = null;
        boolean deleted = false;

        if (r.getTargetType() == Report.TargetType.POST) {
            Post p = postRepository.findById(r.getTargetId()).orElse(null);
            if (p == null) deleted = true;
            else {
                summary = "【帖子】" + p.getTitle() + "\n" + excerpt(p.getContent());
                postId = p.getId();
                targetAuthor = p.getAuthor() != null ? p.getAuthor().getDisplayName() : null;
            }
        } else if (r.getTargetType() == Report.TargetType.COMMENT) {
            Comment c = commentRepository.findById(r.getTargetId()).orElse(null);
            if (c == null || Boolean.TRUE.equals(c.getDeleted())) deleted = true;
            else {
                summary = "【评论】" + c.getContent();
                commentId = c.getId();
                postId = c.getPost() != null ? c.getPost().getId() : null;
                targetAuthor = c.getAuthor() != null ? c.getAuthor().getDisplayName() : null;
            }
        } else if (r.getTargetType() == Report.TargetType.USER) {
            User u = userRepository.findById(r.getTargetId()).orElse(null);
            if (u == null) deleted = true;
            else {
                summary = "【用户】@" + u.getUsername() + " (" + u.getDisplayName() + ")";
                userId = u.getId();
                targetAuthor = u.getDisplayName();
            }
        }

        return new ReportDtos.ReportView(
                r.getId(), r.getReporterId(), reporter,
                r.getTargetType(), r.getTargetId(), r.getReason(), r.getStatus(),
                r.getHandledBy(), r.getHandleNote(), r.getCreatedAt(),
                summary, postId, commentId, userId, targetAuthor, deleted);
    }

    private String excerpt(String content) {
        if (content == null) return "";
        String plain = content.replaceAll("\\s+", " ").trim();
        return plain.length() <= 120 ? plain : plain.substring(0, 120) + "...";
    }

    /** 处理：删除/封禁违规目标并标记已处理 */
    @PostMapping("/{id}/resolve")
    public ApiResponse<Void> resolve(@PathVariable Long id,
                                     @RequestParam(required = false) String note,
                                     @AuthenticationPrincipal ForumUserPrincipal principal) {
        Report report = reportRepository.findById(id)
                .orElseThrow(() -> com.forum.exception.BusinessException.notFound("举报不存在"));
        if (report.getTargetType() == Report.TargetType.POST) {
            postService.deleteByModerator(report.getTargetId(), principal.getId());
        } else if (report.getTargetType() == Report.TargetType.COMMENT) {
            commentService.delete(report.getTargetId(), principal.getId());
        } else {
            adminService.banUser(principal.getId(), report.getTargetId(), true);
        }
        report.setStatus(Report.Status.RESOLVED);
        report.setHandledBy(principal.getId());
        report.setHandleNote(note);
        reportRepository.save(report);
        logService.log(principal.getId(), principal.getUsername(), "REPORT_RESOLVE",
                report.getTargetType() + ":" + report.getTargetId(), "处理举报：" + (note == null ? "" : note));
        notifyReporter(report);
        return ApiResponse.okMessage("已处理");
    }

    /** 驳回（不处理） */
    @PostMapping("/{id}/reject")
    public ApiResponse<Void> reject(@PathVariable Long id,
                                    @RequestParam(required = false) String note,
                                    @AuthenticationPrincipal ForumUserPrincipal principal) {
        Report report = reportRepository.findById(id)
                .orElseThrow(() -> com.forum.exception.BusinessException.notFound("举报不存在"));
        report.setStatus(Report.Status.REJECTED);
        report.setHandledBy(principal.getId());
        report.setHandleNote(note);
        reportRepository.save(report);
        notifyReporter(report);
        return ApiResponse.okMessage("已驳回");
    }

    /** 通知举报人处理结果 */
    private void notifyReporter(Report report) {
        String type = report.getTargetType() == Report.TargetType.POST ? "帖子"
                : report.getTargetType() == Report.TargetType.COMMENT ? "评论" : "用户";
        boolean resolved = report.getStatus() == Report.Status.RESOLVED;
        notificationService.notify(
                report.getReporterId(), report.getHandledBy(),
                com.forum.entity.Notification.Type.REPORT,
                resolved ? "你的举报已处理" : "你的举报已驳回",
                "你举报的" + type + "已被" + (resolved ? "处理" : "驳回")
                        + (report.getHandleNote() == null || report.getHandleNote().isBlank()
                        ? "" : "，备注：" + report.getHandleNote()),
                report.getTargetId());
    }
}
