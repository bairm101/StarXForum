package com.forum.controller;

import com.forum.dto.ApiResponse;
import com.forum.dto.QrLoginDtos;
import com.forum.security.ForumUserPrincipal;
import com.forum.service.QrLoginService;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/qr-login")
public class QrLoginController {
    private final QrLoginService service;
    public QrLoginController(QrLoginService service) { this.service = service; }
    @PostMapping("/create") public ApiResponse<QrLoginDtos.Create> create() { return ApiResponse.ok(service.create()); }
    @GetMapping("/status") public ApiResponse<QrLoginDtos.Status> status(@RequestParam String sessionId,@RequestParam String token) { return ApiResponse.ok(service.status(sessionId,token)); }
    @PostMapping("/approve") public ApiResponse<Void> approve(@RequestBody QrLoginDtos.Approve req,@AuthenticationPrincipal ForumUserPrincipal p) { service.approve(req.sessionId(),req.token(),p.getId()); return ApiResponse.okMessage("已授权登录"); }
}
