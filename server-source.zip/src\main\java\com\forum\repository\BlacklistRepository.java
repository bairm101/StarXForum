package com.forum.repository;

import com.forum.entity.Blacklist;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface BlacklistRepository extends JpaRepository<Blacklist, Long> {
    Optional<Blacklist> findByUserIdAndBlockedId(Long userId, Long blockedId);
    boolean existsByUserIdAndBlockedId(Long userId, Long blockedId);
    void deleteByUserIdAndBlockedId(Long userId, Long blockedId);
    long countByUserId(Long userId);
    Page<Blacklist> findByUserIdOrderByCreatedAtDesc(Long userId, Pageable pageable);
    /** 我拉黑了哪些人 */
    List<Blacklist> findByUserId(Long userId);
    /** 谁拉黑了我（用于被拉黑后限制访问） */
    List<Blacklist> findByBlockedId(Long blockedId);
}
