package com.forum.service;

import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.time.Duration;

/**
 * 基于 Redis 的简单 IP 限流（固定窗口计数）。
 */
@Service
public class RateLimitService {

    private final StringRedisTemplate redis;

    public RateLimitService(StringRedisTemplate redis) {
        this.redis = redis;
    }

    /**
     * 判断 key 在窗口内是否超过上限。超过返回 true（应拒绝）。
     */
    public boolean isLimited(String key, int maxAttempts, Duration window) {
        try {
            Long count = redis.opsForValue().increment(key);
            if (count != null && count == 1L) {
                redis.expire(key, window);
            }
            return count != null && count > maxAttempts;
        } catch (Exception e) {
            // Redis 故障时不限流，避免影响正常登录
            return false;
        }
    }
}
