package com.forum.repository;

import com.forum.entity.Report;
import org.springframework.data.domain.*;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface ReportRepository extends JpaRepository<Report, Long> {
    Optional<Report> findByReporterIdAndTargetTypeAndTargetId(Long reporterId, Report.TargetType type, Long targetId);
    Page<Report> findByStatusOrderByCreatedAtDesc(Report.Status status, Pageable pageable);
}
