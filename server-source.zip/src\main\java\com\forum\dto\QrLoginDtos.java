package com.forum.dto;

public class QrLoginDtos {
    public record Create(String sessionId, String token, String payload, long expiresInSeconds) {}
    public record Status(String status, String token, String displayName) {}
    public record Approve(String sessionId, String token) {}
}
