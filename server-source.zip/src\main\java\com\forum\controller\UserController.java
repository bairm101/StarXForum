package com.forum.controller;

import com.forum.dto.ApiResponse;
import com.forum.dto.auth.UserDtos;
import com.forum.entity.User;
import com.forum.exception.BusinessException;
import com.forum.repository.UserRepository;
import com.forum.security.ForumUserPrincipal;
import com.forum.service.SocialService;
import com.forum.service.UserService;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/users")
public class UserController {

    private final UserService userService;
    private final UserRepository userRepository;
    private final SocialService socialService;

    public UserController(UserService userService, UserRepository userRepository, SocialService socialService) {
        this.userService = userService;
        this.userRepository = userRepository;
        this.socialService = socialService;
    }

    @GetMapping("/{id}/profile")
    public ApiResponse<UserDtos.UserProfile> profile(@PathVariable Long id,
                                                     @AuthenticationPrincipal ForumUserPrincipal principal) {
        // 被拉黑者无法查看拉黑者主页
        if (principal != null && socialService.iAmBlockedBy(principal.getId(), id)) {
            throw BusinessException.forbidden("你已被该用户拉黑，无法查看其主页");
        }
        return ApiResponse.ok(userService.getProfile(id));
    }

    /** 按用户名查用户（用于 @提及 跳转） */
    @GetMapping("/by-name/{username}")
    public ApiResponse<UserDtos.UserProfile> byName(@PathVariable String username) {
        User u = userRepository.findByUsername(username)
                .orElseThrow(() -> BusinessException.notFound("用户不存在"));
        return ApiResponse.ok(UserDtos.UserProfile.from(u));
    }

    /** 按 UID 查用户（用于 @UID:xxx 提及跳转） */
    @GetMapping("/by-uid/{uid}")
    public ApiResponse<UserDtos.UserProfile> byUid(@PathVariable String uid) {
        User u = userRepository.findByUid(uid)
                .orElseThrow(() -> BusinessException.notFound("用户不存在"));
        return ApiResponse.ok(UserDtos.UserProfile.from(u));
    }
}
