package com.forum.service;

import com.forum.dto.PageResponse;
import com.forum.entity.OperationLog;
import com.forum.repository.OperationLogRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * 管理员操作日志。
 */
@Service
public class AdminLogService {

    private final OperationLogRepository logRepository;

    public AdminLogService(OperationLogRepository logRepository) {
        this.logRepository = logRepository;
    }

    @Transactional
    public void log(Long operatorId, String operatorName, String action, String target, String detail) {
        OperationLog log = new OperationLog();
        log.setOperatorId(operatorId);
        log.setOperatorName(operatorName);
        log.setAction(action);
        log.setTarget(target == null ? null : target.substring(0, Math.min(target.length(), 255)));
        log.setDetail(detail == null ? null : detail.substring(0, Math.min(detail.length(), 1000)));
        logRepository.save(log);
    }

    @Transactional(readOnly = true)
    public PageResponse<OperationLog> list(String keyword, String action, int page, int size) {
        Pageable pageable = PageRequest.of(page, Math.max(1, Math.min(size, 100)));
        Page<OperationLog> result;
        if (action != null && !action.isBlank()) {
            result = logRepository.findByActionOrderByCreatedAtDesc(action, pageable);
        } else if (keyword != null && !keyword.isBlank()) {
            result = logRepository.findByOperatorNameContainingOrderByCreatedAtDesc(keyword, pageable);
        } else {
            result = logRepository.findByOrderByCreatedAtDesc(pageable);
        }
        return PageResponse.of(result.getContent(), page, pageable.getPageSize(), result.getTotalElements());
    }
}
