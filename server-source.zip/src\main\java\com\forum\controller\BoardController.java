package com.forum.controller;

import com.forum.dto.ApiResponse;
import com.forum.dto.ForumDtos;
import com.forum.security.ForumUserPrincipal;
import com.forum.service.BoardService;
import com.forum.service.UserService;
import jakarta.validation.Valid;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api")
public class BoardController {

    private final BoardService boardService;
    private final UserService userService;

    public BoardController(BoardService boardService, UserService userService) {
        this.boardService = boardService;
        this.userService = userService;
    }

    @GetMapping("/boards")
    public ApiResponse<List<ForumDtos.BoardView>> listVisible() {
        return ApiResponse.ok(boardService.listVisible());
    }

    @GetMapping("/boards/{id}")
    public ApiResponse<ForumDtos.BoardView> get(@PathVariable Long id) {
        return ApiResponse.ok(boardService.get(id));
    }

    @GetMapping("/admin/boards")
    public ApiResponse<List<ForumDtos.BoardView>> listAll(
            @AuthenticationPrincipal ForumUserPrincipal principal) {
        requireBoardManager(principal.getId());
        return ApiResponse.ok(boardService.listAll());
    }

    @PostMapping("/admin/boards")
    public ApiResponse<ForumDtos.BoardView> create(@Valid @RequestBody ForumDtos.BoardRequest req,
                                                   @AuthenticationPrincipal ForumUserPrincipal principal) {
        requireBoardManager(principal.getId());
        return ApiResponse.ok(boardService.create(req));
    }

    @PutMapping("/admin/boards/{id}")
    public ApiResponse<ForumDtos.BoardView> update(@PathVariable Long id,
                                                   @Valid @RequestBody ForumDtos.BoardRequest req,
                                                   @AuthenticationPrincipal ForumUserPrincipal principal) {
        requireBoardManager(principal.getId());
        return ApiResponse.ok(boardService.update(id, req));
    }

    @DeleteMapping("/admin/boards/{id}")
    public ApiResponse<Void> delete(@PathVariable Long id,
                                    @AuthenticationPrincipal ForumUserPrincipal principal) {
        requireBoardManager(principal.getId());
        boardService.delete(id);
        return ApiResponse.okMessage("删除成功");
    }

    private void requireBoardManager(Long userId) {
        var user = userService.requireUser(userId);
        if (!user.isOwner() && !user.isSuperAdmin()) {
            throw com.forum.exception.BusinessException.forbidden("仅站长或超级管理员可管理板块");
        }
    }
}
