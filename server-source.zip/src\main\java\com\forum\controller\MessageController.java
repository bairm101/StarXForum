package com.forum.controller;

import com.forum.dto.ApiResponse;
import com.forum.dto.MessageDtos;
import com.forum.dto.PageResponse;
import com.forum.security.ForumUserPrincipal;
import com.forum.service.MessageService;
import jakarta.validation.Valid;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/messages")
public class MessageController {

    private final MessageService messageService;
    private final com.forum.service.ReactionService reactionService;

    public MessageController(MessageService messageService,
                             com.forum.service.ReactionService reactionService) {
        this.messageService = messageService;
        this.reactionService = reactionService;
    }

    /** 举报私信会话：可附聊天记录 ID 与截图地址作为证据 */
    @PostMapping("/report")
    public ApiResponse<Void> report(@RequestBody ReportRequest req,
                                    @AuthenticationPrincipal ForumUserPrincipal principal) {
        reactionService.reportChat(req.peerId(), req.reason(),
                req.messageIds(), req.images(), principal.getId());
        return ApiResponse.okMessage("举报已提交");
    }

    public record ReportRequest(Long peerId, String reason,
                                java.util.List<Long> messageIds,
                                java.util.List<String> images) {}

    @PostMapping
    public ApiResponse<MessageDtos.MessageView> send(
            @Valid @RequestBody MessageDtos.SendMessageRequest req,
            @AuthenticationPrincipal ForumUserPrincipal principal) {
        return ApiResponse.ok(messageService.send(req, principal.getId()), "发送成功");
    }

    @GetMapping("/conversations")
    public ApiResponse<List<MessageDtos.ConversationView>> conversations(
            @RequestParam(defaultValue = "20") int limit,
            @AuthenticationPrincipal ForumUserPrincipal principal) {
        return ApiResponse.ok(messageService.conversations(principal.getId(), limit));
    }

    @GetMapping("/with/{peerId}")
    public ApiResponse<PageResponse<MessageDtos.MessageView>> conversation(
            @PathVariable Long peerId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size,
            @AuthenticationPrincipal ForumUserPrincipal principal) {
        return ApiResponse.ok(messageService.conversation(peerId, page, size, principal.getId()));
    }

    @GetMapping("/unread")
    public ApiResponse<MessageDtos.UnreadCount> unread(
            @AuthenticationPrincipal ForumUserPrincipal principal) {
        return ApiResponse.ok(new MessageDtos.UnreadCount(messageService.unreadCount(principal.getId())));
    }

    @PostMapping("/read-all")
    public ApiResponse<Void> readAll(@AuthenticationPrincipal ForumUserPrincipal principal) {
        messageService.markAllRead(principal.getId());
        return ApiResponse.okMessage("已全部标为已读");
    }

    @DeleteMapping("/with/{peerId}")
    public ApiResponse<Void> deleteConversation(@PathVariable Long peerId,
                                                @AuthenticationPrincipal ForumUserPrincipal principal) {
        messageService.deleteConversation(peerId, principal.getId());
        return ApiResponse.okMessage("会话已删除");
    }
}
