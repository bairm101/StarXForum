package com.forum.repository;

import com.forum.entity.OperationLog;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OperationLogRepository extends JpaRepository<OperationLog, Long> {
    Page<OperationLog> findByOrderByCreatedAtDesc(Pageable pageable);
    Page<OperationLog> findByOperatorNameContainingOrderByCreatedAtDesc(String keyword, Pageable pageable);
    Page<OperationLog> findByActionOrderByCreatedAtDesc(String action, Pageable pageable);
}
