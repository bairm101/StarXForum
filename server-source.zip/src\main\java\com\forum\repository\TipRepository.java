package com.forum.repository;

import com.forum.entity.Tip;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TipRepository extends JpaRepository<Tip, Long> {

    long countByUserIdAndPostId(Long userId, Long postId);

    long countByPostId(Long postId);
}
