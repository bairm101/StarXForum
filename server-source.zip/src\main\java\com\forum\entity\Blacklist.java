package com.forum.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Index;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

/**
 * 拉黑关系。userId 拉黑 blockedId。
 * 被拉黑者无法：向拉黑者发私信、查看拉黑者主页与帖子。
 */
@Entity
@Table(name = "blacklists",
        uniqueConstraints = @UniqueConstraint(name = "uk_blacklist", columnNames = {"user_id", "blocked_id"}),
        indexes = {
                @Index(name = "idx_blk_user", columnList = "user_id"),
                @Index(name = "idx_blk_target", columnList = "blocked_id")
        })
public class Blacklist extends BaseEntity {

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(name = "blocked_id", nullable = false)
    private Long blockedId;

    public Long getUserId() { return userId; }
    public void setUserId(Long v) { this.userId = v; }
    public Long getBlockedId() { return blockedId; }
    public void setBlockedId(Long v) { this.blockedId = v; }
}
