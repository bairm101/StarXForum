package com.forum.service;

import com.forum.dto.PageResponse;
import com.forum.entity.Notification;
import com.forum.entity.NotificationSettings;
import com.forum.entity.User;
import com.forum.exception.BusinessException;
import com.forum.repository.NotificationRepository;
import com.forum.repository.NotificationSettingsRepository;
import com.forum.repository.UserRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class NotificationService {

    private final NotificationRepository notificationRepository;
    private final NotificationSettingsRepository settingsRepository;
    private final UserRepository userRepository;

    public NotificationService(NotificationRepository notificationRepository,
                               NotificationSettingsRepository settingsRepository,
                               UserRepository userRepository) {
        this.notificationRepository = notificationRepository;
        this.settingsRepository = settingsRepository;
        this.userRepository = userRepository;
    }

    /** 创建一条通知，遵守用户偏好开关。给自己发的不通知。 */
    @Transactional
    public void notify(Long userId, Long actorId, Notification.Type type,
                       String title, String content, Long refId) {
        if (userId == null || userId.equals(actorId)) {
            return;
        }
        NotificationSettings settings = settingsFor(userId);
        boolean enabled = switch (type) {
            case ANNOUNCEMENT -> Boolean.TRUE.equals(settings.getEnableAnnouncement());
            case MODERATION_APPROVED, MODERATION_REJECTED -> Boolean.TRUE.equals(settings.getEnableModeration());
            case COMMENT, MENTION -> Boolean.TRUE.equals(settings.getEnableComment());
            case LIKE -> Boolean.TRUE.equals(settings.getEnableLike());
            case REPORT -> Boolean.TRUE.equals(settings.getEnableModeration());
            case DEVICE_LOGIN -> Boolean.TRUE.equals(settings.getEnableDeviceLogin());
        };
        if (!enabled) {
            return;
        }
        Notification n = new Notification();
        n.setUserId(userId);
        n.setType(type);
        n.setTitle(title);
        n.setContent(content);
        n.setRefId(refId);
        n.setRead(false);
        n.setCreatedAt(LocalDateTime.now());
        notificationRepository.save(n);
    }

    /** 站长群发系统公告给全部用户（遵守各自公告开关）。 */
    @Transactional
    public int broadcast(Long actorId, String title, String content) {
        User actor = userRepository.findById(actorId)
                .orElseThrow(() -> BusinessException.notFound("操作者不存在"));
        if (!actor.isOwner()) {
            throw BusinessException.forbidden("仅站长可发送系统公告");
        }
        int count = 0;
        for (User u : userRepository.findAll()) {
            NotificationSettings settings = settingsFor(u.getId());
            if (!Boolean.TRUE.equals(settings.getEnableAnnouncement())) {
                continue;
            }
            Notification n = new Notification();
            n.setUserId(u.getId());
            n.setType(Notification.Type.ANNOUNCEMENT);
            n.setTitle(title);
            n.setContent(content);
            n.setRead(false);
            n.setCreatedAt(LocalDateTime.now());
            notificationRepository.save(n);
            count++;
        }
        return count;
    }

    public PageResponse<Notification> list(Long userId, int page, int size) {
        Pageable pageable = PageRequest.of(page, Math.max(1, Math.min(size, 100)));
        Page<Notification> result = notificationRepository.findByUserIdOrderByCreatedAtDesc(userId, pageable);
        return PageResponse.of(result.getContent(), page, pageable.getPageSize(), result.getTotalElements());
    }

    public long unreadCount(Long userId) {
        return notificationRepository.countByUserIdAndReadFalse(userId);
    }

    @Transactional
    public int markAllRead(Long userId) {
        return notificationRepository.markAllRead(userId);
    }

    @Transactional
    public void markRead(Long id, Long userId) {
        notificationRepository.markRead(id, userId);
    }

    public NotificationSettings settingsFor(Long userId) {
        return settingsRepository.findByUserId(userId).orElseGet(() -> {
            NotificationSettings s = new NotificationSettings();
            s.setUserId(userId);
            return settingsRepository.save(s);
        });
    }

    @Transactional
    public NotificationSettings updateSettings(Long userId, NotificationSettings req) {
        NotificationSettings settings = settingsFor(userId);
        if (req.getEnableAnnouncement() != null) settings.setEnableAnnouncement(req.getEnableAnnouncement());
        if (req.getEnableModeration() != null) settings.setEnableModeration(req.getEnableModeration());
        if (req.getEnableComment() != null) settings.setEnableComment(req.getEnableComment());
        if (req.getEnableLike() != null) settings.setEnableLike(req.getEnableLike());
        if (req.getEnableDeviceLogin() != null) settings.setEnableDeviceLogin(req.getEnableDeviceLogin());
        return settingsRepository.save(settings);
    }
}
