package com.forum.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Index;
import jakarta.persistence.Lob;
import jakarta.persistence.Table;

import java.time.LocalDateTime;

/**
 * 帖子编辑历史快照。
 */
@Entity
@Table(name = "post_revisions", indexes = {
        @Index(name = "idx_rev_post", columnList = "post_id")
})
public class PostRevision extends BaseEntity {

    @Column(name = "post_id", nullable = false)
    private Long postId;

    @Column(nullable = false, length = 200)
    private String title;

    @Lob
    @Column(nullable = false, columnDefinition = "LONGTEXT")
    private String content;

    @Column(name = "editor_id")
    private Long editorId;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    public Long getPostId() { return postId; }
    public void setPostId(Long v) { this.postId = v; }
    public String getTitle() { return title; }
    public void setTitle(String v) { this.title = v; }
    public String getContent() { return content; }
    public void setContent(String v) { this.content = v; }
    public Long getEditorId() { return editorId; }
    public void setEditorId(Long v) { this.editorId = v; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime v) { this.createdAt = v; }
}
