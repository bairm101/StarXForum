package com.forum.controller;

import com.forum.dto.ApiResponse;
import com.forum.security.ForumUserPrincipal;
import com.forum.service.AdminService;
import com.forum.service.MaintenanceService;
import com.forum.security.ForumUserPrincipal;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/api/admin/maintenance")
public class MaintenanceController {
    private final MaintenanceService maintenance;
    private final AdminService admin;
    public MaintenanceController(MaintenanceService maintenance, AdminService admin) { this.maintenance=maintenance; this.admin=admin; }

    @GetMapping("/stats")
    public ApiResponse<Map<String,Object>> stats(@AuthenticationPrincipal ForumUserPrincipal p) { admin.ensureStaff(p.getId()); return ApiResponse.ok(maintenance.stats()); }

    @PostMapping("/clear/{target}")
    public ApiResponse<Map<String,Object>> clear(@PathVariable String target, @AuthenticationPrincipal ForumUserPrincipal p) {
        admin.ensureStaff(p.getId());
        return ApiResponse.ok(maintenance.clear(target), "清理完成");
    }
}
