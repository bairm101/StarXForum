package com.forum.entity;

import jakarta.persistence.*;

/** 同一用户对同一帖子或评论只能踩一次。 */
@Entity
@Table(name = "dislikes",
        uniqueConstraints = @UniqueConstraint(name = "uk_dislikes_user_target",
                columnNames = {"user_id", "target_type", "target_id"}),
        indexes = @Index(name = "idx_dislikes_target", columnList = "target_type,target_id"))
public class Dislike extends BaseEntity {
    @Column(name = "user_id", nullable = false)
    private Long userId;
    @Enumerated(EnumType.STRING)
    @Column(name = "target_type", nullable = false, length = 16)
    private Like.TargetType targetType;
    @Column(name = "target_id", nullable = false)
    private Long targetId;

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }
    public Like.TargetType getTargetType() { return targetType; }
    public void setTargetType(Like.TargetType targetType) { this.targetType = targetType; }
    public Long getTargetId() { return targetId; }
    public void setTargetId(Long targetId) { this.targetId = targetId; }
}
