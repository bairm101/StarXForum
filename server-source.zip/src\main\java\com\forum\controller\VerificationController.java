package com.forum.controller;

import com.forum.dto.AdminDtos;
import com.forum.dto.ApiResponse;
import com.forum.service.VerificationService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/verification")
public class VerificationController {
    private final VerificationService service;
    public VerificationController(VerificationService service) { this.service = service; }

    @GetMapping("/challenge")
    public ApiResponse<AdminDtos.ChallengeView> challenge(@RequestParam(defaultValue = "POST") String purpose) {
        return ApiResponse.ok(service.createChallenge(purpose));
    }

    @PostMapping("/email/code")
    public ApiResponse<Void> send(@RequestBody AdminDtos.EmailCodeRequest req) {
        service.sendEmailCode(req);
        return ApiResponse.okMessage("验证码已发送");
    }
}
