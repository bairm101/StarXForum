package com.forum.controller;

import com.forum.dto.ApiResponse;
import com.forum.entity.SensitiveWord;
import com.forum.security.ForumUserPrincipal;
import com.forum.service.AdminService;
import com.forum.service.SensitiveWordService;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admin/sensitive-words")
public class SensitiveWordController {

    private final SensitiveWordService service;
    private final AdminService adminService;

    public SensitiveWordController(SensitiveWordService service, AdminService adminService) {
        this.service = service;
        this.adminService = adminService;
    }

    @GetMapping
    public ApiResponse<List<SensitiveWord>> list() {
        return ApiResponse.ok(service.list());
    }

    @PostMapping
    public ApiResponse<SensitiveWord> add(@RequestBody SensitiveWord req,
                                          @AuthenticationPrincipal ForumUserPrincipal principal) {
        adminService.ensureOwnerOrSuperAdmin(principal.getId());
        return ApiResponse.ok(service.add(req.getWord(), req.getReplacement()));
    }

    @PutMapping("/{id}")
    public ApiResponse<SensitiveWord> update(@PathVariable Long id, @RequestBody SensitiveWord req,
                                             @AuthenticationPrincipal ForumUserPrincipal principal) {
        adminService.ensureOwnerOrSuperAdmin(principal.getId());
        return ApiResponse.ok(service.update(id, req.getReplacement(), req.getEnabled()));
    }

    @DeleteMapping("/{id}")
    public ApiResponse<Void> delete(@PathVariable Long id,
                                    @AuthenticationPrincipal ForumUserPrincipal principal) {
        adminService.ensureOwnerOrSuperAdmin(principal.getId());
        service.delete(id);
        return ApiResponse.okMessage("已删除");
    }
}
