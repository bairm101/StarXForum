package com.forum.controller;

import com.forum.dto.ApiResponse;
import com.forum.dto.PageResponse;
import com.forum.entity.Post;
import com.forum.security.ForumUserPrincipal;
import com.forum.service.FavoriteService;
import com.forum.service.PostService;
import org.springframework.data.domain.Page;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/favorites")
public class FavoriteController {

    private final FavoriteService favoriteService;
    private final PostService postService;

    public FavoriteController(FavoriteService favoriteService, PostService postService) {
        this.favoriteService = favoriteService;
        this.postService = postService;
    }

    @PostMapping("/toggle/{postId}")
    public ApiResponse<Boolean> toggle(@PathVariable Long postId,
                                       @AuthenticationPrincipal ForumUserPrincipal principal) {
        boolean favorited = favoriteService.toggle(principal.getId(), postId);
        return ApiResponse.ok(favorited, favorited ? "已收藏" : "已取消收藏");
    }

    @GetMapping("/check/{postId}")
    public ApiResponse<Boolean> check(@PathVariable Long postId,
                                      @AuthenticationPrincipal ForumUserPrincipal principal) {
        return ApiResponse.ok(favoriteService.isFavorited(principal.getId(), postId));
    }

    @GetMapping("/mine")
    public ApiResponse<PageResponse<com.forum.dto.ForumDtos.PostSummary>> mine(
            @AuthenticationPrincipal ForumUserPrincipal principal,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        Page<Post> posts = favoriteService.myFavorites(principal.getId(), page, size);
        return ApiResponse.ok(postService.toSummaryPageForFavorites(posts, principal.getId()));
    }
}
