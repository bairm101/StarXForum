package com.forum.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.forum.security.JwtAuthenticationFilter;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity
@EnableConfigurationProperties(ForumProperties.class)
public class SecurityConfig {

    private final JwtAuthenticationFilter jwtAuthenticationFilter;
    private final ForumProperties properties;
    private final ObjectMapper objectMapper;

    public SecurityConfig(JwtAuthenticationFilter jwtAuthenticationFilter,
                          ForumProperties properties,
                          ObjectMapper objectMapper) {
        this.jwtAuthenticationFilter = jwtAuthenticationFilter;
        this.properties = properties;
        this.objectMapper = objectMapper;
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        // BCrypt 强度 10，自动加盐
        return new BCryptPasswordEncoder(10);
    }

    @Bean
    public DaoAuthenticationProvider authenticationProvider(UserDetailsService userDetailsService,
                                                            PasswordEncoder passwordEncoder) {
        DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
        provider.setUserDetailsService(userDetailsService);
        provider.setPasswordEncoder(passwordEncoder);
        // 不暴露"用户不存在"与"密码错误"的差异，防止用户名枚举
        provider.setHideUserNotFoundExceptions(true);
        return provider;
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
        return config.getAuthenticationManager();
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
                .csrf(csrf -> csrf.disable())
                .cors(cors -> cors.configurationSource(corsConfigurationSource()))
                .sessionManagement(sm -> sm.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .authorizeHttpRequests(auth -> auth
                        // 预检请求
                        .requestMatchers(HttpMethod.OPTIONS, "/**").permitAll()
                        // 认证入口
                        .requestMatchers("/api/auth/register", "/api/auth/login", "/api/auth/verify-device",
                                "/api/auth/forgot-password", "/api/auth/forgot-password/send").permitAll()
                        .requestMatchers("/api/verification/challenge", "/api/verification/email/code").permitAll()
                        .requestMatchers(HttpMethod.GET, "/media/**").permitAll()
                        .requestMatchers("/api/qr-login/create", "/api/qr-login/status").permitAll()
                        // 公开只读接口
                        .requestMatchers(HttpMethod.GET,
                                "/api/boards/**",
                                "/api/posts/**",
                                "/api/comments/**",
                                "/api/polls/**",
                                "/api/topics/**",
                                "/api/search/**",
                                "/api/users/*/profile",
                                "/api/users/*/posts",
                                "/api/users/*/comments",
                                "/api/users/*/following",
                                "/api/users/*/followers",
                                "/api/users/*/follow-status",
                                "/api/users/by-name/**",
                                "/api/users/by-uid/**",
                                "/api/settings").permitAll()
                        // 静态上传资源
                        .requestMatchers(HttpMethod.GET, "/uploads/**").permitAll()
                        // 健康检查
                        .requestMatchers("/api/health").permitAll()
                        // 管理后台（站长/超管/管理员，内部再按板块细分）
                        .requestMatchers("/api/admin/**").hasAnyRole("OWNER", "SUPER_ADMIN", "ADMIN")
                        // 运营统计（含概览/趋势/活跃用户）仅管理员可见，避免匿名泄露运营数据
                        .requestMatchers("/api/stats/**").hasAnyRole("OWNER", "SUPER_ADMIN", "ADMIN")
                        // 其余需登录
                        .anyRequest().authenticated()
                )
                .exceptionHandling(ex -> ex
                        .authenticationEntryPoint((req, res, e) ->
                                writeError(res, HttpServletResponse.SC_UNAUTHORIZED, "未登录或登录态已失效"))
                        .accessDeniedHandler((req, res, e) ->
                                writeError(res, HttpServletResponse.SC_FORBIDDEN, "没有操作权限"))
                )
                .addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }

    private void writeError(HttpServletResponse response, int status, String message) throws java.io.IOException {
        response.setStatus(status);
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setCharacterEncoding("UTF-8");
        objectMapper.writeValue(response.getWriter(),
                Map.of("success", false, "message", message));
    }

    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration config = new CorsConfiguration();
        String origins = properties.getCors().getAllowedOrigins();

        List<String> patterns = Arrays.stream(origins.split(","))
                .map(String::trim).filter(s -> !s.isEmpty()).toList();
        if (patterns.isEmpty()) {
            patterns = List.of("*");
        }
        // 统一用 Origin Pattern：支持精确域名与 localhost:* 通配，且不再无条件回显任意来源
        config.setAllowedOriginPatterns(patterns);
        // 认证走 Bearer Token（Authorization 头），不依赖 Cookie，无需 credentials
        config.setAllowCredentials(false);

        config.setAllowedMethods(List.of("GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"));
        config.setAllowedHeaders(List.of("Authorization", "Content-Type", "X-Challenge-Id", "X-Challenge-Answer"));
        config.setExposedHeaders(List.of("Authorization"));
        config.setMaxAge(3600L);

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", config);
        return source;
    }
}
