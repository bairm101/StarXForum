package com.forum.controller;

import com.forum.dto.ApiResponse;
import com.forum.service.StatsService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/stats")
public class StatsController {

    private final StatsService statsService;

    public StatsController(StatsService statsService) {
        this.statsService = statsService;
    }

    @GetMapping("/overview")
    public ApiResponse<Map<String, Object>> overview() {
        return ApiResponse.ok(statsService.overview());
    }

    @GetMapping("/daily/registrations")
    public ApiResponse<List<Map<String, Object>>> registrations(@RequestParam(defaultValue = "7") int days) {
        return ApiResponse.ok(statsService.registrationsDaily(days));
    }

    @GetMapping("/daily/posts")
    public ApiResponse<List<Map<String, Object>>> posts(@RequestParam(defaultValue = "7") int days) {
        return ApiResponse.ok(statsService.postsDaily(days));
    }

    @GetMapping("/daily/comments")
    public ApiResponse<List<Map<String, Object>>> comments(@RequestParam(defaultValue = "7") int days) {
        return ApiResponse.ok(statsService.commentsDaily(days));
    }

    @GetMapping("/active-users")
    public ApiResponse<List<Map<String, Object>>> activeUsers(@RequestParam(defaultValue = "10") int limit) {
        return ApiResponse.ok(statsService.activeUsers(limit));
    }
}
