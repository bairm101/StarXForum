package com.forum.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Index;
import jakarta.persistence.Table;

@Entity
@Table(name = "upload_records", indexes = {
        @Index(name = "idx_upload_user", columnList = "user_id")
})
public class UploadRecord extends BaseEntity {
    @Column(name = "user_id", nullable = false)
    private Long userId;
    @Column(nullable = false, length = 16)
    private String type;
    @Column(nullable = false, length = 255)
    private String path;
    @Column(name = "size_bytes", nullable = false)
    private Long sizeBytes;
    @Column(name = "public_code", unique = true, length = 32)
    private String publicCode;
    @Column(name = "original_name", length = 255)
    private String originalName;
    @Column(name = "content_type", length = 128)
    private String contentType;

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
    public String getPath() { return path; }
    public void setPath(String path) { this.path = path; }
    public Long getSizeBytes() { return sizeBytes; }
    public void setSizeBytes(Long sizeBytes) { this.sizeBytes = sizeBytes; }
    public String getPublicCode() { return publicCode; }
    public void setPublicCode(String publicCode) { this.publicCode = publicCode; }
    public String getOriginalName() { return originalName; }
    public void setOriginalName(String originalName) { this.originalName = originalName; }
    public String getContentType() { return contentType; }
    public void setContentType(String contentType) { this.contentType = contentType; }
}
