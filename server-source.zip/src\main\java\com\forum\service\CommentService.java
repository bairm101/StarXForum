package com.forum.service;

import com.forum.dto.ForumDtos;
import com.forum.dto.PageResponse;
import com.forum.entity.Comment;
import com.forum.entity.Like;
import com.forum.entity.Notification;
import com.forum.entity.Post;
import com.forum.entity.User;
import com.forum.exception.BusinessException;
import com.forum.repository.CommentRepository;
import com.forum.repository.DislikeRepository;
import com.forum.repository.LikeRepository;
import com.forum.repository.PostRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class CommentService {

    private final CommentRepository commentRepository;
    private final PostRepository postRepository;
    private final LikeRepository likeRepository;
    private final DislikeRepository dislikeRepository;
    private final UserService userService;
    private final PostService postService;
    private final NotificationService notificationService;
    private final ContentFilterService contentFilterService;

    public CommentService(CommentRepository commentRepository,
                          PostRepository postRepository,
                          LikeRepository likeRepository,
                          DislikeRepository dislikeRepository,
                          UserService userService,
                          PostService postService,
                          NotificationService notificationService,
                          ContentFilterService contentFilterService) {
        this.commentRepository = commentRepository;
        this.postRepository = postRepository;
        this.likeRepository = likeRepository;
        this.dislikeRepository = dislikeRepository;
        this.userService = userService;
        this.postService = postService;
        this.notificationService = notificationService;
        this.contentFilterService = contentFilterService;
    }

    /**
     * 帖子评论分页（顶层评论，含一级子回复）。
     */
    @Transactional(readOnly = true)
    public PageResponse<ForumDtos.CommentView> listByPost(Long postId, int page, int size, String sort, Long currentUserId) {
        Post post = postRepository.findByIdAndDeletedFalse(postId)
                .orElseThrow(() -> BusinessException.notFound("帖子不存在或已删除"));

        Pageable pageable = PageRequest.of(page, UserService.normalizeSize(size),
                Sort.by(Sort.Direction.ASC, "createdAt"));
        Page<Comment> roots = "hot".equalsIgnoreCase(sort)
                ? commentRepository.findByPostIdAndParentIsNullAndDeletedFalseOrderByLikeCountDescCreatedAtAsc(postId, pageable)
                : commentRepository.findByPostIdAndParentIsNullAndDeletedFalseOrderByCreatedAtAsc(postId, pageable);

        // 批量取所有顶层评论的子回复，组装树
        List<Long> rootIds = roots.getContent().stream().map(Comment::getId).toList();
        Map<Long, List<Comment>> childrenByParent = rootIds.isEmpty() ? Map.of()
                : commentRepository.findByParentIdInAndDeletedFalseOrderByCreatedAtAsc(rootIds)
                        .stream().collect(Collectors.groupingBy(c -> c.getParent().getId()));

        // 一次性解析点赞/点踩状态与可编辑权限
        Set<Long> likedCommentIds = resolveLiked(rootIds, currentUserId);
        Set<Long> dislikedCommentIds = resolveDisliked(rootIds, currentUserId);
        Set<Long> likedReplyIds = childrenByParent.values().stream()
                .flatMap(List::stream).map(Comment::getId).collect(Collectors.toSet());
        Set<Long> likedReplyResult = resolveLiked(new ArrayList<>(likedReplyIds), currentUserId);
        Set<Long> dislikedReplyIds = resolveDisliked(new ArrayList<>(likedReplyIds), currentUserId);

        List<ForumDtos.CommentView> items = roots.getContent().stream()
                .map(root -> toView(root,
                        childrenByParent.getOrDefault(root.getId(), List.of()),
                        likedCommentIds, dislikedCommentIds, likedReplyResult, dislikedReplyIds, currentUserId))
                .toList();

        return PageResponse.of(items, page, UserService.normalizeSize(size), roots.getTotalElements());
    }

    @Transactional(readOnly = true)
    public PageResponse<ForumDtos.CommentView> listByAuthor(Long authorId, int page, int size, Long currentUserId) {
        Pageable pageable = PageRequest.of(page, UserService.normalizeSize(size),
                Sort.by(Sort.Direction.DESC, "createdAt"));
        Page<Comment> comments = commentRepository.findByAuthorIdAndDeletedFalse(authorId, pageable);
        Set<Long> likedIds = resolveLiked(comments.getContent().stream().map(Comment::getId).toList(), currentUserId);
        Set<Long> dislikedIds = resolveDisliked(comments.getContent().stream().map(Comment::getId).toList(), currentUserId);

        List<ForumDtos.CommentView> items = comments.getContent().stream()
                .map(c -> toView(c, List.of(), likedIds, dislikedIds, Set.of(), Set.of(), currentUserId))
                .toList();
        return PageResponse.of(items, page, UserService.normalizeSize(size), comments.getTotalElements());
    }

    @Transactional
    public ForumDtos.CommentView create(Long postId, ForumDtos.CreateCommentRequest req, Long userId) {
        Post post = postRepository.findByIdAndDeletedFalse(postId)
                .orElseThrow(() -> BusinessException.notFound("帖子不存在或已删除"));
        if (Boolean.TRUE.equals(post.getLocked())) {
            throw BusinessException.forbidden("帖子已锁定，无法回复");
        }
        User author = userService.requireUser(userId);

        String filteredContent = contentFilterService.filter(req.content());

        // 使用敏感词：记录违规，频繁使用自动降权
        if (contentFilterService.containsSensitive(req.content())) {
            userService.recordSensitiveViolation(userId);
        }

        Comment comment = new Comment();
        comment.setContent(filteredContent);
        comment.setPost(post);
        comment.setAuthor(author);

        if (req.parentId() != null) {
            Comment parent = commentRepository.findByIdAndDeletedFalse(req.parentId())
                    .orElseThrow(() -> BusinessException.notFound("要回复的评论不存在或已删除"));
            if (!parent.getPost().getId().equals(postId)) {
                throw new BusinessException("回复的评论不属于该帖子");
            }
            // 支持回复子评论：向上归并到顶层评论，保持二级楼中楼结构（@ 由客户端补充）
            Comment root = parent;
            while (root.getParent() != null) {
                root = root.getParent();
            }
            comment.setParent(root);
        }

        Comment saved = commentRepository.save(comment);
        postRepository.addCommentCount(postId, 1);
        userService.incrementCommentCount(userId, 1);
        postService.touchActivity(postId);

        // 被评论通知：通知帖子作者
        notificationService.notify(post.getAuthor().getId(), userId, Notification.Type.COMMENT,
                "有人回复了你的帖子",
                author.getDisplayName() + " 回复了《" + post.getTitle() + "》", postId);

        // @提及通知
        contentFilterService.notifyMentions(filteredContent, userId, author.getDisplayName(),
                post.getTitle(), postId);

        boolean liked = false;
        return toView(saved, List.of(), liked ? Set.of(saved.getId()) : Set.of(),
                dislikeRepository.existsByUserIdAndTargetTypeAndTargetId(userId, Like.TargetType.COMMENT, saved.getId())
                        ? Set.of(saved.getId()) : Set.of(), Set.of(), Set.of(), userId);
    }

    @Transactional
    public ForumDtos.CommentView update(Long id, ForumDtos.UpdateCommentRequest req, Long userId) {
        Comment comment = commentRepository.findByIdAndDeletedFalse(id)
                .orElseThrow(() -> BusinessException.notFound("评论不存在或已删除"));

        if (!comment.getAuthor().getId().equals(userId)) {
            throw BusinessException.forbidden("只能编辑自己的评论");
        }
        comment.setContent(contentFilterService.filter(req.content().trim()));
        Comment saved = commentRepository.save(comment);

        boolean liked = likeRepository.existsByUserIdAndTargetTypeAndTargetId(
                userId, Like.TargetType.COMMENT, id);
        boolean disliked = dislikeRepository.existsByUserIdAndTargetTypeAndTargetId(
                userId, Like.TargetType.COMMENT, id);
        return toView(saved, List.of(), liked ? Set.of(id) : Set.of(),
                disliked ? Set.of(id) : Set.of(), Set.of(), Set.of(), userId);
    }

    @Transactional
    public void delete(Long id, Long userId) {
        Comment comment = commentRepository.findByIdAndDeletedFalse(id)
                .orElseThrow(() -> BusinessException.notFound("评论不存在或已删除"));

        if (!comment.getAuthor().getId().equals(userId) && !comment.getPost().getAuthor().getId().equals(userId) && !canModerateComment(comment, userId)) {
            throw BusinessException.forbidden("只能删除自己的评论");
        }

        // 级联软删未删除的子回复，保证计数与实际一致
        List<Comment> replies = commentRepository.findByParentIdInAndDeletedFalseOrderByCreatedAtAsc(List.of(id));
        for (Comment r : replies) {
            r.setDeleted(true);
            commentRepository.save(r);
            userService.incrementCommentCount(r.getAuthor().getId(), -1);
        }

        comment.setDeleted(true);
        commentRepository.save(comment);
        userService.incrementCommentCount(comment.getAuthor().getId(), -1);
        postRepository.addCommentCount(comment.getPost().getId(), -(1 + replies.size()));
        postService.touchActivity(comment.getPost().getId());
    }

    @Transactional
    public ForumDtos.LikeResult toggleLike(Long commentId, Long userId) {
        Comment comment = commentRepository.findByIdAndDeletedFalse(commentId)
                .orElseThrow(() -> BusinessException.notFound("评论不存在或已删除"));

        boolean exists = likeRepository.existsByUserIdAndTargetTypeAndTargetId(
                userId, Like.TargetType.COMMENT, commentId);

        if (exists) {
            likeRepository.deleteByUserIdAndTargetTypeAndTargetId(userId, Like.TargetType.COMMENT, commentId);
            commentRepository.addLikeCount(commentId, -1);
            return new ForumDtos.LikeResult(false, Math.max(0, comment.getLikeCount() - 1));
        }

        // 点赞时取消已点踩（互斥）
        if (dislikeRepository.existsByUserIdAndTargetTypeAndTargetId(userId, Like.TargetType.COMMENT, commentId)) {
            dislikeRepository.deleteByUserIdAndTargetTypeAndTargetId(userId, Like.TargetType.COMMENT, commentId);
            commentRepository.addDislikeCount(commentId, -1);
        }

        Like like = new Like();
        like.setUserId(userId);
        like.setTargetType(Like.TargetType.COMMENT);
        like.setTargetId(commentId);
        likeRepository.save(like);
        commentRepository.addLikeCount(commentId, 1);

        // 被点赞通知：通知评论作者
        User liker = userService.requireUser(userId);
        notificationService.notify(comment.getAuthor().getId(), userId, Notification.Type.LIKE,
                "有人赞了你的评论",
                liker.getDisplayName() + " 赞了你的评论",
                comment.getPost() != null ? comment.getPost().getId() : null);

        return new ForumDtos.LikeResult(true, comment.getLikeCount() + 1);
    }

    // ---------- 内部工具 ----------

    private ForumDtos.CommentView toView(Comment c,
                                         List<Comment> replies,
                                         Set<Long> likedIds,
                                         Set<Long> dislikedIds,
                                         Set<Long> likedReplyIds,
                                         Set<Long> dislikedReplyIds,
                                         Long currentUserId) {
        boolean liked = likedIds.contains(c.getId());
        boolean disliked = dislikedIds.contains(c.getId());
        boolean canEdit = currentUserId != null && c.getAuthor().getId().equals(currentUserId);
        boolean canDelete = canModify(c, currentUserId);

        List<ForumDtos.CommentView> replyViews = replies.stream()
                .map(r -> toView(r, List.of(), likedReplyIds, dislikedReplyIds, Set.of(), Set.of(), currentUserId))
                .toList();

        return new ForumDtos.CommentView(
                c.getId(),
                contentFilterService.filter(c.getContent()),
                c.getPost() != null ? c.getPost().getId() : null,
                c.getParent() != null ? c.getParent().getId() : null,
                com.forum.dto.auth.UserDtos.AuthorSummary.from(c.getAuthor()),
                c.getLikeCount(),
                c.getDislikeCount(),
                liked,
                disliked,
                canEdit,
                canDelete,
                replyViews,
                c.getCreatedAt()
        );
    }

    private boolean canModify(Comment c, Long currentUserId) {
        if (currentUserId == null) {
            return false;
        }
        if (c.getAuthor().getId().equals(currentUserId)) {
            return true;
        }
        return canModerateComment(c, currentUserId);
    }

    /** 对该评论所在帖子的板块有管理权限者可删/改评论 */
    private boolean canModerateComment(Comment c, Long userId) {
        if (userId == null) {
            return false;
        }
        try {
            User u = userService.requireUser(userId);
            if (c.getPost() == null || c.getPost().getBoard() == null) {
                return u.isOwner() || u.isSuperAdmin();
            }
            return u.canManageBoard(c.getPost().getBoard().getId());
        } catch (BusinessException e) {
            return false;
        }
    }

    private Set<Long> resolveLiked(List<Long> ids, Long currentUserId) {
        return postService.resolveLikedIds(ids, currentUserId, Like.TargetType.COMMENT);
    }

    private Set<Long> resolveDisliked(List<Long> ids, Long currentUserId) {
        if (currentUserId == null || ids.isEmpty()) return Set.of();
        return dislikeRepository.findByUserIdAndTargetTypeAndTargetIdIn(currentUserId, Like.TargetType.COMMENT, ids)
                .stream().map(com.forum.entity.Dislike::getTargetId).collect(Collectors.toSet());
    }
}
