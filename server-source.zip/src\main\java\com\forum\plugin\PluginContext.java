package com.forum.plugin;

import java.nio.file.Path;
import java.util.Map;

public record PluginContext(Path dataDirectory, Map<String, String> attributes) {}
