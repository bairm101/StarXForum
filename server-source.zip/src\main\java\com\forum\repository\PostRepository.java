package com.forum.repository;

import com.forum.entity.Post;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface PostRepository extends JpaRepository<Post, Long> {

    Page<Post> findByDeletedFalse(Pageable pageable);

    Page<Post> findByBoardIdAndDeletedFalse(Long boardId, Pageable pageable);

    Page<Post> findByAuthorIdAndDeletedFalse(Long authorId, Pageable pageable);

    Optional<Post> findByIdAndDeletedFalse(Long id);

    Optional<Post> findByPuidAndDeletedFalse(String puid);

    Page<Post> findByTopicsContainingAndDeletedFalseAndStatus(String topic, Post.PostStatus status, Pageable pageable);

    /** 批量预取 board/author，避免懒加载越界 */
    @Query("SELECT p FROM Post p LEFT JOIN FETCH p.board LEFT JOIN FETCH p.author WHERE p.id IN :ids")
    List<Post> findByIdsWithBoard(@Param("ids") java.util.Collection<Long> ids);

    // ---------- 按审核状态过滤（公开列表只看 APPROVED） ----------

    Page<Post> findByDeletedFalseAndStatus(Post.PostStatus status, Pageable pageable);

    Page<Post> findByBoardIdAndDeletedFalseAndStatus(Long boardId, Post.PostStatus status, Pageable pageable);

    Page<Post> findByAuthorIdAndDeletedFalseAndStatus(Long authorId, Post.PostStatus status, Pageable pageable);

    Page<Post> findByAuthorIdInAndDeletedFalseAndStatus(java.util.Collection<Long> authorIds, Post.PostStatus status, Pageable pageable);

    /** 待审核队列（按板块） */
    Page<Post> findByBoardIdAndStatusAndDeletedFalse(Long boardId, Post.PostStatus status, Pageable pageable);

    /** 全部待审核（超管/站长） */
    Page<Post> findByStatusAndDeletedFalse(Post.PostStatus status, Pageable pageable);

    /** 推荐候选池：最近 + 热门（未删除且已审核） */
    List<Post> findTop200ByDeletedFalseAndStatusOrderByIdDesc(Post.PostStatus status);

    /**
     * 全文搜索。使用 MySQL ngram 全文索引以支持中文；
     * 索引由 FullTextIndexInitializer 在启动时确保存在。
     * 未命中全文索引时由调用方回退到 LIKE 查询。
     */
    @Query(
            value = """
                    SELECT * FROM posts
                    WHERE deleted = 0 AND status = 'APPROVED'
                      AND MATCH(title, content) AGAINST (:kw IN NATURAL LANGUAGE MODE)
                    ORDER BY MATCH(title, content) AGAINST (:kw IN NATURAL LANGUAGE MODE) DESC,
                             last_activity_at DESC
                    """,
            countQuery = """
                    SELECT COUNT(*) FROM posts
                    WHERE deleted = 0 AND status = 'APPROVED'
                      AND MATCH(title, content) AGAINST (:kw IN NATURAL LANGUAGE MODE)
                    """,
            nativeQuery = true
    )
    Page<Post> fullTextSearch(@Param("kw") String keyword, Pageable pageable);

    /** LIKE 回退搜索，保证短词/生僻词也能命中（原生 SQL，避开 CLOB 的 lower() 类型限制） */
    @Query(
            value = """
                    SELECT * FROM posts
                    WHERE deleted = 0 AND status = 'APPROVED'
                      AND (title LIKE CONCAT('%', :kw, '%')
                           OR content LIKE CONCAT('%', :kw, '%'))
                    ORDER BY last_activity_at DESC
                    """,
            countQuery = """
                    SELECT COUNT(*) FROM posts
                    WHERE deleted = 0 AND status = 'APPROVED'
                      AND (title LIKE CONCAT('%', :kw, '%')
                           OR content LIKE CONCAT('%', :kw, '%'))
                    """,
            nativeQuery = true
    )
    Page<Post> likeSearch(@Param("kw") String keyword, Pageable pageable);

    @Modifying
    @Query("UPDATE Post p SET p.viewCount = p.viewCount + 1 WHERE p.id = :id")
    void incrementViewCount(@Param("id") Long id);

    @Modifying
    @Query("UPDATE Post p SET p.commentCount = p.commentCount + :delta WHERE p.id = :id")
    void addCommentCount(@Param("id") Long id, @Param("delta") int delta);

    @Modifying
    @Query("UPDATE Post p SET p.likeCount = p.likeCount + :delta WHERE p.id = :id")
    void addLikeCount(@Param("id") Long id, @Param("delta") int delta);

    @Modifying
    @Query("UPDATE Post p SET p.dislikeCount = p.dislikeCount + :delta WHERE p.id = :id")
    void addDislikeCount(@Param("id") Long id, @Param("delta") int delta);

    long countByBoardIdAndDeletedFalse(Long boardId);

    long countByDeletedFalse();

    long countByStatusAndDeletedFalse(Post.PostStatus status);
}
