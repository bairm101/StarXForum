package com.forum.service;

import com.forum.dto.ForumDtos;
import com.forum.entity.*;
import com.forum.exception.BusinessException;
import com.forum.repository.*;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ReactionService {
    @PersistenceContext
    private EntityManager entityManager;
    private final PostRepository posts;
    private final CommentRepository comments;
    private final LikeRepository likes;
    private final DislikeRepository dislikes;
    private final UserService users;
    private final ReportRepository reports;

    public ReactionService(PostRepository posts, CommentRepository comments, LikeRepository likes,
                           DislikeRepository dislikes, UserService users, ReportRepository reports) {
        this.posts = posts; this.comments = comments; this.likes = likes; this.dislikes = dislikes;
        this.users = users; this.reports = reports;
    }

    @Transactional
    public ForumDtos.LikeResult toggleDislike(Like.TargetType type, Long targetId, Long userId) {
        boolean exists = dislikes.existsByUserIdAndTargetTypeAndTargetId(userId, type, targetId);
        if (exists) {
            dislikes.deleteByUserIdAndTargetTypeAndTargetId(userId, type, targetId);
            changeCount(type, targetId, -1);
            return new ForumDtos.LikeResult(false, count(type, targetId));
        }
        // 点踩时取消点赞，保证同一用户不会同时点赞和点踩。
        if (likes.existsByUserIdAndTargetTypeAndTargetId(userId, type, targetId)) {
            likes.deleteByUserIdAndTargetTypeAndTargetId(userId, type, targetId);
            if (type == Like.TargetType.POST) posts.addLikeCount(targetId, -1); else comments.addLikeCount(targetId, -1);
        }
        Dislike d = new Dislike(); d.setUserId(userId); d.setTargetType(type); d.setTargetId(targetId); dislikes.save(d);
        changeCount(type, targetId, 1);
        return new ForumDtos.LikeResult(true, count(type, targetId));
    }

    public boolean disliked(Like.TargetType type, Long id, Long userId) {
        return userId != null && dislikes.existsByUserIdAndTargetTypeAndTargetId(userId, type, id);
    }

    @Transactional
    public void report(Report.TargetType type, Long targetId, String reason, Long reporterId) {
        if (reason == null || reason.isBlank()) throw new BusinessException("请填写举报原因");
        if (reports.findByReporterIdAndTargetTypeAndTargetId(reporterId, type, targetId).isPresent())
            throw BusinessException.conflict("你已经举报过该内容");
        switch (type) {
            case POST -> posts.findByIdAndDeletedFalse(targetId)
                    .orElseThrow(() -> BusinessException.notFound("帖子不存在"));
            case COMMENT -> comments.findByIdAndDeletedFalse(targetId)
                    .orElseThrow(() -> BusinessException.notFound("评论不存在"));
            case USER -> users.requireUser(targetId);
        }
        Report r = new Report(); r.setReporterId(reporterId); r.setTargetType(type); r.setTargetId(targetId); r.setReason(reason.trim()); reports.save(r);
    }

    /**
     * 举报私信会话（可附聊天记录 ID 与截图地址作为证据）。
     * 目标按 USER 处理；证据序列化为 JSON 存入 evidence_json。
     */
    @Transactional
    public void reportChat(Long peerId, String reason, java.util.List<Long> messageIds,
                           java.util.List<String> images, Long reporterId) {
        users.requireUser(peerId);
        if (reports.findByReporterIdAndTargetTypeAndTargetId(reporterId, Report.TargetType.USER, peerId).isPresent())
            throw BusinessException.conflict("你已经举报过该用户");

        // 校验所选消息确实属于当前双方会话
        if (messageIds != null && !messageIds.isEmpty()) {
            String in = messageIds.stream().map(String::valueOf)
                    .reduce((a, b) -> a + "," + b).orElse("");
            Long ok = ((Number) entityManager.createNativeQuery(
                    "SELECT COUNT(*) FROM messages WHERE id IN (" + in + ") " +
                    "AND ((sender_id=:me AND recipient_id=:peer) OR (sender_id=:peer AND recipient_id=:me)) " +
                    "AND deleted_by_sender=0 AND deleted_by_recipient=0")
                    .setParameter("me", reporterId).setParameter("peer", peerId)
                    .getSingleResult()).longValue();
            if (ok == null || ok != messageIds.size())
                throw BusinessException.notFound("部分聊天记录不存在");
        }

        String ev = null;
        try {
            java.util.Map<String, Object> m = new java.util.HashMap<>();
            m.put("messageIds", messageIds == null ? java.util.List.of() : messageIds);
            m.put("images", images == null ? java.util.List.of() : images);
            ev = new com.fasterxml.jackson.databind.ObjectMapper().writeValueAsString(m);
        } catch (Exception ignored) { }

        Report r = new Report();
        r.setReporterId(reporterId);
        r.setTargetType(Report.TargetType.USER);
        r.setTargetId(peerId);
        r.setReason(reason != null && !reason.isBlank() ? reason.trim() : "(通过聊天记录举报)");
        r.setEvidenceJson(ev);
        reports.save(r);
    }

    private void changeCount(Like.TargetType type, Long id, int delta) {
        if (type == Like.TargetType.POST) posts.addDislikeCount(id, delta); else comments.addDislikeCount(id, delta);
    }
    private long count(Like.TargetType type, Long id) {
        return dislikes.countByTargetTypeAndTargetId(type, id);
    }
}
