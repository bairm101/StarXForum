package com.forum.dto;

import com.forum.dto.auth.UserDtos;
import com.forum.entity.Board;
import com.forum.entity.Comment;
import com.forum.entity.Post;
import com.forum.entity.SiteSettings;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.time.LocalDateTime;
import java.util.List;

public class ForumDtos {

    // ---------- 板块 ----------

    public record BoardView(
            Long id,
            String name,
            String description,
            Integer sortOrder,
            Integer postCount,
            Boolean visible,
            Boolean requireModeration
    ) {
        public static BoardView from(Board b) {
            return new BoardView(b.getId(), b.getName(), b.getDescription(),
                    b.getSortOrder(), b.getPostCount(), b.getVisible(), b.getRequireModeration());
        }
    }

    public record BoardRequest(
            @NotBlank(message = "板块名称不能为空")
            @Size(max = 50, message = "板块名称最长 50 字")
            String name,

            @Size(max = 255, message = "板块描述最长 255 字")
            String description,

            Integer sortOrder,
            Boolean visible,
            Boolean requireModeration
    ) {
    }

    // ---------- 站点设置 ----------

    public record SiteSettingsRequest(
            @Size(max = 64, message = "站点名最长 64 字")
            String siteName,

            @Size(max = 255, message = "描述最长 255 字")
            String siteDescription,

            @Size(max = 500, message = "公告最长 500 字")
            String announcement,

            Boolean allowRegister
    ) {
    }

    public record SiteSettingsView(
            Long id,
            String siteName,
            String siteDescription,
            String announcement,
            Boolean allowRegister,
            String pageTitle,
            String defaultTheme,
            String footerText,
            String footerIcp,
            String footerLinksJson,
            String officialWebsite,
            String webShareBaseUrl,
            String contactEmail,
            String aboutIcp,
            Integer autoRefreshSeconds,
            LocalDateTime updatedAt
    ) {
        public static SiteSettingsView from(SiteSettings s) {
            return new SiteSettingsView(s.getId(), s.getSiteName(), s.getSiteDescription(),
                    s.getAnnouncement(), s.getAllowRegister(), s.getPageTitle(), s.getDefaultTheme(),
                    s.getFooterText(), s.getFooterIcp(), s.getFooterLinksJson(),
                    s.getOfficialWebsite(), s.getWebShareBaseUrl(), s.getContactEmail(), s.getAboutIcp(),
                    s.getAutoRefreshSeconds(), s.getUpdatedAt());
        }
    }

    // ---------- 帖子 ----------

    /** 列表项：不含正文，减少传输量 */
    public record PostSummary(
            Long id,
            String title,
            String excerpt,
            Long boardId,
            String boardName,
            UserDtos.AuthorSummary author,
            Integer viewCount,
            Integer commentCount,
            Integer likeCount,
            Integer dislikeCount,
            Boolean pinned,
            Boolean boardPinned,
            Boolean locked,
            Boolean likedByMe,
            Long totalTipGold,
            Integer tipCount,
            String status,
            String thumbnailUrl,
            String videoUrl,
            String gateType,
            String topics,
            String puid,
            LocalDateTime createdAt,
            LocalDateTime lastActivityAt
    ) {
        public static PostSummary from(Post p, boolean likedByMe) {
            return new PostSummary(
                    p.getId(),
                    p.getTitle(),
                    buildExcerpt(p.getContent()),
                    p.getBoard() != null ? p.getBoard().getId() : null,
                    p.getBoard() != null ? p.getBoard().getName() : null,
                    UserDtos.AuthorSummary.from(p.getAuthor()),
                    p.getViewCount(),
                    p.getCommentCount(),
                    p.getLikeCount(),
                    p.getDislikeCount(),
                    p.getPinned(),
                    p.getBoardPinned(),
                    p.getLocked(),
                    likedByMe,
                    p.getTotalTipGold(),
                    p.getTipCount(),
                    p.getStatus() != null ? p.getStatus().name() : "APPROVED",
                    p.getThumbnailUrl(),
                    extractVideoUrl(p.getContent()),
                    p.getGateType(),
                    p.getTopics(),
                    p.getPuid(),
                    p.getCreatedAt(),
                    p.getLastActivityAt()
            );
        }

        private static String extractVideoUrl(String content) {
            if (content == null) return null;
            var m = java.util.regex.Pattern.compile("\\[视频\\]\\(([^)]+)\\)").matcher(content);
            return m.find() ? m.group(1) : null;
        }

        private static String buildExcerpt(String content) {
            if (content == null) {
                return "";
            }
            String plain = content.replaceAll("\\s+", " ").trim();
            return plain.length() <= 120 ? plain : plain.substring(0, 120) + "...";
        }
    }

    /** 详情：含完整正文 */
    public record PostDetail(
            Long id,
            String title,
            String content,
            Long boardId,
            String boardName,
            UserDtos.AuthorSummary author,
            Integer viewCount,
            Integer commentCount,
            Integer likeCount,
            Integer dislikeCount,
            Boolean pinned,
            Boolean boardPinned,
            Boolean locked,
            Boolean likedByMe,
            Boolean dislikedByMe,
            Boolean canEdit,
            Long totalTipGold,
            Integer tipCount,
            Integer myTipTimes,
            String status,
            String thumbnailUrl,
            String topics,
            String puid,
            String gateType,
            Boolean gateUnlocked,
            Long gatePrice,
            String gatedContent,
            LocalDateTime createdAt,
            LocalDateTime updatedAt,
            LocalDateTime lastActivityAt
    ) {
        public static PostDetail from(Post p, boolean likedByMe, boolean canEdit, int myTipTimes) {
            return from(p, likedByMe, canEdit, myTipTimes, false, false);
        }
        public static PostDetail from(Post p, boolean likedByMe, boolean canEdit, int myTipTimes, boolean unlocked) {
            return from(p, likedByMe, canEdit, myTipTimes, unlocked, false, p.getContent(), p.getThumbnailUrl());
        }
        public static PostDetail from(Post p, boolean likedByMe, boolean canEdit, int myTipTimes, boolean unlocked, boolean dislikedByMe) {
            return from(p, likedByMe, canEdit, myTipTimes, unlocked, dislikedByMe, p.getContent(), p.getThumbnailUrl());
        }
        public static PostDetail from(Post p, boolean likedByMe, boolean canEdit, int myTipTimes, boolean unlocked, String content, String thumbnail) {
            return from(p, likedByMe, canEdit, myTipTimes, unlocked, false, content, thumbnail);
        }
        public static PostDetail from(Post p, boolean likedByMe, boolean canEdit, int myTipTimes, boolean unlocked, boolean dislikedByMe, String content, String thumbnail) {
            return new PostDetail(
                    p.getId(),
                    p.getTitle(),
                    content,
                    p.getBoard() != null ? p.getBoard().getId() : null,
                    p.getBoard() != null ? p.getBoard().getName() : null,
                    UserDtos.AuthorSummary.from(p.getAuthor()),
                    p.getViewCount(),
                    p.getCommentCount(),
                    p.getLikeCount(),
                    p.getDislikeCount(),
                    p.getPinned(),
                    p.getBoardPinned(),
                    p.getLocked(),
                    likedByMe,
                    dislikedByMe,
                    canEdit,
                    p.getTotalTipGold(),
                    p.getTipCount(),
                    myTipTimes,
                    p.getStatus() != null ? p.getStatus().name() : "APPROVED",
                    thumbnail,
                    p.getTopics(),
                    p.getPuid(),
                    p.getGateType(),
                    unlocked,
                    p.getGatePrice(),
                    unlocked ? p.getGatedContent() : null,
                    p.getCreatedAt(),
                    p.getUpdatedAt(),
                    p.getLastActivityAt()
            );
        }
    }

    public record CreatePostRequest(
            @NotBlank(message = "标题不能为空")
            @Size(min = 2, max = 200, message = "标题长度需在 2-200 之间")
            String title,

            @NotBlank(message = "内容不能为空")
            @Size(max = 100000, message = "内容过长")
            String content,

            @NotNull(message = "请选择板块")
            Long boardId,
            String gateType,
            String gatedContent,
            Long gatePrice,
            String topics
    ) {
    }

    public record UpdatePostRequest(
            @NotBlank(message = "标题不能为空")
            @Size(min = 2, max = 200, message = "标题长度需在 2-200 之间")
            String title,

            @NotBlank(message = "内容不能为空")
            @Size(max = 100000, message = "内容过长")
            String content,

            Long boardId,
            String topics
    ) {
    }

    // ---------- 评论 ----------

    public record CommentView(
            Long id,
            String content,
            Long postId,
            Long parentId,
            UserDtos.AuthorSummary author,
            Integer likeCount,
            Integer dislikeCount,
            Boolean likedByMe,
            Boolean dislikedByMe,
            Boolean canEdit,
            Boolean canDelete,
            List<CommentView> replies,
            LocalDateTime createdAt
    ) {
    }

    public record CreateCommentRequest(
            @NotBlank(message = "评论内容不能为空")
            @Size(max = 5000, message = "评论最长 5000 字")
            String content,

            /** 回复某条评论时传入，顶层评论留空 */
            Long parentId
    ) {
    }

    public record UpdateCommentRequest(
            @NotBlank(message = "评论内容不能为空")
            @Size(max = 5000, message = "评论最长 5000 字")
            String content
    ) {
    }

    // ---------- 点赞 ----------

    public record LikeResult(boolean liked, long likeCount) {
    }

    // ---------- 统计 ----------

    public record OverviewStats(
            long userCount,
            long postCount,
            long commentCount,
            long boardCount
    ) {
    }
}
