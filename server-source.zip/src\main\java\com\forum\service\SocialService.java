package com.forum.service;

import com.forum.dto.PageResponse;
import com.forum.dto.auth.UserDtos;
import com.forum.entity.Blacklist;
import com.forum.entity.Follow;
import com.forum.entity.Message;
import com.forum.entity.User;
import com.forum.exception.BusinessException;
import com.forum.repository.BlacklistRepository;
import com.forum.repository.FollowRepository;
import com.forum.repository.MessageRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * 社交关系：关注 / 粉丝 / 拉黑，以及私信发送门槛。
 * 门槛规则：
 *  - 互相关注：可无限制发私信
 *  - 单向关注（我关注对方 或 对方关注我）：每天 1 条
 *  - 无任何关注关系：不能发送（需先关注）
 *  - 被对方拉黑：不能发送、不能查看其主页与帖子
 */
@Service
public class SocialService {

    private final FollowRepository followRepository;
    private final BlacklistRepository blacklistRepository;
    private final MessageRepository messageRepository;
    private final UserService userService;

    public SocialService(FollowRepository followRepository,
                         BlacklistRepository blacklistRepository,
                         MessageRepository messageRepository,
                         UserService userService) {
        this.followRepository = followRepository;
        this.blacklistRepository = blacklistRepository;
        this.messageRepository = messageRepository;
        this.userService = userService;
    }

    // ---------- 关注 ----------

    @Transactional
    public boolean toggleFollow(Long userId, Long targetId) {
        if (userId.equals(targetId)) throw new BusinessException("不能关注自己");
        userService.requireUser(targetId);
        if (followRepository.existsByUserIdAndFollowingId(userId, targetId)) {
            followRepository.deleteByUserIdAndFollowingId(userId, targetId);
            return false;
        }
        Follow f = new Follow();
        f.setUserId(userId);
        f.setFollowingId(targetId);
        followRepository.save(f);
        return true;
    }

    @Transactional(readOnly = true)
    public boolean isFollowing(Long userId, Long targetId) {
        return userId != null && followRepository.existsByUserIdAndFollowingId(userId, targetId);
    }

    @Transactional(readOnly = true)
    public boolean isMutual(Long userId, Long targetId) {
        return followRepository.existsByUserIdAndFollowingId(userId, targetId)
                && followRepository.existsByUserIdAndFollowingId(targetId, userId);
    }

    @Transactional(readOnly = true)
    public long followingCount(Long userId) {
        return followRepository.countByUserId(userId);
    }

    @Transactional(readOnly = true)
    public long followerCount(Long userId) {
        return followRepository.countByFollowingId(userId);
    }

    @Transactional(readOnly = true)
    public PageResponse<UserDtos.AuthorSummary> following(Long userId, int page, int size) {
        Pageable pageable = PageRequest.of(page, Math.max(1, Math.min(size, 50)));
        Page<Follow> rows = followRepository.findByUserIdOrderByCreatedAtDesc(userId, pageable);
        return mapFollows(rows, page, true);
    }

    @Transactional(readOnly = true)
    public PageResponse<UserDtos.AuthorSummary> followers(Long userId, int page, int size) {
        Pageable pageable = PageRequest.of(page, Math.max(1, Math.min(size, 50)));
        Page<Follow> rows = followRepository.findByFollowingIdOrderByCreatedAtDesc(userId, pageable);
        return mapFollows(rows, page, false);
    }

    @Transactional(readOnly = true)
    public Set<Long> followingIds(Long userId) {
        return followRepository.findByUserId(userId).stream().map(Follow::getFollowingId).collect(Collectors.toSet());
    }

    private PageResponse<UserDtos.AuthorSummary> mapFollows(Page<Follow> rows, int page, boolean followingList) {
        List<UserDtos.AuthorSummary> items = rows.getContent().stream()
                .map(f -> userService.requireUser(followingList ? f.getFollowingId() : f.getUserId()))
                .map(UserDtos.AuthorSummary::from)
                .toList();
        return PageResponse.of(items, page, rows.getSize(), rows.getTotalElements());
    }

    // ---------- 拉黑 ----------

    @Transactional
    public boolean toggleBlock(Long userId, Long targetId) {
        if (userId.equals(targetId)) throw new BusinessException("不能拉黑自己");
        userService.requireUser(targetId);
        if (blacklistRepository.existsByUserIdAndBlockedId(userId, targetId)) {
            blacklistRepository.deleteByUserIdAndBlockedId(userId, targetId);
            return false;
        }
        Blacklist b = new Blacklist();
        b.setUserId(userId);
        b.setBlockedId(targetId);
        blacklistRepository.save(b);
        return true;
    }

    @Transactional(readOnly = true)
    public boolean isBlocked(Long userId, Long targetId) {
        // targetId 是否被 userId 拉黑
        return userId != null && blacklistRepository.existsByUserIdAndBlockedId(userId, targetId);
    }

    /** 我是否被 targetId 拉黑（被拉黑后限制访问） */
    @Transactional(readOnly = true)
    public boolean iAmBlockedBy(Long userId, Long targetId) {
        return userId != null && blacklistRepository.existsByUserIdAndBlockedId(targetId, userId);
    }

    @Transactional(readOnly = true)
    public long blockedCount(Long userId) {
        return blacklistRepository.countByUserId(userId);
    }

    @Transactional(readOnly = true)
    public PageResponse<UserDtos.AuthorSummary> blockedList(Long userId, int page, int size) {
        Pageable pageable = PageRequest.of(page, Math.max(1, Math.min(size, 50)));
        Page<Blacklist> rows = blacklistRepository.findByUserIdOrderByCreatedAtDesc(userId, pageable);
        List<UserDtos.AuthorSummary> items = rows.getContent().stream()
                .map(b -> userService.requireUser(b.getBlockedId()))
                .map(UserDtos.AuthorSummary::from)
                .toList();
        return PageResponse.of(items, page, rows.getSize(), rows.getTotalElements());
    }

    /** 当前用户被哪些人拉黑（用于过滤这些人的帖子/主页） */
    @Transactional(readOnly = true)
    public Set<Long> whoBlockedMe(Long userId) {
        if (userId == null) return Set.of();
        return blacklistRepository.findByBlockedId(userId).stream().map(Blacklist::getUserId).collect(Collectors.toSet());
    }

    // ---------- 私信门槛 ----------

    public enum MsgGate { ALLOWED, ONE_PER_DAY, NO_RELATION, BLOCKED }

    @Transactional(readOnly = true)
    public MsgGate messageGate(Long senderId, Long recipientId) {
        if (blacklistRepository.existsByUserIdAndBlockedId(recipientId, senderId)) {
            return MsgGate.BLOCKED;
        }
        boolean iFollow = followRepository.existsByUserIdAndFollowingId(senderId, recipientId);
        boolean theyFollow = followRepository.existsByUserIdAndFollowingId(recipientId, senderId);
        if (iFollow && theyFollow) return MsgGate.ALLOWED;
        if (iFollow || theyFollow) return MsgGate.ONE_PER_DAY;
        return MsgGate.NO_RELATION;
    }

    /** 今天 sender→recipient 已发消息数 */
    @Transactional(readOnly = true)
    public long todayMessageCount(Long senderId, Long recipientId) {
        LocalDateTime from = LocalDate.now().atStartOfDay();
        String key = Message.buildConversationKey(senderId, recipientId);
        return messageRepository.countByConversationKeyAndSenderIdAndCreatedAtAfter(key, senderId, from);
    }
}
