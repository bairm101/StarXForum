package com.forum.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Index;
import jakarta.persistence.Table;

/**
 * 投票选项。
 */
@Entity
@Table(name = "poll_options", indexes = {
        @Index(name = "idx_pollopt_poll", columnList = "poll_id")
})
public class PollOption extends BaseEntity {

    @Column(name = "poll_id", nullable = false)
    private Long pollId;

    @Column(nullable = false, length = 200)
    private String optionText;

    @Column(name = "vote_count", nullable = false)
    private Integer voteCount = 0;

    public Long getPollId() { return pollId; }
    public void setPollId(Long v) { this.pollId = v; }
    public String getOptionText() { return optionText; }
    public void setOptionText(String v) { this.optionText = v; }
    public Integer getVoteCount() { return voteCount; }
    public void setVoteCount(Integer v) { this.voteCount = v; }
}
