package com.forum.entity;

import jakarta.persistence.*;

/** 用户对帖子或评论的举报记录。 */
@Entity
@Table(name = "reports",
        uniqueConstraints = @UniqueConstraint(name = "uk_reports_user_target",
                columnNames = {"reporter_id", "target_type", "target_id"}),
        indexes = {@Index(name = "idx_reports_status", columnList = "status,created_at")})
public class Report extends BaseEntity {
    public enum TargetType { POST, COMMENT, USER }
    public enum Status { PENDING, RESOLVED, REJECTED }

    @Column(name = "reporter_id", nullable = false)
    private Long reporterId;
    @Enumerated(EnumType.STRING)
    @Column(name = "target_type", nullable = false, length = 16)
    private TargetType targetType;
    @Column(name = "target_id", nullable = false)
    private Long targetId;
    @Column(nullable = false, length = 500)
    private String reason;
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 16)
    private Status status = Status.PENDING;
    @Column(name = "handled_by")
    private Long handledBy;
    @Column(name = "handle_note", length = 500)
    private String handleNote;
    /** 举报证据：JSON 数组/对象字符串（如聊天记录 ID、截图地址），可为空 */
    @Column(name = "evidence_json", columnDefinition = "TEXT")
    private String evidenceJson;

    public Long getReporterId() { return reporterId; }
    public void setReporterId(Long reporterId) { this.reporterId = reporterId; }
    public TargetType getTargetType() { return targetType; }
    public void setTargetType(TargetType targetType) { this.targetType = targetType; }
    public Long getTargetId() { return targetId; }
    public void setTargetId(Long targetId) { this.targetId = targetId; }
    public String getReason() { return reason; }
    public void setReason(String reason) { this.reason = reason; }
    public Status getStatus() { return status; }
    public void setStatus(Status status) { this.status = status; }
    public Long getHandledBy() { return handledBy; }
    public void setHandledBy(Long handledBy) { this.handledBy = handledBy; }
    public String getHandleNote() { return handleNote; }
    public void setHandleNote(String handleNote) { this.handleNote = handleNote; }
    public String getEvidenceJson() { return evidenceJson; }
    public void setEvidenceJson(String evidenceJson) { this.evidenceJson = evidenceJson; }
}
