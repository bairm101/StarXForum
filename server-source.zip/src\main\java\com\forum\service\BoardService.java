package com.forum.service;

import com.forum.dto.ForumDtos;
import com.forum.entity.Board;
import com.forum.exception.BusinessException;
import com.forum.repository.BoardRepository;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class BoardService {

    private final BoardRepository boardRepository;

    public BoardService(BoardRepository boardRepository) {
        this.boardRepository = boardRepository;
    }

    @Transactional(readOnly = true)
    @Cacheable(value = "boards", key = "'visible'")
    public List<ForumDtos.BoardView> listVisible() {
        return boardRepository.findAllByVisibleTrueOrderBySortOrderAscIdAsc()
                .stream().map(ForumDtos.BoardView::from).toList();
    }

    @Transactional(readOnly = true)
    public List<ForumDtos.BoardView> listAll() {
        return boardRepository.findAllByOrderBySortOrderAscIdAsc()
                .stream().map(ForumDtos.BoardView::from).toList();
    }

    @Transactional(readOnly = true)
    public Board requireBoard(Long id) {
        return boardRepository.findById(id)
                .orElseThrow(() -> BusinessException.notFound("板块不存在"));
    }

    @Transactional(readOnly = true)
    public ForumDtos.BoardView get(Long id) {
        return ForumDtos.BoardView.from(requireBoard(id));
    }

    @Transactional
    @CacheEvict(value = "boards", allEntries = true)
    public ForumDtos.BoardView create(ForumDtos.BoardRequest req) {
        String name = req.name().trim();
        if (boardRepository.existsByName(name)) {
            throw BusinessException.conflict("板块名称已存在");
        }
        Board board = new Board();
        board.setName(name);
        board.setDescription(trimOrNull(req.description()));
        board.setSortOrder(req.sortOrder() == null ? 0 : req.sortOrder());
        board.setVisible(req.visible() == null || req.visible());
        board.setRequireModeration(Boolean.TRUE.equals(req.requireModeration()));
        return ForumDtos.BoardView.from(boardRepository.save(board));
    }

    @Transactional
    @CacheEvict(value = "boards", allEntries = true)
    public ForumDtos.BoardView update(Long id, ForumDtos.BoardRequest req) {
        Board board = requireBoard(id);
        String name = req.name().trim();

        boardRepository.findByName(name).ifPresent(existing -> {
            if (!existing.getId().equals(id)) {
                throw BusinessException.conflict("板块名称已存在");
            }
        });

        board.setName(name);
        board.setDescription(trimOrNull(req.description()));
        if (req.sortOrder() != null) {
            board.setSortOrder(req.sortOrder());
        }
        if (req.visible() != null) {
            board.setVisible(req.visible());
        }
        if (req.requireModeration() != null) {
            board.setRequireModeration(req.requireModeration());
        }
        return ForumDtos.BoardView.from(boardRepository.save(board));
    }

    @Transactional
    @CacheEvict(value = "boards", allEntries = true)
    public void delete(Long id) {
        Board board = requireBoard(id);
        if (board.getPostCount() != null && board.getPostCount() > 0) {
            throw new BusinessException("板块下仍有帖子，请先转移或删除帖子后再删除板块");
        }
        boardRepository.delete(board);
    }

    @Transactional
    @CacheEvict(value = "boards", allEntries = true)
    public void adjustPostCount(Long boardId, int delta) {
        boardRepository.addPostCount(boardId, delta);
    }

    @Transactional
    @CacheEvict(value = "boards", allEntries = true)
    public void ensureDefaults() {
        if (boardRepository.count() > 0) {
            return;
        }
        createDefault("综合讨论", "什么都可以聊", 1);
        createDefault("技术交流", "编程、运维与技术问题", 2);
        createDefault("公告反馈", "站点公告与建议反馈", 3);
    }

    private void createDefault(String name, String desc, int order) {
        Board b = new Board();
        b.setName(name);
        b.setDescription(desc);
        b.setSortOrder(order);
        b.setVisible(true);
        boardRepository.save(b);
    }

    private String trimOrNull(String s) {
        if (s == null) {
            return null;
        }
        String t = s.trim();
        return t.isEmpty() ? null : t;
    }
}
