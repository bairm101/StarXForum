package com.forum.security;

import com.forum.entity.User;
import com.forum.repository.UserRepository;
import com.forum.repository.UserSessionRepository;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.lang.NonNull;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.Optional;

@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    private static final String HEADER = "Authorization";
    private static final String PREFIX = "Bearer ";

    private final JwtService jwtService;
    private final UserRepository userRepository;
    private final UserSessionRepository sessionRepository;

    public JwtAuthenticationFilter(JwtService jwtService,
                                   UserRepository userRepository,
                                   UserSessionRepository sessionRepository) {
        this.jwtService = jwtService;
        this.userRepository = userRepository;
        this.sessionRepository = sessionRepository;
    }

    @Override
    protected void doFilterInternal(@NonNull HttpServletRequest request,
                                    @NonNull HttpServletResponse response,
                                    @NonNull FilterChain filterChain)
            throws ServletException, IOException {

        String token = extractToken(request);
        if (token != null && SecurityContextHolder.getContext().getAuthentication() == null) {
            JwtService.ParsedToken parsed = jwtService.parse(token);
            if (parsed != null) {
                // 会话吊销校验：删除设备后对应 sid 立即失效
                if (parsed.sid() != null) {
                    var sessionOpt = sessionRepository.findBySid(parsed.sid());
                    if (sessionOpt.isEmpty() || Boolean.TRUE.equals(sessionOpt.get().getRevoked())) {
                        filterChain.doFilter(request, response);
                        return;
                    }
                    var session = sessionOpt.get();
                    session.setLastSeenAt(LocalDateTime.now());
                    try {
                        sessionRepository.save(session);
                    } catch (Exception ignored) {
                        // 最后活跃时间更新失败不影响认证
                    }
                }

                // 每次请求校验用户当前状态，确保封禁能立即生效
                Optional<User> maybeUser = userRepository.findById(parsed.userId());
                if (maybeUser.isPresent() && maybeUser.get().getStatus() == User.UserStatus.ACTIVE) {
                    ForumUserPrincipal principal = ForumUserPrincipal.from(maybeUser.get());
                    UsernamePasswordAuthenticationToken auth =
                            new UsernamePasswordAuthenticationToken(
                                    principal, null, principal.getAuthorities());
                    auth.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
                    SecurityContextHolder.getContext().setAuthentication(auth);
                }
            }
        }

        filterChain.doFilter(request, response);
    }

    private String extractToken(HttpServletRequest request) {
        String header = request.getHeader(HEADER);
        if (header != null && header.startsWith(PREFIX)) {
            String value = header.substring(PREFIX.length()).trim();
            return value.isEmpty() ? null : value;
        }
        return null;
    }
}
