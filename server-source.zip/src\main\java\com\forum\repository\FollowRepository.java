package com.forum.repository;

import com.forum.entity.Follow;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface FollowRepository extends JpaRepository<Follow, Long> {
    Optional<Follow> findByUserIdAndFollowingId(Long userId, Long followingId);
    boolean existsByUserIdAndFollowingId(Long userId, Long followingId);
    void deleteByUserIdAndFollowingId(Long userId, Long followingId);
    long countByUserId(Long userId);
    long countByFollowingId(Long userId);
    Page<Follow> findByUserIdOrderByCreatedAtDesc(Long userId, Pageable pageable);
    Page<Follow> findByFollowingIdOrderByCreatedAtDesc(Long userId, Pageable pageable);
    List<Follow> findByUserId(Long userId);
    List<Follow> findByFollowingId(Long userId);
}
