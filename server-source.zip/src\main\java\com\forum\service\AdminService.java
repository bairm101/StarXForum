package com.forum.service;

import com.forum.dto.ForumDtos;
import com.forum.dto.AdminDtos;
import com.forum.dto.PageResponse;
import com.forum.dto.auth.UserDtos;
import com.forum.entity.Post;
import com.forum.entity.SiteSettings;
import com.forum.entity.User;
import com.forum.exception.BusinessException;
import com.forum.repository.BoardRepository;
import com.forum.repository.CommentRepository;
import com.forum.repository.PostRepository;
import com.forum.repository.SiteSettingsRepository;
import com.forum.repository.UserRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 管理后台服务。权限分层：
 *  - 站长(OWNER)：最高权限，可任命超管/管理员、改站点设置
 *  - 超级管理员(SUPER_ADMIN)：全部板块 + 可任命管理员
 *  - 管理员(ADMIN)：仅所辖板块
 */
@Service
public class AdminService {

    private final UserRepository userRepository;
    private final BoardRepository boardRepository;
    private final PostRepository postRepository;
    private final CommentRepository commentRepository;
    private final SiteSettingsRepository siteSettingsRepository;
    private final PasswordEncoder passwordEncoder;
    private final CheckinService checkinService;
    private final org.springframework.jdbc.core.JdbcTemplate jdbcTemplate;
    private final FileStorageService fileStorageService;

    public AdminService(UserRepository userRepository,
                        BoardRepository boardRepository,
                        PostRepository postRepository,
                        CommentRepository commentRepository,
                        SiteSettingsRepository siteSettingsRepository,
                        PasswordEncoder passwordEncoder,
                        CheckinService checkinService,
                        org.springframework.jdbc.core.JdbcTemplate jdbcTemplate,
                        FileStorageService fileStorageService) {
        this.userRepository = userRepository;
        this.boardRepository = boardRepository;
        this.postRepository = postRepository;
        this.commentRepository = commentRepository;
        this.siteSettingsRepository = siteSettingsRepository;
        this.passwordEncoder = passwordEncoder;
        this.checkinService = checkinService;
        this.jdbcTemplate = jdbcTemplate;
        this.fileStorageService = fileStorageService;
    }

    private User requireOperator(Long operatorId) {
        User op = userRepository.findById(operatorId)
                .orElseThrow(() -> BusinessException.notFound("操作者不存在"));
        if (!op.isStaff()) {
            throw BusinessException.forbidden("需要管理员权限");
        }
        return op;
    }

    /** 供控制器校验访问者具备管理权限 */
    public void ensureStaff(Long operatorId) {
        requireOperator(operatorId);
    }

    /** 仅站长/超管可执行（敏感词管理等全局配置） */
    public void ensureOwnerOrSuperAdmin(Long operatorId) {
        User op = requireOperator(operatorId);
        if (!op.isOwner() && !op.isSuperAdmin()) {
            throw BusinessException.forbidden("仅站长/超级管理员可操作");
        }
    }

    // ---------- 用户管理 ----------

    @Transactional(readOnly = true)
    public PageResponse<UserDtos.UserProfile> listUsers(int page, int size, String keyword) {
        Pageable pageable = PageRequest.of(page, UserService.normalizeSize(size),
                Sort.by(Sort.Direction.DESC, "createdAt"));
        Page<User> result;
        if (keyword != null && !keyword.isBlank()) {
            result = userRepository.searchByKeyword(keyword.trim(), pageable);
        } else {
            result = userRepository.findAll(pageable);
        }
        return PageResponse.of(result.getContent().stream().map(UserDtos.UserProfile::from).toList(),
                page, UserService.normalizeSize(size), result.getTotalElements());
    }

    /** 管理员后台创建用户（角色不可高于操作者，且不允许创建站长） */
    @Transactional
    public UserDtos.UserProfile createUser(Long operatorId, AdminDtos.CreateUserRequest r) {
        User op = requireOperator(operatorId);
        String username = r.username() == null ? "" : r.username().trim();
        if (username.length() < 3 || username.length() > 32) {
            throw new BusinessException("用户名长度需在 3-32 之间");
        }
        if (r.password() == null || r.password().length() < 8) {
            throw new BusinessException("密码至少 8 位");
        }
        if (userRepository.existsByUsername(username)) {
            throw BusinessException.conflict("用户名已被占用");
        }
        String email = (r.email() == null || r.email().isBlank()) ? null : r.email().trim();
        if (email != null && userRepository.existsByEmail(email)) {
            throw BusinessException.conflict("邮箱已被注册");
        }
        User.Role role = User.Role.USER;
        if (r.role() != null && !r.role().isBlank()) {
            try {
                role = User.Role.valueOf(r.role().trim().toUpperCase());
            } catch (IllegalArgumentException e) {
                throw new BusinessException("非法角色");
            }
        }
        if (role == User.Role.OWNER) {
            throw BusinessException.forbidden("不能创建站长账号");
        }
        if (rankOf(role) >= rankOf(op.getRole())) {
            throw BusinessException.forbidden("不能创建同级或更高级别的账号");
        }
        User u = new User();
        u.setUsername(username);
        u.setUid(generateUid());
        u.setPasswordHash(passwordEncoder.encode(r.password()));
        u.setEmail(email);
        u.setEmailVerified(email != null);
        u.setNickname((r.nickname() == null || r.nickname().isBlank()) ? null : r.nickname().trim());
        u.setRole(role);
        u.setStatus(User.UserStatus.ACTIVE);
        return UserDtos.UserProfile.from(userRepository.save(u));
    }

    /** 生成唯一 UID（U + 9 位，不含易混淆字符） */
    private String generateUid() {
        final String alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
        java.util.Random rnd = new java.util.Random();
        for (int attempt = 0; attempt < 50; attempt++) {
            StringBuilder sb = new StringBuilder("U");
            for (int i = 0; i < 9; i++) sb.append(alphabet.charAt(rnd.nextInt(alphabet.length())));
            String uid = sb.toString();
            if (!userRepository.existsByUid(uid)) return uid;
        }
        return "U" + System.currentTimeMillis();
    }

    /** 后台删除用户（级联清理），仅可删除低于自己等级的账号 */
    @Transactional
    public void deleteUser(Long operatorId, Long userId) {
        User op = requireOperator(operatorId);
        if (userId.equals(operatorId)) {
            throw new BusinessException("不能删除自己的账号");
        }
        User target = userRepository.findById(userId)
                .orElseThrow(() -> BusinessException.notFound("用户不存在"));
        if (rankOf(target.getRole()) >= rankOf(op.getRole())) {
            throw BusinessException.forbidden("不能删除同级或更高级别的账号");
        }
        cancelUserInternal(userId);
    }

    /**
     * 注销/删除账号的统一级联处理：
     *  1. 该用户的所有帖子连同评论/点赞/打赏/投票等全部物理删除
     *  2. 该用户上传的文件（物理文件 + 记录）全部删除
     *  3. 点赞/收藏/关注/黑名单/通知/会话等关联数据清除
     *  4. 用户标记为 CANCELLED：资料匿名化（头像/签名/邮箱清空），
     *     其历史评论保留但显示为「账号已注销」，私信保留供对方查看
     */
    @Transactional
    public void cancelUserInternal(Long userId) {
        User u = userRepository.findById(userId)
                .orElseThrow(() -> BusinessException.notFound("用户不存在"));

        List<Long> postIds = jdbcTemplate.queryForList(
                "SELECT id FROM posts WHERE author_id = ?", Long.class, userId);
        if (!postIds.isEmpty()) {
            String in = postIds.stream().map(String::valueOf).reduce((a, b) -> a + "," + b).orElse("");
            List<Long> commentIds = jdbcTemplate.queryForList(
                    "SELECT id FROM comments WHERE post_id IN (" + in + ")", Long.class);
            if (!commentIds.isEmpty()) {
                String cin = commentIds.stream().map(String::valueOf).reduce((a, b) -> a + "," + b).orElse("");
                jdbcTemplate.update("DELETE FROM likes WHERE target_type='COMMENT' AND target_id IN (" + cin + ")");
                jdbcTemplate.update("DELETE FROM dislikes WHERE target_type='COMMENT' AND target_id IN (" + cin + ")");
            }
            jdbcTemplate.update("DELETE FROM likes WHERE target_type='POST' AND target_id IN (" + in + ")");
            jdbcTemplate.update("DELETE FROM dislikes WHERE target_type='POST' AND target_id IN (" + in + ")");
            jdbcTemplate.update("DELETE FROM favorites WHERE post_id IN (" + in + ")");
            jdbcTemplate.update("DELETE FROM tips WHERE post_id IN (" + in + ")");
            jdbcTemplate.update("DELETE FROM poll_votes WHERE poll_id IN (SELECT id FROM polls WHERE post_id IN (" + in + "))");
            jdbcTemplate.update("DELETE FROM poll_options WHERE poll_id IN (SELECT id FROM polls WHERE post_id IN (" + in + "))");
            jdbcTemplate.update("DELETE FROM polls WHERE post_id IN (" + in + ")");
            jdbcTemplate.update("DELETE FROM post_revisions WHERE post_id IN (" + in + ")");
            jdbcTemplate.update("DELETE FROM post_unlocks WHERE post_id IN (" + in + ")");
            jdbcTemplate.update("UPDATE comments SET parent_id = NULL WHERE post_id IN (" + in + ")");
            jdbcTemplate.update("DELETE FROM comments WHERE post_id IN (" + in + ")");
            jdbcTemplate.update("DELETE FROM posts WHERE id IN (" + in + ")");
        }

        // 用户自身的互动数据
        jdbcTemplate.update("DELETE FROM likes WHERE user_id = ?", userId);
        jdbcTemplate.update("DELETE FROM dislikes WHERE user_id = ?", userId);
        jdbcTemplate.update("DELETE FROM favorites WHERE user_id = ?", userId);
        jdbcTemplate.update("DELETE FROM tips WHERE user_id = ?", userId);
        jdbcTemplate.update("DELETE FROM poll_votes WHERE user_id = ?", userId);
        jdbcTemplate.update("DELETE FROM post_unlocks WHERE user_id = ?", userId);
        jdbcTemplate.update("DELETE FROM follows WHERE user_id = ? OR following_id = ?", userId, userId);
        jdbcTemplate.update("DELETE FROM blacklists WHERE user_id = ? OR blocked_id = ?", userId, userId);
        jdbcTemplate.update("DELETE FROM notifications WHERE user_id = ?", userId);
        jdbcTemplate.update("DELETE FROM notification_settings WHERE user_id = ?", userId);
        jdbcTemplate.update("DELETE FROM user_sessions WHERE user_id = ?", userId);

        // 上传文件：物理文件 + 数据库记录
        try {
            fileStorageService.deleteAllByUser(userId);
        } catch (Exception e) {
            // 文件清理失败不阻断注销流程
        }

        // 匿名化并标记注销
        u.setStatus(User.UserStatus.CANCELLED);
        u.setEmail(null);
        u.setEmailVerified(false);
        u.setAvatarUrl(null);
        u.setSignature(null);
        u.setPendingSignature(null);
        u.setTitle(null);
        u.setPostCount(0);
        u.setCommentCount(commentRepository == null ? 0 : u.getCommentCount());
        userRepository.save(u);
    }

    @Transactional
    public void banUser(Long operatorId, Long userId, boolean banned) {
        User op = requireOperator(operatorId);
        User user = userRepository.findById(userId)
                .orElseThrow(() -> BusinessException.notFound("用户不存在"));

        if (rankOf(user.getRole()) >= rankOf(op.getRole())) {
            throw BusinessException.forbidden("不能封禁同级或更高级别的管理者");
        }
        user.setStatus(banned ? User.UserStatus.BANNED : User.UserStatus.ACTIVE);
        userRepository.save(user);
    }

    /**
     * 任命角色。
     *  - 站长可任命 超管/管理员/普通用户
     *  - 超管可任命 管理员/普通用户
     *  - 任命管理员时必须指定所辖板块
     */
    @Transactional
    public UserDtos.UserProfile setRole(Long operatorId, Long userId, String role, Long managedBoardId) {
        User op = requireOperator(operatorId);
        User user = userRepository.findById(userId)
                .orElseThrow(() -> BusinessException.notFound("用户不存在"));

        User.Role target;
        try {
            target = User.Role.valueOf(role.toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new BusinessException("非法角色");
        }
        if (target == User.Role.OWNER) {
            throw BusinessException.forbidden("不能任命站长");
        }
        if (!op.canAssignRole(target)) {
            throw BusinessException.forbidden("无权任命该角色");
        }
        if (user.getId().equals(op.getId()) && target != op.getRole()) {
            throw BusinessException.conflict("不能修改自己的角色");
        }
        // 降级高权限者需更高级别操作者
        if (rankOf(user.getRole()) >= rankOf(op.getRole())) {
            throw BusinessException.forbidden("不能修改同级或更高级别的管理者");
        }
        // 任命管理员必须指定板块
        if (target == User.Role.ADMIN) {
            if (managedBoardId == null) {
                throw new BusinessException("任命管理员需指定所辖板块");
            }
            boardRepository.findById(managedBoardId)
                    .orElseThrow(() -> BusinessException.notFound("板块不存在"));
            user.setManagedBoardId(managedBoardId);
        } else {
            user.setManagedBoardId(null);
        }

        user.setRole(target);
        User saved = userRepository.save(user);
        return UserDtos.UserProfile.from(saved);
    }

    /** 设置头衔（站长/超管） */
    @Transactional
    public UserDtos.UserProfile setTitle(Long operatorId, Long userId, String title) {
        User op = requireOperator(operatorId);
        if (!op.isOwner() && !op.isSuperAdmin()) {
            throw BusinessException.forbidden("仅站长或超级管理员可设置头衔");
        }
        User user = userRepository.findById(userId)
                .orElseThrow(() -> BusinessException.notFound("用户不存在"));
        String t = title == null ? null : title.trim();
        if (t != null && t.length() > 32) {
            throw new BusinessException("头衔最长 32 字");
        }
        user.setTitle(t == null || t.isEmpty() ? null : t);
        return UserDtos.UserProfile.from(userRepository.save(user));
    }

    private int rankOf(User.Role role) {
        return switch (role) {
            case OWNER -> 3;
            case SUPER_ADMIN -> 2;
            case ADMIN -> 1;
            default -> 0;
        };
    }

    // ---------- 帖子审核队列 ----------

    /**
     * 待审核帖子队列：管理员只看所辖板块，超管/站长看全部。
     */
    @Transactional(readOnly = true)
    public PageResponse<ForumDtos.PostSummary> pendingPosts(Long operatorId, int page, int size) {
        User op = requireOperator(operatorId);
        Pageable pageable = PageRequest.of(page, UserService.normalizeSize(size),
                Sort.by(Sort.Direction.ASC, "createdAt"));

        Page<Post> result = (op.isOwner() || op.isSuperAdmin())
                ? postRepository.findByStatusAndDeletedFalse(Post.PostStatus.PENDING, pageable)
                : postRepository.findByBoardIdAndStatusAndDeletedFalse(
                        op.getManagedBoardId(), Post.PostStatus.PENDING, pageable);

        List<ForumDtos.PostSummary> items = result.getContent().stream()
                .map(p -> ForumDtos.PostSummary.from(p, false)).toList();
        return PageResponse.of(items, page, UserService.normalizeSize(size), result.getTotalElements());
    }

    @Transactional(readOnly = true)
    public PageResponse<ForumDtos.PostSummary> listPosts(Long operatorId, int page, int size) {
        requireOperator(operatorId);
        Pageable pageable = PageRequest.of(page, UserService.normalizeSize(size),
                Sort.by(Sort.Direction.DESC, "createdAt"));
        Page<Post> result = postRepository.findByDeletedFalse(pageable);
        List<ForumDtos.PostSummary> items = result.getContent().stream()
                .map(p -> ForumDtos.PostSummary.from(p, false)).toList();
        return PageResponse.of(items, page, UserService.normalizeSize(size), result.getTotalElements());
    }

    // ---------- 站点设置 ----------

    @Transactional(readOnly = true)
    public SiteSettings getSettings() {
        return siteSettingsRepository.findById(1L).orElseGet(this::createDefaultSettings);
    }

    @Transactional
    public SiteSettings updateSettings(Long operatorId, ForumDtos.SiteSettingsRequest req) {
        User op = requireOperator(operatorId);
        if (!op.isOwner()) {
            throw BusinessException.forbidden("仅站长可修改站点设置");
        }
        SiteSettings s = getSettings();
        if (req.siteName() != null && !req.siteName().isBlank()) {
            s.setSiteName(req.siteName().trim());
        }
        if (req.siteDescription() != null) {
            s.setSiteDescription(req.siteDescription().trim());
        }
        if (req.announcement() != null) {
            String a = req.announcement().trim();
            s.setAnnouncement(a.isEmpty() ? null : a);
        }
        if (req.allowRegister() != null) {
            s.setAllowRegister(req.allowRegister());
        }
        s.setUpdatedAt(LocalDateTime.now());
        return siteSettingsRepository.save(s);
    }

    @Transactional
    public AdminDtos.SettingsView updateFullSettings(Long operatorId, AdminDtos.SettingsRequest r) {
        User op = requireOperator(operatorId);
        if (!op.isOwner()) throw BusinessException.forbidden("仅站长可修改站点设置");
        SiteSettings s = getSettings();
        if (r.siteName() != null && !r.siteName().isBlank()) s.setSiteName(r.siteName().trim());
        if (r.pageTitle() != null && !r.pageTitle().isBlank()) s.setPageTitle(r.pageTitle().trim());
        if (r.siteDescription() != null) s.setSiteDescription(r.siteDescription().trim());
        if (r.announcement() != null) s.setAnnouncement(blankToNull(r.announcement()));
        if (r.allowRegister() != null) s.setAllowRegister(r.allowRegister());
        if (r.defaultTheme() != null && List.of("SYSTEM", "LIGHT", "DARK").contains(r.defaultTheme())) s.setDefaultTheme(r.defaultTheme());
        if (r.footerText() != null) s.setFooterText(blankToNull(r.footerText()));
        if (r.footerIcp() != null) s.setFooterIcp(blankToNull(r.footerIcp()));
        if (r.footerLinksJson() != null) s.setFooterLinksJson(r.footerLinksJson());
        if (r.signatureAuditMode() != null && List.of("OFF", "FIRST", "ALWAYS").contains(r.signatureAuditMode())) s.setSignatureAuditMode(r.signatureAuditMode());
        if (r.emailVerificationEnabled() != null) s.setEmailVerificationEnabled(r.emailVerificationEnabled());
        if (r.arithmeticEmailEnabled() != null) s.setArithmeticEmailEnabled(r.arithmeticEmailEnabled());
        if (r.arithmeticPostEnabled() != null) s.setArithmeticPostEnabled(r.arithmeticPostEnabled());
        if (r.arithmeticCommentEnabled() != null) s.setArithmeticCommentEnabled(r.arithmeticCommentEnabled());
        if (r.smtpEnabled() != null) s.setSmtpEnabled(r.smtpEnabled());
        if (r.smtpHost() != null) s.setSmtpHost(blankToNull(r.smtpHost()));
        if (r.smtpPort() != null && r.smtpPort() > 0 && r.smtpPort() <= 65535) s.setSmtpPort(r.smtpPort());
        if (r.smtpUsername() != null) s.setSmtpUsername(blankToNull(r.smtpUsername()));
        if (r.smtpPassword() != null && !r.smtpPassword().isBlank()) s.setSmtpPassword(r.smtpPassword());
        if (r.smtpSsl() != null) s.setSmtpSsl(r.smtpSsl());
        if (r.imageCompressEnabled() != null) s.setImageCompressEnabled(r.imageCompressEnabled());
        if (r.videoCompressEnabled() != null) s.setVideoCompressEnabled(r.videoCompressEnabled());
        if (r.postEditAuditEnabled() != null) s.setPostEditAuditEnabled(r.postEditAuditEnabled());
        if (r.deviceVerificationEnabled() != null) s.setDeviceVerificationEnabled(r.deviceVerificationEnabled());
        if (r.imageMaxMb() != null && r.imageMaxMb() >= 1 && r.imageMaxMb() <= 100) s.setImageMaxMb(r.imageMaxMb());
        if (r.videoMaxMb() != null && r.videoMaxMb() >= 1 && r.videoMaxMb() <= 2048) s.setVideoMaxMb(r.videoMaxMb());
        if (r.officialWebsite() != null) s.setOfficialWebsite(blankToNull(r.officialWebsite()));
        if (r.webShareBaseUrl() != null) s.setWebShareBaseUrl(blankToNull(r.webShareBaseUrl()));
        if (r.contactEmail() != null) s.setContactEmail(blankToNull(r.contactEmail()));
        if (r.aboutIcp() != null) s.setAboutIcp(blankToNull(r.aboutIcp()));
        if (r.autoRefreshSeconds() != null && r.autoRefreshSeconds() >= 0 && r.autoRefreshSeconds() <= 3600) s.setAutoRefreshSeconds(r.autoRefreshSeconds());
        s.setUpdatedAt(LocalDateTime.now());
        return AdminDtos.SettingsView.from(siteSettingsRepository.save(s));
    }

    @Transactional(readOnly = true)
    public AdminDtos.SettingsView fullSettings(Long operatorId) {
        requireOperator(operatorId);
        return AdminDtos.SettingsView.from(getSettings());
    }

    @Transactional
    public UserDtos.UserProfile updateUserParameters(Long operatorId, Long userId, AdminDtos.UserParametersRequest r) {
        User op = requireOperator(operatorId);
        if (!op.isOwner()) throw BusinessException.forbidden("仅站长可调整用户参数");
        User u = userRepository.findById(userId).orElseThrow(() -> BusinessException.notFound("用户不存在"));
        if (r.username() != null && !r.username().isBlank() && !r.username().equals(u.getUsername())) {
            if (userRepository.existsByUsername(r.username().trim())) throw BusinessException.conflict("用户名已被占用");
            u.setUsername(r.username().trim());
        }
        if (r.signature() != null) u.setSignature(blankToNull(r.signature()));
        if (r.password() != null && r.password().length() >= 8) u.setPasswordHash(passwordEncoder.encode(r.password()));
        if (r.email() != null) {
            String email = blankToNull(r.email());
            if (email != null) {
                userRepository.findByEmail(email).ifPresent(existing -> {
                    if (!existing.getId().equals(u.getId())) throw BusinessException.conflict("邮箱已被其他用户占用");
                });
                u.setEmail(email);
            } else {
                u.setEmail(null);
            }
        }
        if (r.level() != null) u.setLevel(Math.max(1, Math.min(10, r.level())));
        if (r.exp() != null) u.setExp(Math.max(0, r.exp()));
        if (r.gold() != null) u.setGold(Math.max(0, r.gold()));
        if (r.rankingWeight() != null) u.setRankingWeight(Math.max(0.1, Math.min(10.0, r.rankingWeight())));
        if (r.maxUploadMb() != null) u.setMaxUploadMb(r.maxUploadMb() > 0 ? r.maxUploadMb() : null);
        if (r.level() != null || r.exp() != null) checkinService.normalizeLevel(u);
        return UserDtos.UserProfile.from(userRepository.save(u));
    }

    @Transactional
    public UserDtos.UserProfile moderateSignature(Long operatorId, Long userId, boolean approve) {
        User op = requireOperator(operatorId);
        if (!op.isOwner() && !op.isSuperAdmin() && !op.isAdmin()) {
            throw BusinessException.forbidden("仅管理员、超级管理员或站长可审核签名");
        }
        User u = userRepository.findById(userId).orElseThrow(() -> BusinessException.notFound("用户不存在"));
        if (u.getPendingSignature() == null) throw BusinessException.conflict("没有待审核签名");
        if (approve) { u.setSignature(u.getPendingSignature()); u.setSignatureApprovedOnce(true); }
        u.setPendingSignature(null);
        return UserDtos.UserProfile.from(userRepository.save(u));
    }

    private String blankToNull(String value) {
        String v = value == null ? null : value.trim();
        return v == null || v.isEmpty() ? null : v;
    }

    private SiteSettings createDefaultSettings() {
        SiteSettings s = new SiteSettings();
        return siteSettingsRepository.save(s);
    }

    // ---------- 统计 ----------

    @Transactional(readOnly = true)
    public ForumDtos.OverviewStats overview() {
        return new ForumDtos.OverviewStats(
                userRepository.count(),
                postRepository.countByDeletedFalse(),
                commentRepository.countByDeletedFalse(),
                boardRepository.count()
        );
    }
}
