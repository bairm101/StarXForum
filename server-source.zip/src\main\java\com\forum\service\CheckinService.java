package com.forum.service;

import com.forum.dto.CheckinDtos;
import com.forum.entity.Post;
import com.forum.entity.Tip;
import com.forum.entity.User;
import com.forum.exception.BusinessException;
import com.forum.repository.PostRepository;
import com.forum.repository.TipRepository;
import com.forum.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.concurrent.ThreadLocalRandom;

/**
 * 签到 / 等级 / 打赏业务。
 *
 * 等级公式（lv2 起）：
 *   升到下一级所需经验 = 当前等级 * (a + 当前等级停留天数)
 *   其中 a=100，停留天数上限 30。
 * 签到奖励：
 *   金币 1-10，经验 25-50。
 * 打赏：
 *   每个帖子每个用户最多 3 次。
 */
@Service
public class CheckinService {

    private static final int BASE_EXP = 100;
    private static final int MAX_DAYS_STAYED = 30;
    private static final int MAX_LEVEL = 10;
    private static final int MAX_TIP_PER_POST = 3;

    private final UserRepository userRepository;
    private final PostRepository postRepository;
    private final TipRepository tipRepository;

    public CheckinService(UserRepository userRepository,
                          PostRepository postRepository,
                          TipRepository tipRepository) {
        this.userRepository = userRepository;
        this.postRepository = postRepository;
        this.tipRepository = tipRepository;
    }

    // ---------- 签到 ----------

    @Transactional
    public CheckinDtos.CheckinResult checkin(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> BusinessException.notFound("用户不存在"));

        LocalDate today = LocalDate.now();
        if (today.equals(user.getLastCheckinDate())) {
            throw BusinessException.conflict("今日已签到");
        }

        int expGain = ThreadLocalRandom.current().nextInt(25, 51);
        int goldGain = ThreadLocalRandom.current().nextInt(1, 11);

        // 连续签到：昨天签过则 +1，否则重置为 1
        if (user.getLastCheckinDate() != null
                && user.getLastCheckinDate().equals(today.minusDays(1))) {
            user.setCheckinStreak(user.getCheckinStreak() + 1);
        } else {
            user.setCheckinStreak(1);
        }

        user.setLastCheckinDate(today);
        if (user.getLevelUpAt() == null) {
            user.setLevelUpAt(user.getCreatedAt() != null ? user.getCreatedAt() : LocalDateTime.now());
        }

        user.setGold(user.getGold() + goldGain);
        user.setExp(user.getExp() + expGain);

        int beforeLevel = user.getLevel();
        normalizeLevel(user);
        boolean leveledUp = user.getLevel() > beforeLevel;

        userRepository.save(user);

        return new CheckinDtos.CheckinResult(
                goldGain, expGain, leveledUp, user.getLevel(),
                user.getExp(), user.getGold(), user.getCheckinStreak(),
                nextLevelExp(user)
        );
    }

    /**
     * 消耗经验升级，可能连升多级。
     */
    public void normalizeLevel(User user) {
        while (user.getLevel() < MAX_LEVEL) {
            int need = nextLevelExp(user);
            if (user.getExp() >= need) {
                user.setExp(user.getExp() - need);
                user.setLevel(user.getLevel() + 1);
                user.setLevelUpAt(LocalDateTime.now());
            } else {
                break;
            }
        }
        if (user.getLevel() >= MAX_LEVEL) {
            user.setLevel(MAX_LEVEL);
        }
    }

    /**
     * 升到下一级所需经验 = 当前等级 * (100 + min(停留天数, 30))
     */
    public int nextLevelExp(User user) {
        long days = daysStayedAtLevel(user);
        long capped = Math.min(days, MAX_DAYS_STAYED);
        return (int) (user.getLevel() * (BASE_EXP + capped));
    }

    private long daysStayedAtLevel(User user) {
        LocalDateTime since = user.getLevelUpAt() != null
                ? user.getLevelUpAt()
                : (user.getCreatedAt() != null ? user.getCreatedAt() : LocalDateTime.now());
        long days = ChronoUnit.DAYS.between(since, LocalDateTime.now());
        return Math.max(days, 0);
    }

    // ---------- 状态 ----------

    @Transactional(readOnly = true)
    public CheckinDtos.CheckinStatus status(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> BusinessException.notFound("用户不存在"));
        boolean checkedToday = LocalDate.now().equals(user.getLastCheckinDate());
        return new CheckinDtos.CheckinStatus(
                user.getLevel(), user.getExp(), user.getGold(),
                user.getCheckinStreak(), checkedToday,
                user.getLastCheckinDate(),
                user.getLevel() >= MAX_LEVEL ? 0 : nextLevelExp(user),
                daysStayedAtLevel(user)
        );
    }

    // ---------- 打赏 ----------

    @Transactional
    public CheckinDtos.TipResult tip(Long postId, Long amount, Long userId) {
        if (amount == null || amount <= 0) {
            throw new BusinessException("打赏金额必须大于 0");
        }
        if (amount > 2) {
            throw new BusinessException("单次打赏最多 2 金币");
        }

        User tipper = userRepository.findById(userId)
                .orElseThrow(() -> BusinessException.notFound("用户不存在"));
        Post post = postRepository.findByIdAndDeletedFalse(postId)
                .orElseThrow(() -> BusinessException.notFound("帖子不存在或已删除"));

        if (post.getAuthor().getId().equals(userId)) {
            throw BusinessException.conflict("不能打赏自己的帖子");
        }
        long already = tipRepository.countByUserIdAndPostId(userId, postId);
        if (already >= MAX_TIP_PER_POST) {
            throw BusinessException.conflict("每人每帖最多打赏 " + MAX_TIP_PER_POST + " 次");
        }
        if (tipper.getGold() < amount) {
            throw new BusinessException("金币不足，请先签到获取金币");
        }

        User author = post.getAuthor();
        tipper.setGold(tipper.getGold() - amount);
        author.setGold(author.getGold() + amount);

        post.setTotalTipGold(post.getTotalTipGold() + amount);
        post.setTipCount(post.getTipCount() + 1);

        Tip tip = new Tip();
        tip.setUser(tipper);
        tip.setPost(post);
        tip.setAmount(amount);

        userRepository.save(tipper);
        userRepository.save(author);
        postRepository.save(post);
        tipRepository.save(tip);

        return new CheckinDtos.TipResult(
                amount,
                post.getTotalTipGold(),
                post.getTipCount(),
                tipper.getGold(),
                (int) (already + 1),
                MAX_TIP_PER_POST
        );
    }

    @Transactional(readOnly = true)
    public int myTipCount(Long postId, Long userId) {
        if (userId == null) {
            return 0;
        }
        return (int) tipRepository.countByUserIdAndPostId(userId, postId);
    }
}
