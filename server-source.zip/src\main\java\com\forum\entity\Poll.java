package com.forum.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Index;
import jakarta.persistence.Table;

/**
 * 帖子投票。
 */
@Entity
@Table(name = "polls", indexes = {
        @Index(name = "idx_poll_post", columnList = "post_id", unique = true)
})
public class Poll extends BaseEntity {

    @Column(name = "post_id", nullable = false)
    private Long postId;

    @Column(nullable = false, length = 200)
    private String question;

    /** 单选还是多选 */
    @Column(nullable = false)
    private Boolean multiple = false;

    /** 投票截止时间，null 表示不截止 */
    @Column(name = "deadline")
    private java.time.LocalDateTime deadline;

    public Long getPostId() { return postId; }
    public void setPostId(Long v) { this.postId = v; }
    public String getQuestion() { return question; }
    public void setQuestion(String v) { this.question = v; }
    public Boolean getMultiple() { return multiple; }
    public void setMultiple(Boolean v) { this.multiple = v; }
    public java.time.LocalDateTime getDeadline() { return deadline; }
    public void setDeadline(java.time.LocalDateTime v) { this.deadline = v; }
}
