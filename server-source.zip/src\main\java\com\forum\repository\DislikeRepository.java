package com.forum.repository;

import com.forum.entity.Dislike;
import com.forum.entity.Like;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Collection;
import java.util.List;

public interface DislikeRepository extends JpaRepository<Dislike, Long> {
    boolean existsByUserIdAndTargetTypeAndTargetId(Long userId, Like.TargetType type, Long targetId);
    void deleteByUserIdAndTargetTypeAndTargetId(Long userId, Like.TargetType type, Long targetId);
    List<Dislike> findByUserIdAndTargetTypeAndTargetIdIn(Long userId, Like.TargetType type, Collection<Long> ids);
    long countByTargetTypeAndTargetId(Like.TargetType type, Long targetId);
}
