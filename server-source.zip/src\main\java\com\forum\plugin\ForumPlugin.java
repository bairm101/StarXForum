package com.forum.plugin;

/** 外部 Jar 插件 SPI。插件 jar 在 META-INF/services/com.forum.plugin.ForumPlugin 注册实现类。 */
public interface ForumPlugin {
    String id();
    String name();
    String version();
    void initialize(PluginContext context) throws Exception;
}
