package com.forum.repository;

import com.forum.entity.Like;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

public interface LikeRepository extends JpaRepository<Like, Long> {

    Optional<Like> findByUserIdAndTargetTypeAndTargetId(
            Long userId, Like.TargetType targetType, Long targetId);

    boolean existsByUserIdAndTargetTypeAndTargetId(
            Long userId, Like.TargetType targetType, Long targetId);

    void deleteByUserIdAndTargetTypeAndTargetId(
            Long userId, Like.TargetType targetType, Long targetId);

    long countByTargetTypeAndTargetId(Like.TargetType targetType, Long targetId);

    /** 批量查询当前用户已点赞的目标，用于列表页标记状态 */
    List<Like> findByUserIdAndTargetTypeAndTargetIdIn(
            Long userId, Like.TargetType targetType, Collection<Long> targetIds);

    long countByUserId(Long userId);
}
