package com.forum.service;

import com.forum.dto.MessageDtos;
import com.forum.dto.PageResponse;
import com.forum.dto.auth.UserDtos;
import com.forum.entity.Message;
import com.forum.entity.User;
import com.forum.exception.BusinessException;
import com.forum.repository.MessageRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class MessageService {

    private final MessageRepository messageRepository;
    private final UserService userService;
    private final SocialService socialService;

    public MessageService(MessageRepository messageRepository, UserService userService, SocialService socialService) {
        this.messageRepository = messageRepository;
        this.userService = userService;
        this.socialService = socialService;
    }

    @Transactional
    public MessageDtos.MessageView send(MessageDtos.SendMessageRequest req, Long senderId) {
        if (req.recipientId().equals(senderId)) {
            throw new BusinessException("不能给自己发送私信");
        }
        User recipient = userService.requireUser(req.recipientId());

        // 私信门槛：拉黑 / 关注关系
        SocialService.MsgGate gate = socialService.messageGate(senderId, recipient.getId());
        if (gate == SocialService.MsgGate.BLOCKED) {
            throw new BusinessException("你已被对方拉黑，无法发送私信");
        }
        if (gate == SocialService.MsgGate.NO_RELATION) {
            throw new BusinessException("请先关注对方后再发送私信");
        }
        if (gate == SocialService.MsgGate.ONE_PER_DAY
                && socialService.todayMessageCount(senderId, recipient.getId()) >= 1) {
            throw new BusinessException("单向关注每天只能发送一条消息，可邀请对方回关后畅聊");
        }

        Message msg = new Message();
        msg.setSender(userService.requireUser(senderId));
        msg.setRecipient(recipient);
        msg.setContent(req.content().trim());
        msg.setRead(false);
        msg.setConversationKey(Message.buildConversationKey(senderId, recipient.getId()));

        Message saved = messageRepository.save(msg);
        return MessageDtos.MessageView.from(saved, senderId);
    }

    /**
     * 会话消息列表（倒序，取最新在前）。
     */
    @Transactional
    public PageResponse<MessageDtos.MessageView> conversation(Long peerId, int page, int size, Long userId) {
        userService.requireUser(peerId);
        String key = Message.buildConversationKey(userId, peerId);
        messageRepository.markConversationRead(key, userId);

        Pageable pageable = PageRequest.of(page, UserService.normalizeSize(size),
                Sort.by(Sort.Direction.DESC, "createdAt"));
        Page<Message> messages = messageRepository.findConversation(key, userId, pageable);
        return PageResponse.of(
                messages.getContent().stream().map(m -> MessageDtos.MessageView.from(m, userId)).toList(),
                page, UserService.normalizeSize(size), messages.getTotalElements()
        );
    }

    /**
     * 会话列表：每个会话的最新一条 + 未读数。
     */
    @Transactional(readOnly = true)
    public List<MessageDtos.ConversationView> conversations(Long userId, int limit) {
        int size = Math.max(1, Math.min(limit, 100));
        Pageable pageable = PageRequest.of(0, size);
        Page<Message> summaries = messageRepository.findConversationSummaries(userId, pageable);

        return summaries.getContent().stream().map(last -> {
            User peer = last.getSender().getId().equals(userId) ? last.getRecipient() : last.getSender();
            long unread = last.getRecipient().getId().equals(userId) && !last.getRead() ? 1 : 0;
            return new MessageDtos.ConversationView(
                    last.getConversationKey(),
                    UserDtos.AuthorSummary.from(peer),
                    last.getContent(),
                    last.getSender().getId().equals(userId),
                    last.getRead(),
                    unread,
                    last.getCreatedAt()
            );
        }).toList();
    }

    @Transactional(readOnly = true)
    public long unreadCount(Long userId) {
        return messageRepository.countByRecipientIdAndReadFalseAndDeletedByRecipientFalse(userId);
    }

    @Transactional
    public int markAllRead(Long userId) {
        return messageRepository.markAllRead(userId);
    }

    @Transactional
    public void deleteConversation(Long peerId, Long userId) {
        userService.requireUser(peerId);
        String key = Message.buildConversationKey(userId, peerId);
        messageRepository.softDeleteBySender(key, userId);
        messageRepository.softDeleteByRecipient(key, userId);
    }
}
