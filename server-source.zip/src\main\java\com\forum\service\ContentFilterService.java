package com.forum.service;

import com.forum.entity.Notification;
import com.forum.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 内容处理：敏感词过滤 + @提及通知。
 */
@Service
public class ContentFilterService {

    private static final Pattern MENTION = Pattern.compile("@([\\w\\u4e00-\\u9fa5\\-]{3,32})");
    private static final Pattern MENTION_UID = Pattern.compile("@UID:([A-Za-z0-9]{4,32})");

    private final SensitiveWordService sensitiveWordService;
    private final UserRepository userRepository;
    private final NotificationService notificationService;

    public ContentFilterService(SensitiveWordService sensitiveWordService,
                                UserRepository userRepository,
                                NotificationService notificationService) {
        this.sensitiveWordService = sensitiveWordService;
        this.userRepository = userRepository;
        this.notificationService = notificationService;
    }

    /** 过滤敏感词。 */
    public String filter(String content) {
        return sensitiveWordService.filter(content);
    }

    /** 是否命中敏感词。 */
    public boolean containsSensitive(String content) {
        return sensitiveWordService.containsSensitive(content);
    }

    /** 解析 @提及（含 @UID:xxxx）并发送通知（内容需已过滤）。 */
    public void notifyMentions(String content, Long actorId, String actorName,
                               String title, Long refId) {
        if (content == null) return;
        Set<Long> mentioned = new HashSet<>();
        Matcher mu = MENTION_UID.matcher(content);
        while (mu.find()) {
            userRepository.findByUid(mu.group(1)).ifPresent(u -> mentioned.add(u.getId()));
        }
        Matcher m = MENTION.matcher(content);
        while (m.find()) {
            userRepository.findByUsername(m.group(1)).ifPresent(u -> mentioned.add(u.getId()));
        }
        for (Long uid : mentioned) {
            if (uid.equals(actorId)) continue;
            notificationService.notify(uid, actorId, Notification.Type.MENTION,
                    "有人提到了你",
                    actorName + " 在《" + (title == null ? "内容" : title) + "》中提到了你",
                    refId);
        }
    }

    /** 过滤 + 提及通知（refId 已知的场景）。 */
    public String filterAndNotify(String content, Long actorId, String actorName,
                                  String title, Long refId) {
        String filtered = filter(content);
        if (filtered != null) {
            notifyMentions(filtered, actorId, actorName, title, refId);
        }
        return filtered;
    }
}
