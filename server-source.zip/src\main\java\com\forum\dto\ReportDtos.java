package com.forum.dto;

import com.forum.entity.Report;

import java.time.LocalDateTime;

/**
 * 举报管理视图：在原始举报记录基础上附带被举报目标的摘要与跳转信息，
 * 便于管理员在不跳转的情况下直接看到原文内容。
 */
public class ReportDtos {

    public record ReportView(
            Long id,
            Long reporterId,
            String reporterName,
            Report.TargetType targetType,
            Long targetId,
            String reason,
            Report.Status status,
            Long handledBy,
            String handleNote,
            LocalDateTime createdAt,
            // 被举报目标摘要：帖子→标题+摘要；评论→评论内容；用户→@用户名(昵称)
            String targetSummary,
            // 跳转信息（用于点击跳转）
            Long postId,
            Long commentId,
            Long userId,
            String targetAuthor,
            Boolean targetDeleted
    ) {
    }
}
