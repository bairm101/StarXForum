package com.forum.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.time.LocalDateTime;

/**
 * 站点全局配置。单行记录（id=1），仅站长可修改。
 */
@Entity
@Table(name = "site_settings")
public class SiteSettings {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "site_name", nullable = false, length = 64)
    private String siteName = "论坛";

    @Column(name = "site_description", length = 255)
    private String siteDescription = "交流分享社区";

    /** 是否允许新用户注册（站长可关闭） */
    @Column(name = "allow_register", nullable = false)
    private Boolean allowRegister = true;

    /** 全站公告（可为空） */
    @Column(length = 500)
    private String announcement;

    @Column(name = "page_title", length = 128)
    private String pageTitle = "论坛";

    @Column(name = "default_theme", length = 16)
    private String defaultTheme = "SYSTEM";

    @Column(name = "footer_text", length = 500)
    private String footerText;

    @Column(name = "footer_icp", length = 128)
    private String footerIcp;

    @Column(name = "footer_links_json", columnDefinition = "TEXT")
    private String footerLinksJson = "[]";

    @Column(name = "signature_audit_mode", length = 16)
    private String signatureAuditMode = "OFF";

    @Column(name = "email_verification_enabled", nullable = false)
    private Boolean emailVerificationEnabled = false;

    @Column(name = "arithmetic_email_enabled", nullable = false)
    private Boolean arithmeticEmailEnabled = true;

    @Column(name = "arithmetic_post_enabled", nullable = false)
    private Boolean arithmeticPostEnabled = true;

    @Column(name = "arithmetic_comment_enabled", nullable = false)
    private Boolean arithmeticCommentEnabled = true;

    @Column(name = "smtp_enabled", nullable = false)
    private Boolean smtpEnabled = false;

    @Column(name = "smtp_host", length = 128)
    private String smtpHost = "smtp.qq.com";

    @Column(name = "smtp_port")
    private Integer smtpPort = 465;

    @Column(name = "smtp_username", length = 128)
    private String smtpUsername;

    @Column(name = "smtp_password", length = 255)
    private String smtpPassword;

    @Column(name = "smtp_ssl", nullable = false)
    private Boolean smtpSsl = true;

    @Column(name = "image_compress_enabled", nullable = false)
    private Boolean imageCompressEnabled = false;

    @Column(name = "video_compress_enabled", nullable = false)
    private Boolean videoCompressEnabled = false;

    @Column(name = "post_edit_audit_enabled", nullable = false)
    private Boolean postEditAuditEnabled = false;

    /** 换设备登录二次验证（邮箱验证码）开关，站长可配置 */
    @Column(name = "device_verification_enabled", nullable = false)
    private Boolean deviceVerificationEnabled = false;

    @Column(name = "image_max_mb", nullable = false)
    private Integer imageMaxMb = 5;

    @Column(name = "video_max_mb", nullable = false)
    private Integer videoMaxMb = 15;

    /** {"USER":100,"ADMIN":500,"SUPER_ADMIN":2048,"OWNER":4096}，单位 MB */
    @Column(name = "role_upload_quota_json", columnDefinition = "TEXT")
    private String roleUploadQuotaJson = "{\"USER\":100,\"ADMIN\":500,\"SUPER_ADMIN\":2048,\"OWNER\":4096}";

    /** 关于页：官方网站 */
    @Column(name = "official_website", length = 255)
    private String officialWebsite = "www.starxx.cn";

    /** 分享帖子时生成链接使用的 Web 根地址 */
    @Column(name = "web_share_base_url", length = 255)
    private String webShareBaseUrl = "https://forum.starxx.cn";

    /** 关于页：联系邮箱 */
    @Column(name = "contact_email", length = 128)
    private String contactEmail = "908696225@qq.com";

    /** 关于页：备案号（ICP） */
    @Column(name = "about_icp", length = 128)
    private String aboutIcp;

    /** 客户端自动刷新间隔（秒），0 表示关闭自动刷新 */
    @Column(name = "auto_refresh_seconds", nullable = false)
    private Integer autoRefreshSeconds = 180;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getSiteName() {
        return siteName;
    }

    public void setSiteName(String siteName) {
        this.siteName = siteName;
    }

    public String getSiteDescription() {
        return siteDescription;
    }

    public void setSiteDescription(String siteDescription) {
        this.siteDescription = siteDescription;
    }

    public Boolean getAllowRegister() {
        return allowRegister;
    }

    public void setAllowRegister(Boolean allowRegister) {
        this.allowRegister = allowRegister;
    }

    public String getAnnouncement() {
        return announcement;
    }

    public void setAnnouncement(String announcement) {
        this.announcement = announcement;
    }

    public String getPageTitle() { return pageTitle; }
    public void setPageTitle(String pageTitle) { this.pageTitle = pageTitle; }
    public String getDefaultTheme() { return defaultTheme; }
    public void setDefaultTheme(String defaultTheme) { this.defaultTheme = defaultTheme; }
    public String getFooterText() { return footerText; }
    public void setFooterText(String footerText) { this.footerText = footerText; }
    public String getFooterIcp() { return footerIcp; }
    public void setFooterIcp(String footerIcp) { this.footerIcp = footerIcp; }
    public String getFooterLinksJson() { return footerLinksJson; }
    public void setFooterLinksJson(String footerLinksJson) { this.footerLinksJson = footerLinksJson; }
    public String getSignatureAuditMode() { return signatureAuditMode; }
    public void setSignatureAuditMode(String signatureAuditMode) { this.signatureAuditMode = signatureAuditMode; }
    public Boolean getEmailVerificationEnabled() { return emailVerificationEnabled; }
    public void setEmailVerificationEnabled(Boolean value) { this.emailVerificationEnabled = value; }
    public Boolean getArithmeticEmailEnabled() { return arithmeticEmailEnabled; }
    public void setArithmeticEmailEnabled(Boolean value) { this.arithmeticEmailEnabled = value; }
    public Boolean getArithmeticPostEnabled() { return arithmeticPostEnabled; }
    public void setArithmeticPostEnabled(Boolean value) { this.arithmeticPostEnabled = value; }
    public Boolean getArithmeticCommentEnabled() { return arithmeticCommentEnabled; }
    public void setArithmeticCommentEnabled(Boolean value) { this.arithmeticCommentEnabled = value; }
    public Boolean getSmtpEnabled() { return smtpEnabled; }
    public void setSmtpEnabled(Boolean smtpEnabled) { this.smtpEnabled = smtpEnabled; }
    public String getSmtpHost() { return smtpHost; }
    public void setSmtpHost(String smtpHost) { this.smtpHost = smtpHost; }
    public Integer getSmtpPort() { return smtpPort; }
    public void setSmtpPort(Integer smtpPort) { this.smtpPort = smtpPort; }
    public String getSmtpUsername() { return smtpUsername; }
    public void setSmtpUsername(String smtpUsername) { this.smtpUsername = smtpUsername; }
    public String getSmtpPassword() { return smtpPassword; }
    public void setSmtpPassword(String smtpPassword) { this.smtpPassword = smtpPassword; }
    public Boolean getSmtpSsl() { return smtpSsl; }
    public void setSmtpSsl(Boolean smtpSsl) { this.smtpSsl = smtpSsl; }
    public Boolean getImageCompressEnabled() { return imageCompressEnabled; }
    public void setImageCompressEnabled(Boolean value) { this.imageCompressEnabled = value; }
    public Boolean getVideoCompressEnabled() { return videoCompressEnabled; }
    public void setVideoCompressEnabled(Boolean value) { this.videoCompressEnabled = value; }
    public Boolean getPostEditAuditEnabled() { return postEditAuditEnabled; }
    public void setPostEditAuditEnabled(Boolean value) { this.postEditAuditEnabled = value; }
    public Boolean getDeviceVerificationEnabled() { return deviceVerificationEnabled; }
    public void setDeviceVerificationEnabled(Boolean value) { this.deviceVerificationEnabled = value; }
    public Integer getImageMaxMb() { return imageMaxMb; }
    public void setImageMaxMb(Integer imageMaxMb) { this.imageMaxMb = imageMaxMb; }
    public Integer getVideoMaxMb() { return videoMaxMb; }
    public void setVideoMaxMb(Integer videoMaxMb) { this.videoMaxMb = videoMaxMb; }
    public String getRoleUploadQuotaJson() { return roleUploadQuotaJson; }
    public void setRoleUploadQuotaJson(String value) { this.roleUploadQuotaJson = value; }
    public String getOfficialWebsite() { return officialWebsite; }
    public void setOfficialWebsite(String value) { this.officialWebsite = value; }
    public String getWebShareBaseUrl() { return webShareBaseUrl; }
    public void setWebShareBaseUrl(String value) { this.webShareBaseUrl = value; }
    public String getContactEmail() { return contactEmail; }
    public void setContactEmail(String value) { this.contactEmail = value; }
    public String getAboutIcp() { return aboutIcp; }
    public void setAboutIcp(String value) { this.aboutIcp = value; }
    public Integer getAutoRefreshSeconds() { return autoRefreshSeconds; }
    public void setAutoRefreshSeconds(Integer value) { this.autoRefreshSeconds = value; }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }
}
