package com.forum.controller;

import com.forum.dto.ApiResponse;
import com.forum.dto.PageResponse;
import com.forum.dto.auth.UserDtos;
import com.forum.security.ForumUserPrincipal;
import com.forum.service.SocialService;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/users")
public class SocialController {

    private final SocialService socialService;

    public SocialController(SocialService socialService) {
        this.socialService = socialService;
    }

    @PostMapping("/{id}/follow")
    public ApiResponse<Boolean> follow(@PathVariable Long id, @AuthenticationPrincipal ForumUserPrincipal p) {
        boolean now = socialService.toggleFollow(p.getId(), id);
        return ApiResponse.ok(now, now ? "已关注" : "已取消关注");
    }

    @PostMapping("/{id}/unfollow")
    public ApiResponse<Boolean> unfollow(@PathVariable Long id, @AuthenticationPrincipal ForumUserPrincipal p) {
        if (socialService.isFollowing(p.getId(), id)) {
            socialService.toggleFollow(p.getId(), id);
        }
        return ApiResponse.ok(false, "已取消关注");
    }

    @GetMapping("/{id}/following")
    public ApiResponse<PageResponse<UserDtos.AuthorSummary>> following(@PathVariable Long id,
            @RequestParam(defaultValue = "0") int page, @RequestParam(defaultValue = "20") int size) {
        return ApiResponse.ok(socialService.following(id, page, size));
    }

    @GetMapping("/{id}/followers")
    public ApiResponse<PageResponse<UserDtos.AuthorSummary>> followers(@PathVariable Long id,
            @RequestParam(defaultValue = "0") int page, @RequestParam(defaultValue = "20") int size) {
        return ApiResponse.ok(socialService.followers(id, page, size));
    }

    @GetMapping("/{id}/follow-status")
    public ApiResponse<Map<String, Object>> followStatus(@PathVariable Long id,
            @AuthenticationPrincipal ForumUserPrincipal p) {
        Long me = p == null ? null : p.getId();
        Map<String, Object> m = new java.util.HashMap<>();
        m.put("isFollowing", me != null && socialService.isFollowing(me, id));
        m.put("isMutual", me != null && socialService.isMutual(me, id));
        m.put("followingCount", socialService.followingCount(id));
        m.put("followerCount", socialService.followerCount(id));
        m.put("iBlocked", me != null && socialService.isBlocked(me, id));
        m.put("blockedMe", me != null && socialService.iAmBlockedBy(me, id));
        return ApiResponse.ok(m);
    }

    @PostMapping("/{id}/block")
    public ApiResponse<Boolean> block(@PathVariable Long id, @AuthenticationPrincipal ForumUserPrincipal p) {
        boolean now = socialService.toggleBlock(p.getId(), id);
        return ApiResponse.ok(now, now ? "已拉黑" : "已解除拉黑");
    }

    @GetMapping("/{id}/blocks")
    public ApiResponse<PageResponse<UserDtos.AuthorSummary>> blocks(@PathVariable Long id,
            @RequestParam(defaultValue = "0") int page, @RequestParam(defaultValue = "20") int size,
            @AuthenticationPrincipal ForumUserPrincipal p) {
        if (p == null || !p.getId().equals(id)) {
            throw new com.forum.exception.BusinessException("无权查看", org.springframework.http.HttpStatus.FORBIDDEN);
        }
        return ApiResponse.ok(socialService.blockedList(id, page, size));
    }
}
