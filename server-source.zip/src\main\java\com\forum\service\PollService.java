package com.forum.service;

import com.forum.entity.Poll;
import com.forum.entity.PollOption;
import com.forum.entity.PollVote;
import com.forum.entity.Post;
import com.forum.exception.BusinessException;
import com.forum.repository.PollOptionRepository;
import com.forum.repository.PollRepository;
import com.forum.repository.PollVoteRepository;
import com.forum.repository.PostRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 帖子投票：创建投票、投票、结果查询。
 */
@Service
public class PollService {

    private final PostRepository postRepository;
    private final PollRepository pollRepo;
    private final PollOptionRepository optionRepo;
    private final PollVoteRepository voteRepo;

    public PollService(PostRepository postRepository,
                       PollRepository pollRepo,
                       PollOptionRepository optionRepo,
                       PollVoteRepository voteRepo) {
        this.postRepository = postRepository;
        this.pollRepo = pollRepo;
        this.optionRepo = optionRepo;
        this.voteRepo = voteRepo;
    }

    @Transactional
    public Map<String, Object> create(Long postId, String question, boolean multiple,
                                      List<String> options, java.time.LocalDateTime deadline, Long userId) {
        Post post = postRepository.findByIdAndDeletedFalse(postId)
                .orElseThrow(() -> BusinessException.notFound("帖子不存在或已删除"));
        if (!post.getAuthor().getId().equals(userId)) {
            throw BusinessException.forbidden("只有作者可为帖子创建投票");
        }
        if (question == null || question.isBlank()) throw new BusinessException("投票问题不能为空");
        if (options == null || options.size() < 2) throw new BusinessException("至少需要两个选项");

        pollRepo.deleteByPostId(postId);

        Poll poll = new Poll();
        poll.setPostId(postId);
        poll.setQuestion(question.trim());
        poll.setMultiple(multiple);
        poll.setDeadline(deadline);
        poll = pollRepo.save(poll);

        for (String opt : options) {
            if (opt == null || opt.isBlank()) continue;
            PollOption po = new PollOption();
            po.setPollId(poll.getId());
            po.setOptionText(opt.trim());
            po.setVoteCount(0);
            optionRepo.save(po);
        }
        return getResult(poll.getId(), userId);
    }

    @Transactional
    public Map<String, Object> vote(Long pollId, List<Long> optionIds, Long userId) {
        Poll poll = pollRepo.findById(pollId).orElseThrow(() -> BusinessException.notFound("投票不存在"));
        if (poll.getDeadline() != null && poll.getDeadline().isBefore(java.time.LocalDateTime.now())) {
            throw BusinessException.conflict("投票已截止");
        }
        if (optionIds == null || optionIds.isEmpty()) throw new BusinessException("请选择选项");
        if (!Boolean.TRUE.equals(poll.getMultiple()) && optionIds.size() > 1) {
            throw new BusinessException("该投票为单选，只能选择一个选项");
        }

        // 清除已投选项
        for (PollVote v : voteRepo.findByPollIdAndUserId(pollId, userId)) {
            optionRepo.findById(v.getOptionId()).ifPresent(opt -> {
                opt.setVoteCount(Math.max(0, opt.getVoteCount() - 1));
                optionRepo.save(opt);
            });
            voteRepo.delete(v);
        }

        for (Long optId : optionIds) {
            PollOption opt = optionRepo.findById(optId).orElseThrow(() -> BusinessException.notFound("选项不存在"));
            if (!opt.getPollId().equals(pollId)) throw BusinessException.forbidden("选项不属于该投票");
            PollVote v = new PollVote();
            v.setPollId(pollId);
            v.setUserId(userId);
            v.setOptionId(optId);
            voteRepo.save(v);
            opt.setVoteCount(opt.getVoteCount() + 1);
            optionRepo.save(opt);
        }
        return getResult(pollId, userId);
    }

    @Transactional(readOnly = true)
    public Map<String, Object> getResult(Long pollId, Long userId) {
        Poll poll = pollRepo.findById(pollId).orElseThrow(() -> BusinessException.notFound("投票不存在"));
        List<PollOption> options = optionRepo.findByPollIdOrderByIdAsc(pollId);
        List<Long> myVotes = voteRepo.findByPollIdAndUserId(pollId, userId)
                .stream().map(PollVote::getOptionId).toList();

        Map<String, Object> result = new HashMap<>();
        result.put("id", poll.getId());
        result.put("postId", poll.getPostId());
        result.put("question", poll.getQuestion());
        result.put("multiple", poll.getMultiple());
        result.put("deadline", poll.getDeadline());
        result.put("voted", !myVotes.isEmpty());
        result.put("myVotes", myVotes);

        int total = options.stream().mapToInt(PollOption::getVoteCount).sum();
        List<Map<String, Object>> optionViews = new ArrayList<>();
        for (PollOption opt : options) {
            Map<String, Object> o = new HashMap<>();
            o.put("id", opt.getId());
            o.put("text", opt.getOptionText());
            o.put("count", opt.getVoteCount());
            o.put("percent", total == 0 ? 0 : Math.round(opt.getVoteCount() * 100.0 / total));
            optionViews.add(o);
        }
        result.put("options", optionViews);
        result.put("totalVotes", total);
        return result;
    }
}
