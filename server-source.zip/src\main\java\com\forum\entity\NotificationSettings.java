package com.forum.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Index;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

/**
 * 用户通知偏好：每类通知可独立开关。默认全部开启。
 */
@Entity
@Table(
        name = "notification_settings",
        uniqueConstraints = @UniqueConstraint(columnNames = {"user_id"}),
        indexes = @Index(name = "idx_notif_setting_user", columnList = "user_id")
)
public class NotificationSettings extends BaseEntity {

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(name = "enable_announcement", nullable = false)
    private Boolean enableAnnouncement = true;

    @Column(name = "enable_moderation", nullable = false)
    private Boolean enableModeration = true;

    @Column(name = "enable_comment", nullable = false)
    private Boolean enableComment = true;

    @Column(name = "enable_like", nullable = false)
    private Boolean enableLike = true;

    @Column(name = "enable_device_login", nullable = false)
    private Boolean enableDeviceLogin = true;

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Boolean getEnableAnnouncement() {
        return enableAnnouncement;
    }

    public void setEnableAnnouncement(Boolean enableAnnouncement) {
        this.enableAnnouncement = enableAnnouncement;
    }

    public Boolean getEnableModeration() {
        return enableModeration;
    }

    public void setEnableModeration(Boolean enableModeration) {
        this.enableModeration = enableModeration;
    }

    public Boolean getEnableComment() {
        return enableComment;
    }

    public void setEnableComment(Boolean enableComment) {
        this.enableComment = enableComment;
    }

    public Boolean getEnableLike() {
        return enableLike;
    }

    public void setEnableLike(Boolean enableLike) {
        this.enableLike = enableLike;
    }

    public Boolean getEnableDeviceLogin() {
        return enableDeviceLogin;
    }

    public void setEnableDeviceLogin(Boolean enableDeviceLogin) {
        this.enableDeviceLogin = enableDeviceLogin;
    }
}
