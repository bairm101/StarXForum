package com.forum.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Index;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

/**
 * 用户投票记录。
 */
@Entity
@Table(name = "poll_votes",
        uniqueConstraints = @UniqueConstraint(columnNames = {"poll_id", "user_id", "option_id"}),
        indexes = @Index(name = "idx_vote_poll_user", columnList = "poll_id,user_id"))
public class PollVote extends BaseEntity {

    @Column(name = "poll_id", nullable = false)
    private Long pollId;

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(name = "option_id", nullable = false)
    private Long optionId;

    public Long getPollId() { return pollId; }
    public void setPollId(Long v) { this.pollId = v; }
    public Long getUserId() { return userId; }
    public void setUserId(Long v) { this.userId = v; }
    public Long getOptionId() { return optionId; }
    public void setOptionId(Long v) { this.optionId = v; }
}
