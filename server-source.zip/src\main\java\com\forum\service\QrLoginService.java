package com.forum.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.forum.dto.QrLoginDtos;
import com.forum.entity.User;
import com.forum.exception.BusinessException;
import com.forum.security.JwtService;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.security.MessageDigest;
import java.time.Duration;
import java.util.Map;
import java.util.UUID;

@Service
public class QrLoginService {
    private static final Duration TTL = Duration.ofMinutes(2);
    private final StringRedisTemplate redis;
    private final UserService users;
    private final JwtService jwt;
    private final ObjectMapper json = new ObjectMapper();

    public QrLoginService(StringRedisTemplate redis, UserService users, JwtService jwt) {
        this.redis = redis; this.users = users; this.jwt = jwt;
    }

    public QrLoginDtos.Create create() {
        String session = UUID.randomUUID().toString();
        String token = UUID.randomUUID().toString().replace("-", "") + UUID.randomUUID().toString().replace("-", "");
        redis.opsForValue().set(key(session), encode(Map.of("token", sha(token), "status", "PENDING")), TTL);
        String payload = "forum://qr-login?session=" + session + "&token=" + token;
        return new QrLoginDtos.Create(session, token, payload, TTL.toSeconds());
    }

    public QrLoginDtos.Status status(String session, String token) {
        Map<String, String> state = read(session, token);
        if ("APPROVED".equals(state.get("status"))) {
            Long userId = Long.valueOf(state.get("userId"));
            User user = users.requireUser(userId);
            redis.delete(key(session));
            return new QrLoginDtos.Status("APPROVED", jwt.generateToken(user.getId(), user.getUsername(), user.getRole().name()), user.getDisplayName());
        }
        return new QrLoginDtos.Status("PENDING", null, null);
    }

    public void approve(String session, String token, Long userId) {
        Map<String, String> state = read(session, token);
        if (!"PENDING".equals(state.get("status"))) throw BusinessException.conflict("二维码已处理或已过期");
        state.put("status", "APPROVED"); state.put("userId", String.valueOf(userId));
        redis.opsForValue().set(key(session), encode(state), TTL);
    }

    private Map<String, String> read(String session, String token) {
        String raw = redis.opsForValue().get(key(session));
        if (raw == null) throw BusinessException.conflict("二维码已过期");
        try {
            Map<String, String> state = json.readValue(raw, Map.class);
            if (!MessageDigest.isEqual(state.get("token").getBytes(), sha(token).getBytes())) throw BusinessException.forbidden("二维码令牌无效");
            return state;
        } catch (BusinessException e) { throw e; }
        catch (Exception e) { throw BusinessException.conflict("二维码状态无效"); }
    }

    private String key(String session) { return "qr:login:" + session; }
    private String encode(Map<String, String> state) { try { return json.writeValueAsString(state); } catch (Exception e) { throw new IllegalStateException(e); } }
    private String sha(String value) { try { byte[] b=MessageDigest.getInstance("SHA-256").digest(value.getBytes(java.nio.charset.StandardCharsets.UTF_8)); StringBuilder s=new StringBuilder(); for(byte x:b)s.append(String.format("%02x",x)); return s.toString(); } catch(Exception e){throw new IllegalStateException(e);} }
}
