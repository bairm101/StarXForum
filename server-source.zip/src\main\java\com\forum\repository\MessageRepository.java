package com.forum.repository;

import com.forum.entity.Message;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface MessageRepository extends JpaRepository<Message, Long> {

    /**
     * 取某会话的消息（排除当前用户已删除的）。
     */
    @Query("""
            SELECT m FROM Message m
            WHERE m.conversationKey = :key
              AND ((m.sender.id = :uid AND m.deletedBySender = false)
                OR (m.recipient.id = :uid AND m.deletedByRecipient = false))
            ORDER BY m.createdAt DESC
            """)
    Page<Message> findConversation(@Param("key") String conversationKey,
                                   @Param("uid") Long userId,
                                   Pageable pageable);

    /**
     * 会话列表：取每个会话的最新一条消息 id。
     */
    @Query(value = """
            SELECT m.* FROM messages m
            INNER JOIN (
              SELECT conversation_key, MAX(id) AS max_id
              FROM messages
              WHERE (sender_id = :uid AND deleted_by_sender = 0)
                 OR (recipient_id = :uid AND deleted_by_recipient = 0)
              GROUP BY conversation_key
            ) t ON m.id = t.max_id
            ORDER BY m.created_at DESC
            """,
            countQuery = """
            SELECT COUNT(DISTINCT conversation_key) FROM messages
            WHERE (sender_id = :uid AND deleted_by_sender = 0)
               OR (recipient_id = :uid AND deleted_by_recipient = 0)
            """,
            nativeQuery = true)
    Page<Message> findConversationSummaries(@Param("uid") Long userId, Pageable pageable);

    long countByRecipientIdAndReadFalseAndDeletedByRecipientFalse(Long recipientId);

    /** 统计某会话中某发送者当天消息数（用于单向关注每日限条） */
    long countByConversationKeyAndSenderIdAndCreatedAtAfter(String conversationKey, Long senderId,
                                                            java.time.LocalDateTime after);

    @Modifying
    @Query("""
            UPDATE Message m SET m.read = true
            WHERE m.conversationKey = :key AND m.recipient.id = :uid AND m.read = false
            """)
    int markConversationRead(@Param("key") String conversationKey, @Param("uid") Long userId);

    List<Message> findByConversationKeyAndRecipientIdAndReadFalse(String conversationKey, Long recipientId);

    @Modifying
    @Query("UPDATE Message m SET m.read = true WHERE m.recipient.id = :uid AND m.read = false")
    int markAllRead(@Param("uid") Long userId);

    @Modifying
    @Query("UPDATE Message m SET m.deletedBySender = true WHERE m.conversationKey = :key AND m.sender.id = :uid")
    int softDeleteBySender(@Param("key") String conversationKey, @Param("uid") Long userId);

    @Modifying
    @Query("UPDATE Message m SET m.deletedByRecipient = true WHERE m.conversationKey = :key AND m.recipient.id = :uid")
    int softDeleteByRecipient(@Param("key") String conversationKey, @Param("uid") Long userId);

    long count();
}
