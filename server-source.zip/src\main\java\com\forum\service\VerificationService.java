package com.forum.service;

import com.forum.dto.AdminDtos;
import com.forum.entity.SiteSettings;
import com.forum.exception.BusinessException;
import com.forum.repository.SiteSettingsRepository;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.util.Properties;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

@Service
public class VerificationService {
    private final StringRedisTemplate redis;
    private final SiteSettingsRepository settingsRepository;

    public VerificationService(StringRedisTemplate redis, SiteSettingsRepository settingsRepository) {
        this.redis = redis;
        this.settingsRepository = settingsRepository;
    }

    public AdminDtos.ChallengeView createChallenge(String purpose) {
        String p = purpose == null ? "POST" : purpose.toUpperCase();
        int a = ThreadLocalRandom.current().nextInt(0, 11);
        int b = ThreadLocalRandom.current().nextInt(1, 11);
        String op = new String[]{"+", "-", "×", "÷"}[ThreadLocalRandom.current().nextInt(4)];
        int answer;
        if ("-".equals(op) && a < b) { int t = a; a = b; b = t; }
        if ("÷".equals(op)) { a = a * b; answer = a / b; }
        else if ("+".equals(op)) answer = a + b;
        else if ("-".equals(op)) answer = a - b;
        else answer = a * b;
        String id = UUID.randomUUID().toString();
        redis.opsForValue().set("verify:math:" + id, p + ":" + answer, Duration.ofMinutes(5));
        return new AdminDtos.ChallengeView(id, a + " " + op + " " + b + " = ?", p, 300);
    }

    public void requireChallenge(String purpose, String id, Integer answer) {
        SiteSettings s = settingsRepository.findById(1L).orElseGet(SiteSettings::new);
        boolean enabled = switch (purpose.toUpperCase()) {
            case "EMAIL" -> Boolean.TRUE.equals(s.getArithmeticEmailEnabled());
            case "COMMENT" -> Boolean.TRUE.equals(s.getArithmeticCommentEnabled());
            default -> Boolean.TRUE.equals(s.getArithmeticPostEnabled());
        };
        if (!enabled) return;
        if (id == null || answer == null) throw new BusinessException("请完成算术验证");
        String key = "verify:math:" + id;
        String stored = redis.opsForValue().get(key);
        redis.delete(key);
        if (stored == null || !stored.equals(purpose.toUpperCase() + ":" + answer)) {
            throw new BusinessException("算术验证错误或已过期");
        }
    }

    public void sendEmailCode(AdminDtos.EmailCodeRequest req) {
        requireChallenge("EMAIL", req.challengeId(), req.answer());
        SiteSettings s = settingsRepository.findById(1L).orElseGet(SiteSettings::new);
        if (!Boolean.TRUE.equals(s.getSmtpEnabled())) throw new BusinessException("邮件服务未开启");
        if (s.getSmtpUsername() == null || s.getSmtpPassword() == null) throw new BusinessException("SMTP 配置不完整");
        enforceCooldown("verify:email:" + req.email().toLowerCase());
        String code = String.valueOf(ThreadLocalRandom.current().nextInt(100000, 1000000));
        JavaMailSenderImpl sender = new JavaMailSenderImpl();
        sender.setHost(s.getSmtpHost()); sender.setPort(s.getSmtpPort());
        sender.setUsername(s.getSmtpUsername()); sender.setPassword(s.getSmtpPassword());
        Properties p = sender.getJavaMailProperties();
        p.put("mail.smtp.auth", "true");
        p.put("mail.smtp.ssl.enable", String.valueOf(Boolean.TRUE.equals(s.getSmtpSsl())));
        SimpleMailMessage msg = new SimpleMailMessage();
        msg.setFrom(s.getSmtpUsername()); msg.setTo(req.email()); msg.setSubject(s.getSiteName() + " 注册验证码");
        msg.setText("您的验证码是：" + code + "，5分钟内有效。若非本人操作请忽略。");
        sender.send(msg);
        redis.opsForValue().set("verify:email:" + req.email().toLowerCase(), code, Duration.ofMinutes(5));
    }

    public boolean verifyEmailCode(String email, String code) {
        if (email == null || code == null) return false;
        String key = "verify:email:" + email.toLowerCase();
        String stored = redis.opsForValue().get(key);
        if (code.equals(stored)) { redis.delete(key); return true; }
        return false;
    }

    /** 通用：按 Redis 键发送验证码到指定邮箱。text 为正文前缀，验证码自动附加。 */
    public void sendRawCode(String email, String subject, String text, String redisKey) {
        SiteSettings s = settingsRepository.findById(1L).orElseGet(SiteSettings::new);
        if (!Boolean.TRUE.equals(s.getSmtpEnabled())) throw new BusinessException("邮件服务未开启");
        if (s.getSmtpUsername() == null || s.getSmtpPassword() == null) throw new BusinessException("SMTP 配置不完整");
        enforceCooldown(redisKey);
        String code = String.valueOf(ThreadLocalRandom.current().nextInt(100000, 1000000));
        JavaMailSenderImpl sender = new JavaMailSenderImpl();
        sender.setHost(s.getSmtpHost()); sender.setPort(s.getSmtpPort());
        sender.setUsername(s.getSmtpUsername()); sender.setPassword(s.getSmtpPassword());
        Properties p = sender.getJavaMailProperties();
        p.put("mail.smtp.auth", "true");
        p.put("mail.smtp.ssl.enable", String.valueOf(Boolean.TRUE.equals(s.getSmtpSsl())));
        SimpleMailMessage msg = new SimpleMailMessage();
        msg.setFrom(s.getSmtpUsername()); msg.setTo(email); msg.setSubject(s.getSiteName() + " " + subject);
        msg.setText(text + code + "，5分钟内有效。若非本人操作请忽略。");
        sender.send(msg);
        redis.opsForValue().set(redisKey, code, Duration.ofMinutes(5));
    }

    /** 通用：按 Redis 键校验验证码。 */
    public boolean verifyCode(String redisKey, String code) {
        if (code == null) return false;
        String stored = redis.opsForValue().get(redisKey);
        if (code.equals(stored)) { redis.delete(redisKey); return true; }
        return false;
    }

    /** 发验证码 60 秒冷却，防止频繁发送。作用域跟随验证码存储键。 */
    private void enforceCooldown(String redisKey) {
        String cdKey = "sendcd:" + redisKey;
        if (Boolean.TRUE.equals(redis.hasKey(cdKey))) {
            throw new BusinessException("发送太频繁，请 60 秒后再试");
        }
        redis.opsForValue().set(cdKey, "1", Duration.ofSeconds(60));
    }
}
