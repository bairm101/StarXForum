package com.forum.repository;

import com.forum.entity.Board;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface BoardRepository extends JpaRepository<Board, Long> {

    List<Board> findAllByVisibleTrueOrderBySortOrderAscIdAsc();

    List<Board> findAllByOrderBySortOrderAscIdAsc();

    Optional<Board> findByName(String name);

    boolean existsByName(String name);

    @Modifying
    @Query("UPDATE Board b SET b.postCount = b.postCount + :delta WHERE b.id = :id")
    void addPostCount(@Param("id") Long id, @Param("delta") int delta);
}
