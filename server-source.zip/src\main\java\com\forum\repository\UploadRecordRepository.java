package com.forum.repository;

import com.forum.entity.UploadRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface UploadRecordRepository extends JpaRepository<UploadRecord, Long> {
    @Query("SELECT COALESCE(SUM(u.sizeBytes), 0) FROM UploadRecord u WHERE u.userId = :userId")
    Long usedBytes(@Param("userId") Long userId);
    java.util.Optional<UploadRecord> findByPublicCode(String publicCode);
    java.util.Optional<UploadRecord> findByPath(String path);
    java.util.List<UploadRecord> findByUserId(Long userId);
}
