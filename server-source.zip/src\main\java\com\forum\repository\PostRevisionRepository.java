package com.forum.repository;

import com.forum.entity.PostRevision;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PostRevisionRepository extends JpaRepository<PostRevision, Long> {
    List<PostRevision> findByPostIdOrderByCreatedAtDesc(Long postId);
    void deleteByPostId(Long postId);
}
