package com.forum.service;

import com.forum.repository.UploadRecordRepository;
import org.springframework.stereotype.Service;

@Service
public class MediaUrlService {
    private final UploadRecordRepository records;
    public MediaUrlService(UploadRecordRepository records) { this.records = records; }

    /** 将历史绝对上传地址、/uploads 路径统一转换为不暴露服务器地址的随机媒体路径。 */
    public String publicUrl(String raw) {
        if (raw == null || raw.isBlank()) return raw;
        if (raw.matches("[A-Za-z0-9]{12}")) return "/media/" + raw;
        if (raw.contains("/media/")) return raw.substring(raw.indexOf("/media/"));
        String path = raw;
        int uploads = path.indexOf("/uploads/");
        if (uploads >= 0) path = path.substring(uploads);
        if (!path.startsWith("/uploads/")) return raw;
        return records.findByPath(path).map(x -> "/media/" + x.getPublicCode()).orElse(raw);
    }

    public String normalizeContent(String content) {
        if (content == null) return null;
        var pattern = java.util.regex.Pattern.compile("(https?://[^\\s)]+)?(/(?:uploads|media)/[^\\s)]+)");
        var matcher = pattern.matcher(content);
        var out = new StringBuffer();
        while (matcher.find()) matcher.appendReplacement(out, java.util.regex.Matcher.quoteReplacement(publicUrl(matcher.group(0))));
        matcher.appendTail(out);
        return out.toString();
    }
}
