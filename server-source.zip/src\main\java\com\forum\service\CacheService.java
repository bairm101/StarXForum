package com.forum.service;

import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.util.concurrent.TimeUnit;
import java.util.List;

/**
 * Redis 辅助封装：原子去重计数、简单缓存。
 * Redis 故障时优雅降级（返回可继续执行的默认值），不影响主流程。
 */
@Service
public class CacheService {

    private final StringRedisTemplate redis;
    private volatile boolean redisAvailable = true;

    public CacheService(StringRedisTemplate redis) {
        this.redis = redis;
    }

    /**
     * 若键不存在则设置并返回 true（首次），否则返回 false（去重）。
     */
    public boolean markOnce(String key, Duration ttl) {
        if (!redisAvailable) {
            return true;
        }
        try {
            return Boolean.TRUE.equals(redis.opsForValue()
                    .setIfAbsent(key, "1", ttl.toSeconds(), TimeUnit.SECONDS));
        } catch (Exception e) {
            redisAvailable = false;
            return true;
        }
    }

    /**
     * 每 X 秒只放行一次，用于点赞/访问频率限制。返回是否放行。
     */
    public boolean throttle(String key, Duration interval) {
        if (!redisAvailable) {
            return true;
        }
        try {
            Long n = redis.opsForValue().increment(key);
            if (n != null && n == 1) {
                redis.expire(key, interval);
                return true;
            }
            return false;
        } catch (Exception e) {
            redisAvailable = false;
            return true;
        }
    }

    /** 只清理本应用使用的 Redis 前缀，避免误伤同机其他应用。 */
    public long clearForumKeys() {
        List<String> patterns = List.of("post:*", "verify:*", "rl:*", "sens:*", "qr:*", "device:*", "emailchange:*");
        long count = 0;
        for (String pattern : patterns) {
            var keys = redis.keys(pattern);
            if (keys != null && !keys.isEmpty()) {
                redis.delete(keys);
                count += keys.size();
            }
        }
        return count;
    }
}
